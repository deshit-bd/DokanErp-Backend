import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../dashboard/screens/dashboard_screen.dart';
import '../../reports/screens/reports_screens.dart';
import '../../settings/screens/settings_screens.dart';
import '../../pos/screens/pos_screens.dart';
import '../../../app/dokan_app_providers.dart';
import '../../../shared/widgets/dokan_placeholder_screen.dart';
import '../../notifications/screens/notification_center_screen.dart';

String _bnDigits(String input) {
  const map = <String, String>{
    '0': '০',
    '1': '১',
    '2': '২',
    '3': '৩',
    '4': '৪',
    '5': '৫',
    '6': '৬',
    '7': '৭',
    '8': '৮',
    '9': '৯',
  };
  return input.split('').map((char) => map[char] ?? char).join();
}

String _latinDigits(String input) {
  const map = <String, String>{
    '০': '0',
    '১': '1',
    '২': '2',
    '৩': '3',
    '৪': '4',
    '৫': '5',
    '৬': '6',
    '৭': '7',
    '৮': '8',
    '৯': '9',
  };
  return input.split('').map((char) => map[char] ?? char).join();
}

String _currency(int value) => '৳${_bnDigits(value.toString())}';

Color _stockStatusColor(int stock, int threshold) {
  if (stock <= 0) {
    return const Color(0xFFD43B3B);
  }
  if (stock < threshold) {
    return const Color(0xFFF49B1A);
  }
  return const Color(0xFF0C8C67);
}

Color _stockStatusBackground(int stock, int threshold) {
  if (stock <= 0) {
    return const Color(0xFFFDEEEF);
  }
  if (stock < threshold) {
    return const Color(0xFFFFF4E0);
  }
  return const Color(0xFFE5F7ED);
}

String _stockStatusLabel(int stock, int threshold) {
  if (stock <= 0) return 'স্টক নেই';
  if (stock < threshold) return 'কম স্টক';
  return 'পর্যাপ্ত স্টক';
}

String _emojiForCategory(String category) {
  switch (category) {
    case 'চাল-ডাল':
      return '🌾';
    case 'তেল-মসলা':
      return '🛢️';
    case 'সাবান':
      return '🧼';
    case 'পানীয়':
      return '🥤';
    case 'বিস্কুট':
      return '🍪';
    default:
      return '📦';
  }
}

List<String> _productCategoryOptions(Iterable<String> categories) {
  final options = categories
      .where((category) => category != DokanCategoryNotifier.uncategorized && category != 'সব')
      .toList(growable: false);
  if (options.isEmpty) {
    return <String>[DokanCategoryNotifier.uncategorized];
  }
  return options;
}

enum _ProductSortMode { name, lowStock, highestSales }

enum _LowStockAlertFilter { all, lowStock, outOfStock }

class DokanCatalogProduct {
  const DokanCatalogProduct({
    required this.name,
    required this.barcode,
    required this.category,
    required this.emoji,
    this.brand = '',
    this.unit = '',
    this.imageLabel = '',
    required this.salePrice,
    required this.purchasePrice,
    required this.stock,
    required this.lowStockThreshold,
    required this.salesCount,
    required this.packInfo,
  });

  final String name;
  final String barcode;
  final String category;
  final String emoji;
  final String brand;
  final String unit;
  final String imageLabel;
  final int salePrice;
  final int purchasePrice;
  final int stock;
  final int lowStockThreshold;
  final int salesCount;
  final String packInfo;

  DokanCatalogProduct copyWith({
    String? name,
    String? barcode,
    String? category,
    String? emoji,
    String? brand,
    String? unit,
    String? imageLabel,
    int? salePrice,
    int? purchasePrice,
    int? stock,
    int? lowStockThreshold,
    int? salesCount,
    String? packInfo,
  }) {
    return DokanCatalogProduct(
      name: name ?? this.name,
      barcode: barcode ?? this.barcode,
      category: category ?? this.category,
      emoji: emoji ?? this.emoji,
      brand: brand ?? this.brand,
      unit: unit ?? this.unit,
      imageLabel: imageLabel ?? this.imageLabel,
      salePrice: salePrice ?? this.salePrice,
      purchasePrice: purchasePrice ?? this.purchasePrice,
      stock: stock ?? this.stock,
      lowStockThreshold: lowStockThreshold ?? this.lowStockThreshold,
      salesCount: salesCount ?? this.salesCount,
      packInfo: packInfo ?? this.packInfo,
    );
  }

  String get stockLabel {
    if (stock <= 0) {
      return 'স্টক নেই';
    }
    if (stock <= lowStockThreshold) {
      return 'কম স্টক';
    }
    return 'পর্যাপ্ত স্টক';
  }

  Color get stockColor {
    if (stock <= 0) {
      return const Color(0xFFD43B3B);
    }
    if (stock <= lowStockThreshold) {
      return const Color(0xFFF49B1A);
    }
    return const Color(0xFF0C8C67);
  }

  Color get stockBackground {
    if (stock <= 0) {
      return const Color(0xFFFDEEEF);
    }
    if (stock <= lowStockThreshold) {
      return const Color(0xFFFFF4E0);
    }
    return const Color(0xFFE5F7ED);
  }
}

class _ProductInventoryState {
  const _ProductInventoryState({
    required this.stock,
    required this.purchasePrice,
    required this.salePrice,
    required this.historyEntries,
  });

  final int stock;
  final int purchasePrice;
  final int salePrice;
  final List<_ProductHistoryEntry> historyEntries;

  _ProductInventoryState copyWith({
    int? stock,
    int? purchasePrice,
    int? salePrice,
    List<_ProductHistoryEntry>? historyEntries,
  }) {
    return _ProductInventoryState(
      stock: stock ?? this.stock,
      purchasePrice: purchasePrice ?? this.purchasePrice,
      salePrice: salePrice ?? this.salePrice,
      historyEntries: historyEntries ?? this.historyEntries,
    );
  }
}

final Map<String, _ProductInventoryState> _productInventoryStore = <String, _ProductInventoryState>{};

class DokanInventoryCatalogNotifier extends Notifier<List<DokanCatalogProduct>> {
  @override
  List<DokanCatalogProduct> build() {
    return List<DokanCatalogProduct>.from(_DokanProductListScreenState._seedProducts);
  }

  void addProduct(DokanCatalogProduct product) {
    state = <DokanCatalogProduct>[product, ...state.where((item) => item.barcode != product.barcode)];
    _saveInventory(
      product,
      _ProductInventoryState(
        stock: product.stock,
        purchasePrice: product.purchasePrice,
        salePrice: product.salePrice,
        historyEntries: _historyFor(product),
      ),
    );
  }

  void reassignCategory(String oldCategory, String newCategory) {
    if (oldCategory == newCategory) return;
    state = [
      for (final item in state)
        if (item.category == oldCategory) item.copyWith(category: newCategory) else item,
    ];
  }

  void applyStockAdd(
    DokanCatalogProduct product, {
    required int addAmount,
    required int purchasePrice,
    required String referenceText,
  }) {
    final current = _inventoryFor(product);
    final updatedProduct = product.copyWith(
      stock: product.stock + addAmount,
      purchasePrice: purchasePrice,
    );
    final history = <_ProductHistoryEntry>[
      _ProductHistoryEntry(
        label: 'স্টক যোগ',
        amount: '+${_bnDigits(addAmount.toString())}টি',
        timeLabel: 'আজ • ${referenceText.isEmpty ? 'চালান' : 'চালান #$referenceText'}',
        color: const Color(0xFF0C8C67),
        timestamp: DateTime.now(),
        kind: DokanStockMovementType.purchase,
      ),
      ...current.historyEntries,
    ];
    _saveInventory(
      updatedProduct,
      current.copyWith(
        stock: updatedProduct.stock,
        purchasePrice: purchasePrice,
        historyEntries: history,
      ),
    );
    state = [
      for (final item in state) if (item.barcode == product.barcode) updatedProduct else item,
    ];
  }

  void applyStockReduce(
    DokanCatalogProduct product, {
    required int amount,
    required String reason,
  }) {
    final current = _inventoryFor(product);
    final updatedProduct = product.copyWith(stock: (product.stock - amount).clamp(0, product.stock));
    final history = <_ProductHistoryEntry>[
      _ProductHistoryEntry(
        label: 'স্টক কমানো • $reason',
        amount: '-${_bnDigits(amount.toString())}টি',
        timeLabel: 'আজ • $reason',
        color: const Color(0xFFF49B1A),
        timestamp: DateTime.now(),
        kind: DokanStockMovementType.loss,
      ),
      ...current.historyEntries,
    ];
    _saveInventory(
      updatedProduct,
      current.copyWith(
        stock: updatedProduct.stock,
        historyEntries: history,
      ),
    );
    state = [
      for (final item in state) if (item.barcode == product.barcode) updatedProduct else item,
    ];
  }

  void applyPriceChange(
    DokanCatalogProduct product, {
    required int purchasePrice,
    required int salePrice,
  }) {
    final current = _inventoryFor(product);
    final updatedProduct = product.copyWith(
      purchasePrice: purchasePrice,
      salePrice: salePrice,
    );
    final history = <_ProductHistoryEntry>[
      _ProductHistoryEntry(
        label: 'দাম পরিবর্তন',
        amount: 'ক্রয় ${_currency(purchasePrice)} → বিক্রয় ${_currency(salePrice)}',
        timeLabel: 'আজ • মূল্য হালনাগাদ',
        color: const Color(0xFF0C8C67),
        timestamp: DateTime.now(),
        kind: DokanStockMovementType.manual,
      ),
      ...current.historyEntries,
    ];
    _saveInventory(
      updatedProduct,
      current.copyWith(
        purchasePrice: purchasePrice,
        salePrice: salePrice,
        historyEntries: history,
      ),
    );
    state = [
      for (final item in state) if (item.barcode == product.barcode) updatedProduct else item,
    ];
  }
}

final dokanInventoryCatalogProvider =
    NotifierProvider<DokanInventoryCatalogNotifier, List<DokanCatalogProduct>>(DokanInventoryCatalogNotifier.new);

final lowStockProvider = Provider<List<DokanCatalogProduct>>((ref) {
  final products = ref.watch(dokanInventoryCatalogProvider);
  final threshold = ref.watch(stockThresholdProvider);
  return products.where((product) => product.stock > 0 && product.stock < threshold).toList(growable: false);
});

class _LowStockFilterNotifier extends Notifier<_LowStockAlertFilter> {
  @override
  _LowStockAlertFilter build() => _LowStockAlertFilter.all;

  void setFilter(_LowStockAlertFilter filter) {
    state = filter;
  }
}

final dokanLowStockFilterProvider =
    NotifierProvider<_LowStockFilterNotifier, _LowStockAlertFilter>(_LowStockFilterNotifier.new);

_ProductInventoryState _inventoryFallback(DokanCatalogProduct product) {
  return _ProductInventoryState(
    stock: product.stock,
    purchasePrice: product.purchasePrice,
    salePrice: product.salePrice,
    historyEntries: _historyFor(product),
  );
}

_ProductInventoryState _inventoryFor(DokanCatalogProduct product) {
  return _productInventoryStore.putIfAbsent(product.barcode, () => _inventoryFallback(product));
}

void _saveInventory(DokanCatalogProduct product, _ProductInventoryState state) {
  _productInventoryStore[product.barcode] = state;
}

// ignore: unused_element
void _applyStockAdd(
  DokanCatalogProduct product, {
  required int addAmount,
  required int purchasePrice,
  required String referenceText,
}) {
  final current = _inventoryFor(product);
  final history = <_ProductHistoryEntry>[
    _ProductHistoryEntry(
      label: 'স্টক যোগ',
      amount: '+${_bnDigits(addAmount.toString())}টি',
      timeLabel: 'আজ • ${referenceText.isEmpty ? 'চালান' : 'চালান #$referenceText'}',
      color: const Color(0xFF0C8C67),
      timestamp: DateTime.now(),
      kind: DokanStockMovementType.purchase,
    ),
    ...current.historyEntries,
  ];
  _saveInventory(
    product,
    current.copyWith(
      stock: current.stock + addAmount,
      purchasePrice: purchasePrice,
      historyEntries: history,
    ),
  );
}

// ignore: unused_element
void _applyStockReduce(
  DokanCatalogProduct product, {
  required int amount,
  required String reason,
}) {
  final current = _inventoryFor(product);
  final history = <_ProductHistoryEntry>[
    _ProductHistoryEntry(
      label: 'স্টক কমানো • $reason',
      amount: '-${_bnDigits(amount.toString())}টি',
      timeLabel: 'আজ • $reason',
      color: const Color(0xFFF49B1A),
      timestamp: DateTime.now(),
      kind: DokanStockMovementType.loss,
    ),
    ...current.historyEntries,
  ];
  _saveInventory(
    product,
    current.copyWith(
      stock: (current.stock - amount).clamp(0, current.stock),
      historyEntries: history,
    ),
  );
}

// ignore: unused_element
void _applyPriceChange(
  DokanCatalogProduct product, {
  required int purchasePrice,
  required int salePrice,
}) {
  final current = _inventoryFor(product);
  final history = <_ProductHistoryEntry>[
    _ProductHistoryEntry(
      label: 'দাম পরিবর্তন',
      amount: 'ক্রয় ${_currency(purchasePrice)} → বিক্রয় ${_currency(salePrice)}',
      timeLabel: 'আজ • মূল্য হালনাগাদ',
      color: const Color(0xFF0C8C67),
      timestamp: DateTime.now(),
      kind: DokanStockMovementType.manual,
    ),
    ...current.historyEntries,
  ];
  _saveInventory(
    product,
    current.copyWith(
      purchasePrice: purchasePrice,
      salePrice: salePrice,
      historyEntries: history,
    ),
  );
}

enum DokanStockMovementType { sale, purchase, loss, returnItem, manual }

enum DokanStockLedgerFilter { all, today, yesterday, thisWeek, thisMonth }

class DokanStockLedgerEntry {
  const DokanStockLedgerEntry({
    required this.type,
    required this.typeLabel,
    required this.productName,
    required this.category,
    required this.timestamp,
    required this.delta,
    required this.stockSnapshot,
    required this.color,
    required this.icon,
    required this.note,
  });

  final DokanStockMovementType type;
  final String typeLabel;
  final String productName;
  final String category;
  final DateTime timestamp;
  final int delta;
  final int stockSnapshot;
  final Color color;
  final IconData icon;
  final String note;
}

class DokanStockLedgerSummary {
  const DokanStockLedgerSummary({
    required this.totalSales,
    required this.todayChange,
    required this.totalPurchase,
  });

  final int totalSales;
  final int todayChange;
  final int totalPurchase;
}

class _StockLedgerFilterNotifier extends Notifier<DokanStockLedgerFilter> {
  @override
  DokanStockLedgerFilter build() => DokanStockLedgerFilter.all;

  void setFilter(DokanStockLedgerFilter filter) {
    state = filter;
  }
}

final stockLedgerFilterProvider =
    NotifierProvider<_StockLedgerFilterNotifier, DokanStockLedgerFilter>(_StockLedgerFilterNotifier.new);

final stockLedgerProvider = Provider<List<DokanStockLedgerEntry>>((ref) {
  final products = ref.watch(dokanInventoryCatalogProvider);
  final ledger = <DokanStockLedgerEntry>[];

  for (final product in products) {
    final inventory = _inventoryFor(product);
    final history = List<_ProductHistoryEntry>.from(inventory.historyEntries);
    if (history.isEmpty) {
      continue;
    }

    final orderedHistory = history.reversed.toList(growable: false);
    final totalDelta = orderedHistory.fold<int>(0, (sum, entry) => sum + _historyDelta(entry));
    var snapshot = product.stock - totalDelta;
    if (snapshot < 0) {
      snapshot = 0;
    }

    for (var index = 0; index < orderedHistory.length; index++) {
      final entry = orderedHistory[index];
      final delta = _historyDelta(entry);
      snapshot += delta;
      ledger.add(
        DokanStockLedgerEntry(
          type: _historyType(entry),
          typeLabel: _historyTypeLabel(entry),
          productName: product.name,
          category: product.category,
          timestamp: _historyTimestamp(entry, index),
          delta: delta,
          stockSnapshot: snapshot,
          color: entry.color,
          icon: _historyIcon(entry),
          note: entry.timeLabel,
        ),
      );
    }
  }

  ledger.sort((a, b) => b.timestamp.compareTo(a.timestamp));
  return ledger;
});

final filteredLogProvider = Provider<List<DokanStockLedgerEntry>>((ref) {
  final filter = ref.watch(stockLedgerFilterProvider);
  final logs = ref.watch(stockLedgerProvider);
  if (filter == DokanStockLedgerFilter.all) {
    return logs;
  }

  final now = DateTime.now();
  final today = DateUtils.dateOnly(now);
  final yesterday = DateUtils.dateOnly(now.subtract(const Duration(days: 1)));
  final startOfWeek = DateUtils.dateOnly(now.subtract(Duration(days: now.weekday - 1)));
  final startOfMonth = DateTime(now.year, now.month, 1);

  return logs.where((entry) {
    final entryDate = DateUtils.dateOnly(entry.timestamp);
    switch (filter) {
      case DokanStockLedgerFilter.today:
        return entryDate == today;
      case DokanStockLedgerFilter.yesterday:
        return entryDate == yesterday;
      case DokanStockLedgerFilter.thisWeek:
        return !entryDate.isBefore(startOfWeek);
      case DokanStockLedgerFilter.thisMonth:
        return !entryDate.isBefore(startOfMonth);
      case DokanStockLedgerFilter.all:
        return true;
    }
  }).toList(growable: false);
});

final stockSummaryProvider = Provider<DokanStockLedgerSummary>((ref) {
  final logs = ref.watch(stockLedgerProvider);
  final today = DateUtils.dateOnly(DateTime.now());
  var totalSales = 0;
  var todayChange = 0;
  var totalPurchase = 0;

  for (final entry in logs) {
    if (entry.type == DokanStockMovementType.sale) {
      totalSales += entry.delta.abs();
    }
    if (entry.type == DokanStockMovementType.purchase) {
      totalPurchase += entry.delta.abs();
    }
    if (DateUtils.dateOnly(entry.timestamp) == today) {
      todayChange += entry.delta;
    }
  }

  return DokanStockLedgerSummary(
    totalSales: totalSales,
    todayChange: todayChange,
    totalPurchase: totalPurchase,
  );
});

DateTime _historyTimestamp(_ProductHistoryEntry entry, int orderIndex) {
  final now = DateTime.now();
  final normalized = _latinDigits(entry.timeLabel);
  final match = RegExp(r'(\d{1,2})(?::|\.)(\d{2})\s*(AM|PM)', caseSensitive: false).firstMatch(normalized);
  var hour = now.hour;
  var minute = now.minute;
  if (match != null) {
    hour = int.tryParse(match.group(1) ?? '') ?? hour;
    minute = int.tryParse(match.group(2) ?? '') ?? minute;
    final ampm = (match.group(3) ?? 'AM').toUpperCase();
    if (ampm == 'PM' && hour < 12) {
      hour += 12;
    }
    if (ampm == 'AM' && hour == 12) {
      hour = 0;
    }
  }
  if (entry.timestamp != null) {
    return entry.timestamp!;
  }
  if (entry.timeLabel.contains('গতকাল')) {
    final day = now.subtract(const Duration(days: 1));
    return DateTime(day.year, day.month, day.day, hour, minute).subtract(Duration(minutes: orderIndex));
  }
  if (entry.timeLabel.contains('আজ')) {
    return DateTime(now.year, now.month, now.day, hour, minute).subtract(Duration(minutes: orderIndex));
  }
  return now.subtract(Duration(minutes: orderIndex * 7 + 3));
}

int _historyDelta(_ProductHistoryEntry entry) {
  final normalized = _latinDigits(entry.amount);
  final match = RegExp(r'([+-]?)\s*(\d+)').firstMatch(normalized);
  final value = int.tryParse(match?.group(2) ?? '') ?? 0;
  if (entry.label.contains('দাম পরিবর্তন')) {
    return 0;
  }
  if (match?.group(1) == '-') {
    return -value;
  }
  if (match?.group(1) == '+') {
    return value;
  }
  if (entry.label.contains('বিক্রয়') || entry.label.contains('কমানো') || entry.label.contains('ক্ষতি')) {
    return -value;
  }
  return value;
}

DokanStockMovementType _historyType(_ProductHistoryEntry entry) {
  if (entry.kind != null) return entry.kind!;
  if (entry.label.contains('বিক্রয়')) return DokanStockMovementType.sale;
  if (entry.label.contains('ক্রয়') || entry.label.contains('স্টক যোগ')) return DokanStockMovementType.purchase;
  if (entry.label.contains('ফেরত')) return DokanStockMovementType.returnItem;
  if (entry.label.contains('ক্ষতি') || entry.label.contains('কমানো')) return DokanStockMovementType.loss;
  return DokanStockMovementType.manual;
}

String _historyTypeLabel(_ProductHistoryEntry entry) {
  switch (_historyType(entry)) {
    case DokanStockMovementType.sale:
      return 'বিক্রয়';
    case DokanStockMovementType.purchase:
      return 'ক্রয়';
    case DokanStockMovementType.loss:
      return 'ক্ষতি';
    case DokanStockMovementType.returnItem:
      return 'রিটার্ন';
    case DokanStockMovementType.manual:
      return 'ম্যানুয়াল';
  }
}

IconData _historyIcon(_ProductHistoryEntry entry) {
  switch (_historyType(entry)) {
    case DokanStockMovementType.sale:
      return Icons.shopping_cart_outlined;
    case DokanStockMovementType.purchase:
      return Icons.inventory_2_outlined;
    case DokanStockMovementType.loss:
      return Icons.warning_amber_rounded;
    case DokanStockMovementType.returnItem:
      return Icons.assignment_return_outlined;
    case DokanStockMovementType.manual:
      return Icons.edit_outlined;
  }
}

class _ProductHistoryEntry {
  const _ProductHistoryEntry({
    required this.label,
    required this.amount,
    required this.timeLabel,
    required this.color,
    this.timestamp,
    this.kind,
  });

  final String label;
  final String amount;
  final String timeLabel;
  final Color color;
  final DateTime? timestamp;
  final DokanStockMovementType? kind;
}

class _StockAddResult {
  const _StockAddResult({
    required this.addAmount,
    required this.purchasePrice,
    required this.referenceText,
  });

  final int addAmount;
  final int purchasePrice;
  final String referenceText;
}

class DokanNewProductAddScreen extends ConsumerStatefulWidget {
  const DokanNewProductAddScreen({super.key, required this.existingBarcodes});

  final Set<String> existingBarcodes;

  @override
  ConsumerState<DokanNewProductAddScreen> createState() => _DokanNewProductAddScreenState();
}

class _DokanNewProductAddScreenState extends ConsumerState<DokanNewProductAddScreen> {
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  final TextEditingController _nameController = TextEditingController();
  final TextEditingController _brandController = TextEditingController();
  final TextEditingController _barcodeController = TextEditingController();
  final TextEditingController _salePriceController = TextEditingController();
  final TextEditingController _purchasePriceController = TextEditingController();
  final TextEditingController _stockController = TextEditingController(text: '0');
  final TextEditingController _lowStockController = TextEditingController(text: '5');

  String _selectedCategory = 'চাল-ডাল';
  String _selectedUnit = 'পিস';
  String _selectedImageLabel = 'ছবি যোগ করা হয়নি';
  bool _isSaving = false;
  String? _imageHint;
  String? _imageError;
  String? _formError;

  static const List<String> _units = <String>['পিস', 'কেজি', 'লিটার', 'প্যাকেট'];

  @override
  void dispose() {
    _nameController.dispose();
    _brandController.dispose();
    _barcodeController.dispose();
    _salePriceController.dispose();
    _purchasePriceController.dispose();
    _stockController.dispose();
    _lowStockController.dispose();
    super.dispose();
  }

  int _parseInt(String value, {int fallback = 0}) {
    final parsed = int.tryParse(value.trim());
    return parsed ?? fallback;
  }

  Future<void> _chooseImageSource() async {
    final choice = await showModalBottomSheet<String>(
      context: context,
      backgroundColor: Colors.transparent,
      builder: (sheetContext) {
        return SafeArea(
          child: Container(
            margin: const EdgeInsets.all(16),
            padding: const EdgeInsets.all(18),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(22),
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Text(
                  'ছবি নির্বাচন',
                  style: TextStyle(
                    color: Color(0xFF111111),
                    fontSize: 18,
                    fontWeight: FontWeight.w900,
                  ),
                ),
                const SizedBox(height: 12),
                ListTile(
                  leading: const Icon(Icons.photo_library_outlined, color: Color(0xFF111111)),
                  title: const Text(
                    'গ্যালারি থেকে',
                    style: TextStyle(color: Color(0xFF111111), fontWeight: FontWeight.w700),
                  ),
                  onTap: () => Navigator.of(sheetContext).pop('gallery'),
                ),
                ListTile(
                  leading: const Icon(Icons.photo_camera_outlined, color: Color(0xFF111111)),
                  title: const Text(
                    'ক্যামেরা থেকে',
                    style: TextStyle(color: Color(0xFF111111), fontWeight: FontWeight.w700),
                  ),
                  onTap: () => Navigator.of(sheetContext).pop('camera'),
                ),
                ListTile(
                  leading: const Icon(Icons.do_not_disturb_alt_outlined, color: Color(0xFF111111)),
                  title: const Text(
                    'ছবি বাদ দিন',
                    style: TextStyle(color: Color(0xFF111111), fontWeight: FontWeight.w700),
                  ),
                  onTap: () => Navigator.of(sheetContext).pop('remove'),
                ),
              ],
            ),
          ),
        );
      },
    );

    if (!mounted || choice == null) {
      return;
    }

    setState(() {
      if (choice == 'remove') {
        _selectedImageLabel = 'ছবি যোগ করা হয়নি';
        _imageHint = null;
        _imageError = null;
      } else if (choice == 'camera') {
        _selectedImageLabel = 'ক্যামেরা থেকে ছবি';
        _imageHint = 'ছবি নির্বাচিত';
        _imageError = null;
      } else {
        _selectedImageLabel = 'গ্যালারি থেকে ছবি';
        _imageHint = 'ছবি নির্বাচিত';
        _imageError = null;
      }
    });
  }

  String? _validateBarcode(String? value) {
    final barcode = value?.trim() ?? '';
    if (barcode.isEmpty) return null;
    if (widget.existingBarcodes.contains(barcode)) {
      return 'এই বারকোডটি ইতিমধ্যে আছে';
    }
    return null;
  }

  String? _validateRequiredText(String? value, String errorMessage) {
    if (value == null || value.trim().isEmpty) {
      return errorMessage;
    }
    return null;
  }

  Future<void> _submit() async {
    final form = _formKey.currentState;
    if (form == null || !form.validate()) {
      return;
    }
    if (_imageHint == null) {
      setState(() => _imageError = 'ছবি নির্বাচন করুন');
      return;
    }
    setState(() => _imageError = null);
    setState(() => _formError = null);

    setState(() => _isSaving = true);
    await Future<void>.delayed(const Duration(milliseconds: 700));
    if (!mounted) {
      return;
    }

    final name = _nameController.text.trim();
    final barcode = _barcodeController.text.trim();
    final salePrice = _parseInt(_salePriceController.text);
    final purchasePrice = _parseInt(_purchasePriceController.text);
    final stock = _parseInt(_stockController.text, fallback: 0);
    final lowStock = _parseInt(_lowStockController.text, fallback: 5);
    final brand = _brandController.text.trim();
    final categoryOptions = _productCategoryOptions(ref.read(categoryProvider));
    final category = categoryOptions.contains(_selectedCategory) ? _selectedCategory : categoryOptions.first;

    if (name.isEmpty || barcode.isEmpty || brand.isEmpty || _imageHint == null) {
      setState(() => _formError = 'সব আবশ্যিক তথ্য পূরণ করুন');
      setState(() => _isSaving = false);
      return;
    }

    Navigator.of(context).pop(
      DokanCatalogProduct(
        name: name,
        barcode: barcode,
        category: category,
        emoji: _emojiForCategory(category),
        brand: brand,
        unit: _selectedUnit,
        imageLabel: _selectedImageLabel,
        salePrice: salePrice,
        purchasePrice: purchasePrice,
        stock: stock,
        lowStockThreshold: lowStock <= 0 ? 5 : lowStock,
        salesCount: 0,
        packInfo: _selectedUnit,
      ),
    );
  }

  Widget _buildFieldCard({
    required String label,
    required Widget child,
    EdgeInsetsGeometry padding = const EdgeInsets.all(16),
  }) {
    return Container(
      padding: padding,
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(22),
        border: Border.all(color: const Color(0xFFD9E6E2)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            label,
            style: const TextStyle(
              color: Color(0xFF141F22),
              fontSize: 14,
              fontWeight: FontWeight.w800,
            ),
          ),
          const SizedBox(height: 10),
          child,
        ],
      ),
    );
  }

  InputDecoration _inputDecoration({required String hintText, Widget? suffixIcon}) {
    return InputDecoration(
      hintText: hintText,
      hintStyle: const TextStyle(
        color: Color(0xFF111111),
        fontWeight: FontWeight.w600,
      ),
      filled: true,
      fillColor: Colors.white,
      contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 15),
      suffixIcon: suffixIcon,
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(18),
        borderSide: const BorderSide(color: Color(0xFFD9E6E2)),
      ),
      enabledBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(18),
        borderSide: const BorderSide(color: Color(0xFFD9E6E2)),
      ),
      focusedBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(18),
        borderSide: const BorderSide(color: Color(0xFF00694C), width: 1.5),
      ),
      errorBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(18),
        borderSide: const BorderSide(color: Color(0xFFD43B3B), width: 1.5),
      ),
      focusedErrorBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(18),
        borderSide: const BorderSide(color: Color(0xFFD43B3B), width: 1.5),
      ),
      errorStyle: const TextStyle(
        color: Color(0xFFD43B3B),
        fontSize: 12,
        fontWeight: FontWeight.w800,
      ),
      errorMaxLines: 2,
    );
  }

  @override
  Widget build(BuildContext context) {
    final categories = ref.watch(categoryProvider);
    final categoryOptions = _productCategoryOptions(categories);
    final selectedCategory = categoryOptions.contains(_selectedCategory) ? _selectedCategory : categoryOptions.first;
    return DefaultTextStyle.merge(
      style: const TextStyle(fontFamily: 'Hind Siliguri'),
      child: Scaffold(
        backgroundColor: const Color(0xFFF3F8F7),
        resizeToAvoidBottomInset: true,
        body: SafeArea(
          child: Form(
            key: _formKey,
            child: ListView(
              padding: const EdgeInsets.fromLTRB(16, 12, 16, 20),
              keyboardDismissBehavior: ScrollViewKeyboardDismissBehavior.onDrag,
              children: [
                Container(
                  height: 82,
                  padding: const EdgeInsets.symmetric(horizontal: 14),
                  decoration: BoxDecoration(
                    color: const Color(0xFFF3FAFB),
                    border: Border.all(color: const Color(0xFFD9E6E2)),
                  ),
                  child: Row(
                    children: [
                      Material(
                        color: Colors.white,
                        shape: const CircleBorder(),
                        child: InkWell(
                          customBorder: const CircleBorder(),
                          onTap: _isSaving ? null : () => Navigator.of(context).pop(),
                          child: const SizedBox(
                            width: 44,
                            height: 44,
                            child: Icon(Icons.arrow_back, color: Color(0xFF3D4943)),
                          ),
                        ),
                      ),
                      const Expanded(
                        child: Center(
                          child: Text(
                            'নতুন পণ্য যোগ করুন',
                            style: TextStyle(
                              color: Color(0xFF00694C),
                              fontSize: 22,
                              fontWeight: FontWeight.w900,
                            ),
                          ),
                        ),
                      ),
                      const SizedBox(width: 44),
                    ],
                  ),
                ),
                const SizedBox(height: 14),
                Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: const Color(0xFFF7FBFA),
                    borderRadius: BorderRadius.circular(18),
                    border: Border.all(color: const Color(0xFFD8E6E1)),
                  ),
                  child: const Text(
                    'এই পণ্যটি আপনার দোকানে সাথে সাথে যোগ হবে এবং আমাদের টিম যাচাই করে Master DB তে যুক্ত করবে',
                    style: TextStyle(
                      color: Color(0xFF55605C),
                      fontSize: 13,
                      height: 1.55,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ),
                const SizedBox(height: 14),
                GestureDetector(
                  onTap: _isSaving ? null : _chooseImageSource,
                  child: Container(
                    padding: const EdgeInsets.all(18),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(22),
                      border: Border.all(
                        color: _imageHint == null ? const Color(0xFFD9E6E2) : const Color(0xFF0C8C67),
                        width: 1.4,
                      ),
                    ),
                    child: Row(
                      children: [
                        Container(
                          width: 76,
                          height: 76,
                          decoration: BoxDecoration(
                            color: const Color(0xFFEAF7F0),
                            borderRadius: BorderRadius.circular(18),
                          ),
                          alignment: Alignment.center,
                          child: Icon(
                            _imageHint == null ? Icons.photo_outlined : Icons.check_circle_outline,
                            color: const Color(0xFF0C8C67),
                            size: 34,
                          ),
                        ),
                        const SizedBox(width: 14),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              const Text(
                              'ছবি যোগ করুন *',
                                style: TextStyle(
                                  color: Color(0xFF111111),
                                  fontSize: 16,
                                  fontWeight: FontWeight.w900,
                                ),
                              ),
                              const SizedBox(height: 6),
                              Text(
                                _selectedImageLabel,
                                style: const TextStyle(
                                  color: Color(0xFF111111),
                                  fontSize: 13,
                                  fontWeight: FontWeight.w600,
                                ),
                              ),
                              if (_imageHint != null) ...[
                                const SizedBox(height: 6),
                                Text(
                                  _imageHint!,
                                  style: const TextStyle(
                                    color: Color(0xFF111111),
                                    fontSize: 12,
                                    fontWeight: FontWeight.w700,
                                  ),
                                ),
                              ],
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                if (_imageError != null) ...[
                  const SizedBox(height: 8),
                  Padding(
                    padding: const EdgeInsets.only(left: 4),
                    child: Text(
                      _imageError!,
                      style: const TextStyle(
                        color: Color(0xFFD43B3B),
                        fontSize: 13,
                        fontWeight: FontWeight.w800,
                      ),
                    ),
                  ),
                ],
                if (_formError != null) ...[
                  const SizedBox(height: 8),
                  Container(
                    width: double.infinity,
                    padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
                    decoration: BoxDecoration(
                      color: const Color(0xFFFFEBEB),
                      borderRadius: BorderRadius.circular(14),
                      border: Border.all(color: const Color(0xFFD43B3B)),
                    ),
                    child: const Text(
                      'সব আবশ্যিক তথ্য পূরণ করুন',
                      style: TextStyle(
                        color: Color(0xFFD43B3B),
                        fontSize: 13,
                        fontWeight: FontWeight.w800,
                      ),
                    ),
                  ),
                ],
                const SizedBox(height: 14),
                _buildFieldCard(
                  label: 'পণ্যের নাম (আবশ্যিক) *',
                  child: TextFormField(
                    controller: _nameController,
                    textInputAction: TextInputAction.next,
                    autovalidateMode: AutovalidateMode.always,
                    onChanged: (_) => setState(() {}),
                    validator: (value) {
                      if (value == null || value.trim().isEmpty) {
                        return 'পণ্যের নাম দিন';
                      }
                      return null;
                    },
                    decoration: _inputDecoration(hintText: 'যেমন: প্রাণ চিপস ১০টাকা'),
                    style: const TextStyle(color: Color(0xFF111111), fontWeight: FontWeight.w700),
                  ),
                ),
                const SizedBox(height: 12),
                _buildFieldCard(
                  label: 'ক্যাটাগরি *',
                  child: DropdownButtonFormField<String>(
                    initialValue: selectedCategory,
                    dropdownColor: Colors.white,
                    items: categoryOptions
                        .map(
                          (category) => DropdownMenuItem<String>(
                            value: category,
                            child: Text(
                              category,
                              style: const TextStyle(
                                color: Color(0xFF111111),
                                fontWeight: FontWeight.w700,
                              ),
                            ),
                          ),
                        )
                        .toList(),
                    onChanged: (value) {
                      if (value == null) return;
                      setState(() => _selectedCategory = value);
                    },
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return 'ক্যাটাগরি নির্বাচন করুন';
                      }
                      return null;
                    },
                    decoration: _inputDecoration(hintText: 'ক্যাটাগরি নির্বাচন করুন'),
                    style: const TextStyle(color: Color(0xFF111111), fontWeight: FontWeight.w700),
                  ),
                ),
                const SizedBox(height: 12),
                _buildFieldCard(
                  label: 'ব্র্যান্ড *',
                  child: TextFormField(
                    controller: _brandController,
                    textInputAction: TextInputAction.next,
                    onChanged: (_) => setState(() {}),
                    validator: (value) => _validateRequiredText(value, 'ব্র্যান্ড দিন'),
                    decoration: _inputDecoration(hintText: 'যেমন: প্রাণ'),
                    style: const TextStyle(color: Color(0xFF111111), fontWeight: FontWeight.w700),
                  ),
                ),
                const SizedBox(height: 12),
                _buildFieldCard(
                  label: 'পরিমাণের একক *',
                  child: DropdownButtonFormField<String>(
                    initialValue: _selectedUnit,
                    dropdownColor: Colors.white,
                    items: _units
                        .map(
                          (unit) => DropdownMenuItem<String>(
                            value: unit,
                            child: Text(
                              unit,
                              style: const TextStyle(
                                color: Color(0xFF111111),
                                fontWeight: FontWeight.w700,
                              ),
                            ),
                          ),
                        )
                        .toList(),
                    onChanged: (value) {
                      if (value == null) return;
                      setState(() => _selectedUnit = value);
                    },
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return 'পরিমাণের একক নির্বাচন করুন';
                      }
                      return null;
                    },
                    decoration: _inputDecoration(hintText: 'পিস / কেজি / লিটার / প্যাকেট'),
                    style: const TextStyle(color: Color(0xFF111111), fontWeight: FontWeight.w700),
                  ),
                ),
                const SizedBox(height: 12),
                _buildFieldCard(
                  label: 'বারকোড *',
                  child: TextFormField(
                    controller: _barcodeController,
                    textInputAction: TextInputAction.next,
                    keyboardType: TextInputType.number,
                    inputFormatters: [FilteringTextInputFormatter.digitsOnly],
                    onChanged: (_) => setState(() {}),
                    validator: (value) {
                      final textError = _validateRequiredText(value, 'বারকোড দিন');
                      if (textError != null) return textError;
                      if (value!.trim().length < 6) {
                        return 'কমপক্ষে ৬ সংখ্যা দিন';
                      }
                      return _validateBarcode(value);
                    },
                    decoration: _inputDecoration(hintText: 'বারকোড লিখুন'),
                    style: const TextStyle(color: Color(0xFF111111), fontWeight: FontWeight.w700),
                  ),
                ),
                const SizedBox(height: 12),
                Row(
                  children: [
                    Expanded(
                      child: _buildFieldCard(
                        label: 'বিক্রয় মূল্য ৳ *',
                        child: TextFormField(
                          controller: _salePriceController,
                          keyboardType: TextInputType.number,
                          inputFormatters: [FilteringTextInputFormatter.digitsOnly],
                          onChanged: (_) => setState(() {}),
                          validator: (value) {
                            final parsed = int.tryParse(value?.trim() ?? '');
                            if (parsed == null || parsed <= 0) {
                              return 'বিক্রয় মূল্য দিন';
                            }
                            return null;
                          },
                          decoration: _inputDecoration(hintText: '৳ ০'),
                          style: const TextStyle(color: Color(0xFF111111), fontWeight: FontWeight.w700),
                        ),
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: _buildFieldCard(
                        label: 'ক্রয় মূল্য ৳',
                        child: TextFormField(
                          controller: _purchasePriceController,
                          keyboardType: TextInputType.number,
                          inputFormatters: [FilteringTextInputFormatter.digitsOnly],
                          onChanged: (_) => setState(() {}),
                          validator: (value) {
                            if (value == null || value.trim().isEmpty) {
                              return 'ক্রয় মূল্য দিন';
                            }
                            final parsed = int.tryParse(value.trim());
                            if (parsed == null || parsed < 0) {
                              return 'সঠিক ক্রয় মূল্য দিন';
                            }
                            return null;
                          },
                          decoration: _inputDecoration(hintText: '৳ ০'),
                          style: const TextStyle(color: Color(0xFF111111), fontWeight: FontWeight.w700),
                        ),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 12),
                Row(
                  children: [
                    Expanded(
                      child: _buildFieldCard(
                        label: 'বর্তমান স্টক',
                        child: TextFormField(
                          controller: _stockController,
                          keyboardType: TextInputType.number,
                          inputFormatters: [FilteringTextInputFormatter.digitsOnly],
                          onChanged: (_) => setState(() {}),
                          validator: (value) {
                            if (value == null || value.trim().isEmpty) return 'বর্তমান স্টক দিন';
                            final parsed = int.tryParse(value.trim());
                            if (parsed == null || parsed < 0) {
                              return 'সঠিক স্টক দিন';
                            }
                            return null;
                          },
                          decoration: _inputDecoration(hintText: '০'),
                          style: const TextStyle(color: Color(0xFF111111), fontWeight: FontWeight.w700),
                        ),
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: _buildFieldCard(
                        label: 'কম স্টক সীমা',
                        child: TextFormField(
                          controller: _lowStockController,
                          keyboardType: TextInputType.number,
                          inputFormatters: [FilteringTextInputFormatter.digitsOnly],
                          onChanged: (_) => setState(() {}),
                          validator: (value) {
                            if (value == null || value.trim().isEmpty) return 'কম স্টক সীমা দিন';
                            final parsed = int.tryParse(value.trim());
                            if (parsed == null || parsed < 0) {
                              return 'সঠিক সীমা দিন';
                            }
                            return null;
                          },
                          decoration: _inputDecoration(hintText: '৫'),
                          style: const TextStyle(color: Color(0xFF111111), fontWeight: FontWeight.w700),
                        ),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 14),
                Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: const Color(0xFFEAF7F0),
                    borderRadius: BorderRadius.circular(22),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text(
                        'প্রিভিউ',
                        style: TextStyle(
                          color: Color(0xFF141F22),
                          fontSize: 16,
                          fontWeight: FontWeight.w900,
                        ),
                      ),
                      const SizedBox(height: 12),
                      Text(
                        _nameController.text.trim().isEmpty ? 'পণ্যের নাম' : _nameController.text.trim(),
                        style: const TextStyle(
                          color: Color(0xFF111111),
                          fontSize: 20,
                          fontWeight: FontWeight.w900,
                        ),
                      ),
                      const SizedBox(height: 6),
                      Text(
                        'ক্যাটাগরি: $_selectedCategory • একক: $_selectedUnit',
                        style: const TextStyle(
                          color: Color(0xFF111111),
                          fontSize: 13,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                      const SizedBox(height: 8),
                        Text(
                          'বারকোড: ${_barcodeController.text.trim().isEmpty ? 'স্বয়ংক্রিয়ভাবে তৈরি হবে' : _barcodeController.text.trim()}',
                          style: const TextStyle(
                          color: Color(0xFF111111),
                          fontSize: 13,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 16),
                Container(
                  padding: const EdgeInsets.all(14),
                  decoration: BoxDecoration(
                    color: const Color(0xFFF7FBFA),
                    borderRadius: BorderRadius.circular(18),
                    border: Border.all(color: const Color(0xFFD8E6E1)),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: const [
                          Icon(Icons.check_circle_rounded, color: Color(0xFF0C8C67), size: 18),
                          SizedBox(width: 8),
                          Expanded(
                            child: Text(
                              'পণ্যের তথ্য যাচাই করলে দ্রুত Master DB তে যুক্ত হবে',
                              style: TextStyle(
                                color: Color(0xFF111111),
                                fontSize: 13,
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 18),
                SizedBox(
                  height: 56,
                  child: ElevatedButton(
                    onPressed: _isSaving ? null : _submit,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: const Color(0xFF0C8C67),
                      foregroundColor: Colors.white,
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
                    ),
                    child: _isSaving
                        ? const SizedBox(
                            width: 22,
                            height: 22,
                            child: CircularProgressIndicator(strokeWidth: 2.4, color: Colors.white),
                          )
                        : const Text(
                            'পণ্য যোগ করুন',
                            style: TextStyle(fontWeight: FontWeight.w900, fontSize: 16),
                          ),
                  ),
                ),
                const SizedBox(height: 14),
                _buildFieldCard(
                  label: 'স্মারক',
                    child: Text(
                      _selectedImageLabel,
                      style: const TextStyle(
                      color: Color(0xFF111111),
                      fontSize: 13,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ),
                const SizedBox(height: 12),
              ],
            ),
          ),
        ),
        bottomNavigationBar: _ProductBottomNav(
          selectedIndex: 2,
          onHomeTap: () => Navigator.of(context).push(
            MaterialPageRoute(builder: (_) => const DokanHomeDashboardScreen()),
          ),
          onSalesTap: () => Navigator.of(context).push(
            MaterialPageRoute(builder: (_) => const DokanPosSalesHistoryScreen()),
          ),
          onProductsTap: () => Navigator.of(context).push(
            MaterialPageRoute(builder: (_) => const DokanProductListScreen()),
          ),
          onReportsTap: () => Navigator.of(context).push(
            MaterialPageRoute(builder: (_) => const DokanReportsHomeScreen()),
          ),
          onMoreTap: () => Navigator.of(context).push(
            MaterialPageRoute(builder: (_) => const DokanAroOptionScreen()),
          ),
        ),
      ),
    );
  }
}

class DokanProductStockAddScreen extends StatefulWidget {
  class _DokanProductStockAddScreenState
  const DokanProductStockAddScreen({super.key, required this.product});

  final DokanCatalogProduct product;

  @override
  State<DokanProductStockAddScreen> createState() => _DokanProductStockAddScreenState();
}

class _DokanProductStockAddScreenState extends State<DokanProductStockAddScreen> {
  final TextEditingController _supplierController = TextEditingController();
  late final TextEditingController _purchaseController;
  final TextEditingController _referenceController = TextEditingController();
  final TextEditingController _noteController = TextEditingController();
  int _addAmount = 10;
  String? _errorText;

  @override
  void initState() {
    super.initState();
    _purchaseController = TextEditingController(text: widget.product.purchasePrice.toString());
  }

  @override
  void dispose() {
    _supplierController.dispose();
    _purchaseController.dispose();
    _referenceController.dispose();
    _noteController.dispose();
    super.dispose();
  }

  void _submit() {
    final container = ProviderScope.containerOf(context);
final flow = container.read(dokanAppFlowProvider);

if (flow.isSalesman) {
  ScaffoldMessenger.of(context).showSnackBar(
    const SnackBar(
      content: Text('সেলসম্যান স্টক আপডেট করতে পারবেন না'),
    ),
  );
  return;
}
    if (_addAmount <= 0) {
      setState(() => _errorText = 'যোগ করার পরিমাণ অবশ্যই ১ বা তার বেশি হতে হবে');
      return;
    }
    final purchasePrice = int.tryParse(_purchaseController.text.trim()) ?? 0;
    if (purchasePrice <= 0) {
      setState(() => _errorText = 'ক্রয় মূল্য সঠিকভাবে দিন');
      return;
    }
    Navigator.of(context).pop(
      _StockAddResult(
        addAmount: _addAmount,
        purchasePrice: purchasePrice,
        referenceText: _referenceController.text.trim(),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final newStock = widget.product.stock + _addAmount;

    return Scaffold(
      backgroundColor: const Color(0xFFF3F8F7),
      resizeToAvoidBottomInset: true,
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.fromLTRB(16, 12, 16, 16),
          keyboardDismissBehavior: ScrollViewKeyboardDismissBehavior.onDrag,
          children: [
            Container(
              height: 82,
              padding: const EdgeInsets.symmetric(horizontal: 14),
              decoration: BoxDecoration(
                color: const Color(0xFFF3FAFB),
                border: Border.all(color: const Color(0xFFD9E6E2)),
              ),
              child: Row(
                children: [
                  Material(
                    color: Colors.white,
                    shape: const CircleBorder(),
                    child: InkWell(
                      customBorder: const CircleBorder(),
                      onTap: () => Navigator.of(context).pop(),
                      child: const SizedBox(
                        width: 44,
                        height: 44,
                        child: Icon(Icons.arrow_back, color: Color(0xFF3D4943)),
                      ),
                    ),
                  ),
                  const Expanded(
                    child: Center(
                      child: Text(
                        'স্টক যোগ',
                        style: TextStyle(
                          color: Color(0xFF00694C),
                          fontSize: 24,
                          fontWeight: FontWeight.w900,
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(width: 44),
                ],
              ),
            ),
            const SizedBox(height: 16),
            Container(
              padding: const EdgeInsets.all(18),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(22),
                border: Border.all(color: const Color(0xFFD9E6E2)),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    widget.product.name,
                    style: const TextStyle(
                      color: Color(0xFF141F22),
                      fontSize: 20,
                      fontWeight: FontWeight.w900,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    'বর্তমান স্টক: ${_bnDigits(widget.product.stock.toString())}টি',
                    style: const TextStyle(
                      color: Color(0xFF5F6A66),
                      fontSize: 13,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 16),
            Container(
              padding: const EdgeInsets.all(18),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(22),
                border: Border.all(color: const Color(0xFFD9E6E2)),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'যোগ করার পরিমাণ',
                    style: TextStyle(
                      color: Color(0xFF141F22),
                      fontSize: 20,
                      fontWeight: FontWeight.w900,
                    ),
                  ),
                  const SizedBox(height: 12),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
                    decoration: BoxDecoration(
                      color: const Color(0xFFF4F8F7),
                      borderRadius: BorderRadius.circular(16),
                      border: Border.all(color: const Color(0xFFD9E6E2)),
                    ),
                    child: Row(
                      children: [
                        _StepperButton(
                          icon: Icons.remove,
                          onTap: () {
                            if (_addAmount <= 1) return;
                            setState(() => _addAmount -= 1);
                          },
                        ),
                        const SizedBox(width: 14),
                        Expanded(
                          child: Column(
                            children: [
                              Text(
                                '+${_bnDigits(_addAmount.toString())}টি',
                                style: const TextStyle(
                                  color: Color(0xFF0C8C67),
                                  fontSize: 22,
                                  fontWeight: FontWeight.w900,
                                ),
                              ),
                              const SizedBox(height: 4),
                              const Text(
                                'স্টেপার দিয়ে পরিমাণ নির্ধারণ করুন',
                                textAlign: TextAlign.center,
                                style: TextStyle(
                                  color: Color(0xFF6F7D78),
                                  fontSize: 12,
                                  fontWeight: FontWeight.w600,
                                ),
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(width: 14),
                        _StepperButton(
                          icon: Icons.add,
                          onTap: () => setState(() => _addAmount += 1),
                          active: true,
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 14),
                  Row(
                    children: [
                      Expanded(
                        child: _MiniFormField(
                          label: 'সরবরাহকারী',
                          controller: _supplierController,
                          hintText: 'সরবরাহকারীর নাম',
                          onChanged: (_) {
                            if (_errorText != null) setState(() => _errorText = null);
                          },
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: _MiniFormField(
                          label: 'ক্রয় মূল্য',
                          controller: _purchaseController,
                          hintText: '০',
                          keyboardType: TextInputType.number,
                          onChanged: (_) {
                            if (_errorText != null) setState(() => _errorText = null);
                          },
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 14),
                  Row(
                    children: [
                      Expanded(
                        child: _MiniFormField(
                          label: 'চালান / রেফারেন্স নম্বর',
                          controller: _referenceController,
                          hintText: 'রেফারেন্স লিখুন',
                          onChanged: (_) {
                            if (_errorText != null) setState(() => _errorText = null);
                          },
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: _MiniFormField(
                          label: 'নোট',
                          controller: _noteController,
                          hintText: 'সংক্ষিপ্ত নোট',
                          onChanged: (_) {
                            if (_errorText != null) setState(() => _errorText = null);
                          },
                        ),
                      ),
                    ],
                  ),
                  if (_errorText != null) ...[
                    const SizedBox(height: 12),
                    Text(
                      _errorText!,
                      style: const TextStyle(
                        color: Color(0xFFD43B3B),
                        fontSize: 13,
                        fontWeight: FontWeight.w800,
                      ),
                    ),
                  ],
                ],
              ),
            ),
            const SizedBox(height: 16),
            Container(
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                color: const Color(0xFFEAF7F0),
                borderRadius: BorderRadius.circular(18),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'লাইভ প্রিভিউ',
                    style: TextStyle(
                      color: Color(0xFF141F22),
                      fontSize: 15,
                      fontWeight: FontWeight.w900,
                    ),
                  ),
                  const SizedBox(height: 10),
                  _DetailInfoRow(label: 'বর্তমান স্টক', value: '${_bnDigits(widget.product.stock.toString())}টি'),
                  const SizedBox(height: 8),
                  _DetailInfoRow(
                    label: 'যোগ হবে',
                    value: '+${_bnDigits(_addAmount.toString())}টি',
                    valueColor: const Color(0xFF0C8C67),
                  ),
                  const SizedBox(height: 8),
                  _DetailInfoRow(
                    label: 'নতুন স্টক',
                    value: '${_bnDigits(newStock.toString())}টি',
                    valueColor: const Color(0xFF00694C),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 16),
            Row(
              children: [
                Expanded(
                  child: OutlinedButton(
                    onPressed: () => Navigator.of(context).pop(),
                    style: OutlinedButton.styleFrom(
                      side: const BorderSide(color: Color(0xFFC5D4CF), width: 1.4),
                      foregroundColor: const Color(0xFF3D4943),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                      minimumSize: const Size.fromHeight(52),
                    ),
                    child: const Text('বাতিল', style: TextStyle(fontWeight: FontWeight.w900)),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: ElevatedButton(
                    onPressed: _submit,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: const Color(0xFF0C8C67),
                      foregroundColor: Colors.white,
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                      minimumSize: const Size.fromHeight(52),
                    ),
                    child: const Text('স্টক যোগ করুন', style: TextStyle(fontWeight: FontWeight.w900)),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
      bottomNavigationBar: _ProductBottomNav(
        selectedIndex: 2,
        onHomeTap: () => Navigator.of(context).push(
          MaterialPageRoute(builder: (_) => const DokanHomeDashboardScreen()),
        ),
        onSalesTap: () => Navigator.of(context).push(
          MaterialPageRoute(builder: (_) => const DokanPosSalesHistoryScreen()),
        ),
        onProductsTap: () => Navigator.of(context).push(
          MaterialPageRoute(builder: (_) => const DokanProductListScreen()),
        ),
        onReportsTap: () => Navigator.of(context).push(
          MaterialPageRoute(builder: (_) => const DokanReportsHomeScreen()),
        ),
        onMoreTap: () => Navigator.of(context).push(
          MaterialPageRoute(builder: (_) => const DokanAroOptionScreen()),
        ),
      ),
    );
  }
}

class _StockReduceResult {
  const _StockReduceResult({
    required this.amount,
    required this.reason,
  });

  final int amount;
  final String reason;
}

class _PriceChangeResult {
  const _PriceChangeResult({
    required this.purchasePrice,
    required this.salePrice,
  });

  final int purchasePrice;
  final int salePrice;
}

List<_ProductHistoryEntry> _historyFor(DokanCatalogProduct product) {
  switch (product.barcode) {
    case '880001':
      return const [
        _ProductHistoryEntry(label: 'বিক্রয়', amount: '-২টি', timeLabel: 'আজ ৯:৪১ AM', color: Color(0xFFD43B3B)),
        _ProductHistoryEntry(label: 'বিক্রয়', amount: '-১টি', timeLabel: 'আজ ৮:৩০ AM', color: Color(0xFFD43B3B)),
        _ProductHistoryEntry(label: 'ক্রয়', amount: '+২৫টি', timeLabel: 'গতকাল', color: Color(0xFF0C8C67)),
      ];
    case '880004':
      return const [
        _ProductHistoryEntry(label: 'বিক্রয়', amount: '-২টি', timeLabel: 'আজ ৯:৪১ AM', color: Color(0xFFD43B3B)),
        _ProductHistoryEntry(label: 'বিক্রয়', amount: '-১টি', timeLabel: 'আজ ৮:৩০ AM', color: Color(0xFFD43B3B)),
        _ProductHistoryEntry(label: 'ক্রয়', amount: '+১২টি', timeLabel: 'গতকাল', color: Color(0xFF0C8C67)),
      ];
    case '880005':
      return const [
        _ProductHistoryEntry(label: 'বিক্রয়', amount: '-৩টি', timeLabel: 'আজ ১১:১০ AM', color: Color(0xFFD43B3B)),
        _ProductHistoryEntry(label: 'বিক্রয়', amount: '-২টি', timeLabel: 'আজ ৯:১৫ AM', color: Color(0xFFD43B3B)),
        _ProductHistoryEntry(label: 'স্টক সমন্বয়', amount: '+৩০টি', timeLabel: 'গতকাল', color: Color(0xFFF49B1A)),
      ];
    case '880002':
      return const [
        _ProductHistoryEntry(label: 'বিক্রয়', amount: '-১টি', timeLabel: 'গতকাল', color: Color(0xFFD43B3B)),
        _ProductHistoryEntry(label: 'স্টক সমন্বয়', amount: '-৫টি', timeLabel: 'গতকাল', color: Color(0xFFF49B1A)),
        _ProductHistoryEntry(label: 'ক্রয়', amount: '+১০টি', timeLabel: 'গত মঙ্গলবার', color: Color(0xFF0C8C67)),
      ];
    default:
      return const [
        _ProductHistoryEntry(label: 'বিক্রয়', amount: '-১টি', timeLabel: 'আজ', color: Color(0xFFD43B3B)),
        _ProductHistoryEntry(label: 'ক্রয়', amount: '+১০টি', timeLabel: 'গতকাল', color: Color(0xFF0C8C67)),
        _ProductHistoryEntry(label: 'স্টক সমন্বয়', amount: '-২টি', timeLabel: 'গত সপ্তাহ', color: Color(0xFFF49B1A)),
      ];
  }
}

class DokanProductListScreen extends ConsumerStatefulWidget {
  const DokanProductListScreen({super.key});

  @override
  ConsumerState<DokanProductListScreen> createState() => _DokanProductListScreenState();
}

class _DokanProductListScreenState extends ConsumerState<DokanProductListScreen> {
  final TextEditingController _searchController = TextEditingController();

  String _selectedCategory = 'সব';
  _ProductSortMode _sortMode = _ProductSortMode.name;
  String _searchQuery = '';

  static const List<DokanCatalogProduct> _seedProducts = <DokanCatalogProduct>[
    DokanCatalogProduct(
      name: 'মিনিকেট চাল ১কেজি',
      barcode: '880001',
      category: 'চাল-ডাল',
      emoji: '🌾',
      salePrice: 630,
      purchasePrice: 582,
      stock: 48,
      lowStockThreshold: 5,
      salesCount: 48,
      packInfo: 'প্যাকিং ২ কেজি',
    ),
    DokanCatalogProduct(
      name: 'চিনি ১কেজি',
      barcode: '880002',
      category: 'চাল-ডাল',
      emoji: '🧂',
      salePrice: 120,
      purchasePrice: 98,
      stock: 19,
      lowStockThreshold: 5,
      salesCount: 18,
      packInfo: 'দৈনন্দিন ব্যবহার',
    ),
    DokanCatalogProduct(
      name: 'সয়াবিন তেল ১লি',
      barcode: '880003',
      category: 'তেল-মসলা',
      emoji: '🛢️',
      salePrice: 165,
      purchasePrice: 148,
      stock: 24,
      lowStockThreshold: 5,
      salesCount: 24,
      packInfo: 'পুষ্টি ৫ লিটার',
    ),
    DokanCatalogProduct(
      name: 'লাক্স সাবান ১০০গ্রা',
      barcode: '880004',
      category: 'সাবান',
      emoji: '🧼',
      salePrice: 58,
      purchasePrice: 42,
      stock: 4,
      lowStockThreshold: 5,
      salesCount: 12,
      packInfo: 'ব্যক্তিগত যত্ন',
    ),
    DokanCatalogProduct(
      name: 'কোকা কোলা ২৫০মি',
      barcode: '880005',
      category: 'পানীয়',
      emoji: '🥤',
      salePrice: 35,
      purchasePrice: 28,
      stock: 0,
      lowStockThreshold: 5,
      salesCount: 36,
      packInfo: '৫০০ মি.লি.',
    ),
    DokanCatalogProduct(
      name: 'ডাইজেস্টিভ বিস্কুট ২০০গ্রা',
      barcode: '880006',
      category: 'বিস্কুট',
      emoji: '🍪',
      salePrice: 75,
      purchasePrice: 60,
      stock: 16,
      lowStockThreshold: 5,
      salesCount: 20,
      packInfo: 'ক্রিস্পি প্যাক',
    ),
  ];

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  List<DokanCatalogProduct> _visibleProducts(List<DokanCatalogProduct> catalogProducts, List<String> categories) {
    final query = _searchQuery.trim().toLowerCase();
    final categoryExists = categories.contains(_selectedCategory);
    final filtered = catalogProducts.where((product) {
      final matchesCategory = _selectedCategory == 'সব' || !categoryExists || product.category == _selectedCategory;
      final matchesSearch = query.isEmpty ||
          product.name.toLowerCase().contains(query) ||
          product.barcode.toLowerCase().contains(query);
      return matchesCategory && matchesSearch;
    }).toList();

    switch (_sortMode) {
      case _ProductSortMode.name:
        filtered.sort((a, b) => a.name.compareTo(b.name));
        break;
      case _ProductSortMode.lowStock:
        filtered.sort((a, b) => a.stock.compareTo(b.stock));
        break;
      case _ProductSortMode.highestSales:
        filtered.sort((a, b) => b.salesCount.compareTo(a.salesCount));
        break;
    }

    return filtered;
  }

  Future<void> _openAddProductScreen() async {
    final flow = ref.read(dokanAppFlowProvider);

if (flow.isSalesman) {
  ScaffoldMessenger.of(context).showSnackBar(
    const SnackBar(
      content: Text('সেলসম্যান নতুন পণ্য যোগ করতে পারবেন না'),
    ),
  );
  return;
}
    final existingBarcodes = ref.read(dokanInventoryCatalogProvider).map((product) => product.barcode).toSet();
    final createdProduct = await Navigator.of(context).push<DokanCatalogProduct>(
      MaterialPageRoute(
        builder: (_) => DokanNewProductAddScreen(existingBarcodes: existingBarcodes),
      ),
    );

    if (!mounted || createdProduct == null) {
      return;
    }

    ref.read(dokanInventoryCatalogProvider.notifier).addProduct(createdProduct);
    setState(() {
      _selectedCategory = 'সব';
      _sortMode = _ProductSortMode.name;
      _searchQuery = '';
      _searchController.clear();
    });

    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('পণ্য সফলভাবে যোগ করা হয়েছে'),
        backgroundColor: Color(0xFF0C8C67),
        behavior: SnackBarBehavior.floating,
      ),
    );
  }

  void _openInventoryDrawer() {
    final flow = ref.read(dokanAppFlowProvider);

if (flow.isSalesman) {
  ScaffoldMessenger.of(context).showSnackBar(
    const SnackBar(
      content: Text('সেলসম্যান মোডে সেটিংস ব্যবহার করা যাবে না'),
    ),
  );
  return;
}
    showGeneralDialog<void>(
      context: context,
      barrierDismissible: true,
      barrierLabel: 'inventory-drawer',
      barrierColor: Colors.black.withValues(alpha: 0.38),
      transitionDuration: const Duration(milliseconds: 260),
      pageBuilder: (dialogContext, animation, secondaryAnimation) {
        return Align(
          alignment: Alignment.centerLeft,
          child: SafeArea(
            child: FractionallySizedBox(
              widthFactor: 0.86,
              heightFactor: 1,
              child: Material(
                color: const Color(0xFFF7FBF8),
                elevation: 20,
                shadowColor: Colors.black26,
                borderRadius: const BorderRadius.only(
                  topRight: Radius.circular(28),
                  bottomRight: Radius.circular(28),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Container(
                      width: double.infinity,
                      padding: const EdgeInsets.fromLTRB(18, 18, 18, 16),
                      decoration: const BoxDecoration(
                        color: Color(0xFFEAF7F0),
                        borderRadius: BorderRadius.only(
                          topRight: Radius.circular(28),
                        ),
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: const [
                          Text(
                            'পণ্য মেনু',
                            style: TextStyle(
                              color: Color(0xFF00694C),
                              fontSize: 20,
                              fontWeight: FontWeight.w900,
                            ),
                          ),
                          SizedBox(height: 6),
                          Text(
                            'স্টক, ক্যাটাগরি আর সতর্কতা সেটিংস',
                            style: TextStyle(
                              color: Color(0xFF111111),
                              fontSize: 13,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                        ],
                      ),
                    ),
                    Expanded(
                      child: ListView(
                        padding: const EdgeInsets.fromLTRB(12, 14, 12, 12),
                        children: [
                          _DrawerActionTile(
                            icon: Icons.warning_amber_rounded,
                            title: 'কম স্টক সতর্কতা',
                            subtitle: 'থ্রেশহোল্ড ও সতর্কতা হালনাগাদ করুন',
                            onTap: () {
                              final flow = ref.read(dokanAppFlowProvider);

if (flow.isSalesman) {
  Navigator.of(dialogContext).pop();
  return;
}
                              Navigator.of(dialogContext).pop();
                              WidgetsBinding.instance.addPostFrameCallback((_) {
                                if (!mounted) return;
                                Navigator.of(context).push(
                                  MaterialPageRoute(
                                    builder: (_) => const DokanLowStockAlertScreen(),
                                  ),
                                );
                              });
                            },
                          ),
                          const SizedBox(height: 10),
                          _DrawerActionTile(
                            icon: Icons.category_rounded,
                            title: 'ক্যাটাগরি সেটিংস',
                            subtitle: 'নতুন ক্যাটাগরি যোগ, মুছুন বা সম্পাদনা করুন',
                            onTap: () {
  final flow = ref.read(dokanAppFlowProvider);

  if (flow.isSalesman) {
    Navigator.of(dialogContext).pop();
    return;
  }

  Navigator.of(dialogContext).pop();

  WidgetsBinding.instance.addPostFrameCallback((_) {
    if (!mounted) return;

    Navigator.of(context).push(
      MaterialPageRoute(
        builder: (_) => const DokanCategorySettingsScreen(),
      ),
    );
  });
},
                          ),
                          const SizedBox(height: 10),
                          _DrawerActionTile(
                            icon: Icons.timeline_rounded,
                            title: 'স্টক মুভমেন্ট লগ',
                            subtitle: 'স্টক add / reduce / sales history',
                            onTap: () {
                              Navigator.of(dialogContext).pop();
                              WidgetsBinding.instance.addPostFrameCallback((_) {
                                if (!mounted) return;
                                Navigator.of(context).push(
                                  MaterialPageRoute(
                                    builder: (_) => const DokanStockMovementLogScreen(),
                                  ),
                                );
                              });
                            },
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        );
      },
      transitionBuilder: (context, animation, secondaryAnimation, child) {
        final slide = Tween<Offset>(
          begin: const Offset(-1, 0),
          end: Offset.zero,
        ).animate(CurvedAnimation(parent: animation, curve: Curves.easeOutCubic));
        return SlideTransition(position: slide, child: child);
      },
    );
  }

  void _openSortMenu() {
    showModalBottomSheet<void>(
      context: context,
      backgroundColor: Colors.transparent,
      builder: (sheetContext) {
        return SafeArea(
          child: DefaultTextStyle.merge(
            style: const TextStyle(
              color: Color(0xFF111111),
              fontWeight: FontWeight.w700,
            ),
            child: Container(
            margin: const EdgeInsets.all(16),
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(22),
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: _ProductSortMode.values.map((mode) {
                final label = switch (mode) {
                  _ProductSortMode.name => 'নাম অনুযায়ী',
                  _ProductSortMode.lowStock => 'কম স্টক আগে',
                  _ProductSortMode.highestSales => 'বেশি বিক্রি',
                };
                return ListTile(
                  leading: Icon(
                    mode == _ProductSortMode.name
                        ? Icons.sort_by_alpha
                        : mode == _ProductSortMode.lowStock
                            ? Icons.arrow_upward
                            : Icons.trending_up,
                    color: const Color(0xFF00694C),
                  ),
                  title: Text(
                    label,
                    style: const TextStyle(
                      color: Color(0xFF111111),
                      fontWeight: FontWeight.w800,
                    ),
                  ),
                  trailing: _sortMode == mode
                      ? const Icon(Icons.check_circle, color: Color(0xFF0C8C67))
                      : null,
                  onTap: () {
                    setState(() => _sortMode = mode);
                    Navigator.of(sheetContext).pop();
                  },
                );
              }).toList(),
            ),
          ),
          ),
        );
      },
    );
  }

  void _openProductDetail(DokanCatalogProduct product) {
    Navigator.of(context).push(
      MaterialPageRoute(
        builder: (_) => DokanProductDetailScreen(product: product),
      ),
    );
  }

  Widget _buildBottomNav() {
    return _ProductBottomNav(
      selectedIndex: 2,
      onHomeTap: () => Navigator.of(context).push(
        MaterialPageRoute(builder: (_) => const DokanHomeDashboardScreen()),
      ),
      onSalesTap: () => Navigator.of(context).push(
        MaterialPageRoute(builder: (_) => const DokanPosSalesHistoryScreen()),
      ),
      onProductsTap: () {},
      onReportsTap: () => Navigator.of(context).push(
        MaterialPageRoute(builder: (_) => const DokanReportsHomeScreen()),
      ),
      onMoreTap: () => Navigator.of(context).push(
        MaterialPageRoute(builder: (_) => const DokanAroOptionScreen()),
      ),
    );
  }

  Widget _statChip(String title, String value, {Color? accent}) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(18),
          border: Border.all(color: const Color(0xFFD9E6E2)),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              title,
              style: const TextStyle(
                color: Color(0xFF5F6A66),
                fontSize: 13,
                fontWeight: FontWeight.w700,
              ),
            ),
            const SizedBox(height: 6),
            Text(
              value,
              style: TextStyle(
                color: accent ?? const Color(0xFF141F22),
                fontSize: 18,
                fontWeight: FontWeight.w900,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _categoryChip(String label) {
    final selected = _selectedCategory == label;
    return Padding(
      padding: const EdgeInsets.only(right: 10),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          borderRadius: BorderRadius.circular(999),
          onTap: () => setState(() => _selectedCategory = label),
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 180),
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
            decoration: BoxDecoration(
              color: selected ? const Color(0xFF00694C) : const Color(0xFFEAF2F0),
              borderRadius: BorderRadius.circular(999),
            ),
            child: Text(
              label,
              style: TextStyle(
                color: selected ? Colors.white : const Color(0xFF3D4943),
                fontWeight: FontWeight.w800,
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _productCard(DokanCatalogProduct product, int threshold) {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        borderRadius: BorderRadius.circular(18),
        onTap: () => _openProductDetail(product),
        child: Container(
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(18),
            border: Border.all(color: const Color(0xFFD9E6E2)),
            boxShadow: [
              BoxShadow(
                color: const Color(0xFFB9C8C3).withValues(alpha: 0.06),
                blurRadius: 12,
                offset: const Offset(0, 6),
              ),
            ],
          ),
          child: Row(
            children: [
              Container(
                width: 62,
                height: 62,
                decoration: const BoxDecoration(
                  color: Color(0xFFEAF2F0),
                  shape: BoxShape.circle,
                ),
                alignment: Alignment.center,
                child: Text(product.emoji, style: const TextStyle(fontSize: 30)),
              ),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      product.name,
                      style: const TextStyle(
                        color: Color(0xFF141F22),
                        fontSize: 16,
                        fontWeight: FontWeight.w900,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      product.brand.isNotEmpty ? '${product.category} • ${product.brand}' : product.category,
                      style: const TextStyle(
                        color: Color(0xFF5F6A66),
                        fontSize: 13,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                    const SizedBox(height: 6),
                    Text(
                      'বারকোড: ${product.barcode}',
                      style: const TextStyle(
                        color: Color(0xFF7C8A84),
                        fontSize: 12,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 10),
              Column(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  Text(
                    _currency(product.salePrice),
                    style: const TextStyle(
                      color: Color(0xFF00694C),
                      fontSize: 18,
                      fontWeight: FontWeight.w900,
                    ),
                  ),
                  const SizedBox(height: 8),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                    decoration: BoxDecoration(
                      color: _stockStatusBackground(product.stock, threshold),
                      borderRadius: BorderRadius.circular(999),
                    ),
                    child: Text(
                      product.stock <= 0
                          ? 'স্টক নেই'
                          : 'স্টক ${_bnDigits(product.stock.toString())}টি',
                      style: TextStyle(
                        color: _stockStatusColor(product.stock, threshold),
                        fontSize: 12,
                        fontWeight: FontWeight.w800,
                      ),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {

    final flow = ref.watch(dokanAppFlowProvider);
final isSalesman = flow.isSalesman;

    final catalogProducts = ref.watch(dokanInventoryCatalogProvider);
    final categories = ref.watch(categoryProvider);
    final threshold = ref.watch(stockThresholdProvider);
    final visibleProducts = _visibleProducts(catalogProducts, categories);
    final normalizedCategories = <String>['সব', ...categories.where((category) => category != DokanCategoryNotifier.uncategorized)];
    if (_selectedCategory != 'সব' && !normalizedCategories.contains(_selectedCategory)) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (!mounted) return;
        if (_selectedCategory != 'সব' && !ref.read(categoryProvider).contains(_selectedCategory)) {
          setState(() => _selectedCategory = 'সব');
        }
      });
    }
    final lowStockCount = visibleProducts.where((item) => item.stock > 0 && item.stock < threshold).length;
    final outOfStockCount = visibleProducts.where((item) => item.stock <= 0).length;

    return Scaffold(
      backgroundColor: const Color(0xFFF3F8F7),
      resizeToAvoidBottomInset: true,
      body: SafeArea(
        bottom: false,
        child: ListView(
          padding: const EdgeInsets.fromLTRB(16, 12, 16, 16),
          keyboardDismissBehavior: ScrollViewKeyboardDismissBehavior.onDrag,
          children: [
            Container(
              height: 82,
              padding: const EdgeInsets.symmetric(horizontal: 14),
              decoration: BoxDecoration(
                color: const Color(0xFFF3FAFB),
                border: Border.all(color: const Color(0xFFD9E6E2)),
              ),
              child: Row(
                children: [
                  Material(
                    color: Colors.white,
                    shape: const CircleBorder(),
                    child: InkWell(
                      customBorder: const CircleBorder(),
                      onTap: _openInventoryDrawer,
                      child: const SizedBox(
                        width: 44,
                        height: 44,
                        child: Icon(Icons.menu, color: Color(0xFF3D4943)),
                      ),
                    ),
                  ),
                  const Expanded(
                    child: Center(
                      child: Text(
                        'পণ্য তালিকা',
                        style: TextStyle(
                          color: Color(0xFF00694C),
                          fontSize: 24,
                          fontWeight: FontWeight.w900,
                        ),
                      ),
                    ),
                  ),
                  _HeaderIconButton(
                    icon: Icons.qr_code_scanner_rounded,
                    onTap: () => Navigator.of(context).push(
                      MaterialPageRoute(builder: (_) => const DokanBarcodeScannerScreen()),
                    ),
                  ),
                  const SizedBox(width: 10),
                  _HeaderIconButton(
                    icon: Icons.tune_rounded,
                    onTap: _openSortMenu,
                  ),
                ],
              ),
            ),
            const SizedBox(height: 14),
            TextField(
              controller: _searchController,
              onChanged: (value) => setState(() => _searchQuery = value),
              style: const TextStyle(
                color: Color(0xFF141F22),
                fontWeight: FontWeight.w700,
              ),
              decoration: InputDecoration(
                hintText: 'পণ্যের নাম বা বারকোড লিখুন...',
                hintStyle: const TextStyle(color: Color(0xFF111111)),
                prefixIcon: const Icon(Icons.search, color: Color(0xFF6F7D78)),
                suffixIcon: _searchQuery.isEmpty
                    ? null
                    : IconButton(
                        onPressed: () {
                          setState(() {
                            _searchController.clear();
                            _searchQuery = '';
                          });
                        },
                        icon: const Icon(Icons.close, color: Color(0xFF6F7D78)),
                      ),
                filled: true,
                fillColor: Colors.white,
                contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(18),
                  borderSide: const BorderSide(color: Color(0xFFD9E6E2)),
                ),
                enabledBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(18),
                  borderSide: const BorderSide(color: Color(0xFFD9E6E2)),
                ),
                focusedBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(18),
                  borderSide: const BorderSide(color: Color(0xFF00694C), width: 1.6),
                ),
              ),
            ),
            const SizedBox(height: 12),
            Row(
              children: [
                _statChip('মোট পণ্য', _bnDigits(visibleProducts.length.toString())),
                const SizedBox(width: 10),
                _statChip('কম স্টক', _bnDigits(lowStockCount.toString()), accent: const Color(0xFFF49B1A)),
                const SizedBox(width: 10),
                _statChip('স্টক নেই', _bnDigits(outOfStockCount.toString()), accent: const Color(0xFFD43B3B)),
              ],
            ),
              const SizedBox(height: 16),
              SingleChildScrollView(
                scrollDirection: Axis.horizontal,
                child: Row(
                  children: normalizedCategories.map(_categoryChip).toList(),
                ),
              ),
            const SizedBox(height: 14),
            Row(
              children: [
                const Text(
                  'ফিল্টার:',
                  style: TextStyle(
                    color: Color(0xFF111111),
                    fontSize: 14,
                    fontWeight: FontWeight.w800,
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: Theme(
                    data: Theme.of(context).copyWith(
                      canvasColor: Colors.white,
                    ),
                    child: DropdownButtonFormField<_ProductSortMode>(
                      initialValue: _sortMode,
                      isExpanded: true,
                      dropdownColor: Colors.white,
                      icon: const Icon(Icons.keyboard_arrow_down_rounded, color: Color(0xFF6F6F6F)),
                      decoration: InputDecoration(
                        filled: true,
                        fillColor: Colors.white,
                        contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(16),
                          borderSide: const BorderSide(color: Color(0xFFD9E6E2)),
                        ),
                        enabledBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(16),
                          borderSide: const BorderSide(color: Color(0xFFD9E6E2)),
                        ),
                        focusedBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(16),
                          borderSide: const BorderSide(color: Color(0xFF00694C), width: 1.4),
                        ),
                      ),
                      style: const TextStyle(
                        color: Color(0xFF111111),
                        fontWeight: FontWeight.w800,
                      ),
                      items: const [
                        DropdownMenuItem(
                          value: _ProductSortMode.name,
                          child: Text(
                            'নাম অনুযায়ী',
                            style: TextStyle(
                              color: Color(0xFF111111),
                              fontWeight: FontWeight.w800,
                            ),
                          ),
                        ),
                        DropdownMenuItem(
                          value: _ProductSortMode.lowStock,
                          child: Text(
                            'কম স্টক আগে',
                            style: TextStyle(
                              color: Color(0xFF111111),
                              fontWeight: FontWeight.w800,
                            ),
                          ),
                        ),
                        DropdownMenuItem(
                          value: _ProductSortMode.highestSales,
                          child: Text(
                            'বেশি বিক্রি',
                            style: TextStyle(
                              color: Color(0xFF111111),
                              fontWeight: FontWeight.w800,
                            ),
                          ),
                        ),
                      ],
                      onChanged: (value) {
                        if (value == null) return;
                        setState(() => _sortMode = value);
                      },
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 14),
            if (visibleProducts.isEmpty)
              Container(
                padding: const EdgeInsets.all(24),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(22),
                  border: Border.all(color: const Color(0xFFD9E6E2)),
                ),
                child: Column(
                  children: const [
                    Icon(Icons.inventory_2_outlined, color: Color(0xFF0C8C67), size: 48),
                    SizedBox(height: 10),
                    Text(
                      'কোনো পণ্য পাওয়া যায়নি',
                      style: TextStyle(
                        color: Color(0xFF141F22),
                        fontSize: 18,
                        fontWeight: FontWeight.w900,
                      ),
                    ),
                  ],
                ),
              )
            else
              ListView.separated(
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                itemCount: visibleProducts.length,
                separatorBuilder: (context, index) => const SizedBox(height: 10),
                itemBuilder: (context, index) => _productCard(visibleProducts[index], threshold),
              ),
            const SizedBox(height: 18),
          ],
        ),
      ),
      floatingActionButton: FloatingActionButton(
       onPressed: isSalesman ? null : _openAddProductScreen,
        backgroundColor: const Color(0xFF00694C),
        foregroundColor: Colors.white,
        child: const Icon(Icons.add),
      ),
      bottomNavigationBar: _buildBottomNav(),
    );
  }
}

class DokanProductDetailScreen extends ConsumerStatefulWidget {
  const DokanProductDetailScreen({super.key, this.product});

  final DokanCatalogProduct? product;

  @override
  ConsumerState<DokanProductDetailScreen> createState() => _DokanProductDetailScreenState();
}

class _DokanProductDetailScreenState extends ConsumerState<DokanProductDetailScreen> {
  DokanCatalogProduct get _item {
    final catalog = ref.watch(dokanInventoryCatalogProvider);
    final barcode = widget.product?.barcode;
    if (barcode != null) {
      for (final item in catalog) {
        if (item.barcode == barcode) return item;
      }
    }
    return widget.product ??
        const DokanCatalogProduct(
          name: 'মিনিকেট চাল ১কেজি',
          barcode: '880001',
          category: 'চাল-ডাল',
          emoji: '🌾',
          salePrice: 630,
          purchasePrice: 582,
          stock: 48,
          lowStockThreshold: 5,
          salesCount: 48,
          packInfo: 'প্যাকিং ২ কেজি',
        );
  }

  Future<void> _showAddStockSheet(DokanCatalogProduct item) async {
    final result = await Navigator.of(context).push<_StockAddResult>(
      MaterialPageRoute(
        builder: (_) => DokanProductStockAddScreen(product: item),
      ),
    );

    if (!mounted || result == null) {
      return;
    }

    ref.read(dokanInventoryCatalogProvider.notifier).applyStockAdd(
          item,
          addAmount: result.addAmount,
          purchasePrice: result.purchasePrice,
          referenceText: result.referenceText,
        );
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('স্টক সফলভাবে যোগ করা হয়েছে'),
        backgroundColor: Color(0xFF0C8C67),
        behavior: SnackBarBehavior.floating,
      ),
    );
  }

  Future<void> _openStockReduceScreen(DokanCatalogProduct item) async {
    final result = await Navigator.of(context).push<_StockReduceResult>(
      MaterialPageRoute(
        builder: (_) => DokanProductStockReduceScreen(product: item),
      ),
    );

    if (!mounted || result == null) {
      return;
    }

    ref.read(dokanInventoryCatalogProvider.notifier).applyStockReduce(
          item,
          amount: result.amount,
          reason: result.reason,
        );
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('স্টক সফলভাবে হালনাগাদ হয়েছে'),
        backgroundColor: Color(0xFF0C8C67),
        behavior: SnackBarBehavior.floating,
      ),
    );
  }

  Future<void> _openPriceManagement(DokanCatalogProduct item) async {
    final result = await Navigator.of(context).push<_PriceChangeResult>(
      MaterialPageRoute(
        builder: (_) => DokanProductPriceManagementScreen(product: item),
      ),
    );

    if (!mounted || result == null) {
      return;
    }

    ref.read(dokanInventoryCatalogProvider.notifier).applyPriceChange(
          item,
          purchasePrice: result.purchasePrice,
          salePrice: result.salePrice,
        );
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('দাম সফলভাবে পরিবর্তন করা হয়েছে'),
        backgroundColor: Color(0xFF0C8C67),
        behavior: SnackBarBehavior.floating,
      ),
    );
  }

  void _openHistory(DokanCatalogProduct item) {
    Navigator.of(context).push(
      MaterialPageRoute(
        builder: (_) => DokanFullStockHistoryScreen(product: item),
      ),
    );
  }

  Widget _bottomNav(BuildContext context) {
    return _ProductBottomNav(
      selectedIndex: 2,
      onHomeTap: () => Navigator.of(context).push(
        MaterialPageRoute(builder: (_) => const DokanHomeDashboardScreen()),
      ),
      onSalesTap: () => Navigator.of(context).push(
        MaterialPageRoute(builder: (_) => const DokanPosSalesHistoryScreen()),
      ),
      onProductsTap: () => Navigator.of(context).push(
        MaterialPageRoute(builder: (_) => const DokanProductListScreen()),
      ),
      onReportsTap: () => Navigator.of(context).push(
        MaterialPageRoute(builder: (_) => const DokanReportsHomeScreen()),
      ),
      onMoreTap: () => Navigator.of(context).push(
        MaterialPageRoute(builder: (_) => const DokanAroOptionScreen()),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final item = _item;
    final threshold = ref.watch(stockThresholdProvider);
    final state = _inventoryFor(item);
    final effectiveItem = item.copyWith(
      stock: state.stock,
      purchasePrice: state.purchasePrice,
      salePrice: state.salePrice,
    );
    final stockStatus = _stockStatusLabel(effectiveItem.stock, threshold);
    final stockColor = _stockStatusColor(effectiveItem.stock, threshold);
    final profitPerUnit = effectiveItem.salePrice - effectiveItem.purchasePrice;
    final history = state.historyEntries;

    return DefaultTextStyle.merge(
      style: const TextStyle(fontFamily: 'Hind Siliguri'),
      child: Scaffold(
        backgroundColor: const Color(0xFFF3F8F7),
        body: SafeArea(
          bottom: false,
          child: ListView(
            padding: const EdgeInsets.fromLTRB(16, 12, 16, 16),
            children: [
              Container(
                height: 82,
                padding: const EdgeInsets.symmetric(horizontal: 14),
                decoration: BoxDecoration(
                  color: const Color(0xFFF3FAFB),
                  border: Border.all(color: const Color(0xFFD9E6E2)),
                ),
                child: Row(
                  children: [
                    Material(
                      color: Colors.white,
                      shape: const CircleBorder(),
                      child: InkWell(
                        customBorder: const CircleBorder(),
                        onTap: () => Navigator.of(context).pop(),
                        child: const SizedBox(
                          width: 44,
                          height: 44,
                          child: Icon(Icons.arrow_back, color: Color(0xFF3D4943)),
                        ),
                      ),
                    ),
                    const Expanded(
                      child: Center(
                        child: Text(
                          'পণ্য বিস্তারিত',
                          style: TextStyle(
                            color: Color(0xFF00694C),
                            fontSize: 24,
                            fontWeight: FontWeight.w900,
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(width: 44),
                  ],
                ),
              ),
              const SizedBox(height: 16),
              Container(
                padding: const EdgeInsets.all(18),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(22),
                  border: Border.all(color: const Color(0xFFD9E6E2)),
                ),
                child: Column(
                  children: [
                    Container(
                      width: 72,
                      height: 72,
                      decoration: const BoxDecoration(
                        color: Color(0xFFEAF2F0),
                        shape: BoxShape.circle,
                      ),
                      alignment: Alignment.center,
                      child: Text(effectiveItem.emoji, style: const TextStyle(fontSize: 34)),
                    ),
                    const SizedBox(height: 14),
                    Text(
                      effectiveItem.name,
                      textAlign: TextAlign.center,
                      style: const TextStyle(
                        color: Color(0xFF141F22),
                        fontSize: 22,
                        fontWeight: FontWeight.w900,
                      ),
                    ),
                    const SizedBox(height: 8),
                    Text(
                      '${effectiveItem.category} • ${effectiveItem.brand.isNotEmpty ? effectiveItem.brand : effectiveItem.packInfo}',
                      style: const TextStyle(
                        color: Color(0xFF5F6A66),
                        fontSize: 13,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    const SizedBox(height: 14),
                    Row(
                      children: [
                        Expanded(
                          child: _DetailMiniInfo(
                            title: 'বর্তমান বিক্রয় মূল্য',
                            value: _currency(effectiveItem.salePrice),
                          ),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: _DetailMiniInfo(
                            title: 'বর্তমান ক্রয় মূল্য',
                            value: _currency(effectiveItem.purchasePrice),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 16),
              Container(
                padding: const EdgeInsets.all(18),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(22),
                  border: Border.all(color: const Color(0xFFD9E6E2)),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text(
                      'স্টক সতর্কতা সীমা',
                      style: TextStyle(
                        color: Color(0xFF141F22),
                        fontSize: 20,
                        fontWeight: FontWeight.w900,
                      ),
                    ),
                    const SizedBox(height: 12),
                    _DetailInfoRow(
                      label: 'সীমা',
                      value: '${_bnDigits(threshold.toString())}টি',
                    ),
                    const SizedBox(height: 10),
                    Text(
                      'স্টক ${_bnDigits(threshold.toString())}টির নিচে গেলে সতর্কতা আসবে',
                      style: TextStyle(
                        color: Color(0xFF5F6A66),
                        fontSize: 14,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 16),
              Container(
                padding: const EdgeInsets.all(18),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(22),
                  border: Border.all(color: const Color(0xFFD9E6E2)),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text(
                      'স্টক তথ্য',
                      style: TextStyle(
                        color: Color(0xFF141F22),
                        fontSize: 20,
                        fontWeight: FontWeight.w900,
                      ),
                    ),
                    const SizedBox(height: 14),
                    _DetailInfoRow(label: 'বর্তমান স্টক', value: '${_bnDigits(effectiveItem.stock.toString())}টি'),
                    const SizedBox(height: 10),
                    _DetailInfoRow(label: 'কম স্টক সীমা', value: '${_bnDigits(threshold.toString())}টি'),
                    const SizedBox(height: 10),
                    _DetailInfoRow(label: 'স্ট্যাটাস', value: stockStatus, valueColor: stockColor),
                  ],
                ),
              ),
              const SizedBox(height: 16),
              Container(
                padding: const EdgeInsets.all(18),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(22),
                  border: Border.all(color: const Color(0xFFD9E6E2)),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text(
                      'বিক্রয় তথ্য',
                      style: TextStyle(
                        color: Color(0xFF141F22),
                        fontSize: 20,
                        fontWeight: FontWeight.w900,
                      ),
                    ),
                    const SizedBox(height: 14),
                    Row(
                      children: [
                        Expanded(
                          child: _SalesMetricCard(
                            title: 'মোট বিক্রি',
                            value: '${_bnDigits(effectiveItem.salesCount.toString())}টি',
                          ),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: _SalesMetricCard(
                            title: 'মোট আয়',
                            value: _currency(effectiveItem.salesCount * effectiveItem.salePrice),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 12),
                    _SalesMetricCard(
                      title: 'মোট লাভ',
                      value: _currency(profitPerUnit * effectiveItem.salesCount),
                      emphasis: true,
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 16),
              Row(
                children: [
                  Expanded(
                    child: SizedBox(
                      height: 56,
                      child: OutlinedButton(
                        onPressed: () => _showAddStockSheet(effectiveItem),
                        style: OutlinedButton.styleFrom(
                          side: const BorderSide(color: Color(0xFF00694C), width: 1.6),
                          foregroundColor: const Color(0xFF00694C),
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
                        ),
                        child: const Text('স্টক যোগ', style: TextStyle(fontWeight: FontWeight.w900)),
                      ),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: SizedBox(
                      height: 56,
                      child: ElevatedButton(
                        onPressed: () => _openPriceManagement(effectiveItem),
                        style: ElevatedButton.styleFrom(
                          backgroundColor: const Color(0xFF00694C),
                          foregroundColor: Colors.white,
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
                        ),
                        child: const Text('দাম পরিবর্তন', style: TextStyle(fontWeight: FontWeight.w900)),
                      ),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: SizedBox(
                      height: 56,
                      child: OutlinedButton(
                        onPressed: () => _openStockReduceScreen(effectiveItem),
                        style: OutlinedButton.styleFrom(
                          side: const BorderSide(color: Color(0xFFD43B3B), width: 1.6),
                          foregroundColor: const Color(0xFFD43B3B),
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
                        ),
                        child: const Text('স্টক কমান', style: TextStyle(fontWeight: FontWeight.w900)),
                      ),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 16),
              Container(
                padding: const EdgeInsets.all(18),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(22),
                  border: Border.all(color: const Color(0xFFD9E6E2)),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        const Text(
                          'স্টক ইতিহাস',
                          style: TextStyle(
                            color: Color(0xFF141F22),
                            fontSize: 20,
                            fontWeight: FontWeight.w900,
                          ),
                        ),
                        TextButton(
                          onPressed: () => _openHistory(effectiveItem),
                          style: TextButton.styleFrom(
                            foregroundColor: const Color(0xFF00694C),
                          ),
                          child: const Text('সব দেখুন', style: TextStyle(fontWeight: FontWeight.w900)),
                        ),
                      ],
                    ),
                    const SizedBox(height: 12),
                    ...history.take(3).map(
                          (entry) => Padding(
                            padding: const EdgeInsets.only(bottom: 10),
                            child: _StockHistoryTile(entry: entry),
                          ),
                        ),
                  ],
                ),
              ),
              const SizedBox(height: 16),
            ],
          ),
        ),
        bottomNavigationBar: _bottomNav(context),
      ),
    );
  }
}

class DokanFullStockHistoryScreen extends StatelessWidget {
  const DokanFullStockHistoryScreen({super.key, required this.product});

  final DokanCatalogProduct product;

  Widget _bottomNav(BuildContext context) {
    return _ProductBottomNav(
      selectedIndex: 2,
      onHomeTap: () => Navigator.of(context).push(
        MaterialPageRoute(builder: (_) => const DokanHomeDashboardScreen()),
      ),
      onSalesTap: () => Navigator.of(context).push(
        MaterialPageRoute(builder: (_) => const DokanPosSalesHistoryScreen()),
      ),
      onProductsTap: () => Navigator.of(context).push(
        MaterialPageRoute(builder: (_) => const DokanProductListScreen()),
      ),
      onReportsTap: () => Navigator.of(context).push(
        MaterialPageRoute(builder: (_) => const DokanReportsHomeScreen()),
      ),
      onMoreTap: () => Navigator.of(context).push(
        MaterialPageRoute(builder: (_) => const DokanAroOptionScreen()),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final state = _inventoryFor(product);
    return Scaffold(
          backgroundColor: const Color(0xFFF3F8F7),
          body: SafeArea(
            bottom: false,
            child: ListView(
              padding: const EdgeInsets.fromLTRB(16, 12, 16, 16),
              children: [
                Container(
                  height: 82,
                  padding: const EdgeInsets.symmetric(horizontal: 14),
                  decoration: BoxDecoration(
                    color: const Color(0xFFF3FAFB),
                    border: Border.all(color: const Color(0xFFD9E6E2)),
                  ),
                  child: Row(
                    children: [
                      Material(
                        color: Colors.white,
                        shape: const CircleBorder(),
                        child: InkWell(
                          customBorder: const CircleBorder(),
                          onTap: () => Navigator.of(context).pop(),
                          child: const SizedBox(
                            width: 44,
                            height: 44,
                            child: Icon(Icons.arrow_back, color: Color(0xFF3D4943)),
                          ),
                        ),
                      ),
                      const Expanded(
                        child: Center(
                          child: Text(
                            'সম্পূর্ণ স্টক ইতিহাস',
                            style: TextStyle(
                              color: Color(0xFF00694C),
                              fontSize: 22,
                              fontWeight: FontWeight.w900,
                            ),
                          ),
                        ),
                      ),
                      const SizedBox(width: 44),
                    ],
                  ),
                ),
                const SizedBox(height: 16),
                Container(
                  padding: const EdgeInsets.all(18),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(22),
                    border: Border.all(color: const Color(0xFFD9E6E2)),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        product.name,
                        style: const TextStyle(
                          color: Color(0xFF141F22),
                          fontSize: 20,
                          fontWeight: FontWeight.w900,
                        ),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        '${product.category} • ${product.packInfo}',
                        style: const TextStyle(
                          color: Color(0xFF5F6A66),
                          fontSize: 14,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                      const SizedBox(height: 14),
                      ...state.historyEntries.map(
                        (entry) => Padding(
                          padding: const EdgeInsets.only(bottom: 10),
                          child: _StockHistoryTile(entry: entry),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
          bottomNavigationBar: _bottomNav(context),
        );
  }
}

class _StepperButton extends StatelessWidget {
  const _StepperButton({
    required this.icon,
    required this.onTap,
    this.active = false,
  });

  final IconData icon;
  final VoidCallback onTap;
  final bool active;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: active ? const Color(0xFF0C8C67) : Colors.white,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
      child: InkWell(
        borderRadius: BorderRadius.circular(14),
        onTap: onTap,
        child: SizedBox(
          width: 42,
          height: 42,
          child: Icon(
            icon,
            color: active ? Colors.white : const Color(0xFF3D4943),
            size: 22,
          ),
        ),
      ),
    );
  }
}

class _MiniFormField extends StatelessWidget {
  const _MiniFormField({
    required this.label,
    required this.controller,
    required this.hintText,
    this.keyboardType,
    this.onChanged,
  });

  final String label;
  final TextEditingController controller;
  final String hintText;
  final TextInputType? keyboardType;
  final ValueChanged<String>? onChanged;

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label,
          style: const TextStyle(
            color: Color(0xFF141F22),
            fontSize: 14,
            fontWeight: FontWeight.w800,
          ),
        ),
        const SizedBox(height: 8),
        TextField(
          controller: controller,
          keyboardType: keyboardType,
          onChanged: onChanged,
          style: const TextStyle(
            color: Color(0xFF141F22),
            fontWeight: FontWeight.w700,
          ),
          decoration: InputDecoration(
            hintText: hintText,
            hintStyle: const TextStyle(
              color: Color(0xFF6F7D78),
              fontWeight: FontWeight.w600,
            ),
            filled: true,
            fillColor: const Color(0xFFF4F8F7),
            contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(16),
              borderSide: const BorderSide(color: Color(0xFFD9E6E2)),
            ),
            enabledBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(16),
              borderSide: const BorderSide(color: Color(0xFFD9E6E2)),
            ),
            focusedBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(16),
              borderSide: const BorderSide(color: Color(0xFF00694C), width: 1.5),
            ),
          ),
        ),
      ],
    );
  }
}

class DokanProductStockReduceScreen extends StatefulWidget {
  const DokanProductStockReduceScreen({super.key, required this.product});

  final DokanCatalogProduct product;

  @override
  State<DokanProductStockReduceScreen> createState() => _DokanProductStockReduceScreenState();
}

class _DokanProductStockReduceScreenState extends State<DokanProductStockReduceScreen> {
  final TextEditingController _amountController = TextEditingController(text: '1');
  String _reason = 'ক্ষতিগ্রস্ত';
  String? _errorText;

  @override
  void dispose() {
    _amountController.dispose();
    super.dispose();
  }

  void _save(int currentStock) {
    final amount = int.tryParse(_amountController.text.trim()) ?? 0;
    if (amount <= 0) {
      setState(() => _errorText = 'কমানোর পরিমাণ অবশ্যই ১ বা তার বেশি হতে হবে');
      return;
    }
    if (amount > currentStock) {
      setState(() => _errorText = 'স্টকের চেয়ে বেশি কমানো যাবে না');
      return;
    }

    Navigator.of(context).pop(
      _StockReduceResult(amount: amount, reason: _reason),
    );
  }

  Widget _buildHeader(BuildContext context) {
    return Container(
      height: 82,
      padding: const EdgeInsets.symmetric(horizontal: 14),
      decoration: BoxDecoration(
        color: const Color(0xFFF3FAFB),
        border: Border.all(color: const Color(0xFFD9E6E2)),
      ),
      child: Row(
        children: [
          Material(
            color: Colors.white,
            shape: const CircleBorder(),
            child: InkWell(
              customBorder: const CircleBorder(),
              onTap: () => Navigator.of(context).pop(),
              child: const SizedBox(
                width: 44,
                height: 44,
                child: Icon(Icons.arrow_back, color: Color(0xFF3D4943)),
              ),
            ),
          ),
          const Expanded(
            child: Center(
              child: Text(
                'স্টক কমান',
                style: TextStyle(
                  color: Color(0xFF00694C),
                  fontSize: 24,
                  fontWeight: FontWeight.w900,
                ),
              ),
            ),
          ),
          const SizedBox(width: 44),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final state = _inventoryFor(widget.product);
    final currentStock = state.stock;
    final amount = int.tryParse(_amountController.text.trim()) ?? 0;
    final remaining = currentStock - amount;
    final validRemaining = remaining >= 0 ? remaining : 0;

    return DefaultTextStyle.merge(
          style: const TextStyle(fontFamily: 'Hind Siliguri'),
          child: Scaffold(
            backgroundColor: const Color(0xFFF3F8F7),
            body: SafeArea(
              bottom: false,
              child: ListView(
                padding: const EdgeInsets.fromLTRB(16, 12, 16, 16),
                children: [
                  _buildHeader(context),
                  const SizedBox(height: 16),
                  Container(
                    padding: const EdgeInsets.all(18),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(22),
                      border: Border.all(color: const Color(0xFFD9E6E2)),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          widget.product.name,
                          style: const TextStyle(
                            color: Color(0xFF141F22),
                            fontSize: 20,
                            fontWeight: FontWeight.w900,
                          ),
                        ),
                        const SizedBox(height: 6),
                        Text(
                          'বর্তমান স্টক: ${_bnDigits(currentStock.toString())}টি',
                          style: const TextStyle(
                            color: Color(0xFF5F6A66),
                            fontSize: 14,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 16),
                  Container(
                    padding: const EdgeInsets.all(18),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(22),
                      border: Border.all(color: const Color(0xFFD9E6E2)),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text(
                          'কমানোর পরিমাণ',
                          style: TextStyle(
                            color: Color(0xFF141F22),
                            fontSize: 20,
                            fontWeight: FontWeight.w900,
                          ),
                        ),
                        const SizedBox(height: 12),
                        TextField(
                          controller: _amountController,
                          keyboardType: TextInputType.number,
                          inputFormatters: [FilteringTextInputFormatter.digitsOnly],
                          onChanged: (value) {
                            if (_errorText != null) {
                              setState(() => _errorText = null);
                            } else {
                              setState(() {});
                            }
                          },
                          style: const TextStyle(
                            color: Color(0xFF141F22),
                            fontWeight: FontWeight.w700,
                          ),
                          decoration: InputDecoration(
                            hintText: '০',
                            hintStyle: const TextStyle(
                              color: Color(0xFF6F7D78),
                              fontWeight: FontWeight.w600,
                            ),
                            filled: true,
                            fillColor: const Color(0xFFF4F8F7),
                            contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
                            errorText: _errorText,
                            border: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(16),
                              borderSide: const BorderSide(color: Color(0xFFD9E6E2)),
                            ),
                            enabledBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(16),
                              borderSide: BorderSide(
                                color: _errorText == null ? const Color(0xFFD9E6E2) : const Color(0xFFD43B3B),
                              ),
                            ),
                            focusedBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(16),
                              borderSide: const BorderSide(color: Color(0xFF00694C), width: 1.5),
                            ),
                          ),
                        ),
                        const SizedBox(height: 14),
                        const Text(
                          'কারণ নির্বাচন',
                          style: TextStyle(
                            color: Color(0xFF141F22),
                            fontSize: 15,
                            fontWeight: FontWeight.w800,
                          ),
                        ),
                        const SizedBox(height: 10),
                        DropdownButtonFormField<String>(
                          initialValue: _reason,
                          dropdownColor: Colors.white,
                          items: const [
                            DropdownMenuItem(value: 'ক্ষতিগ্রস্ত', child: Text('ক্ষতিগ্রস্ত')),
                            DropdownMenuItem(value: 'মেয়াদোত্তীর্ণ', child: Text('মেয়াদোত্তীর্ণ')),
                            DropdownMenuItem(value: 'হারিয়ে গেছে', child: Text('হারিয়ে গেছে')),
                            DropdownMenuItem(value: 'নমুনা ব্যবহার', child: Text('নমুনা ব্যবহার')),
                            DropdownMenuItem(value: 'অন্যান্য', child: Text('অন্যান্য')),
                          ],
                          onChanged: (value) {
                            if (value == null) return;
                            setState(() => _reason = value);
                          },
                          decoration: InputDecoration(
                            filled: true,
                            fillColor: Colors.white,
                            contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
                            border: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(16),
                              borderSide: const BorderSide(color: Color(0xFFD9E6E2)),
                            ),
                            enabledBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(16),
                              borderSide: const BorderSide(color: Color(0xFFD9E6E2)),
                            ),
                            focusedBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(16),
                              borderSide: const BorderSide(color: Color(0xFF00694C), width: 1.5),
                            ),
                          ),
                          style: const TextStyle(
                            color: Color(0xFF141F22),
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 16),
                  Container(
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      color: const Color(0xFFEAF7F0),
                      borderRadius: BorderRadius.circular(22),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text(
                          'লাইভ প্রিভিউ',
                          style: TextStyle(
                            color: Color(0xFF141F22),
                            fontSize: 18,
                            fontWeight: FontWeight.w900,
                          ),
                        ),
                        const SizedBox(height: 12),
                        _DetailInfoRow(
                          label: 'বর্তমান স্টক',
                          value: '${_bnDigits(currentStock.toString())}টি',
                        ),
                        const SizedBox(height: 8),
                        _DetailInfoRow(
                          label: 'কমবে',
                          value: '-${_bnDigits(amount.toString())}টি',
                          valueColor: const Color(0xFFD43B3B),
                        ),
                        const SizedBox(height: 8),
                        _DetailInfoRow(
                          label: 'অবশিষ্ট',
                          value: '${_bnDigits(validRemaining.toString())}টি',
                          valueColor: const Color(0xFF0C8C67),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 16),
                  Row(
                    children: [
                      Expanded(
                        child: OutlinedButton(
                          onPressed: () => Navigator.of(context).pop(),
                          style: OutlinedButton.styleFrom(
                            side: const BorderSide(color: Color(0xFFC5D4CF), width: 1.4),
                            foregroundColor: const Color(0xFF3D4943),
                            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                            minimumSize: const Size.fromHeight(52),
                          ),
                          child: const Text('বাতিল', style: TextStyle(fontWeight: FontWeight.w900)),
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: ElevatedButton(
                          onPressed: () => _save(currentStock),
                          style: ElevatedButton.styleFrom(
                            backgroundColor: const Color(0xFFD43B3B),
                            foregroundColor: Colors.white,
                            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                            minimumSize: const Size.fromHeight(52),
                          ),
                          child: const Text('স্টক কমান', style: TextStyle(fontWeight: FontWeight.w900)),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
            bottomNavigationBar: _ProductBottomNav(
              selectedIndex: 2,
              onHomeTap: () => Navigator.of(context).push(
                MaterialPageRoute(builder: (_) => const DokanHomeDashboardScreen()),
              ),
              onSalesTap: () => Navigator.of(context).push(
                MaterialPageRoute(builder: (_) => const DokanPosSalesHistoryScreen()),
              ),
              onProductsTap: () => Navigator.of(context).push(
                MaterialPageRoute(builder: (_) => const DokanProductListScreen()),
              ),
              onReportsTap: () => Navigator.of(context).push(
                MaterialPageRoute(builder: (_) => const DokanReportsHomeScreen()),
              ),
              onMoreTap: () => Navigator.of(context).push(
                MaterialPageRoute(builder: (_) => const DokanAroOptionScreen()),
              ),
            ),
          ),
        );
  }
}

class DokanProductPriceManagementScreen extends StatefulWidget {
  const DokanProductPriceManagementScreen({super.key, required this.product});

  final DokanCatalogProduct product;

  @override
  State<DokanProductPriceManagementScreen> createState() => _DokanProductPriceManagementScreenState();
}

class _DokanProductPriceManagementScreenState extends State<DokanProductPriceManagementScreen> {
  late final TextEditingController _purchaseController;
  late final TextEditingController _saleController;
  String? _errorText;

  @override
  void initState() {
    super.initState();
    _purchaseController = TextEditingController(text: widget.product.purchasePrice.toString());
    _saleController = TextEditingController(text: widget.product.salePrice.toString());
  }

  @override
  void dispose() {
    _purchaseController.dispose();
    _saleController.dispose();
    super.dispose();
  }

  void _save() {
    final purchase = int.tryParse(_purchaseController.text.trim()) ?? 0;
    final sale = int.tryParse(_saleController.text.trim()) ?? 0;

    if (purchase <= 0 || sale <= 0) {
      setState(() => _errorText = 'নতুন ক্রয় ও বিক্রয় মূল্য সঠিকভাবে দিন');
      return;
    }
    if (sale < purchase) {
      setState(() => _errorText = 'বিক্রয় মূল্য ক্রয় মূল্যের চেয়ে কম হতে পারে না');
      return;
    }

    Navigator.of(context).pop(
      _PriceChangeResult(
        purchasePrice: purchase,
        salePrice: sale,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final state = _inventoryFor(widget.product);
    final purchase = int.tryParse(_purchaseController.text.trim()) ?? state.purchasePrice;
    final sale = int.tryParse(_saleController.text.trim()) ?? state.salePrice;
    final profit = sale - purchase;
    final profitPercent = purchase > 0 ? ((profit / purchase) * 100).round() : 0;

    return DefaultTextStyle.merge(
          style: const TextStyle(fontFamily: 'Hind Siliguri'),
          child: Scaffold(
            backgroundColor: const Color(0xFFF3F8F7),
            body: SafeArea(
              bottom: false,
              child: ListView(
                padding: const EdgeInsets.fromLTRB(16, 12, 16, 16),
                children: [
                  Container(
                    height: 82,
                    padding: const EdgeInsets.symmetric(horizontal: 14),
                    decoration: BoxDecoration(
                      color: const Color(0xFFF3FAFB),
                      border: Border.all(color: const Color(0xFFD9E6E2)),
                    ),
                    child: Row(
                      children: [
                        Material(
                          color: Colors.white,
                          shape: const CircleBorder(),
                          child: InkWell(
                            customBorder: const CircleBorder(),
                            onTap: () => Navigator.of(context).pop(),
                            child: const SizedBox(
                              width: 44,
                              height: 44,
                              child: Icon(Icons.arrow_back, color: Color(0xFF3D4943)),
                            ),
                          ),
                        ),
                        const Expanded(
                          child: Center(
                            child: Text(
                              'দাম পরিবর্তন',
                              style: TextStyle(
                                color: Color(0xFF00694C),
                                fontSize: 24,
                                fontWeight: FontWeight.w900,
                              ),
                            ),
                          ),
                        ),
                        const SizedBox(width: 44),
                      ],
                    ),
                  ),
                  const SizedBox(height: 16),
                  Container(
                    padding: const EdgeInsets.all(18),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(22),
                      border: Border.all(color: const Color(0xFFD9E6E2)),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          widget.product.name,
                          style: const TextStyle(
                            color: Color(0xFF141F22),
                            fontSize: 20,
                            fontWeight: FontWeight.w900,
                          ),
                        ),
                        const SizedBox(height: 10),
                        Row(
                          children: [
                            Expanded(
                              child: _DetailMiniInfo(
                                title: 'বর্তমান ক্রয় মূল্য',
                                value: _currency(state.purchasePrice),
                              ),
                            ),
                            const SizedBox(width: 12),
                            Expanded(
                              child: _DetailMiniInfo(
                                title: 'বর্তমান বিক্রয় মূল্য',
                                value: _currency(state.salePrice),
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 16),
                  Container(
                    padding: const EdgeInsets.all(18),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(22),
                      border: Border.all(color: const Color(0xFFD9E6E2)),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text(
                          'নতুন দাম লিখুন',
                          style: TextStyle(
                            color: Color(0xFF141F22),
                            fontSize: 20,
                            fontWeight: FontWeight.w900,
                          ),
                        ),
                        const SizedBox(height: 12),
                        Row(
                          children: [
                            Expanded(
                              child: _MiniFormField(
                                label: 'নতুন ক্রয় মূল্য',
                                controller: _purchaseController,
                                hintText: '০',
                                keyboardType: TextInputType.number,
                                onChanged: (_) {
                                  if (_errorText != null) {
                                    setState(() => _errorText = null);
                                  }
                                },
                              ),
                            ),
                            const SizedBox(width: 12),
                            Expanded(
                              child: _MiniFormField(
                                label: 'নতুন বিক্রয় মূল্য',
                                controller: _saleController,
                                hintText: '০',
                                keyboardType: TextInputType.number,
                                onChanged: (_) {
                                  if (_errorText != null) {
                                    setState(() => _errorText = null);
                                  }
                                },
                              ),
                            ),
                          ],
                        ),
                        if (_errorText != null) ...[
                          const SizedBox(height: 12),
                          Text(
                            _errorText!,
                            style: const TextStyle(
                              color: Color(0xFFD43B3B),
                              fontSize: 13,
                              fontWeight: FontWeight.w800,
                            ),
                          ),
                        ],
                      ],
                    ),
                  ),
                  const SizedBox(height: 16),
                  Container(
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      color: const Color(0xFFEAF7F0),
                      borderRadius: BorderRadius.circular(22),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text(
                          'রিয়েল-টাইম হিসাব',
                          style: TextStyle(
                            color: Color(0xFF141F22),
                            fontSize: 18,
                            fontWeight: FontWeight.w900,
                          ),
                        ),
                        const SizedBox(height: 12),
                        _DetailInfoRow(
                          label: 'ক্রয় মূল্য',
                          value: _currency(purchase > 0 ? purchase : state.purchasePrice),
                        ),
                        const SizedBox(height: 8),
                        _DetailInfoRow(
                          label: 'বিক্রয় মূল্য',
                          value: _currency(sale > 0 ? sale : state.salePrice),
                        ),
                        const SizedBox(height: 8),
                        _DetailInfoRow(
                          label: 'মুনাফা',
                          value: _currency(profit),
                          valueColor: profit >= 0 ? const Color(0xFF0C8C67) : const Color(0xFFD43B3B),
                        ),
                        const SizedBox(height: 8),
                        _DetailInfoRow(
                          label: 'মুনাফার শতাংশ',
                          value: '${_bnDigits(profitPercent.toString())}%',
                          valueColor: const Color(0xFF00694C),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 16),
                  Row(
                    children: [
                      Expanded(
                        child: OutlinedButton(
                          onPressed: () => Navigator.of(context).pop(),
                          style: OutlinedButton.styleFrom(
                            side: const BorderSide(color: Color(0xFFC5D4CF), width: 1.4),
                            foregroundColor: const Color(0xFF3D4943),
                            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                            minimumSize: const Size.fromHeight(52),
                          ),
                          child: const Text('বাতিল', style: TextStyle(fontWeight: FontWeight.w900)),
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: ElevatedButton(
                          onPressed: _save,
                          style: ElevatedButton.styleFrom(
                            backgroundColor: const Color(0xFF00694C),
                            foregroundColor: Colors.white,
                            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                            minimumSize: const Size.fromHeight(52),
                          ),
                          child: const Text('দাম সংরক্ষণ করুন', style: TextStyle(fontWeight: FontWeight.w900)),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
            bottomNavigationBar: _ProductBottomNav(
              selectedIndex: 2,
              onHomeTap: () => Navigator.of(context).push(
                MaterialPageRoute(builder: (_) => const DokanHomeDashboardScreen()),
              ),
              onSalesTap: () => Navigator.of(context).push(
                MaterialPageRoute(builder: (_) => const DokanPosSalesHistoryScreen()),
              ),
              onProductsTap: () => Navigator.of(context).push(
                MaterialPageRoute(builder: (_) => const DokanProductListScreen()),
              ),
              onReportsTap: () => Navigator.of(context).push(
                MaterialPageRoute(builder: (_) => const DokanReportsHomeScreen()),
              ),
              onMoreTap: () => Navigator.of(context).push(
                MaterialPageRoute(builder: (_) => const DokanAroOptionScreen()),
              ),
            ),
          ),
        );
  }
}

class _HeaderIconButton extends StatelessWidget {
  const _HeaderIconButton({
    required this.icon,
    required this.onTap,
  });

  final IconData icon;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.white,
      shape: const CircleBorder(),
      child: InkWell(
        customBorder: const CircleBorder(),
        onTap: onTap,
        child: SizedBox(
          width: 44,
          height: 44,
          child: Icon(icon, color: const Color(0xFF3D4943)),
        ),
      ),
    );
  }
}

class _ProductBottomNav extends StatelessWidget {
  const _ProductBottomNav({
    required this.selectedIndex,
    // ignore: unused_element
    VoidCallback? onHomeTap,
    VoidCallback? onSalesTap,
    VoidCallback? onProductsTap,
    VoidCallback? onReportsTap,
    VoidCallback? onMoreTap,
  });
  final int selectedIndex;

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      top: false,
      child: Container(
        padding: const EdgeInsets.fromLTRB(14, 12, 14, 12),
        decoration: const BoxDecoration(
          color: Color(0xFFEAF2F0),
          border: Border(top: BorderSide(color: Color(0xFFD7E5E0))),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            _ProductNavItem(
              icon: Icons.home_outlined,
              label: '\u09b9\u09cb\u09ae',
              selected: selectedIndex == 0,
              onTap: () => Navigator.of(context).popUntil((r) => r.isFirst),
            ),
            _ProductNavItem(
              icon: Icons.point_of_sale_outlined,
              label: '\u09ac\u09bf\u0995\u09cd\u09b0\u09af\u09bc',
              selected: selectedIndex == 1,
              onTap: () => Navigator.of(context).pushReplacement(
                MaterialPageRoute(builder: (_) => const DokanPosMainScreen()),
              ),
            ),
            _ProductNavItem(
              icon: Icons.inventory_2_outlined,
              label: '\u09aa\u09a3\u09cd\u09af',
              selected: selectedIndex == 2,
              onTap: () {},
            ),
            _ProductNavItem(
              icon: Icons.bar_chart_outlined,
              label: '\u09b0\u09bf\u09aa\u09cb\u09b0\u09cd\u099f',
              selected: selectedIndex == 3,
              onTap: () => Navigator.of(context).pushReplacement(
                MaterialPageRoute(builder: (_) => const DokanReportsHomeScreen()),
              ),
            ),
            _ProductNavItem(
              icon: Icons.more_horiz,
              label: '\u0986\u09b0\u0993',
              selected: selectedIndex == 4,
              onTap: () => Navigator.of(context).pushReplacement(
                MaterialPageRoute(builder: (_) => const DokanAroOptionScreen()),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _ProductNavItem extends StatelessWidget {
  const _ProductNavItem({
    required this.icon,
    required this.label,
    required this.selected,
    required this.onTap,
  });

  final IconData icon;
  final String label;
  final bool selected;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final color = selected ? const Color(0xFF00694C) : const Color(0xFF3D4943);
    return Expanded(
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: onTap,
          borderRadius: BorderRadius.circular(14),
          child: Padding(
            padding: const EdgeInsets.symmetric(vertical: 4),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(icon, color: color, size: 28),
                const SizedBox(height: 4),
                Text(
                  label,
                  style: TextStyle(
                    color: color,
                    fontSize: 13,
                    fontWeight: FontWeight.w800,
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _DetailMiniInfo extends StatelessWidget {
  const _DetailMiniInfo({
    required this.title,
    required this.value,
  });

  final String title;
  final String value;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: const Color(0xFFF4F8F7),
        borderRadius: BorderRadius.circular(16),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            title,
            style: const TextStyle(
              color: Color(0xFF5F6A66),
              fontSize: 13,
              fontWeight: FontWeight.w700,
            ),
          ),
          const SizedBox(height: 8),
          Text(
            value,
            style: const TextStyle(
              color: Color(0xFF141F22),
              fontSize: 18,
              fontWeight: FontWeight.w900,
            ),
          ),
        ],
      ),
    );
  }
}

class _DetailInfoRow extends StatelessWidget {
  const _DetailInfoRow({
    required this.label,
    required this.value,
    this.valueColor = const Color(0xFF141F22),
  });

  final String label;
  final String value;
  final Color valueColor;

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(
          label,
          style: const TextStyle(
            color: Color(0xFF5F6A66),
            fontSize: 15,
            fontWeight: FontWeight.w700,
          ),
        ),
        Text(
          value,
          style: TextStyle(
            color: valueColor,
            fontSize: 16,
            fontWeight: FontWeight.w900,
          ),
        ),
      ],
    );
  }
}

class _SalesMetricCard extends StatelessWidget {
  const _SalesMetricCard({
    required this.title,
    required this.value,
    this.emphasis = false,
  });

  final String title;
  final String value;
  final bool emphasis;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: emphasis ? const Color(0xFFEAF7F0) : const Color(0xFFF4F8F7),
        borderRadius: BorderRadius.circular(16),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            title,
            style: const TextStyle(
              color: Color(0xFF5F6A66),
              fontSize: 13,
              fontWeight: FontWeight.w700,
            ),
          ),
          const SizedBox(height: 6),
          Text(
            value,
            style: TextStyle(
              color: emphasis ? const Color(0xFF0C8C67) : const Color(0xFF141F22),
              fontSize: emphasis ? 22 : 18,
              fontWeight: FontWeight.w900,
            ),
          ),
        ],
      ),
    );
  }
}

class _StockHistoryTile extends StatelessWidget {
  const _StockHistoryTile({required this.entry});

  final _ProductHistoryEntry entry;

  @override
  Widget build(BuildContext context) {
    final icon = entry.amount.startsWith('+')
        ? Icons.add
        : entry.amount.startsWith('-')
            ? Icons.remove
            : Icons.sync;

    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: const Color(0xFFD9E6E2)),
      ),
      child: Row(
        children: [
          Container(
            width: 40,
            height: 40,
            decoration: BoxDecoration(
              color: entry.color.withValues(alpha: 0.12),
              shape: BoxShape.circle,
            ),
            alignment: Alignment.center,
            child: Icon(icon, color: entry.color, size: 20),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  '${entry.label} ${entry.amount}',
                  style: const TextStyle(
                    color: Color(0xFF141F22),
                    fontSize: 15,
                    fontWeight: FontWeight.w900,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  entry.timeLabel,
                  style: const TextStyle(
                    color: Color(0xFF6F7D78),
                    fontSize: 13,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ],
            ),
          ),
          const Icon(Icons.chevron_right, color: Color(0xFF6F7D78), size: 24),
        ],
      ),
    );
  }
}

class DokanProductEditScreen extends StatelessWidget {
  const DokanProductEditScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return const DokanPlaceholderScreen(
      title: 'DokanERP Product Edit Screen',
      subtitle: 'Edit existing product information.',
    );
  }
}

class DokanBarcodeScannerScreen extends StatelessWidget {
  const DokanBarcodeScannerScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return const DokanPlaceholderScreen(
      title: 'DokanERP Barcode Scenner',
      subtitle: 'Camera-based barcode scanning screen.',
    );
  }
}

class DokanCustomProductAddScreen extends StatelessWidget {
  const DokanCustomProductAddScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return const DokanPlaceholderScreen(
      title: 'DokanERP Custom Product Add',
      subtitle: 'Add custom products not present in master DB.',
    );
  }
}

class DokanAddProductMasterDbScreen extends StatelessWidget {
  const DokanAddProductMasterDbScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return const DokanPlaceholderScreen(
      title: 'DokanERP Add Product (Master DB)',
      subtitle: 'Add product from the master database.',
    );
  }
}

class DokanLowStockAlertScreen extends ConsumerStatefulWidget {
  const DokanLowStockAlertScreen({super.key});

  @override
  ConsumerState<DokanLowStockAlertScreen> createState() => _DokanLowStockAlertScreenState();
}

class _DokanLowStockAlertScreenState extends ConsumerState<DokanLowStockAlertScreen> {
  void _setFilter(_LowStockAlertFilter filter) {
    ref.read(dokanLowStockFilterProvider.notifier).setFilter(filter);
  }

  List<DokanCatalogProduct> _filteredProducts(List<DokanCatalogProduct> products) {
    final filter = ref.watch(dokanLowStockFilterProvider);
    final alertThreshold = ref.watch(stockThresholdProvider);
    final alertItems = products.where((product) {
      final isLow = product.stock > 0 && product.stock < alertThreshold;
      final isOut = product.stock <= 0;
      return switch (filter) {
        _LowStockAlertFilter.all => isLow || isOut,
        _LowStockAlertFilter.lowStock => isLow,
        _LowStockAlertFilter.outOfStock => isOut,
      };
    }).toList();
    alertItems.sort((a, b) => a.stock.compareTo(b.stock));
    return alertItems;
  }

  Color _statusColor(DokanCatalogProduct product, int threshold) {
    final limit = threshold > 0 ? threshold : 5;
    final maxValue = (limit * 2).clamp(1, 1000000);
    final progress = ((product.stock / maxValue) * 100).clamp(0, 100).toInt();
    if (progress <= 0) return const Color(0xFFD43B3B);
    if (progress <= 30) return const Color(0xFFB71C1C);
    if (progress <= 60) return const Color(0xFFF49B1A);
    return const Color(0xFF0C8C67);
  }

  double _progressValue(DokanCatalogProduct product, int threshold) {
    final limit = threshold > 0 ? threshold : 5;
    final maxValue = (limit * 2).clamp(1, 1000000);
    return (product.stock / maxValue).clamp(0, 1).toDouble();
  }

  Future<void> _openStockAdd(DokanCatalogProduct product) async {
    final result = await Navigator.of(context).push<_StockAddResult>(
      MaterialPageRoute(builder: (_) => DokanProductStockAddScreen(product: product)),
    );
    if (!mounted || result == null) return;
    ref.read(dokanInventoryCatalogProvider.notifier).applyStockAdd(
          product,
          addAmount: result.addAmount,
          purchasePrice: result.purchasePrice,
          referenceText: result.referenceText,
        );
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('স্টক সফলভাবে যোগ করা হয়েছে'),
        backgroundColor: Color(0xFF0C8C67),
        behavior: SnackBarBehavior.floating,
      ),
    );
  }

  Future<void> _openOrderPreview() async {
    final products = ref.read(dokanInventoryCatalogProvider);
    final threshold = ref.read(stockThresholdProvider);
    final previewItems = products
        .where((product) => product.stock <= 0 || product.stock < threshold)
        .toList();
    await Navigator.of(context).push(
      MaterialPageRoute(
        builder: (_) => DokanPurchaseOrderPreviewScreen(products: previewItems, threshold: threshold),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {

    final flow = ref.watch(dokanAppFlowProvider);
final isSalesman = flow.isSalesman;

    final catalogProducts = ref.watch(dokanInventoryCatalogProvider);
    final alertThreshold = ref.watch(stockThresholdProvider);
    final lowStockProducts = ref.watch(lowStockProvider);
    final outOfStockProducts = catalogProducts.where((product) => product.stock <= 0).toList();
    final alertItems = _filteredProducts(catalogProducts);
    final filter = ref.watch(dokanLowStockFilterProvider);

    return Scaffold(
      backgroundColor: const Color(0xFFF3F8F7),
      appBar: AppBar(
        backgroundColor: const Color(0xFFF3FAFB),
        elevation: 0,
        foregroundColor: const Color(0xFF111111),
        leading: IconButton(
          onPressed: () => Navigator.of(context).maybePop(),
          icon: const Icon(Icons.arrow_back, color: Color(0xFF3D4943)),
        ),
        title: const Text(
          'কম স্টক সতর্কতা',
          style: TextStyle(
            color: Color(0xFF00694C),
            fontWeight: FontWeight.w900,
          ),
        ),
      ),
      body: Stack(
children: [

  if (isSalesman)
    Container(
      margin: const EdgeInsets.only(bottom: 14),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: const Color(0xFFF0FDF4),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: const Color(0xFFBBF7D0),
        ),
      ),
      child: const Row(
        children: [
          Icon(
            Icons.visibility_outlined,
            color: Color(0xFF16A34A),
          ),
          SizedBox(width: 8),
          Expanded(
            child: Text(
              'সেলসম্যান মোড • আপনি শুধু স্টক দেখতে পারবেন',
              style: TextStyle(
                fontWeight: FontWeight.w600,
              ),
            ),
          ),
        ],
      ),
    ),

  _InventoryPageCard(
    title: 'সারসংক্ষেপ',
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Expanded(
              child: _SummaryPill(
                label: 'কম স্টক',
                value: '${_bnDigits(lowStockProducts.length.toString())}টি',
                color: const Color(0xFFF49B1A),
              ),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: _SummaryPill(
                label: 'স্টক নেই',
                value: '${_bnDigits(outOfStockProducts.length.toString())}টি',
                color: const Color(0xFFD43B3B),
              ),
            ),
          ],
        ),
        const SizedBox(height: 14),
        Container(
          width: double.infinity,
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(
            color: const Color(0xFFEAF7F0),
            borderRadius: BorderRadius.circular(18),
            border: Border.all(
              color: const Color(0xFFD9E6E2),
            ),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'সতর্কতা সীমা: ${_bnDigits(alertThreshold.toString())}টি',
                style: const TextStyle(
                  color: Color(0xFF111111),
                  fontWeight: FontWeight.w800,
                ),
              ),
              const Text(
                'এই সীমার নিচে নতুন সতর্কতা ধরা হবে',
                style: TextStyle(
                  color: Color(0xFF3D4943),
                  fontWeight: FontWeight.w600,
                ),
              ),
              const SizedBox(height: 12),
              SizedBox(
                width: double.infinity,
                height: 50,
                child: ElevatedButton.icon(
                  onPressed: isSalesman
                      ? null
                      : () {
                          Navigator.of(context).push(
                            MaterialPageRoute(
                              builder: (_) =>
                                  DokanThresholdSettingScreen(
                                initialThreshold:
                                    alertThreshold,
                              ),
                            ),
                          );
                        },
                  style: ElevatedButton.styleFrom(
                    backgroundColor:
                        const Color(0xFF0C8C67),
                    foregroundColor: Colors.white,
                    shape: RoundedRectangleBorder(
                      borderRadius:
                          BorderRadius.circular(16),
                    ),
                  ),
                  icon: const Icon(Icons.tune_rounded),
                  label: const Text(
                    'সীমা নির্ধারণ করুন',
                    style: TextStyle(
                      fontWeight: FontWeight.w900,
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ],
    ),
  ),
              const SizedBox(height: 14),
              SingleChildScrollView(
                scrollDirection: Axis.horizontal,
                child: Row(
                  children: [
                    _AlertFilterChip(
                      label: 'সব',
                      selected: filter == _LowStockAlertFilter.all,
                      onTap: () => _setFilter(_LowStockAlertFilter.all),
                    ),
                    const SizedBox(width: 10),
                    _AlertFilterChip(
                      label: 'কম স্টক',
                      selected: filter == _LowStockAlertFilter.lowStock,
                      onTap: () => _setFilter(_LowStockAlertFilter.lowStock),
                    ),
                    const SizedBox(width: 10),
                    _AlertFilterChip(
                      label: 'স্টক নেই',
                      selected: filter == _LowStockAlertFilter.outOfStock,
                      onTap: () => _setFilter(_LowStockAlertFilter.outOfStock),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 14),
              if (alertItems.isEmpty)
                _InventoryPageCard(
                  title: 'বর্তমান অবস্থা',
                  child: Column(
                    children: const [
                      Icon(Icons.check_circle_rounded, color: Color(0xFF0C8C67), size: 54),
                      SizedBox(height: 12),
                      Text(
                        'সব পণ্যের স্টক পর্যাপ্ত আছে',
                        style: TextStyle(
                          color: Color(0xFF111111),
                          fontSize: 18,
                          fontWeight: FontWeight.w900,
                        ),
                        textAlign: TextAlign.center,
                      ),
                      SizedBox(height: 6),
                      Text(
                      'বর্তমানে কোনো সতর্কতা নেই',
                        style: TextStyle(
                          color: Color(0xFF3D4943),
                          fontWeight: FontWeight.w600,
                        ),
                        textAlign: TextAlign.center,
                      ),
                    ],
                  ),
                )
              else
                Column(
                  children: alertItems
                      .map(
                        (product) => Padding(
                          padding: const EdgeInsets.only(bottom: 12),
                          child: _LowStockProductCard(
                            product: product,
                            statusColor: _statusColor(product, alertThreshold),
                            progress: _progressValue(product, alertThreshold),
                            threshold: alertThreshold,
                            onAddStock: isSalesman
    ? null
    : () => _openStockAdd(product),
                          ),
                        ),
                      )
                      .toList(),
                ),
            ],
          ),
          Align(
            alignment: Alignment.bottomCenter,
            child: _BottomActionBar(
              icon: Icons.local_shipping_rounded,
              text: 'সব সরবরাহকারীকেই অর্ডার পাঠান',
              buttonLabel: 'অর্ডার তৈরি করুন',
              onPressed: _openOrderPreview,
            ),
          ),
        ],
      ),
      bottomNavigationBar: _ProductBottomNav(
        selectedIndex: 2,
        onHomeTap: () => Navigator.of(context).push(
          MaterialPageRoute(builder: (_) => const DokanHomeDashboardScreen()),
        ),
        onSalesTap: () => Navigator.of(context).push(
          MaterialPageRoute(builder: (_) => const DokanPosSalesHistoryScreen()),
        ),
        onProductsTap: () => Navigator.of(context).push(
          MaterialPageRoute(builder: (_) => const DokanProductListScreen()),
        ),
        onReportsTap: () => Navigator.of(context).push(
          MaterialPageRoute(builder: (_) => const DokanReportsHomeScreen()),
        ),
        onMoreTap: () => Navigator.of(context).push(
          MaterialPageRoute(builder: (_) => const DokanAroOptionScreen()),
        ),
      ),
    );
  }
}

class DokanCategorySettingsScreen extends ConsumerStatefulWidget {
  const DokanCategorySettingsScreen({super.key});

  @override
  ConsumerState<DokanCategorySettingsScreen> createState() => _DokanCategorySettingsScreenState();
}

class _DokanCategorySettingsScreenState extends ConsumerState<DokanCategorySettingsScreen> {
  final TextEditingController _addController = TextEditingController();
  final TextEditingController _editController = TextEditingController();
  String? _newCategoryError;
  String? _editError;
  String? _editingCategory;
  String? _deletePendingCategory;

  @override
  void dispose() {
    _addController.dispose();
    _editController.dispose();
    super.dispose();
  }

  List<String> _managedCategories(List<String> categories) {
    return categories
        .where((category) => category != DokanCategoryNotifier.uncategorized)
        .toList(growable: false);
  }

  void _showSnackBar(String message, {bool isError = false}) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        backgroundColor: isError ? const Color(0xFFD43B3B) : const Color(0xFF0C8C67),
        behavior: SnackBarBehavior.floating,
      ),
    );
  }

  String? _validateCategoryName(String value, {String? currentName}) {
    final name = value.trim();
    if (name.isEmpty) {
      return 'ক্যাটাগরির নাম দিন';
    }
    if (name.length < 2) {
      return 'কমপক্ষে ২ অক্ষর দিন';
    }
    final categories = ref.read(categoryProvider);
    final duplicate = categories.any((existing) {
      final same = existing.trim().toLowerCase() == name.toLowerCase();
      if (!same) return false;
      if (currentName == null) return true;
      return existing.trim().toLowerCase() != currentName.trim().toLowerCase();
    });
    if (duplicate) {
      return 'এই ক্যাটাগরি আগে থেকেই আছে';
    }
    return null;
  }

  void _saveNewCategory() {
    final value = _addController.text.trim();
    final error = _validateCategoryName(value);
    if (error != null) {
      setState(() => _newCategoryError = error);
      return;
    }
    ref.read(categoryProvider.notifier).addCategory(value);
    setState(() {
      _newCategoryError = null;
      _addController.clear();
    });
    _showSnackBar('ক্যাটাগরি সফলভাবে যোগ করা হয়েছে');
  }

  void _startEdit(String category) {
    if (category == DokanCategoryNotifier.uncategorized) {
      _showSnackBar('এই ক্যাটাগরি পরিবর্তন করা যাবে না', isError: true);
      return;
    }
    FocusScope.of(context).unfocus();
    setState(() {
      _editingCategory = category;
      _deletePendingCategory = null;
      _editError = null;
      _editController.text = category;
    });
  }

  void _cancelEdit() {
    setState(() {
      _editingCategory = null;
      _editError = null;
      _editController.clear();
    });
  }

  void _saveEditCategory(String oldCategory) {
    final value = _editController.text.trim();
    final error = _validateCategoryName(value, currentName: oldCategory);
    if (error != null) {
      setState(() => _editError = error);
      return;
    }
    ref.read(categoryProvider.notifier).updateCategory(oldCategory, value);
    ref.read(dokanInventoryCatalogProvider.notifier).reassignCategory(oldCategory, value);
    setState(() {
      _editingCategory = null;
      _editError = null;
      _editController.clear();
    });
    _showSnackBar('ক্যাটাগরি সফলভাবে হালনাগাদ হয়েছে');
  }

  void _startDelete(String category) {
    if (category == DokanCategoryNotifier.uncategorized) {
      _showSnackBar('এই ক্যাটাগরি মুছা যাবে না', isError: true);
      return;
    }
    FocusScope.of(context).unfocus();
    setState(() {
      _deletePendingCategory = category;
      _editingCategory = null;
      _editError = null;
    });
  }

  void _cancelDelete() {
    setState(() => _deletePendingCategory = null);
  }

  void _confirmDeleteCategory(String category) {
    ref.read(categoryProvider.notifier).deleteCategory(category);
    ref.read(dokanInventoryCatalogProvider.notifier).reassignCategory(
          category,
          DokanCategoryNotifier.uncategorized,
        );
    setState(() {
      _deletePendingCategory = null;
      if (_editingCategory == category) {
        _editingCategory = null;
        _editController.clear();
      }
    });
    _showSnackBar('ক্যাটাগরি সফলভাবে মুছে ফেলা হয়েছে');
  }

  Widget _buildCategoryTile(String category) {
    final isEditing = _editingCategory == category;
    final isDeletePending = _deletePendingCategory == category;
    final isProtected = category == DokanCategoryNotifier.uncategorized;
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: const Color(0xFFD9E6E2)),
      ),
      child: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(14),
            child: Row(
              children: [
                Container(
                  width: 42,
                  height: 42,
                  decoration: BoxDecoration(
                    color: const Color(0xFFEAF7F0),
                    borderRadius: BorderRadius.circular(14),
                  ),
                  child: const Icon(Icons.category_rounded, color: Color(0xFF00694C), size: 22),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        category,
                        style: const TextStyle(
                          color: Color(0xFF111111),
                          fontSize: 16,
                          fontWeight: FontWeight.w900,
                        ),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        isProtected ? 'সিস্টেম ক্যাটাগরি' : 'পণ্য ও ফিল্টারে ব্যবহৃত হয়',
                        style: const TextStyle(
                          color: Color(0xFF5F6A66),
                          fontSize: 12,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ],
                  ),
                ),
                IconButton(
                  onPressed: isProtected ? null : () => _startEdit(category),
                  icon: const Icon(Icons.edit_outlined, color: Color(0xFF00694C)),
                ),
                IconButton(
                  onPressed: isProtected ? null : () => _startDelete(category),
                  icon: const Icon(Icons.delete_outline_rounded, color: Color(0xFFD43B3B)),
                ),
              ],
            ),
          ),
          if (isEditing)
            Container(
              width: double.infinity,
              padding: const EdgeInsets.fromLTRB(14, 0, 14, 14),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  TextField(
                    controller: _editController,
                    autofocus: true,
                    style: const TextStyle(color: Color(0xFF111111), fontWeight: FontWeight.w700),
                    decoration: InputDecoration(
                      hintText: 'নতুন নাম লিখুন',
                      hintStyle: const TextStyle(color: Color(0xFF9BA5A1)),
                      filled: true,
                      fillColor: Colors.white,
                      border: OutlineInputBorder(borderRadius: BorderRadius.circular(16)),
                      enabledBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(16),
                        borderSide: const BorderSide(color: Color(0xFFD9E6E2)),
                      ),
                      focusedBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(16),
                        borderSide: const BorderSide(color: Color(0xFF00694C), width: 1.5),
                      ),
                    ),
                    onChanged: (_) {
                      if (_editError != null) {
                        setState(() => _editError = null);
                      }
                    },
                    onSubmitted: (_) => _saveEditCategory(category),
                  ),
                  if (_editError != null) ...[
                    const SizedBox(height: 8),
                    Text(
                      _editError!,
                      style: const TextStyle(color: Color(0xFFD43B3B), fontWeight: FontWeight.w800),
                    ),
                  ],
                  const SizedBox(height: 12),
                  Row(
                    children: [
                      OutlinedButton(
                        onPressed: _cancelEdit,
                        style: OutlinedButton.styleFrom(
                          foregroundColor: const Color(0xFF3D4943),
                          side: const BorderSide(color: Color(0xFFD9E6E2)),
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                        ),
                        child: const Text('বাতিল', style: TextStyle(fontWeight: FontWeight.w800)),
                      ),
                      const SizedBox(width: 10),
                      Expanded(
                        child: ElevatedButton(
                          onPressed: () => _saveEditCategory(category),
                          style: ElevatedButton.styleFrom(
                            backgroundColor: const Color(0xFF0C8C67),
                            foregroundColor: Colors.white,
                            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                          ),
                          child: const Text('হালনাগাদ করুন', style: TextStyle(fontWeight: FontWeight.w900)),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          if (isDeletePending)
            Container(
              width: double.infinity,
              padding: const EdgeInsets.fromLTRB(14, 0, 14, 14),
              child: Container(
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(
                  color: const Color(0xFFFFF1F1),
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(color: const Color(0xFFF3C2C2)),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text(
                      'এই ক্যাটাগরি মুছবেন?',
                      style: TextStyle(color: Color(0xFFD43B3B), fontWeight: FontWeight.w900),
                    ),
                    const SizedBox(height: 6),
                    Text(
                      '"$category" মুছে দিলে এর পণ্যগুলো "অজানা" ক্যাটাগরিতে চলে যাবে।',
                      style: const TextStyle(color: Color(0xFF3D4943), fontWeight: FontWeight.w600, height: 1.35),
                    ),
                    const SizedBox(height: 12),
                    Row(
                      children: [
                        Expanded(
                          child: OutlinedButton(
                            onPressed: _cancelDelete,
                            style: OutlinedButton.styleFrom(
                              foregroundColor: const Color(0xFF3D4943),
                              side: const BorderSide(color: Color(0xFFD9E6E2)),
                              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                            ),
                            child: const Text('না', style: TextStyle(fontWeight: FontWeight.w800)),
                          ),
                        ),
                        const SizedBox(width: 10),
                        Expanded(
                          child: ElevatedButton(
                            onPressed: () => _confirmDeleteCategory(category),
                            style: ElevatedButton.styleFrom(
                              backgroundColor: const Color(0xFFD43B3B),
                              foregroundColor: Colors.white,
                              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                            ),
                            child: const Text('হ্যাঁ, মুছুন', style: TextStyle(fontWeight: FontWeight.w900)),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final categories = _managedCategories(ref.watch(categoryProvider));
    return Scaffold(
      backgroundColor: const Color(0xFFF3F8F7),
      appBar: AppBar(
        backgroundColor: const Color(0xFFF3FAFB),
        elevation: 0,
        foregroundColor: const Color(0xFF111111),
        title: const Text(
          'ক্যাটাগরি সেটিংস',
          style: TextStyle(
            color: Color(0xFF00694C),
            fontWeight: FontWeight.w900,
          ),
        ),
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        keyboardDismissBehavior: ScrollViewKeyboardDismissBehavior.onDrag,
        children: [
          _InventoryPageCard(
            title: 'নতুন ক্যাটাগরি যোগ করুন',
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                TextField(
                  controller: _addController,
                  style: const TextStyle(color: Color(0xFF111111), fontWeight: FontWeight.w700),
                  decoration: InputDecoration(
                    hintText: 'যেমন: চাল-ডাল',
                    hintStyle: const TextStyle(color: Color(0xFF9BA5A1)),
                    filled: true,
                    fillColor: Colors.white,
                    border: OutlineInputBorder(borderRadius: BorderRadius.circular(16)),
                    enabledBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(16),
                      borderSide: const BorderSide(color: Color(0xFFD9E6E2)),
                    ),
                    focusedBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(16),
                      borderSide: const BorderSide(color: Color(0xFF00694C), width: 1.5),
                    ),
                  ),
                  onChanged: (_) {
                    if (_newCategoryError != null) {
                      setState(() => _newCategoryError = null);
                    }
                  },
                  onSubmitted: (_) => _saveNewCategory(),
                ),
                if (_newCategoryError != null) ...[
                  const SizedBox(height: 8),
                  Text(
                    _newCategoryError!,
                    style: const TextStyle(color: Color(0xFFD43B3B), fontWeight: FontWeight.w800),
                  ),
                ],
                const SizedBox(height: 14),
                SizedBox(
                  height: 52,
                  width: double.infinity,
                  child: ElevatedButton(
                    onPressed: _saveNewCategory,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: const Color(0xFF0C8C67),
                      foregroundColor: Colors.white,
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                    ),
                    child: const Text(
                      'ক্যাটাগরি যোগ করুন',
                      style: TextStyle(fontWeight: FontWeight.w900),
                    ),
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 14),
          _InventoryPageCard(
            title: 'বর্তমান ক্যাটাগরি',
            child: categories.isEmpty
                ? const Padding(
                    padding: EdgeInsets.symmetric(vertical: 8),
                    child: Text(
                      'এখনও কোনো ক্যাটাগরি নেই',
                      style: TextStyle(color: Color(0xFF3D4943), fontWeight: FontWeight.w700),
                    ),
                  )
                : Column(
                    children: categories.map(_buildCategoryTile).toList(),
                  ),
          ),
          const SizedBox(height: 14),
          _InventoryPageCard(
            title: 'ক্যাটাগরি নীতি',
            child: const Text(
              'নতুন ক্যাটাগরি যোগ, সম্পাদনা বা মুছলে পণ্য তালিকা, ফিল্টার, স্টক পেজ এবং সতর্কতা পেজে তা সাথে সাথে update হবে।',
              style: TextStyle(color: Color(0xFF3D4943), fontWeight: FontWeight.w600, height: 1.45),
            ),
          ),
        ],
      ),
      bottomNavigationBar: _ProductBottomNav(
        selectedIndex: 2,
        onHomeTap: () => Navigator.of(context).push(
          MaterialPageRoute(builder: (_) => const DokanHomeDashboardScreen()),
        ),
        onSalesTap: () => Navigator.of(context).push(
          MaterialPageRoute(builder: (_) => const DokanPosSalesHistoryScreen()),
        ),
        onProductsTap: () => Navigator.of(context).push(
          MaterialPageRoute(builder: (_) => const DokanProductListScreen()),
        ),
        onReportsTap: () => Navigator.of(context).push(
          MaterialPageRoute(builder: (_) => const DokanReportsHomeScreen()),
        ),
        onMoreTap: () => Navigator.of(context).push(
          MaterialPageRoute(builder: (_) => const DokanAroOptionScreen()),
        ),
      ),
    );
  }
}
class DokanThresholdSettingScreen extends ConsumerStatefulWidget {
  const DokanThresholdSettingScreen({super.key, this.initialThreshold});

  final int? initialThreshold;

  @override
  ConsumerState<DokanThresholdSettingScreen> createState() => _DokanThresholdSettingScreenState();
}

class _DokanThresholdSettingScreenState extends ConsumerState<DokanThresholdSettingScreen> {
  final TextEditingController _thresholdController = TextEditingController();
  String? _errorText;

  @override
  void initState() {
    super.initState();
    _thresholdController.text = (widget.initialThreshold ?? ref.read(stockThresholdProvider)).toString();
  }

  @override
  void dispose() {
    _thresholdController.dispose();
    super.dispose();
  }

  void _save() {
    final value = int.tryParse(_thresholdController.text.trim());
    if (value == null || value < 1 || value > 99) {
      setState(() => _errorText = '১ থেকে ৯৯ এর মধ্যে সংখ্যা দিন');
      return;
    }
    ref.read(stockThresholdProvider.notifier).setThreshold(value);
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('সতর্কতা সীমা সফলভাবে হালনাগাদ হয়েছে'),
        backgroundColor: Color(0xFF0C8C67),
        behavior: SnackBarBehavior.floating,
      ),
    );
    Navigator.of(context).pop();
  }

  @override
  Widget build(BuildContext context) {
    final threshold = ref.watch(stockThresholdProvider);
    return Scaffold(
      backgroundColor: const Color(0xFFF3F8F7),
      appBar: AppBar(
        backgroundColor: const Color(0xFFF3FAFB),
        elevation: 0,
        foregroundColor: const Color(0xFF111111),
        title: const Text(
          'স্টক সতর্কতা সীমা নির্ধারণ করুন',
          style: TextStyle(
            color: Color(0xFF00694C),
            fontWeight: FontWeight.w900,
          ),
        ),
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          _InventoryPageCard(
            title: 'গ্লোবাল সীমা',
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'বর্তমান সীমা: ${_bnDigits(threshold.toString())}টি',
                  style: const TextStyle(color: Color(0xFF141F22), fontWeight: FontWeight.w900),
                ),
                const SizedBox(height: 10),
                const Text(
                  'এই মান বদলালে সব পণ্য তালিকা, কম স্টক সতর্কতা এবং ড্যাশবোর্ড সাথে সাথে আপডেট হবে।',
                  style: TextStyle(color: Color(0xFF3D4943), fontWeight: FontWeight.w600, height: 1.45),
                ),
                const SizedBox(height: 14),
                TextField(
                  controller: _thresholdController,
                  keyboardType: TextInputType.number,
                  style: const TextStyle(color: Color(0xFF111111), fontWeight: FontWeight.w700),
                  decoration: InputDecoration(
                    hintText: 'যেমন: 5',
                    hintStyle: const TextStyle(color: Color(0xFF111111)),
                    filled: true,
                    fillColor: Colors.white,
                    border: OutlineInputBorder(borderRadius: BorderRadius.circular(16)),
                    enabledBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(16),
                      borderSide: const BorderSide(color: Color(0xFFD9E6E2)),
                    ),
                    focusedBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(16),
                      borderSide: const BorderSide(color: Color(0xFF00694C), width: 1.5),
                    ),
                  ),
                  onChanged: (_) {
                    if (_errorText != null) setState(() => _errorText = null);
                  },
                ),
                if (_errorText != null) ...[
                  const SizedBox(height: 8),
                  Text(
                    _errorText!,
                    style: const TextStyle(color: Color(0xFFD43B3B), fontWeight: FontWeight.w800),
                  ),
                ],
              ],
            ),
          ),
          const SizedBox(height: 14),
          SizedBox(
            height: 52,
            child: ElevatedButton(
              onPressed: _save,
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFF0C8C67),
                foregroundColor: Colors.white,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
              ),
              child: const Text('সংরক্ষণ করুন', style: TextStyle(fontWeight: FontWeight.w900)),
            ),
          ),
        ],
      ),
      bottomNavigationBar: _ProductBottomNav(
        selectedIndex: 2,
        onHomeTap: () => Navigator.of(context).push(
          MaterialPageRoute(builder: (_) => const DokanHomeDashboardScreen()),
        ),
        onSalesTap: () => Navigator.of(context).push(
          MaterialPageRoute(builder: (_) => const DokanPosSalesHistoryScreen()),
        ),
        onProductsTap: () => Navigator.of(context).push(
          MaterialPageRoute(builder: (_) => const DokanProductListScreen()),
        ),
        onReportsTap: () => Navigator.of(context).push(
          MaterialPageRoute(builder: (_) => const DokanReportsHomeScreen()),
        ),
        onMoreTap: () => Navigator.of(context).push(
          MaterialPageRoute(builder: (_) => const DokanAroOptionScreen()),
        ),
      ),
    );
  }
}

class _LedgerGroup {
  const _LedgerGroup(this.title, this.entries);

  final String title;
  final List<DokanStockLedgerEntry> entries;
}

class DokanStockMovementLogScreen extends ConsumerWidget {
  const DokanStockMovementLogScreen({super.key});

  List<_LedgerGroup> _groupEntries(List<DokanStockLedgerEntry> entries) {
    final today = <DokanStockLedgerEntry>[];
    final yesterday = <DokanStockLedgerEntry>[];
    final previous = <DokanStockLedgerEntry>[];
    final currentDay = DateUtils.dateOnly(DateTime.now());
    final previousDay = DateUtils.dateOnly(DateTime.now().subtract(const Duration(days: 1)));

    for (final entry in entries) {
      final day = DateUtils.dateOnly(entry.timestamp);
      if (day == currentDay) {
        today.add(entry);
      } else if (day == previousDay) {
        yesterday.add(entry);
      } else {
        previous.add(entry);
      }
    }

    return <_LedgerGroup>[
      if (today.isNotEmpty) _LedgerGroup('আজকে', today),
      if (yesterday.isNotEmpty) _LedgerGroup('গতকাল', yesterday),
      if (previous.isNotEmpty) _LedgerGroup('পূর্ববর্তী', previous),
    ];
  }

  String _ledgerDateText(DateTime timestamp) {
    final now = DateUtils.dateOnly(DateTime.now());
    final day = DateUtils.dateOnly(timestamp);
    if (day == now) {
      return 'আজ';
    }
    if (day == now.subtract(const Duration(days: 1))) {
      return 'গতকাল';
    }
    return '${_bnDigits(timestamp.day.toString())}/${_bnDigits(timestamp.month.toString())}/${_bnDigits(timestamp.year.toString())}';
  }

  String _ledgerTimeText(DateTime timestamp) {
    final hour24 = timestamp.hour;
    final suffix = hour24 >= 12 ? 'PM' : 'AM';
    final hour12 = hour24 % 12 == 0 ? 12 : hour24 % 12;
    final minute = timestamp.minute.toString().padLeft(2, '0');
    return '${_bnDigits(hour12.toString())}:$minute $suffix';
  }

  String _deltaText(int delta) {
    final sign = delta >= 0 ? '+' : '-';
    return '$sign${_bnDigits(delta.abs().toString())}টি';
  }

  Widget _buildSummaryCard(DokanStockLedgerSummary summary) {
    final changeColor = summary.todayChange >= 0 ? const Color(0xFF0C8C67) : const Color(0xFFD43B3B);
    return _InventoryPageCard(
      title: 'সারসংক্ষেপ',
      child: IntrinsicHeight(
        child: Row(
          children: [
            Expanded(
              child: _SummaryPill(
                label: 'মোট বিক্রয়',
                value: '${_bnDigits(summary.totalSales.toString())}টি',
                color: const Color(0xFFD43B3B),
              ),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: _SummaryPill(
                label: 'আজকের পরিবর্তন',
                value: '${summary.todayChange >= 0 ? '+' : '-'}${_bnDigits(summary.todayChange.abs().toString())}টি',
                color: changeColor,
              ),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: _SummaryPill(
                label: 'মোট ক্রয়',
                value: '${_bnDigits(summary.totalPurchase.toString())}টি',
                color: const Color(0xFF0C8C67),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildEmptyState(BuildContext context) {
    return _InventoryPageCard(
      title: 'লগ তালিকা',
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 28),
        child: Column(
          children: [
            Container(
              width: 64,
              height: 64,
              decoration: BoxDecoration(
                color: const Color(0xFFE5F7ED),
                borderRadius: BorderRadius.circular(20),
              ),
              child: const Icon(Icons.check_circle_rounded, color: Color(0xFF0C8C67), size: 36),
            ),
            const SizedBox(height: 14),
            const Text(
              'কোনো স্টক মুভমেন্ট পাওয়া যায়নি',
              textAlign: TextAlign.center,
              style: TextStyle(
                color: Color(0xFF111111),
                fontSize: 16,
                fontWeight: FontWeight.w900,
              ),
            ),
            const SizedBox(height: 6),
            const Text(
              'নির্বাচিত ফিল্টারে এখনো কোনো লগ পাওয়া যায়নি।',
              textAlign: TextAlign.center,
              style: TextStyle(
                color: Color(0xFF3D4943),
                fontWeight: FontWeight.w600,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildSection(BuildContext context, _LedgerGroup group) {
    return _InventoryPageCard(
      title: '${group.title} — ${_bnDigits(group.entries.length.toString())}টি',
            child: ListView.separated(
        itemCount: group.entries.length,
        shrinkWrap: true,
        physics: const NeverScrollableScrollPhysics(),
        separatorBuilder: (context, index) => const SizedBox(height: 10),
        itemBuilder: (context, index) {
          final entry = group.entries[index];
          return _StockLogCard(
            entry: entry,
            dateText: _ledgerDateText(entry.timestamp),
            timeText: _ledgerTimeText(entry.timestamp),
            deltaText: _deltaText(entry.delta),
          );
        },
      ),
    );
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final summary = ref.watch(stockSummaryProvider);
    final logs = ref.watch(filteredLogProvider);
    final filter = ref.watch(stockLedgerFilterProvider);
    final groups = _groupEntries(logs);
    return Scaffold(
      backgroundColor: const Color(0xFFF3F8F7),
      appBar: AppBar(
        backgroundColor: const Color(0xFFF3FAFB),
        elevation: 0,
        foregroundColor: const Color(0xFF111111),
        leading: IconButton(
          onPressed: () => Navigator.of(context).maybePop(),
          icon: const Icon(Icons.arrow_back_rounded),
        ),
        title: const Text(
          'স্টক মুভমেন্ট লগ',
          style: TextStyle(
            color: Color(0xFF00694C),
            fontWeight: FontWeight.w900,
          ),
        ),
        actions: [
          IconButton(
            onPressed: () {
              Navigator.of(context).push(
                MaterialPageRoute(
                  builder: (_) => const DokanThresholdSettingScreen(),
                ),
              );
            },
            icon: const Icon(Icons.settings_outlined),
          ),
          IconButton(
            onPressed: () {
              Navigator.of(context).push(
                MaterialPageRoute(
                  builder: (_) => const DokanLowStockAlertScreen(),
                ),
              );
            },
            icon: const Icon(Icons.calendar_month_outlined),
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        keyboardDismissBehavior: ScrollViewKeyboardDismissBehavior.onDrag,
        children: [
          _buildSummaryCard(summary),
          const SizedBox(height: 14),
          _InventoryPageCard(
            title: 'ফিল্টার',
            child: SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: Row(
                children: [
                  _AlertFilterChip(
                    label: 'সব পণ্য',
                    selected: filter == DokanStockLedgerFilter.all,
                    onTap: () => ref.read(stockLedgerFilterProvider.notifier).setFilter(DokanStockLedgerFilter.all),
                  ),
                  const SizedBox(width: 10),
                  _AlertFilterChip(
                    label: 'আজকে',
                    selected: filter == DokanStockLedgerFilter.today,
                    onTap: () => ref.read(stockLedgerFilterProvider.notifier).setFilter(DokanStockLedgerFilter.today),
                  ),
                  const SizedBox(width: 10),
                  _AlertFilterChip(
                    label: 'গতকাল',
                    selected: filter == DokanStockLedgerFilter.yesterday,
                    onTap: () => ref.read(stockLedgerFilterProvider.notifier).setFilter(DokanStockLedgerFilter.yesterday),
                  ),
                  const SizedBox(width: 10),
                  _AlertFilterChip(
                    label: 'এই সপ্তাহ',
                    selected: filter == DokanStockLedgerFilter.thisWeek,
                    onTap: () => ref.read(stockLedgerFilterProvider.notifier).setFilter(DokanStockLedgerFilter.thisWeek),
                  ),
                  const SizedBox(width: 10),
                  _AlertFilterChip(
                    label: 'এই মাস',
                    selected: filter == DokanStockLedgerFilter.thisMonth,
                    onTap: () => ref.read(stockLedgerFilterProvider.notifier).setFilter(DokanStockLedgerFilter.thisMonth),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 14),
          if (logs.isEmpty)
            _buildEmptyState(context)
          else
            ...groups.map(
              (group) => Padding(
                padding: const EdgeInsets.only(bottom: 14),
                child: _buildSection(context, group),
              ),
            ),
        ],
      ),
      bottomNavigationBar: _ProductBottomNav(
        selectedIndex: 2,
        onHomeTap: () => Navigator.of(context).push(
          MaterialPageRoute(builder: (_) => const DokanHomeDashboardScreen()),
        ),
        onSalesTap: () => Navigator.of(context).push(
          MaterialPageRoute(builder: (_) => const DokanPosSalesHistoryScreen()),
        ),
        onProductsTap: () => Navigator.of(context).push(
          MaterialPageRoute(builder: (_) => const DokanProductListScreen()),
        ),
        onReportsTap: () => Navigator.of(context).push(
          MaterialPageRoute(builder: (_) => const DokanReportsHomeScreen()),
        ),
        onMoreTap: () => Navigator.of(context).push(
          MaterialPageRoute(builder: (_) => const DokanAroOptionScreen()),
        ),
      ),
    );
  }
}

class DokanLowStockAlertListScreen extends StatelessWidget {
  const DokanLowStockAlertListScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return const DokanLowStockAlertScreen();
  }
}

class _SummaryPill extends StatelessWidget {
  const _SummaryPill({
    required this.label,
    required this.value,
    required this.color,
  });

  final String label;
  final String value;
  final Color color;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: color.withValues(alpha: 0.08),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: color.withValues(alpha: 0.18)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            label,
            style: const TextStyle(
              color: Color(0xFF3D4943),
              fontWeight: FontWeight.w700,
            ),
          ),
          const SizedBox(height: 6),
          Text(
            value,
            style: TextStyle(
              color: color,
              fontSize: 18,
              fontWeight: FontWeight.w900,
            ),
          ),
        ],
      ),
    );
  }
}

class _AlertFilterChip extends StatelessWidget {
  const _AlertFilterChip({
    required this.label,
    required this.selected,
    required this.onTap,
  });

  final String label;
  final bool selected;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        borderRadius: BorderRadius.circular(999),
        onTap: onTap,
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 180),
          padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 12),
          decoration: BoxDecoration(
            color: selected ? const Color(0xFF0C8C67) : Colors.white,
            borderRadius: BorderRadius.circular(999),
            border: Border.all(color: selected ? const Color(0xFF0C8C67) : const Color(0xFFD9E6E2)),
          ),
          child: Text(
            label,
            style: TextStyle(
              color: selected ? Colors.white : const Color(0xFF111111),
              fontWeight: FontWeight.w800,
            ),
          ),
        ),
      ),
    );
  }
}

class _LowStockProductCard extends StatelessWidget {
  const _LowStockProductCard({
    required this.product,
    required this.statusColor,
    required this.progress,
    required this.threshold,
    required this.onAddStock,
  });

  final DokanCatalogProduct product;
  final Color statusColor;
  final double progress;
  final int threshold;
  final VoidCallback onAddStock;

  @override
  Widget build(BuildContext context) {
    final limit = threshold > 0 ? threshold : 5;
    final remainingText = product.stock <= 0 ? 'স্টক নেই' : '${_bnDigits(product.stock.toString())}টি বাকি';
    final percentage = (progress * 100).round();

    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: const Color(0xFFD9E6E2)),
        boxShadow: const [
          BoxShadow(
            color: Color(0x0F000000),
            blurRadius: 14,
            offset: Offset(0, 4),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                width: 48,
                height: 48,
                decoration: BoxDecoration(
                  color: statusColor.withValues(alpha: 0.12),
                  borderRadius: BorderRadius.circular(14),
                ),
                child: Center(
                  child: Text(
                    product.emoji,
                    style: const TextStyle(fontSize: 24),
                  ),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      product.name,
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                        color: Color(0xFF111111),
                        fontSize: 16,
                        fontWeight: FontWeight.w900,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      product.category,
                      style: const TextStyle(
                        color: Color(0xFF3D4943),
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 10),
              Text(
                '${_bnDigits(product.stock.toString())}টি',
                style: TextStyle(
                  color: statusColor,
                  fontSize: 18,
                  fontWeight: FontWeight.w900,
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          Row(
            children: [
              Expanded(
                child: Text(
                  '$remainingText / সীমা ${_bnDigits(limit.toString())}টি',
                  style: const TextStyle(
                    color: Color(0xFF3D4943),
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ),
              Text(
                '$percentage%',
                style: TextStyle(
                  color: statusColor,
                  fontWeight: FontWeight.w900,
                ),
              ),
            ],
          ),
          const SizedBox(height: 8),
          ClipRRect(
            borderRadius: BorderRadius.circular(999),
            child: LinearProgressIndicator(
              value: progress,
              minHeight: 8,
              color: statusColor,
              backgroundColor: const Color(0xFFDCE7E3),
            ),
          ),
          if (product.stock <= limit) ...[
            const SizedBox(height: 12),
            Align(
              alignment: Alignment.centerRight,
              child: TextButton.icon(
                onPressed: onAddStock,
                style: TextButton.styleFrom(
                  foregroundColor: const Color(0xFF0C8C67),
                  padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                ),
                icon: const Icon(Icons.add_circle_rounded),
                label: const Text(
                  'স্টক যোগ করুন',
                  style: TextStyle(fontWeight: FontWeight.w800),
                ),
              ),
            ),
          ],
        ],
      ),
    );
  }
}

class _StockLogCard extends StatelessWidget {
  const _StockLogCard({
    required this.entry,
    required this.dateText,
    required this.timeText,
    required this.deltaText,
  });

  final DokanStockLedgerEntry entry;
  final String dateText;
  final String timeText;
  final String deltaText;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: const Color(0xFFD9E6E2)),
        boxShadow: const [
          BoxShadow(
            color: Color(0x07000000),
            blurRadius: 12,
            offset: Offset(0, 4),
          ),
        ],
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: 46,
            height: 46,
            decoration: BoxDecoration(
              color: entry.color.withValues(alpha: 0.12),
              shape: BoxShape.circle,
            ),
            child: Icon(entry.icon, color: entry.color, size: 24),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Wrap(
                  spacing: 8,
                  runSpacing: 8,
                  crossAxisAlignment: WrapCrossAlignment.center,
                  children: [
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                      decoration: BoxDecoration(
                        color: entry.color.withValues(alpha: 0.1),
                        borderRadius: BorderRadius.circular(999),
                      ),
                      child: Text(
                        entry.typeLabel,
                        style: TextStyle(
                          color: entry.color,
                          fontSize: 12,
                          fontWeight: FontWeight.w900,
                        ),
                      ),
                    ),
                    Text(
                      entry.productName,
                      style: const TextStyle(
                        color: Color(0xFF111111),
                        fontSize: 15,
                        fontWeight: FontWeight.w900,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 6),
                Text(
                  '${entry.category} • $dateText • $timeText',
                  style: const TextStyle(
                    color: Color(0xFF3D4943),
                    fontWeight: FontWeight.w600,
                  ),
                ),
                const SizedBox(height: 10),
                Text(
                  entry.note,
                  style: const TextStyle(
                    color: Color(0xFF5F6A66),
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(width: 12),
          Column(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Text(
                deltaText,
                style: TextStyle(
                  color: entry.color,
                  fontSize: 18,
                  fontWeight: FontWeight.w900,
                ),
              ),
              const SizedBox(height: 8),
              Text(
                'স্টক: ${_bnDigits(entry.stockSnapshot.toString())}টি',
                style: const TextStyle(
                  color: Color(0xFF3D4943),
                  fontWeight: FontWeight.w700,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class DokanPurchaseOrderPreviewScreen extends StatelessWidget {
  const DokanPurchaseOrderPreviewScreen({super.key, required this.products, required this.threshold});

  final List<DokanCatalogProduct> products;
  final int threshold;

  int _suggestedQty(DokanCatalogProduct product) {
    final limit = threshold > 0 ? threshold : 5;
    final value = (limit * 2) - product.stock;
    return value <= 0 ? 1 : value;
  }

  int _totalSuggested() => products.fold<int>(0, (sum, product) => sum + _suggestedQty(product));

  Future<void> _sendOrders(BuildContext context) async {
    final confirmed = await showDialog<bool>(
      context: context,
      barrierDismissible: true,
      builder: (dialogContext) => Dialog(
        backgroundColor: Colors.white,
        insetPadding: const EdgeInsets.symmetric(horizontal: 24, vertical: 24),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
        child: Padding(
          padding: const EdgeInsets.fromLTRB(18, 18, 18, 16),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Row(
                children: [
                  Icon(Icons.inventory_2_rounded, color: Color(0xFF0C8C67), size: 26),
                  SizedBox(width: 10),
                  Expanded(
                    child: Text(
                      'অর্ডার পাঠানোর নিশ্চিতকরণ',
                      style: TextStyle(
                        color: Color(0xFF111111),
                        fontSize: 18,
                        fontWeight: FontWeight.w900,
                      ),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 14),
              const Text(
                '৭টি কম স্টক পণ্যের জন্য অর্ডার তৈরি হবে। আপনি কি নিশ্চিত?',
                style: TextStyle(
                  color: Color(0xFF3D4943),
                  fontSize: 14,
                  fontWeight: FontWeight.w600,
                ),
              ),
              const SizedBox(height: 20),
              Row(
                children: [
                  Expanded(
                    child: OutlinedButton(
                      onPressed: () => Navigator.of(dialogContext).pop(false),
                      style: OutlinedButton.styleFrom(
                        foregroundColor: const Color(0xFF111111),
                        side: const BorderSide(color: Color(0xFFD9E6E2)),
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                        padding: const EdgeInsets.symmetric(vertical: 12),
                      ),
                      child: const Text(
                        'বাতিল',
                        style: TextStyle(fontWeight: FontWeight.w800),
                      ),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: ElevatedButton(
                      onPressed: () => Navigator.of(dialogContext).pop(true),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: const Color(0xFF0C8C67),
                        foregroundColor: Colors.white,
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                        padding: const EdgeInsets.symmetric(vertical: 12),
                      ),
                      child: const Text(
                        'অর্ডার পাঠান',
                        style: TextStyle(fontWeight: FontWeight.w800),
                      ),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
    if (confirmed != true || !context.mounted) return;
    await showDialog<void>(
      context: context,
      barrierDismissible: true,
      builder: (successContext) => Dialog(
        backgroundColor: Colors.white,
        insetPadding: const EdgeInsets.symmetric(horizontal: 30, vertical: 30),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
        child: Padding(
          padding: const EdgeInsets.fromLTRB(18, 20, 18, 16),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Icon(Icons.check_circle_rounded, color: Color(0xFF0C8C67), size: 56),
              const SizedBox(height: 12),
              const Text(
                'অর্ডার সফলভাবে পাঠানো হয়েছে',
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: Color(0xFF111111),
                  fontSize: 18,
                  fontWeight: FontWeight.w900,
                ),
              ),
              const SizedBox(height: 8),
              const Text(
                'সরবরাহকারীদের কাছে অর্ডার অনুরোধ পাঠানো হয়েছে।',
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: Color(0xFF3D4943),
                  fontSize: 14,
                  fontWeight: FontWeight.w600,
                ),
              ),
              const SizedBox(height: 18),
              SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  onPressed: () => Navigator.of(successContext).pop(),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFF0C8C67),
                    foregroundColor: Colors.white,
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                    padding: const EdgeInsets.symmetric(vertical: 12),
                  ),
                  child: const Text(
                    'ঠিক আছে',
                    style: TextStyle(fontWeight: FontWeight.w800),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF3F8F7),
      appBar: AppBar(
        backgroundColor: const Color(0xFFF3FAFB),
        elevation: 0,
        foregroundColor: const Color(0xFF111111),
        title: const Text(
          'ক্রয় অর্ডার প্রিভিউ',
          style: TextStyle(color: Color(0xFF00694C), fontWeight: FontWeight.w900),
        ),
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          _InventoryPageCard(
            title: 'অর্ডার সারসংক্ষেপ',
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'মোট পণ্য: ${_bnDigits(products.length.toString())}টি',
                  style: const TextStyle(color: Color(0xFF111111), fontWeight: FontWeight.w800),
                ),
                const SizedBox(height: 6),
                Text(
                  'মোট সুপারিশকৃত পরিমাণ: ${_bnDigits(_totalSuggested().toString())}টি',
                  style: const TextStyle(color: Color(0xFF3D4943), fontWeight: FontWeight.w700),
                ),
              ],
            ),
          ),
          const SizedBox(height: 14),
          ...products.map(
            (product) => Padding(
              padding: const EdgeInsets.only(bottom: 10),
              child: Container(
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(18),
                  border: Border.all(color: const Color(0xFFD9E6E2)),
                ),
                child: Row(
                  children: [
                    Text(product.emoji, style: const TextStyle(fontSize: 26)),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            product.name,
                            style: const TextStyle(color: Color(0xFF111111), fontWeight: FontWeight.w900),
                          ),
                          const SizedBox(height: 4),
                          Text(
                            'সুপারিশকৃত: ${_bnDigits(_suggestedQty(product).toString())}টি',
                            style: const TextStyle(color: Color(0xFF3D4943), fontWeight: FontWeight.w700),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(width: 10),
                    Text(
                      product.stock <= 0 ? 'স্টক নেই' : 'কম স্টক',
                      style: const TextStyle(color: Color(0xFFF49B1A), fontWeight: FontWeight.w900),
                    ),
                  ],
                ),
              ),
            ),
          ),
          const SizedBox(height: 18),
          SizedBox(
            height: 54,
            child: ElevatedButton(
              onPressed: () => _sendOrders(context),
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFF0C8C67),
                foregroundColor: Colors.white,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
              ),
              child: const Text('সব সরবরাহকারীকেই অর্ডার পাঠান', style: TextStyle(fontWeight: FontWeight.w900)),
            ),
          ),
        ],
      ),
      bottomNavigationBar: _ProductBottomNav(
        selectedIndex: 2,
        onHomeTap: () => Navigator.of(context).push(
          MaterialPageRoute(builder: (_) => const DokanHomeDashboardScreen()),
        ),
        onSalesTap: () => Navigator.of(context).push(
          MaterialPageRoute(builder: (_) => const DokanPosSalesHistoryScreen()),
        ),
        onProductsTap: () => Navigator.of(context).push(
          MaterialPageRoute(builder: (_) => const DokanProductListScreen()),
        ),
        onReportsTap: () => Navigator.of(context).push(
          MaterialPageRoute(builder: (_) => const DokanReportsHomeScreen()),
        ),
        onMoreTap: () => Navigator.of(context).push(
          MaterialPageRoute(builder: (_) => const DokanAroOptionScreen()),
        ),
      ),
    );
  }
}

class DokanPurchaseOrderSuccessScreen extends StatelessWidget {
  const DokanPurchaseOrderSuccessScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF3F8F7),
      appBar: AppBar(
        backgroundColor: const Color(0xFFF3FAFB),
        elevation: 0,
        foregroundColor: const Color(0xFF111111),
        title: const Text(
          'অর্ডার পাঠানো হয়েছে',
          style: TextStyle(color: Color(0xFF00694C), fontWeight: FontWeight.w900),
        ),
      ),
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: _InventoryPageCard(
            title: 'সফলতা',
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Icon(Icons.check_circle_rounded, color: Color(0xFF0C8C67), size: 72),
                const SizedBox(height: 14),
                const Text(
                  'অর্ডার সফলভাবে পাঠানো হয়েছে',
                  textAlign: TextAlign.center,
                  style: TextStyle(color: Color(0xFF111111), fontSize: 20, fontWeight: FontWeight.w900),
                ),
                const SizedBox(height: 8),
                const Text(
                  'সব সরবরাহকারীর কাছে অর্ডার গেছে',
                  textAlign: TextAlign.center,
                  style: TextStyle(color: Color(0xFF3D4943), fontWeight: FontWeight.w600),
                ),
                const SizedBox(height: 18),
                SizedBox(
                  width: double.infinity,
                  height: 52,
                  child: ElevatedButton(
                    onPressed: () => Navigator.of(context).popUntil((route) => route.isFirst),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: const Color(0xFF0C8C67),
                      foregroundColor: Colors.white,
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                    ),
                    child: const Text('পণ্য তালিকায় ফিরুন', style: TextStyle(fontWeight: FontWeight.w900)),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
      bottomNavigationBar: _ProductBottomNav(
        selectedIndex: 2,
        onHomeTap: () => Navigator.of(context).push(
          MaterialPageRoute(builder: (_) => const DokanHomeDashboardScreen()),
        ),
        onSalesTap: () => Navigator.of(context).push(
          MaterialPageRoute(builder: (_) => const DokanPosSalesHistoryScreen()),
        ),
        onProductsTap: () => Navigator.of(context).push(
          MaterialPageRoute(builder: (_) => const DokanProductListScreen()),
        ),
        onReportsTap: () => Navigator.of(context).push(
          MaterialPageRoute(builder: (_) => const DokanReportsHomeScreen()),
        ),
        onMoreTap: () => Navigator.of(context).push(
          MaterialPageRoute(builder: (_) => const DokanAroOptionScreen()),
        ),
      ),
    );
  }
}

class _InventoryPageCard extends StatelessWidget {
  const _InventoryPageCard({
    required this.title,
    required this.child,
  });

  final String title;
  final Widget child;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: const Color(0xFFD9E6E2)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            title,
            style: const TextStyle(
              color: Color(0xFF111111),
              fontSize: 16,
              fontWeight: FontWeight.w900,
            ),
          ),
          const SizedBox(height: 12),
          child,
        ],
      ),
    );
  }
}

class _DrawerActionTile extends StatelessWidget {
  const _DrawerActionTile({
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.onTap,
  });

  final IconData icon;
  final String title;
  final String subtitle;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.white,
      borderRadius: BorderRadius.circular(18),
      child: InkWell(
        borderRadius: BorderRadius.circular(18),
        onTap: onTap,
        child: Container(
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(18),
            border: Border.all(color: const Color(0xFFD9E6E2)),
          ),
          child: Row(
            children: [
              Container(
                width: 46,
                height: 46,
                decoration: BoxDecoration(
                  color: const Color(0xFFEAF7F0),
                  borderRadius: BorderRadius.circular(14),
                ),
                child: Icon(icon, color: const Color(0xFF00694C)),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      title,
                      style: const TextStyle(
                        color: Color(0xFF111111),
                        fontSize: 16,
                        fontWeight: FontWeight.w900,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      subtitle,
                      style: const TextStyle(
                        color: Color(0xFF3D4943),
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 8),
              const Icon(Icons.chevron_right_rounded, color: Color(0xFF00694C)),
            ],
          ),
        ),
      ),
    );
  }
}

class DokanPopularProductsScreen extends ConsumerWidget {
  const DokanPopularProductsScreen({
    super.key,
    required this.shopName,
    required this.ownerName,
    this.onBack,
    this.onContinue,
  });

  final String shopName;
  final String ownerName;
  final VoidCallback? onBack;
  final VoidCallback? onContinue;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final state = ref.watch(dokanPopularProductsProvider);
    final notifier = ref.read(dokanPopularProductsProvider.notifier);
    final items = notifier.items;

    return switch (state.stage) {
      DokanPopularFlowStage.pick => _buildPickStage(context, notifier, state, items),
      DokanPopularFlowStage.stock => _buildStockStage(context, notifier, state, items),
      DokanPopularFlowStage.complete => _buildCompleteStage(context, notifier, state),
    };
  }

  Widget _buildPickStage(
    BuildContext context,
    DokanPopularProductsNotifier notifier,
    DokanPopularProductsState state,
    List<DokanPopularProductItem> items,
  ) {
    final visibleItems = state.selectedFilter == 'সব'
        ? items
        : items.where((item) => item.category == state.selectedFilter || item.category == 'সব').toList();

    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
        top: false,
        bottom: false,
        child: Column(
          children: [
            _TopHeader(
              background: const Color(0xFFEAF5FB),
              leading: IconButton(
                onPressed: onBack,
                icon: const Icon(Icons.arrow_back, color: Color(0xFF20312D), size: 34),
              ),
              title: 'জনপ্রিয় পণ্য বেছে নিন',
              trailing: _CountPill(text: '${_bengaliNumber(notifier.selectedCount)} টি বাছাই'),
            ),
            const SizedBox(height: 22),
            const Padding(
              padding: EdgeInsets.symmetric(horizontal: 18),
              child: Text(
                'আপনার দোকানে যে পণ্যগুলো আছে সেগুলো বেছে নিন',
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: Color(0xFF4D5A56),
                  fontSize: 18,
                  fontWeight: FontWeight.w500,
                  height: 1.25,
                ),
              ),
            ),
            const SizedBox(height: 22),
            SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.symmetric(horizontal: 18),
              child: Row(
                children: DokanPopularProductsNotifier.filters
                    .map(
                      (filter) => Padding(
                        padding: const EdgeInsets.only(right: 12),
                        child: _FilterChip(
                          label: filter,
                          selected: filter == state.selectedFilter,
                          onTap: () => notifier.setFilter(filter),
                        ),
                      ),
                    )
                    .toList(),
              ),
            ),
            const SizedBox(height: 18),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 18),
              child: Align(
                alignment: Alignment.centerRight,
                child: Text(
                  state.selectedFilter == 'সব' ? 'সব বাছাই করুন' : 'ফিল্টার: ${state.selectedFilter}',
                  style: const TextStyle(
                    color: Color(0xFF00694C),
                    fontSize: 17,
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ),
            ),
            const SizedBox(height: 10),
            Expanded(
              child: ListView.separated(
                padding: const EdgeInsets.fromLTRB(18, 0, 18, 18),
                itemCount: visibleItems.length,
                separatorBuilder: (context, index) => const SizedBox(height: 10),
                itemBuilder: (context, index) {
                  final item = visibleItems[index];
                  return _SelectableProductRow(
                    item: item,
                    onTap: () => notifier.toggleItem(item),
                  );
                },
              ),
            ),
            _BottomActionBar(
              icon: Icons.shopping_cart_outlined,
              text: '${_bengaliNumber(notifier.selectedCount)}টি পণ্য বাছাই হয়েছে',
              buttonLabel: 'পরবর্তী ধাপ',
              onPressed: () => notifier.goToStock(context),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildStockStage(
    BuildContext context,
    DokanPopularProductsNotifier notifier,
    DokanPopularProductsState state,
    List<DokanPopularProductItem> items,
  ) {
    final selectedItems = notifier.stockItems;

    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
        top: false,
        bottom: false,
        child: Column(
          children: [
            _TopHeader(
              background: const Color(0xFFEAF5FB),
              leading: IconButton(
                onPressed: notifier.goToPick,
                icon: const Icon(Icons.arrow_back, color: Color(0xFF20312D), size: 34),
              ),
              title: 'স্টক ও দাম দিন',
              trailing: _CountPill(
                text: '${_bengaliNumber(items.length)} টির মধ্যে ${_bengaliNumber(notifier.completedCount)} টি সম্পন্ন',
                smaller: true,
              ),
            ),
            const SizedBox(height: 22),
            const Padding(
              padding: EdgeInsets.symmetric(horizontal: 18),
              child: Text(
                'প্রতিটি পণ্যের বর্তমান স্টক ও বিক্রয় মূল্য দিন',
                style: TextStyle(
                  color: Color(0xFF4D5A56),
                  fontSize: 17,
                  height: 1.35,
                ),
              ),
            ),
            const SizedBox(height: 14),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 18),
              child: Align(
                alignment: Alignment.centerRight,
                child: TextButton(
                  onPressed: notifier.goToPick,
                  style: TextButton.styleFrom(
                    foregroundColor: const Color(0xFF2F6AF2),
                    padding: EdgeInsets.zero,
                    minimumSize: Size.zero,
                    tapTargetSize: MaterialTapTargetSize.shrinkWrap,
                  ),
                  child: const Text(
                    'আরও পণ্য যোগ করুন',
                    style: TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                ),
              ),
            ),
            const SizedBox(height: 10),
            Expanded(
              child: ListView.separated(
                padding: const EdgeInsets.fromLTRB(18, 0, 18, 18),
                itemCount: selectedItems.length,
                separatorBuilder: (context, index) => const SizedBox(height: 14),
                itemBuilder: (context, index) {
                  final item = selectedItems[index];
                  return _StockProductCard(
                    item: item,
                    onToggle: () => notifier.toggleItem(item),
                    onBackToPick: notifier.goToPick,
                  );
                },
              ),
            ),
            Padding(
              padding: EdgeInsets.fromLTRB(18, 0, 18, 18 + MediaQuery.of(context).padding.bottom),
              child: SizedBox(
                width: double.infinity,
                height: 60,
                child: ElevatedButton(
                  onPressed: () => notifier.goToComplete(context),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFF007A59),
                    foregroundColor: Colors.white,
                    padding: const EdgeInsets.symmetric(horizontal: 28),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
                    elevation: 0,
                  ),
                  child: const Text(
                    'সেটআপ সম্পন্ন করুন',
                    style: TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.w800,
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildCompleteStage(
    BuildContext context,
    DokanPopularProductsNotifier notifier,
    DokanPopularProductsState state,
  ) {
    return Scaffold(
      backgroundColor: const Color(0xFFF2FAF6),
      body: SafeArea(
        top: false,
        bottom: false,
        child: Column(
          children: [
            Padding(
              padding: EdgeInsets.only(top: MediaQuery.of(context).padding.top + 12, left: 12, right: 12),
              child: Row(
                children: [
                  IconButton(
                    onPressed: notifier.goToStockPage,
                    icon: const Icon(Icons.arrow_back, color: Color(0xFF20312D), size: 34),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 6),
            Center(
              child: Column(
                children: [
                  Container(
                    width: 150,
                    height: 150,
                    decoration: BoxDecoration(
                      color: const Color(0xFFE0F0E3),
                      borderRadius: BorderRadius.circular(14),
                    ),
                    child: Stack(
                      alignment: Alignment.center,
                      children: [
                        ..._buildConfetti(),
                        Container(
                          width: 96,
                          height: 96,
                          decoration: const BoxDecoration(
                            color: Color(0xFF0D865F),
                            shape: BoxShape.circle,
                          ),
                          child: const Icon(
                            Icons.check_rounded,
                            color: Colors.white,
                            size: 72,
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 26),
                  Text.rich(
                    TextSpan(
                      children: [
                        const TextSpan(
                          text: 'দোকান সম্পূর্ণ তৈরি!',
                          style: TextStyle(
                            color: Color(0xFF0E7C57),
                            fontSize: 29,
                            fontWeight: FontWeight.w800,
                            height: 1.1,
                          ),
                        ),
                        const TextSpan(
                          text: ' 🎉',
                          style: TextStyle(fontSize: 29),
                        ),
                      ],
                    ),
                    textAlign: TextAlign.center,
                  ),
                  const SizedBox(height: 12),
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 32),
                    child: Text(
                      'আপনার ${_bengaliNumber(notifier.selectedCount)}টি পণ্য যোগ হয়েছে। এখন বিক্রয় শুরু করুন!',
                      textAlign: TextAlign.center,
                      style: const TextStyle(
                        color: Color(0xFF55635F),
                        fontSize: 17,
                        height: 1.45,
                      ),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 26),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 18),
              child: Container(
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(color: const Color(0xFFE1E8E3)),
                  boxShadow: const [
                    BoxShadow(
                      color: Color(0x12000000),
                      blurRadius: 16,
                      offset: Offset(0, 6),
                    ),
                  ],
                ),
                child: Column(
                  children: [
                    _SummaryRow(
                      icon: Icons.inventory_2_outlined,
                      label: 'মোট পণ্য',
                      value: '${_bengaliNumber(notifier.selectedCount)}টি',
                    ),
                    const Divider(height: 1, thickness: 1, color: Color(0xFFE9EEEA)),
                    _SummaryRow(
                      icon: Icons.storefront_outlined,
                      label: 'দোকানের নাম',
                      value: shopName,
                    ),
                    const Divider(height: 1, thickness: 1, color: Color(0xFFE9EEEA)),
                    _SummaryRow(
                      icon: Icons.person_outline_rounded,
                      label: 'মালিক',
                      value: ownerName,
                    ),
                  ],
                ),
              ),
            ),
            const Spacer(),
            Padding(
              padding: EdgeInsets.fromLTRB(18, 0, 18, 18 + MediaQuery.of(context).padding.bottom),
              child: SizedBox(
                width: double.infinity,
                height: 60,
                child: ElevatedButton(
                  onPressed: onContinue,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFF0E865D),
                    foregroundColor: Colors.white,
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                    elevation: 0,
                  ),
                  child: const Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text(
                        'বিক্রয় শুরু করুন',
                        style: TextStyle(
                          fontSize: 20,
                          fontWeight: FontWeight.w800,
                        ),
                      ),
                      SizedBox(width: 16),
                      Icon(Icons.arrow_forward_rounded, size: 32),
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  List<Widget> _buildConfetti() {
    const colors = [
      Color(0xFF2AA57D),
      Color(0xFF8CE2B7),
      Colors.white,
      Color(0xFF0E7C57),
    ];
    final positions = <Offset>[
      const Offset(-48, -50),
      const Offset(-28, -30),
      const Offset(10, -44),
      const Offset(38, -20),
      const Offset(-60, 8),
      const Offset(-26, 34),
      const Offset(18, 32),
      const Offset(56, 12),
      const Offset(-44, 58),
      const Offset(30, 54),
      const Offset(66, -42),
    ];

    return List.generate(positions.length, (index) {
      return Positioned(
        left: 74 + positions[index].dx,
        top: 74 + positions[index].dy,
        child: Transform.rotate(
          angle: (index % 3) * 0.22,
          child: Container(
            width: index.isEven ? 12 : 8,
            height: index.isEven ? 12 : 8,
            decoration: BoxDecoration(
              color: colors[index % colors.length],
              borderRadius: BorderRadius.circular(index.isEven ? 4 : 999),
            ),
          ),
        ),
      );
    });
  }

  String _bengaliNumber(int value) {
    const digits = ['০', '১', '২', '৩', '৪', '৫', '৬', '৭', '৮', '৯'];
    return value.toString().split('').map((char) {
      final index = int.tryParse(char);
      return index == null ? char : digits[index];
    }).join();
  }
}

class _TopHeader extends StatelessWidget {
  const _TopHeader({
    required this.background,
    required this.leading,
    required this.title,
    required this.trailing,
  });

  final Color background;
  final Widget leading;
  final String title;
  final Widget trailing;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: EdgeInsets.only(top: MediaQuery.of(context).padding.top + 12, bottom: 14),
      decoration: BoxDecoration(
        color: background,
        border: const Border(bottom: BorderSide(color: Color(0xFFE1EBEF), width: 1)),
      ),
      child: Row(
        children: [
          const SizedBox(width: 10),
          leading,
          const SizedBox(width: 2),
          Expanded(
            child: Text(
              title,
              textAlign: TextAlign.center,
              style: const TextStyle(
                color: Color(0xFF00694C),
                fontSize: 24,
                fontWeight: FontWeight.w800,
                height: 1.15,
                letterSpacing: -0.3,
              ),
            ),
          ),
          const SizedBox(width: 8),
          trailing,
          const SizedBox(width: 12),
        ],
      ),
    );
  }
}

class _CountPill extends StatelessWidget {
  const _CountPill({
    required this.text,
    this.smaller = false,
  });

  final String text;
  final bool smaller;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: smaller ? 16 : 18, vertical: smaller ? 8 : 10),
      decoration: BoxDecoration(
        color: const Color(0xFFD6EEE7),
        borderRadius: BorderRadius.circular(999),
        border: Border.all(color: const Color(0xFF9FD5C4)),
      ),
      child: Text(
        text,
        style: TextStyle(
          color: const Color(0xFF00694C),
          fontSize: smaller ? 15 : 16,
          fontWeight: FontWeight.w700,
        ),
      ),
    );
  }
}

class _FilterChip extends StatelessWidget {
  const _FilterChip({
    required this.label,
    required this.selected,
    required this.onTap,
  });

  final String label;
  final bool selected;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final background = selected ? const Color(0xFF00694C) : const Color(0xFFDCEAF1);
    final foreground = selected ? Colors.white : const Color(0xFF5C6662);

    return Material(
      color: background,
      borderRadius: BorderRadius.circular(999),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(999),
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 14),
          child: Text(
            label,
            style: TextStyle(
              color: foreground,
              fontSize: 17,
              fontWeight: FontWeight.w700,
            ),
          ),
        ),
      ),
    );
  }
}

class _SelectableProductRow extends StatelessWidget {
  const _SelectableProductRow({
    required this.item,
    required this.onTap,
  });

  final DokanPopularProductItem item;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final isSelected = item.selected;

    return Material(
      color: isSelected ? const Color(0xFFDFF4EE) : Colors.white,
      borderRadius: BorderRadius.circular(16),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(16),
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 14),
          child: Row(
            children: [
              SizedBox(
                width: 44,
                child: Center(
                  child: Text(item.emoji, style: const TextStyle(fontSize: 26)),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      item.name,
                      style: const TextStyle(
                        color: Color(0xFF1C2C27),
                        fontSize: 22,
                        fontWeight: FontWeight.w500,
                        height: 1.05,
                      ),
                    ),
                    const SizedBox(height: 6),
                    Text(
                      item.quantity,
                      style: const TextStyle(
                        color: Color(0xFF44514C),
                        fontSize: 17,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 12),
              AnimatedContainer(
                duration: const Duration(milliseconds: 180),
                width: 34,
                height: 34,
                decoration: BoxDecoration(
                  color: isSelected ? const Color(0xFF00694C) : Colors.transparent,
                  border: Border.all(
                    color: isSelected ? const Color(0xFF00694C) : const Color(0xFF7D8A86),
                    width: 3,
                  ),
                  borderRadius: BorderRadius.circular(6),
                ),
                child: isSelected ? const Icon(Icons.check, color: Colors.white, size: 24) : null,
              ),
              const SizedBox(width: 4),
            ],
          ),
        ),
      ),
    );
  }
}

class _StockProductCard extends StatelessWidget {
  const _StockProductCard({
    required this.item,
    required this.onToggle,
    required this.onBackToPick,
  });

  final DokanPopularProductItem item;
  final VoidCallback onToggle;
  final VoidCallback onBackToPick;

  @override
  Widget build(BuildContext context) {
    final isSelected = item.selected;
    final background = isSelected ? const Color(0xFFDFF4EE) : Colors.white;
    final borderColor = isSelected ? const Color(0xFF0C7A59) : const Color(0xFFE2E8E4);

    return Container(
      decoration: BoxDecoration(
        color: background,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: borderColor, width: isSelected ? 1.5 : 1),
      ),
      child: Padding(
        padding: const EdgeInsets.fromLTRB(16, 14, 16, 16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                SizedBox(
                  width: 40,
                  child: Center(
                    child: Text(item.emoji, style: const TextStyle(fontSize: 24)),
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: Text(
                    item.name,
                    style: const TextStyle(
                      color: Color(0xFF1D2723),
                      fontSize: 22,
                      fontWeight: FontWeight.w500,
                      height: 1.05,
                    ),
                  ),
                ),
                TextButton(
                  onPressed: onToggle,
                  style: TextButton.styleFrom(
                    foregroundColor: const Color(0xFF4D5A56),
                    padding: EdgeInsets.zero,
                    minimumSize: Size.zero,
                    tapTargetSize: MaterialTapTargetSize.shrinkWrap,
                  ),
                  child: const Text(
                    'এড়িয়ে যান',
                    style: TextStyle(fontSize: 14, fontWeight: FontWeight.w600),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 18),
            Row(
              children: [
                Expanded(
                  child: _AmountField(
                    label: 'বর্তমান স্টক',
                    controller: item.stockController,
                    borderColor: borderColor,
                    fillColor: Colors.white,
                    hintText: 'পরিমাণ লিখুন',
                    textColor: const Color(0xFF1C2220),
                  ),
                ),
                const SizedBox(width: 14),
                Expanded(
                  child: _AmountField(
                    label: 'বিক্রয় মূল্য ৮',
                    controller: item.priceController,
                    borderColor: borderColor,
                    fillColor: Colors.white,
                    hintText: 'টাকা লিখুন',
                    textColor: const Color(0xFF1C2220),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 10),
            Align(
              alignment: Alignment.centerLeft,
              child: TextButton(
                onPressed: onBackToPick,
                style: TextButton.styleFrom(
                  foregroundColor: const Color(0xFF2F6AF2),
                  padding: EdgeInsets.zero,
                  minimumSize: Size.zero,
                  tapTargetSize: MaterialTapTargetSize.shrinkWrap,
                ),
                child: const Text(
                  'আরও পণ্য যোগ করুন',
                  style: TextStyle(fontSize: 14, fontWeight: FontWeight.w700),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _AmountField extends StatelessWidget {
  const _AmountField({
    required this.label,
    required this.controller,
    required this.borderColor,
    required this.fillColor,
    required this.hintText,
    required this.textColor,
  });

  final String label;
  final TextEditingController controller;
  final Color borderColor;
  final Color fillColor;
  final String hintText;
  final Color textColor;

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label,
          style: const TextStyle(
            color: Color(0xFF2D6B5A),
            fontSize: 15,
            fontWeight: FontWeight.w600,
          ),
        ),
        const SizedBox(height: 8),
        TextField(
          controller: controller,
          keyboardType: TextInputType.number,
          inputFormatters: [
            FilteringTextInputFormatter.digitsOnly,
            LengthLimitingTextInputFormatter(5),
          ],
          style: TextStyle(
            color: textColor,
            fontSize: 20,
            fontWeight: FontWeight.w600,
          ),
          decoration: InputDecoration(
            hintText: hintText,
            hintStyle: const TextStyle(
              color: Color(0xFF8A9390),
              fontSize: 19,
              fontWeight: FontWeight.w500,
            ),
            filled: true,
            fillColor: fillColor,
            contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(14),
              borderSide: BorderSide(color: borderColor, width: 2),
            ),
            enabledBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(14),
              borderSide: BorderSide(color: borderColor, width: 2),
            ),
            focusedBorder: const OutlineInputBorder(
              borderRadius: BorderRadius.all(Radius.circular(14)),
              borderSide: BorderSide(color: Color(0xFF2F6AF2), width: 2.5),
            ),
          ),
        ),
      ],
    );
  }
}

class _BottomActionBar extends StatelessWidget {
  const _BottomActionBar({
    required this.icon,
    required this.text,
    required this.buttonLabel,
    required this.onPressed,
  });

  final IconData icon;
  final String text;
  final String buttonLabel;
  final VoidCallback onPressed;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: EdgeInsets.fromLTRB(14, 12, 14, 12 + MediaQuery.of(context).padding.bottom),
      decoration: const BoxDecoration(
        color: Color(0xFFF1FAFE),
        border: Border(top: BorderSide(color: Color(0xFFE1EBEF), width: 1)),
      ),
      child: Row(
        children: [
          Icon(icon, color: const Color(0xFF44514C), size: 24),
          const SizedBox(width: 10),
          Expanded(
            child: Text(
              text,
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(
                color: Color(0xFF44514C),
                fontSize: 15,
                fontWeight: FontWeight.w600,
              ),
            ),
          ),
          const SizedBox(width: 10),
          SizedBox(
            height: 48,
            child: ElevatedButton(
              onPressed: onPressed,
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFF007A59),
                foregroundColor: Colors.white,
                padding: const EdgeInsets.symmetric(horizontal: 18),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(999)),
                elevation: 4,
                shadowColor: Colors.black26,
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(
                    buttonLabel,
                    style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w800),
                  ),
                  const SizedBox(width: 8),
                  const Icon(Icons.arrow_forward_rounded, size: 22),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _SummaryRow extends StatelessWidget {
  const _SummaryRow({
    required this.icon,
    required this.label,
    required this.value,
  });

  final IconData icon;
  final String label;
  final String value;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 18),
      child: Row(
        children: [
          Icon(icon, color: const Color(0xFF4E7B6D), size: 28),
          const SizedBox(width: 14),
          Expanded(
            child: Text(
              label,
              style: const TextStyle(
                color: Color(0xFF365148),
                fontSize: 17,
                fontWeight: FontWeight.w600,
              ),
            ),
          ),
          const SizedBox(width: 14),
          Text(
            value,
            style: const TextStyle(
              color: Color(0xFF1D2723),
              fontSize: 18,
              fontWeight: FontWeight.w700,
            ),
          ),
        ],
      ),
    );
  }
}
