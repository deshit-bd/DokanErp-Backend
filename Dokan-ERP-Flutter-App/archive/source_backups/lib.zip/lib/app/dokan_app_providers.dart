import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:shared_preferences/shared_preferences.dart';

enum DokanStartupStage {
  splash,
  onboarding,
  login,
  otpLogin,
  otpVerify,
  pinSetup,
  pinLogin,
  register,
  welcome,
  popularProducts,
  shopSetup,
  home,
}

const String dokanStartupStagePrefsKey = 'dokan_startup_stage';

class DokanAppFlowState {
  const DokanAppFlowState({
    this.stage = DokanStartupStage.splash,
    this.progress = 0,
    this.loginRole = 0,
    this.shopName = 'দোকান',
    this.registeredName = 'আপনার',
    this.isNewAccountFlow = false,
    this.currentUserRole = 0,
    this.currentSalesmanPhone,
    this.currentSalesmanName,
    this.ownerPhone = '01712345678',
    this.ownerPassword = '1234',
  });

  final DokanStartupStage stage;
  final int progress;
  final int loginRole;
  final String shopName;
  final String registeredName;
  final bool isNewAccountFlow;
  final int currentUserRole;
  final String? currentSalesmanPhone;
  final String? currentSalesmanName;
  final String ownerPhone;
  final String ownerPassword;

  DokanAppFlowState copyWith({
    DokanStartupStage? stage,
    int? progress,
    int? loginRole,
    String? shopName,
    String? registeredName,
    bool? isNewAccountFlow,
    int? currentUserRole,
    String? currentSalesmanPhone,
    String? currentSalesmanName,
    String? ownerPhone,
    String? ownerPassword,
  }) {
    return DokanAppFlowState(
      stage: stage ?? this.stage,
      progress: progress ?? this.progress,
      loginRole: loginRole ?? this.loginRole,
      shopName: shopName ?? this.shopName,
      registeredName: registeredName ?? this.registeredName,
      isNewAccountFlow: isNewAccountFlow ?? this.isNewAccountFlow,
      currentUserRole: currentUserRole ?? this.currentUserRole,
      currentSalesmanPhone: currentSalesmanPhone ?? this.currentSalesmanPhone,
      currentSalesmanName: currentSalesmanName ?? this.currentSalesmanName,
      ownerPhone: ownerPhone ?? this.ownerPhone,
      ownerPassword: ownerPassword ?? this.ownerPassword,
    );
  }
}

class DokanAppFlowNotifier extends Notifier<DokanAppFlowState> {
  Timer? _transitionTimer;

  @override
  DokanAppFlowState build() {
    ref.onDispose(() => _transitionTimer?.cancel());
    
    Future.microtask(() async {
      final prefs = await SharedPreferences.getInstance();
      final stageName = prefs.getString(dokanStartupStagePrefsKey);
      final role = prefs.getInt('currentUserRole') ?? 0;
      final salesmanPhone = prefs.getString('currentSalesmanPhone');
      final salesmanName = prefs.getString('currentSalesmanName');
      final ownerPhone = prefs.getString('ownerPhone') ?? '01712345678';
      final ownerPassword = prefs.getString('ownerPassword') ?? '1234';
      final shopName = prefs.getString('shopName') ?? 'দোকান';
      final registeredName = prefs.getString('registeredName') ?? 'আপনার';
      
      DokanStartupStage stage = DokanStartupStage.splash;
      if (stageName != null) {
        stage = DokanStartupStage.values.firstWhere(
          (e) => e.name == stageName,
          orElse: () => DokanStartupStage.splash,
        );
      }
      
      state = state.copyWith(
        stage: stage,
        currentUserRole: role,
        currentSalesmanPhone: salesmanPhone,
        currentSalesmanName: salesmanName,
        ownerPhone: ownerPhone,
        ownerPassword: ownerPassword,
        shopName: shopName,
        registeredName: registeredName,
      );
    });
    
    return const DokanAppFlowState();
  }

  Future<void> _persistStage(DokanStartupStage stage) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(dokanStartupStagePrefsKey, stage.name);
  }

  void _setStage(DokanStartupStage stage) {
    state = state.copyWith(
      stage: stage,
      progress: stage == DokanStartupStage.splash ? state.progress : 100,
    );
    unawaited(_persistStage(stage));
  }

  void setProgress(int progress) {
    state = state.copyWith(progress: progress);
  }

  void startSplash() {
    _transitionTimer?.cancel();
    _transitionTimer = Timer(const Duration(milliseconds: 2300), () {
      _setStage(DokanStartupStage.onboarding);
    });
    state = state.copyWith(stage: DokanStartupStage.splash, progress: 0);
  }

  void finishOnboarding() => _setStage(DokanStartupStage.login);
  void goToOnboarding() => _setStage(DokanStartupStage.onboarding);

  void goToLogin() {
    state = state.copyWith(isNewAccountFlow: false);
    _setStage(DokanStartupStage.login);
  }

  void setLoginRole(int roleIndex) {
    state = state.copyWith(loginRole: roleIndex);
  }

  void goToOtpLogin() => _setStage(DokanStartupStage.otpLogin);
  void goToOtpVerify() => _setStage(DokanStartupStage.otpVerify);
  void goToPinSetup() => _setStage(DokanStartupStage.pinSetup);
  void goToPinLogin() => _setStage(DokanStartupStage.pinLogin);

  void goToRegister() {
    state = state.copyWith(isNewAccountFlow: true);
    _setStage(DokanStartupStage.register);
  }

  void registerAccount({required String name, required String phone, required String password}) {
    state = state.copyWith(
      registeredName: name,
      ownerPhone: phone,
      ownerPassword: password,
      isNewAccountFlow: true,
    );
    SharedPreferences.getInstance().then((prefs) {
      prefs.setString('registeredName', name);
      prefs.setString('ownerPhone', phone);
      prefs.setString('ownerPassword', password);
    });
    _setStage(DokanStartupStage.shopSetup);
  }

  void completeShopSetup(String shopName) {
    state = state.copyWith(shopName: shopName);
    SharedPreferences.getInstance().then((prefs) {
      prefs.setString('shopName', shopName);
    });
    goToOtpVerify();
  }

  void completePinLogin() {
    if (state.isNewAccountFlow) {
      _setStage(DokanStartupStage.welcome);
      return;
    }
    _setStage(DokanStartupStage.home);
  }

  Future<void> loginUser({required int role, String? salesmanPhone, String? salesmanName}) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setInt('currentUserRole', role);
    if (salesmanPhone != null) {
      await prefs.setString('currentSalesmanPhone', salesmanPhone);
    } else {
      await prefs.remove('currentSalesmanPhone');
    }
    if (salesmanName != null) {
      await prefs.setString('currentSalesmanName', salesmanName);
    } else {
      await prefs.remove('currentSalesmanName');
    }
    state = state.copyWith(
      currentUserRole: role,
      currentSalesmanPhone: salesmanPhone,
      currentSalesmanName: salesmanName,
    );
    _setStage(DokanStartupStage.home);
  }

  Future<void> logout() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove('currentUserRole');
    await prefs.remove('currentSalesmanPhone');
    await prefs.remove('currentSalesmanName');
    
    state = state.copyWith(
      currentUserRole: 0,
      currentSalesmanPhone: null,
      currentSalesmanName: null,
    );
    _setStage(DokanStartupStage.login);
  }

  void goToWelcome() => _setStage(DokanStartupStage.welcome);
  void goToHome() => _setStage(DokanStartupStage.home);
  void goToPopularProducts() => _setStage(DokanStartupStage.popularProducts);
}

final dokanAppFlowProvider = NotifierProvider<DokanAppFlowNotifier, DokanAppFlowState>(
  DokanAppFlowNotifier.new,
);

class DokanCategoryNotifier extends Notifier<List<String>> {
  static const String uncategorized = 'অজানা';

  @override
  List<String> build() {
    return <String>[
      'চাল-ডাল',
      'তেল-মসলা',
      'সাবান',
      'পানীয়',
      'বিস্কুট',
      uncategorized,
    ];
  }

  void addCategory(String category) {
    final value = category.trim();
    if (value.isEmpty) return;
    if (state.contains(value)) return;
    state = <String>[...state.where((item) => item != uncategorized), value, uncategorized];
  }

  void deleteCategory(String category) {
    if (category == uncategorized) return;
    state = state.where((item) => item != category).toList(growable: false);
    if (!state.contains(uncategorized)) {
      state = <String>[...state, uncategorized];
    }
  }

  void updateCategory(String oldCategory, String newCategory) {
    final value = newCategory.trim();
    if (value.isEmpty || oldCategory == uncategorized || oldCategory == value) return;
    if (state.contains(value)) return;
    final updated = state.map((item) => item == oldCategory ? value : item).toList();
    if (!updated.contains(uncategorized)) {
      updated.add(uncategorized);
    }
    state = updated;
  }
}

class DokanStockThresholdNotifier extends Notifier<int> {
  @override
  int build() => 5;

  void setThreshold(int value) {
    state = value < 1 ? 1 : value > 99 ? 99 : value;
  }
}

final categoryProvider = NotifierProvider<DokanCategoryNotifier, List<String>>(DokanCategoryNotifier.new);
final stockThresholdProvider = NotifierProvider<DokanStockThresholdNotifier, int>(DokanStockThresholdNotifier.new);

class DokanPopularProductsState {
  const DokanPopularProductsState({
    this.stage = DokanPopularFlowStage.pick,
    this.selectedFilter = 'সব',
    this.revision = 0,
  });

  final DokanPopularFlowStage stage;
  final String selectedFilter;
  final int revision;

  DokanPopularProductsState copyWith({
    DokanPopularFlowStage? stage,
    String? selectedFilter,
    int? revision,
  }) {
    return DokanPopularProductsState(
      stage: stage ?? this.stage,
      selectedFilter: selectedFilter ?? this.selectedFilter,
      revision: revision ?? this.revision,
    );
  }
}

enum DokanPopularFlowStage { pick, stock, complete }

class DokanPopularProductItem {
  DokanPopularProductItem({
    required this.name,
    required this.quantity,
    required this.emoji,
    required this.category,
    required this.selected,
    required String stock,
    required String price,
  })  : stockController = TextEditingController(text: stock),
        priceController = TextEditingController(text: price);

  final String name;
  final String quantity;
  final String emoji;
  final String category;
  bool selected;
  final TextEditingController stockController;
  final TextEditingController priceController;

  void dispose() {
    stockController.dispose();
    priceController.dispose();
  }
}

class DokanPopularProductsNotifier extends Notifier<DokanPopularProductsState> {
  late final List<DokanPopularProductItem> _items;

  static const List<String> filters = <String>[
    'সব',
    'চাল-ডাল',
    'তেল-মসলা',
    'সাবান-শ্যাম্পু',
  ];

  @override
  DokanPopularProductsState build() {
    _items = <DokanPopularProductItem>[
      DokanPopularProductItem(
        name: 'মিনিকেট চাল',
        quantity: '১ কেজি',
        emoji: '🌾',
        category: 'চাল-ডাল',
        selected: true,
        stock: '50',
        price: '72',
      ),
      DokanPopularProductItem(
        name: 'মসুর ডাল',
        quantity: '৫০০ গ্রাম',
        emoji: '🫘',
        category: 'চাল-ডাল',
        selected: false,
        stock: '0',
        price: '0',
      ),
      DokanPopularProductItem(
        name: 'সয়াবিন তেল',
        quantity: '১ লিটার',
        emoji: '🛢️',
        category: 'তেল-মসলা',
        selected: true,
        stock: '30',
        price: '85',
      ),
      DokanPopularProductItem(
        name: 'লবণ',
        quantity: '১ কেজি',
        emoji: '🧂',
        category: 'তেল-মসলা',
        selected: false,
        stock: '0',
        price: '0',
      ),
      DokanPopularProductItem(
        name: 'লাক্স সাবান',
        quantity: '১০০ গ্রাম',
        emoji: '🫧',
        category: 'সাবান-শ্যাম্পু',
        selected: true,
        stock: '100',
        price: '45',
      ),
      DokanPopularProductItem(
        name: 'কোকা কোলা ২৫০মি',
        quantity: '২৫০ মি.লি',
        emoji: '🥤',
        category: 'সব',
        selected: false,
        stock: '0',
        price: '0',
      ),
      DokanPopularProductItem(
        name: 'ফ্রেশ পাউডার দুধ',
        quantity: '৫০০ গ্রাম',
        emoji: '🥛',
        category: 'সাবান-শ্যাম্পু',
        selected: false,
        stock: '0',
        price: '0',
      ),
      DokanPopularProductItem(
        name: 'নাজিরশাইল চাল',
        quantity: '১ কেজি',
        emoji: '🌾',
        category: 'চাল-ডাল',
        selected: true,
        stock: '30',
        price: '85',
      ),
      DokanPopularProductItem(
        name: 'চিনি',
        quantity: '১ কেজি',
        emoji: '🍚',
        category: 'চাল-ডাল',
        selected: false,
        stock: '0',
        price: '0',
      ),
      DokanPopularProductItem(
        name: 'আটা',
        quantity: '২ কেজি',
        emoji: '🌽',
        category: 'চাল-ডাল',
        selected: false,
        stock: '0',
        price: '0',
      ),
      DokanPopularProductItem(
        name: 'বিস্কুট',
        quantity: '৫০ গ্রাম',
        emoji: '🍪',
        category: 'সাবান-শ্যাম্পু',
        selected: false,
        stock: '0',
        price: '0',
      ),
      DokanPopularProductItem(
        name: 'ডিটারজেন্ট',
        quantity: '১ কেজি',
        emoji: '🧼',
        category: 'সাবান-শ্যাম্পু',
        selected: false,
        stock: '0',
        price: '0',
      ),
    ];

    for (final item in _items) {
      item.stockController.addListener(_bump);
      item.priceController.addListener(_bump);
    }

    ref.onDispose(() {
      for (final item in _items) {
        item.dispose();
      }
    });
    return const DokanPopularProductsState();
  }

  List<DokanPopularProductItem> get items => _items;

  void _bump() {
    state = state.copyWith(revision: state.revision + 1);
  }

  void setFilter(String filter) {
    state = state.copyWith(selectedFilter: filter, revision: state.revision + 1);
  }

  void toggleItem(DokanPopularProductItem item) {
    item.selected = !item.selected;
    _bump();
  }

  List<DokanPopularProductItem> get selectionItems {
    if (state.selectedFilter == 'সব') {
      return _items;
    }
    return _items.where((item) => item.category == state.selectedFilter || item.category == 'সব').toList();
  }

  List<DokanPopularProductItem> get stockItems => _items.where((item) => item.selected).toList();

  int get selectedCount => _items.where((item) => item.selected).length;

  int get completedCount => _items.where((item) {
        if (!item.selected) return false;
        return item.stockController.text.trim().isNotEmpty &&
            item.priceController.text.trim().isNotEmpty &&
            item.stockController.text.trim() != '0' &&
            item.priceController.text.trim() != '0';
      }).length;

  void goToPick() {
    state = state.copyWith(stage: DokanPopularFlowStage.pick, revision: state.revision + 1);
  }

  void goToStockPage() {
    state = state.copyWith(stage: DokanPopularFlowStage.stock, revision: state.revision + 1);
  }

  void goToStock(BuildContext context) {
    if (selectedCount == 0) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: const Text('কমপক্ষে একটি পণ্য বাছাই করুন।', style: TextStyle(color: Colors.white)),
          backgroundColor: Colors.red.shade700,
        ),
      );
      return;
    }
    state = state.copyWith(stage: DokanPopularFlowStage.stock, revision: state.revision + 1);
  }

  void goToComplete(BuildContext context) {
    for (final item in _items.where((item) => item.selected)) {
      final stock = item.stockController.text.trim();
      final price = item.priceController.text.trim();
      if (stock.isEmpty || price.isEmpty) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: const Text('সব নির্বাচিত পণ্যের স্টক ও দাম পূরণ করুন।', style: TextStyle(color: Colors.white)),
            backgroundColor: Colors.red.shade700,
          ),
        );
        return;
      }
    }
    state = state.copyWith(stage: DokanPopularFlowStage.complete, revision: state.revision + 1);
  }
}

final dokanPopularProductsProvider = NotifierProvider<DokanPopularProductsNotifier, DokanPopularProductsState>(
  DokanPopularProductsNotifier.new,
);
