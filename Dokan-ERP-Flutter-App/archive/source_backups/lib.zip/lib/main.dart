import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import 'app/dokan_app_providers.dart';
import 'features/auth/screens/auth_screens.dart';
import 'features/dashboard/screens/dashboard_screen.dart';
import 'features/products/screens/product_screens.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
  SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
    statusBarColor: Colors.transparent,
    statusBarIconBrightness: Brightness.light,
    statusBarBrightness: Brightness.dark,
  ));
  runApp(const DokanErpApp());
}

class DokanErpApp extends StatelessWidget {
  const DokanErpApp({super.key});

  @override
  Widget build(BuildContext context) {
    return ProviderScope(
      child: MaterialApp(
        debugShowCheckedModeBanner: false,
        title: 'DokanERP',
        theme: ThemeData(
          useMaterial3: true,
          colorScheme: ColorScheme.fromSeed(
            seedColor: const Color(0xFF00694C),
            brightness: Brightness.dark,
          ),
        ),
        home: const _AppRoot(),
      ),
    );
  }
}

class _AppRoot extends ConsumerStatefulWidget {
  const _AppRoot();

  @override
  ConsumerState<_AppRoot> createState() => _AppRootState();
}

class _AppRootState extends ConsumerState<_AppRoot> with SingleTickerProviderStateMixin {
  late final AnimationController _progressController;

  @override
  void initState() {
    super.initState();
    _progressController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 2200),
    )..addListener(() {
        ref.read(dokanAppFlowProvider.notifier).setProgress(
              (_progressController.value * 100).round(),
            );
      });
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!mounted) {
        return;
      }
      ref.read(dokanAppFlowProvider.notifier).startSplash();
      _progressController.forward(from: 0);
    });
  }

  @override
  void dispose() {
    _progressController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final flow = ref.watch(dokanAppFlowProvider);
    final flowController = ref.read(dokanAppFlowProvider.notifier);

    return switch (flow.stage) {
      DokanStartupStage.splash => _PhoneShell(
          child: _SplashScreen(progress: flow.progress),
        ),
      DokanStartupStage.onboarding => _PhoneShell(
          child: OnboardingFlow(onFinished: flowController.finishOnboarding),
        ),
      DokanStartupStage.login => _PhoneShell(
        child: DokanLoginScreen(
          onBack: flowController.goToOnboarding,
          onLogin: flowController.goToHome,
          onOtpLogin: flowController.goToOtpLogin,
          onAccountOpen: flowController.goToRegister,
          initialRole: flow.loginRole,
          onRoleChanged: flowController.setLoginRole,
        ),
        ),
      DokanStartupStage.otpLogin => _PhoneShell(
          child: DokanOtpLoginScreen(
            onBack: flowController.goToLogin,
            onSendOtp: flowController.goToOtpVerify,
          ),
        ),
      DokanStartupStage.otpVerify => _PhoneShell(
          child: DokanOtpVerificationScreen(
            onBack: flowController.goToOtpLogin,
            onVerified: flowController.goToPinSetup,
          ),
        ),
      DokanStartupStage.pinSetup => _PhoneShell(
          child: DokanPinSetupScreen(
            onBack: flowController.goToOtpVerify,
            onContinue: flowController.goToPinLogin,
          ),
        ),
      DokanStartupStage.pinLogin => _PhoneShell(
          child: DokanPinLoginScreen(
            onBack: flowController.goToPinSetup,
            onLogin: flowController.completePinLogin,
          ),
        ),
      DokanStartupStage.register => _PhoneShell(
          child: DokanRegisterScreen(
            onBack: flowController.goToLogin,
            onContinue: (name, phone, password) {
  flowController.registerAccount(
    name: name,
    phone: phone,
    password: password,
  );
},
          ),
        ),
      DokanStartupStage.shopSetup => _PhoneShell(
          child: DokanShopSetupScreen(
            onBack: flowController.goToRegister,
            onContinue: flowController.completeShopSetup,
          ),
        ),
      DokanStartupStage.welcome => _PhoneShell(
          child: DokanWelcomeScreen(
            accountName: flow.registeredName,
            onPopularProducts: flowController.goToPopularProducts,
          ),
        ),
      DokanStartupStage.popularProducts => _PhoneShell(
          child: DokanPopularProductsScreen(
            shopName: flow.shopName,
            ownerName: flow.registeredName,
            onBack: flowController.goToWelcome,
            onContinue: flowController.goToHome,
          ),
        ),
     DokanStartupStage.home => _PhoneShell(
  child: flow.currentUserRole == 1
      ? const DokanSalesmanDashboardScreen()
      : const DokanHomeDashboardScreen(),
),
    };
  }
}

class _PhoneShell extends StatelessWidget {
  const _PhoneShell({required this.child});

  final Widget child;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: LayoutBuilder(
        builder: (context, constraints) {
          final isWide = constraints.maxWidth >= 700;
          final frameWidth = math.min(390.0, constraints.maxWidth);
          final frameHeight = isWide
              ? math.min(844.0, constraints.maxHeight)
              : constraints.maxHeight;

          final frame = SizedBox(
            width: frameWidth,
            height: frameHeight,
            child: child,
          );

          if (!isWide) {
            return frame;
          }

          return Container(
            decoration: const BoxDecoration(
              gradient: RadialGradient(
                center: Alignment(-0.2, -0.35),
                radius: 1.2,
                colors: [
                  Color(0xFF183730),
                  Color(0xFF071712),
                ],
              ),
            ),
            child: Center(
              child: Container(
                width: frameWidth,
                height: frameHeight,
                decoration: BoxDecoration(
                  color: const Color(0xFF0B221C),
                  borderRadius: BorderRadius.circular(34),
                  border: Border.all(
                    color: Colors.white.withValues(alpha: 0.08),
                  ),
                  boxShadow: const [
                    BoxShadow(
                      color: Color(0x66000000),
                      blurRadius: 40,
                      offset: Offset(0, 20),
                    ),
                  ],
                ),
                child: frame,
              ),
            ),
          );
        },
      ),
    );
  }
}

class _SplashScreen extends StatelessWidget {
  const _SplashScreen({required this.progress});

  final int progress;

  @override
  Widget build(BuildContext context) {
    final clamped = progress.clamp(0, 100);
    final percent = (clamped / 100).clamp(0.0, 1.0);

    return Container(
      decoration: const BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [
            Color(0xFF12362F),
            Color(0xFF081712),
          ],
        ),
      ),
      child: SafeArea(
        bottom: false,
        child: Stack(
          children: [
            const Positioned.fill(child: _Atmosphere()),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20),
              child: Column(
                children: [
                  const SizedBox(height: 28),
                  Expanded(
                    child: Center(
                      child: ConstrainedBox(
                        constraints: const BoxConstraints(maxWidth: 320),
                        child: const _BrandCluster(),
                      ),
                    ),
                  ),
                  const SizedBox(height: 28),
                ],
              ),
            ),
            Positioned(
              left: 0,
              right: 0,
              bottom: 0,
              child: _ProgressOverlay(
                progress: clamped,
                percent: percent,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _ProgressOverlay extends StatelessWidget {
  const _ProgressOverlay({
    required this.progress,
    required this.percent,
  });

  final int progress;
  final double percent;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 0, 20, 24),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          ClipRRect(
            borderRadius: BorderRadius.circular(999),
            child: Container(
              height: 5,
              color: Colors.white.withValues(alpha: 0.18),
              child: Align(
                alignment: Alignment.centerLeft,
                child: FractionallySizedBox(
                  widthFactor: percent,
                  child: Container(
                    decoration: BoxDecoration(
                      gradient: const LinearGradient(
                        colors: [
                          Color(0xFF00FFB9),
                          Color(0xFF00694C),
                        ],
                      ),
                      borderRadius: BorderRadius.circular(999),
                    ),
                  ),
                ),
              ),
            ),
          ),
          const SizedBox(height: 12),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              const Expanded(
                child: Text(
                  'SYSTEM INITIALIZING',
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                    fontSize: 12,
                    fontWeight: FontWeight.w800,
                    letterSpacing: 0.8,
                    color: Colors.white,
                  ),
                ),
              ),
              Text(
                '$progress%',
                style: TextStyle(
                  fontSize: 12,
                  fontWeight: FontWeight.w800,
                  letterSpacing: 1.1,
                  color: Colors.white.withValues(alpha: 0.95),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class _Atmosphere extends StatelessWidget {
  const _Atmosphere();

  @override
  Widget build(BuildContext context) {
    return const DecoratedBox(
      decoration: BoxDecoration(
        gradient: RadialGradient(
          center: Alignment(0.15, -0.2),
          radius: 1.0,
          colors: [
            Color(0x1AFFFFFF),
            Color(0x00000000),
          ],
        ),
      ),
    );
  }
}

class _BrandCluster extends StatelessWidget {
  const _BrandCluster();

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        SizedBox(
          width: 220,
          height: 220,
          child: Stack(
            alignment: Alignment.center,
            children: [
              Container(
                width: 178,
                height: 178,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: const Color(0xFF00694C).withValues(alpha: 0.14),
                  boxShadow: [
                    BoxShadow(
                      color: const Color(0xFF00694C).withValues(alpha: 0.35),
                      blurRadius: 54,
                      spreadRadius: 18,
                    ),
                  ],
                ),
              ),
              Container(
                width: 118,
                height: 118,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: const LinearGradient(
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                    colors: [
                      Color(0xFF0BA37A),
                      Color(0xFF00694C),
                    ],
                  ),
                  border: Border.all(
                    color: Colors.white.withValues(alpha: 0.18),
                    width: 1.2,
                  ),
                  boxShadow: const [
                    BoxShadow(
                      color: Color(0x5500694C),
                      blurRadius: 18,
                      offset: Offset(0, 10),
                    ),
                  ],
                ),
                child: const Icon(
                  Icons.storefront_rounded,
                  size: 54,
                  color: Colors.white,
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 8),
        const Text(
          'DokanERP',
          textAlign: TextAlign.center,
          style: TextStyle(
            fontSize: 42,
            height: 1.0,
            fontWeight: FontWeight.w800,
            letterSpacing: -1.2,
            color: Color(0xFF00FFB9),
          ),
        ),
        const SizedBox(height: 10),
        const Text(
          'আপনার দোকানের সহকারী',
          textAlign: TextAlign.center,
          style: TextStyle(
            fontSize: 16,
            fontWeight: FontWeight.w700,
            letterSpacing: 0.2,
            color: Colors.white,
          ),
        ),
      ],
    );
  }
}

class OnboardingFlow extends StatefulWidget {
  const OnboardingFlow({super.key, required this.onFinished});

  final VoidCallback onFinished;

  @override
  State<OnboardingFlow> createState() => _OnboardingFlowState();
}

class _OnboardingFlowState extends State<OnboardingFlow> {
  final PageController _pageController = PageController();
  int _page = 0;

  static const List<_OnboardingPageData> _pages = [
    _OnboardingPageData(
      title: 'আপনার দোকান এখন আপনার হাতে',
      subtitle: 'মুদি দোকানের বিক্রয়, স্টক ও হিসাব এখন একটি প্রফেশনাল অ্যাপে সামলান।',
      actionLabel: 'পরবর্তী',
      illustration: _OnboardingIllustration.kindOne,
      accent: Color(0xFF00694C),
      tint: Color(0xFFEAF5FA),
    ),
    _OnboardingPageData(
      title: 'বিক্রি করুন মাত্র কয়েক সেকেন্ডে',
      subtitle: 'পণ্য খুঁজুন, কার্টে যোগ করুন এবং নগদ, bKash বা বাকি দিয়ে দ্রুত বিক্রি সম্পন্ন করুন।',
      actionLabel: 'পরবর্তী',
      illustration: _OnboardingIllustration.kindTwo,
      accent: Color(0xFF0E8B69),
      tint: Color(0xFFF1FBFF),
    ),
    _OnboardingPageData(
      title: 'বাকি, লাভ-ক্ষতি সব নজরে রাখুন',
      subtitle: 'বাকি খাতা, দৈনিক রিপোর্ট ও আয়-ব্যয়ের হিসাব এক জায়গা থেকে দেখুন।',
      actionLabel: 'শুরু করুন',
      illustration: _OnboardingIllustration.kindThree,
      accent: Color(0xFF0A6A4F),
      tint: Color(0xFFE8F5E9),
    ),
  ];

  @override
  void dispose() {
    _pageController.dispose();
    super.dispose();
  }

  Future<void> _goToPage(int index) async {
    if (index < 0 || index >= _pages.length) {
      return;
    }
    await _pageController.animateToPage(
      index,
      duration: const Duration(milliseconds: 320),
      curve: Curves.easeOutCubic,
    );
  }

  Future<void> _handlePrimaryAction() async {
    if (_page < _pages.length - 1) {
      await _goToPage(_page + 1);
    } else {
      widget.onFinished();
    }
  }

  @override
  Widget build(BuildContext context) {
    final page = _pages[_page];

    return Container(
      color: const Color(0xFFF7FBFA),
      child: SafeArea(
        bottom: true,
        child: Column(
          children: [
            _OnboardingTopBar(
              onBack: _page == 0 ? null : () => _goToPage(_page - 1),
              onSkip: widget.onFinished,
              tint: page.tint,
            ),
            Expanded(
              child: PageView.builder(
                controller: _pageController,
                onPageChanged: (index) {
                  setState(() {
                    _page = index;
                  });
                },
                itemCount: _pages.length,
                itemBuilder: (context, index) {
                  final data = _pages[index];
                  return _OnboardingPage(
                    pageIndex: index,
                    data: data,
                    onPrimaryAction: _handlePrimaryAction,
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _OnboardingTopBar extends StatelessWidget {
  const _OnboardingTopBar({
    required this.onBack,
    required this.onSkip,
    required this.tint,
  });

  final VoidCallback? onBack;
  final VoidCallback onSkip;
  final Color tint;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 14, 20, 10),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          SizedBox(
            width: 64,
            height: 24,
            child: Align(
              alignment: Alignment.centerLeft,
              child: IconButton(
                onPressed: onBack,
                icon: const Icon(Icons.arrow_back_rounded),
                color: const Color(0xFF3D4943),
                iconSize: 20,
                padding: EdgeInsets.zero,
                constraints: const BoxConstraints.tightFor(width: 24, height: 24),
              ),
            ),
          ),
          TextButton(
            onPressed: onSkip,
            style: TextButton.styleFrom(
              foregroundColor: const Color(0xFF3D4943),
              padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 2),
              visualDensity: VisualDensity.compact,
            ),
            child: const Text(
              'এড়িয়ে যান',
              style: TextStyle(
                fontSize: 14,
                fontWeight: FontWeight.w500,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

enum _OnboardingIllustration { kindOne, kindTwo, kindThree }

class _OnboardingPageData {
  const _OnboardingPageData({
    required this.title,
    required this.subtitle,
    required this.actionLabel,
    required this.illustration,
    required this.accent,
    required this.tint,
  });

  final String title;
  final String subtitle;
  final String actionLabel;
  final _OnboardingIllustration illustration;
  final Color accent;
  final Color tint;
}

class _OnboardingPage extends StatelessWidget {
  const _OnboardingPage({
    required this.pageIndex,
    required this.data,
    required this.onPrimaryAction,
  });

  final int pageIndex;
  final _OnboardingPageData data;
  final VoidCallback onPrimaryAction;

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (context, constraints) {
        final illustrationHeight = math.min(355.0, constraints.maxHeight * 0.56);
        final titleGap = constraints.maxHeight < 500 ? 14.0 : 22.0;
        final subtitleGap = constraints.maxHeight < 500 ? 8.0 : 10.0;

        return SingleChildScrollView(
          physics: const ClampingScrollPhysics(),
          child: ConstrainedBox(
            constraints: BoxConstraints(minHeight: constraints.maxHeight),
            child: Padding(
              padding: const EdgeInsets.fromLTRB(20, 0, 20, 12),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      const SizedBox(height: 4),
                      _IllustrationCard(
                        data: data,
                        height: illustrationHeight,
                      ),
                      SizedBox(height: titleGap),
                      Text(
                        data.title,
                        textAlign: TextAlign.center,
                        style: const TextStyle(
                          fontSize: 20,
                          height: 1.35,
                          fontWeight: FontWeight.w700,
                          letterSpacing: -0.3,
                          color: Color(0xFF131D21),
                        ),
                      ),
                      SizedBox(height: subtitleGap),
                      Text(
                        data.subtitle,
                        textAlign: TextAlign.center,
                        style: const TextStyle(
                          fontSize: 14,
                          height: 1.55,
                          fontWeight: FontWeight.w400,
                          color: Color(0xFF3D4943),
                        ),
                      ),
                    ],
                  ),
                  _PageFooter(
                    pageCount: 3,
                    activeIndex: pageIndex,
                    actionLabel: data.actionLabel,
                    accent: data.accent,
                    onAction: onPrimaryAction,
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }
}

class _IllustrationCard extends StatelessWidget {
  const _IllustrationCard({
    required this.data,
    required this.height,
  });

  final _OnboardingPageData data;
  final double height;

  @override
  Widget build(BuildContext context) {
    return Container(
      height: height,
      decoration: BoxDecoration(
        color: data.tint,
        borderRadius: BorderRadius.circular(14),
      ),
      child: Stack(
        children: [
          Positioned.fill(
            child: _IllustrationBackground(illustration: data.illustration),
          ),
          Center(
            child: _IllustrationScene(
              illustration: data.illustration,
              accent: data.accent,
            ),
          ),
        ],
      ),
    );
  }
}

class _IllustrationBackground extends StatelessWidget {
  const _IllustrationBackground({required this.illustration});

  final _OnboardingIllustration illustration;

  @override
  Widget build(BuildContext context) {
    return DecoratedBox(
      decoration: BoxDecoration(
        gradient: RadialGradient(
          center: const Alignment(0.2, -0.2),
          radius: 1.2,
          colors: switch (illustration) {
            _OnboardingIllustration.kindOne => [
                const Color(0xFFEDF7FA),
                const Color(0xFFEAF5FA),
              ],
            _OnboardingIllustration.kindTwo => [
                const Color(0xFFF6FBFF),
                const Color(0xFFEAF4FA),
              ],
            _OnboardingIllustration.kindThree => [
                const Color(0xFFF0FBF2),
                const Color(0xFFE6F5E8),
              ],
          },
        ),
      ),
    );
  }
}

class _IllustrationScene extends StatelessWidget {
  const _IllustrationScene({
    required this.illustration,
    required this.accent,
  });

  final _OnboardingIllustration illustration;
  final Color accent;

  @override
  Widget build(BuildContext context) {
    return switch (illustration) {
      _OnboardingIllustration.kindOne => _sceneOne(accent),
      _OnboardingIllustration.kindTwo => _sceneTwo(accent),
      _OnboardingIllustration.kindThree => _sceneThree(accent),
    };
  }

  Widget _sceneOne(Color accent) {
    return Stack(
      alignment: Alignment.center,
      children: [
        Positioned(
          right: 34,
          top: 48,
          child: _GlowCircle(color: accent.withValues(alpha: 0.09), size: 118),
        ),
        Positioned(
          left: 28,
          bottom: 40,
          child: _GlowCircle(color: accent.withValues(alpha: 0.14), size: 154),
        ),
        Positioned(
          bottom: 22,
          child: _StoreCard(
            accent: accent,
            title: 'Store',
            subtitle: 'Dokan',
            icon: Icons.storefront_rounded,
          ),
        ),
        Positioned(
          left: 32,
          top: 72,
          child: _FeatureTile(
            label: 'বিক্রি',
            icon: Icons.point_of_sale_rounded,
            color: accent,
          ),
        ),
        Positioned(
          right: 18,
          top: 104,
          child: _FeatureTile(
            label: 'স্টক',
            icon: Icons.inventory_2_rounded,
            color: const Color(0xFF0A8B68),
          ),
        ),
        Positioned(
          right: 42,
          bottom: 52,
          child: _MiniChart(accent: accent),
        ),
      ],
    );
  }

  Widget _sceneTwo(Color accent) {
    return Stack(
      alignment: Alignment.center,
      children: [
        Positioned(
          left: 32,
          top: 44,
          child: _GlowCircle(color: accent.withValues(alpha: 0.1), size: 136),
        ),
        Positioned(
          right: 36,
          bottom: 34,
          child: _GlowCircle(color: accent.withValues(alpha: 0.12), size: 156),
        ),
        Positioned(
          left: 32,
          bottom: 40,
          child: _StackedCard(
            accent: accent,
            title: 'POS',
            subtitle: 'Fast checkout',
            icon: Icons.shopping_cart_checkout_rounded,
          ),
        ),
        Positioned(
          right: 22,
          top: 56,
          child: _FeatureTile(
            label: 'Cash',
            icon: Icons.payments_rounded,
            color: accent,
          ),
        ),
        Positioned(
          right: 42,
          bottom: 74,
          child: _FeatureTile(
            label: 'bKash',
            icon: Icons.account_balance_wallet_rounded,
            color: const Color(0xFF0A8B68),
          ),
        ),
        Positioned(
          top: 126,
          child: _ReceiptCard(accent: accent),
        ),
      ],
    );
  }

  Widget _sceneThree(Color accent) {
    return Stack(
      alignment: Alignment.center,
      children: [
        Positioned(
          right: 36,
          top: 58,
          child: _GlowCircle(color: accent.withValues(alpha: 0.1), size: 130),
        ),
        Positioned(
          left: 28,
          bottom: 34,
          child: _GlowCircle(color: accent.withValues(alpha: 0.12), size: 162),
        ),
        Positioned(
          left: 34,
          top: 58,
          child: _MetricCard(
            title: 'Due',
            value: '৳12,480',
            color: accent,
          ),
        ),
        Positioned(
          right: 28,
          bottom: 46,
          child: _MetricCard(
            title: 'Profit',
            value: '৳3,240',
            color: const Color(0xFF0A8B68),
          ),
        ),
        Positioned(
          bottom: 26,
          child: _LedgerBoard(accent: accent),
        ),
      ],
    );
  }
}

class _GlowCircle extends StatelessWidget {
  const _GlowCircle({required this.color, required this.size});

  final Color color;
  final double size;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        color: color,
      ),
    );
  }
}

class _StoreCard extends StatelessWidget {
  const _StoreCard({
    required this.accent,
    required this.title,
    required this.subtitle,
    required this.icon,
  });

  final Color accent;
  final String title;
  final String subtitle;
  final IconData icon;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 152,
      height: 168,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(20),
        color: Colors.white,
        boxShadow: const [
          BoxShadow(
            color: Color(0x1A000000),
            blurRadius: 26,
            offset: Offset(0, 14),
          ),
        ],
      ),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
            width: 64,
            height: 64,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              gradient: LinearGradient(
                colors: [
                  accent.withValues(alpha: 0.95),
                  accent.withValues(alpha: 0.75),
                ],
              ),
            ),
            child: const Icon(Icons.storefront_rounded, color: Colors.white, size: 34),
          ),
          const SizedBox(height: 14),
          Text(
            title,
            style: const TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.w700,
              color: Color(0xFF131D21),
            ),
          ),
          const SizedBox(height: 4),
          Text(
            subtitle,
            style: const TextStyle(
              fontSize: 12,
              color: Color(0xFF3D4943),
            ),
          ),
        ],
      ),
    );
  }
}

class _FeatureTile extends StatelessWidget {
  const _FeatureTile({
    required this.label,
    required this.icon,
    required this.color,
  });

  final String label;
  final IconData icon;
  final Color color;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 106,
      height: 76,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(18),
        color: Colors.white,
        boxShadow: const [
          BoxShadow(
            color: Color(0x14000000),
            blurRadius: 18,
            offset: Offset(0, 10),
          ),
        ],
      ),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
            width: 34,
            height: 34,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: color.withValues(alpha: 0.12),
            ),
            child: Icon(icon, color: color, size: 18),
          ),
          const SizedBox(height: 8),
          Text(
            label,
            style: const TextStyle(
              fontSize: 11,
              fontWeight: FontWeight.w700,
              color: Color(0xFF131D21),
            ),
          ),
        ],
      ),
    );
  }
}

class _MiniChart extends StatelessWidget {
  const _MiniChart({required this.accent});

  final Color accent;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 94,
      height: 64,
      padding: const EdgeInsets.all(10),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(18),
        color: Colors.white,
        boxShadow: const [
          BoxShadow(
            color: Color(0x14000000),
            blurRadius: 18,
            offset: Offset(0, 10),
          ),
        ],
      ),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.end,
        children: [
          Row(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              _bar(10, accent.withValues(alpha: 0.35)),
              const SizedBox(width: 4),
              _bar(18, accent.withValues(alpha: 0.55)),
              const SizedBox(width: 4),
              _bar(26, accent),
              const SizedBox(width: 4),
              _bar(14, const Color(0xFF0A8B68)),
            ],
          ),
        ],
      ),
    );
  }

  Widget _bar(double height, Color color) {
    return Expanded(
      child: Container(
        height: height,
        decoration: BoxDecoration(
          color: color,
          borderRadius: BorderRadius.circular(999),
        ),
      ),
    );
  }
}

class _StackedCard extends StatelessWidget {
  const _StackedCard({
    required this.accent,
    required this.title,
    required this.subtitle,
    required this.icon,
  });

  final Color accent;
  final String title;
  final String subtitle;
  final IconData icon;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 168,
      height: 176,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(24),
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            Colors.white,
            Colors.white.withValues(alpha: 0.96),
          ],
        ),
        boxShadow: const [
          BoxShadow(
            color: Color(0x1A000000),
            blurRadius: 28,
            offset: Offset(0, 16),
          ),
        ],
      ),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Row(
              children: [
                Container(
                  width: 36,
                  height: 36,
                  decoration: BoxDecoration(
                    color: accent.withValues(alpha: 0.12),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Icon(icon, color: accent, size: 18),
                ),
                const Spacer(),
                Container(
                  width: 42,
                  height: 10,
                  decoration: BoxDecoration(
                    color: const Color(0xFFE8EFEC),
                    borderRadius: BorderRadius.circular(999),
                  ),
                ),
              ],
            ),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: const TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.w700,
                    color: Color(0xFF131D21),
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  subtitle,
                  style: const TextStyle(
                    fontSize: 12,
                    color: Color(0xFF3D4943),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class _ReceiptCard extends StatelessWidget {
  const _ReceiptCard({required this.accent});

  final Color accent;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 184,
      height: 148,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(22),
        color: Colors.white,
        boxShadow: const [
          BoxShadow(
            color: Color(0x14000000),
            blurRadius: 24,
            offset: Offset(0, 14),
          ),
        ],
      ),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Container(
                  width: 38,
                  height: 38,
                  decoration: BoxDecoration(
                    color: accent.withValues(alpha: 0.1),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Icon(Icons.receipt_long_rounded, color: accent, size: 18),
                ),
                const Spacer(),
                Container(
                  width: 42,
                  height: 8,
                  decoration: BoxDecoration(
                    color: const Color(0xFFE8EFEC),
                    borderRadius: BorderRadius.circular(999),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 16),
            _receiptLine(0.9, accent),
            const SizedBox(height: 8),
            _receiptLine(0.6, const Color(0xFFC9D8D2)),
            const SizedBox(height: 8),
            _receiptLine(0.75, const Color(0xFFC9D8D2)),
            const Spacer(),
            Container(
              height: 10,
              decoration: BoxDecoration(
                color: accent.withValues(alpha: 0.18),
                borderRadius: BorderRadius.circular(999),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _receiptLine(double factor, Color color) {
    return FractionallySizedBox(
      widthFactor: factor,
      alignment: Alignment.centerLeft,
      child: Container(
        height: 8,
        decoration: BoxDecoration(
          color: color,
          borderRadius: BorderRadius.circular(999),
        ),
      ),
    );
  }
}

class _MetricCard extends StatelessWidget {
  const _MetricCard({
    required this.title,
    required this.value,
    required this.color,
  });

  final String title;
  final String value;
  final Color color;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 122,
      height: 124,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(20),
        color: Colors.white,
        boxShadow: const [
          BoxShadow(
            color: Color(0x14000000),
            blurRadius: 20,
            offset: Offset(0, 12),
          ),
        ],
      ),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Container(
              width: 34,
              height: 34,
              decoration: BoxDecoration(
                color: color.withValues(alpha: 0.12),
                borderRadius: BorderRadius.circular(12),
              ),
              child: Icon(Icons.analytics_rounded, color: color, size: 18),
            ),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: const TextStyle(
                    fontSize: 12,
                    fontWeight: FontWeight.w700,
                    color: Color(0xFF3D4943),
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  value,
                  style: const TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.w800,
                    color: Color(0xFF131D21),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class _LedgerBoard extends StatelessWidget {
  const _LedgerBoard({required this.accent});

  final Color accent;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 202,
      height: 156,
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(24),
        color: Colors.white,
        boxShadow: const [
          BoxShadow(
            color: Color(0x1A000000),
            blurRadius: 24,
            offset: Offset(0, 14),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                width: 40,
                height: 40,
                decoration: BoxDecoration(
                  color: accent.withValues(alpha: 0.12),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Icon(Icons.trending_up_rounded, color: accent, size: 18),
              ),
              const Spacer(),
              Container(
                width: 48,
                height: 10,
                decoration: BoxDecoration(
                  color: const Color(0xFFE8EFEC),
                  borderRadius: BorderRadius.circular(999),
                ),
              ),
            ],
          ),
          const SizedBox(height: 14),
          _ledgerLine(0.94, accent),
          const SizedBox(height: 8),
          _ledgerLine(0.78, const Color(0xFFC9D8D2)),
          const SizedBox(height: 8),
          _ledgerLine(0.66, const Color(0xFFC9D8D2)),
          const SizedBox(height: 8),
          _ledgerLine(0.42, accent.withValues(alpha: 0.6)),
          const Spacer(),
          Container(
            height: 12,
            decoration: BoxDecoration(
              color: accent.withValues(alpha: 0.18),
              borderRadius: BorderRadius.circular(999),
            ),
          ),
        ],
      ),
    );
  }

  Widget _ledgerLine(double widthFactor, Color color) {
    return FractionallySizedBox(
      widthFactor: widthFactor,
      alignment: Alignment.centerLeft,
      child: Container(
        height: 8,
        decoration: BoxDecoration(
          color: color,
          borderRadius: BorderRadius.circular(999),
        ),
      ),
    );
  }
}

class _PageFooter extends StatelessWidget {
  const _PageFooter({
    required this.pageCount,
    required this.activeIndex,
    required this.actionLabel,
    required this.accent,
    required this.onAction,
  });

  final int pageCount;
  final int? activeIndex;
  final String actionLabel;
  final Color accent;
  final VoidCallback onAction;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 0),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: List.generate(pageCount, (index) {
              final active = index == activeIndex;
              return AnimatedContainer(
                duration: const Duration(milliseconds: 220),
                margin: const EdgeInsets.symmetric(horizontal: 4),
                width: active ? 24 : 8,
                height: 8,
                decoration: BoxDecoration(
                  color: active ? accent : const Color(0xFFBCCAC1),
                  borderRadius: BorderRadius.circular(999),
                ),
              );
            }),
          ),
          const SizedBox(height: 10),
          SizedBox(
            width: double.infinity,
            height: 56,
            child: ElevatedButton(
              onPressed: onAction,
              style: ElevatedButton.styleFrom(
                backgroundColor: accent,
                foregroundColor: Colors.white,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(10),
                ),
                elevation: 0,
              ),
              child: Text(
                actionLabel,
                style: const TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.w700,
                  letterSpacing: 0.4,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
class DokanSalesmanDashboardScreen extends StatelessWidget {
  const DokanSalesmanDashboardScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: Colors.white,
        title: const Text(
          'Salesman Dashboard',
          style: TextStyle(color: Colors.black),
        ),
      ),
      body: const Center(
        child: Text(
          'Salesman Login Successful',
          style: TextStyle(
            color: Colors.black,
            fontSize: 20,
            fontWeight: FontWeight.w700,
          ),
        ),
      ),
    );
  }
}