import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../dashboard/screens/dashboard_screen.dart';
import '../../products/screens/product_screens.dart';
import '../../reports/screens/reports_screens.dart';
import '../../settings/screens/settings_screens.dart';
import '../state/pos_checkout_provider.dart';

String _banglaText(String value, {String fallback = 'পণ্যের নাম নেই'}) {
  final text = value.trim();
  return text.isEmpty ? fallback : text;
}

String _banglaDigits(String input) {
  const map = <String, String>{
    '0': '০',
    '1': '১',
    '2': '২',
    '3': '৩',
    '4': '৪',
    '5': '৫',
    '6': '৬',
    '7': '৭',
    '8': '৮',
    '9': '৯',
  };
  return input.split('').map((char) => map[char] ?? char).join();
}

String _formatCurrency(int value) {
  return '৳${_banglaDigits(value.toString())}';
}

class DokanPosMainScreen extends ConsumerStatefulWidget {
  const DokanPosMainScreen({super.key});

  @override
  ConsumerState<DokanPosMainScreen> createState() => _DokanPosMainScreenState();
}

class _DokanPosMainScreenState extends ConsumerState<DokanPosMainScreen> {
  final TextEditingController _searchController = TextEditingController();
  final TextEditingController _discountController = TextEditingController();
  final TextEditingController _customerNameController = TextEditingController();
  final TextEditingController _customerNumberController =
      TextEditingController();
  final TextEditingController _paymentTransactionController =
      TextEditingController();
  final TextEditingController _cashReceivedController =
      TextEditingController();
  final TextEditingController _cardHolderController = TextEditingController();
  final TextEditingController _cardLast4Controller = TextEditingController();
  final TextEditingController _cardApprovalController = TextEditingController();
  final TextEditingController _cardBankController = TextEditingController();
  final TextEditingController _bankSenderController = TextEditingController();
  final TextEditingController _bankNameController = TextEditingController();
  final TextEditingController _bankAccountController = TextEditingController();
  final TextEditingController _bankReferenceController = TextEditingController();
  final TextEditingController _bankRoutingController = TextEditingController();

  int _selectedCategoryIndex = 0;
  String _searchQuery = '';
  Map<String, String> _paymentFieldErrors = <String, String>{};

  static const List<_Category> _categories = <_Category>[
    _Category(label: 'সব পণ্য', key: 'all'),
    _Category(label: 'চাল-ডাল', key: 'rice'),
    _Category(label: 'তেল-মসলা', key: 'oil'),
    _Category(label: 'প্যাকেট আইটেম', key: 'pack'),
    _Category(label: 'দৈনন্দিন', key: 'daily'),
  ];

  static const List<_Product> _products = <_Product>[
    _Product(
      id: 'rice-5kg',
      name: 'মিনিকেট চাল ৫ কেজি',
      price: 630,
      stock: 12,
      categoryKey: 'rice',
      icon: Icons.rice_bowl_outlined,
      searchTerms: <String>['চাল', 'rice', 'মিনিকেট', 'bhat'],
    ),
    _Product(
      id: 'rice-1kg',
      name: 'মিনিকেট চাল ১ কেজি',
      price: 130,
      stock: 24,
      categoryKey: 'rice',
      icon: Icons.rice_bowl_outlined,
      searchTerms: <String>['চাল', 'rice', 'মিনিকেট'],
    ),
    _Product(
      id: 'lentil-1kg',
      name: 'মসুর ডাল ১ কেজি',
      price: 190,
      stock: 18,
      categoryKey: 'rice',
      icon: Icons.grain_outlined,
      searchTerms: <String>['ডাল', 'lentil', 'mashur', 'mushur'],
    ),
    _Product(
      id: 'lentil-5kg',
      name: 'মসুর ডাল ৫ কেজি',
      price: 880,
      stock: 10,
      categoryKey: 'rice',
      icon: Icons.grain_outlined,
      searchTerms: <String>['ডাল', 'lentil', '5kg'],
    ),
    _Product(
      id: 'soap-100g',
      name: 'লাকো সাবান ১০০ গ্রাম',
      price: 250,
      stock: 26,
      categoryKey: 'daily',
      icon: Icons.spa_outlined,
      searchTerms: <String>['সাবান', 'soap', 'লাকো'],
    ),
    _Product(
      id: 'detergent',
      name: 'ভিট ডিটারজেন্ট',
      price: 285,
      stock: 21,
      categoryKey: 'daily',
      icon: Icons.local_laundry_service_outlined,
      searchTerms: <String>['ডিটারজেন্ট', 'detergent', 'ভিট'],
    ),
    _Product(
      id: 'tea-250',
      name: 'চা কোকো ২৫০ মিলি',
      price: 100,
      stock: 64,
      categoryKey: 'pack',
      icon: Icons.local_drink_outlined,
      searchTerms: <String>['চা', 'কোকো', 'tea', 'drink'],
    ),
    _Product(
      id: 'tea-500',
      name: 'চা কোকো ৫০০ মিলি',
      price: 120,
      stock: 58,
      categoryKey: 'pack',
      icon: Icons.local_drink_outlined,
      searchTerms: <String>['চা', 'কোকো', 'tea', 'drink'],
    ),
    _Product(
      id: 'oil-1l',
      name: 'সয়াবিন তেল ১ লিটার',
      price: 185,
      stock: 15,
      categoryKey: 'oil',
      icon: Icons.water_drop_outlined,
      searchTerms: <String>['তেল', 'oil', 'soyabin', 'soybean'],
    ),
    _Product(
      id: 'oil-500',
      name: 'সরিষার তেল ৫০০ মিলি',
      price: 220,
      stock: 14,
      categoryKey: 'oil',
      icon: Icons.water_drop_outlined,
      searchTerms: <String>['তেল', 'oil', 'সরিষা', 'mustard'],
    ),
    _Product(
      id: 'salt-1kg',
      name: 'সয়াবিন লবণ ১ কেজি',
      price: 40,
      stock: 40,
      categoryKey: 'daily',
      icon: Icons.egg_outlined,
      searchTerms: <String>['লবণ', 'salt', 'solt'],
    ),
    _Product(
      id: 'sugar-1kg',
      name: 'চিনি ১ কেজি',
      price: 135,
      stock: 29,
      categoryKey: 'daily',
      icon: Icons.coffee_outlined,
      searchTerms: <String>['চিনি', 'sugar', 'suger'],
    ),
    _Product(
      id: 'biscuit',
      name: 'বিস্কুট প্যাকেট',
      price: 80,
      stock: 51,
      categoryKey: 'pack',
      icon: Icons.cookie_outlined,
      searchTerms: <String>['বিস্কুট', 'biscuit', 'packet'],
    ),
  ];

  @override
  void initState() {
    super.initState();
    _discountController.text = '0';
    _searchController.addListener(() {
      setState(() {
        _searchQuery = _searchController.text.trim().toLowerCase();
      });
    });
  }

  @override
  void dispose() {
    _searchController.dispose();
    _discountController.dispose();
    _customerNameController.dispose();
    _customerNumberController.dispose();
    _paymentTransactionController.dispose();
    _cashReceivedController.dispose();
    _cardHolderController.dispose();
    _cardLast4Controller.dispose();
    _cardApprovalController.dispose();
    _cardBankController.dispose();
    _bankSenderController.dispose();
    _bankNameController.dispose();
    _bankAccountController.dispose();
    _bankReferenceController.dispose();
    _bankRoutingController.dispose();
    super.dispose();
  }

  List<_Product> get _visibleProducts {
    final category = _categories[_selectedCategoryIndex].key;
    return _products.where((product) {
      final matchesCategory = category == 'all' || product.categoryKey == category;
      final matchesQuery = _searchQuery.isEmpty ||
          product.name.toLowerCase().contains(_searchQuery) ||
          product.searchTerms.any((term) => term.toLowerCase().contains(_searchQuery));
      return matchesCategory && matchesQuery;
    }).toList();
  }

  void _addToCart(_Product product) {
    ref.read(dokanPosProvider.notifier).addItem(product.id, stockLimit: product.stock);
  }

  void _removeFromCart(_Product product) {
    ref.read(dokanPosProvider.notifier).removeItem(product.id);
  }

  Future<void> _openSalesSideMenu() async {
    await showGeneralDialog<void>(
      context: context,
      barrierLabel: 'বিক্রয় মেনু',
      barrierDismissible: true,
      barrierColor: Colors.black.withValues(alpha: 0.25),
      transitionDuration: const Duration(milliseconds: 240),
      pageBuilder: (context, animation, secondaryAnimation) {
        return Align(
          alignment: Alignment.centerLeft,
          child: SafeArea(
            child: Material(
              color: Colors.transparent,
              child: _PosSalesSideMenu(
                onClose: () => Navigator.of(context).pop(),
                onTapHistory: () {
                  Navigator.of(context).pop();
                  Navigator.of(context).push(
                    MaterialPageRoute(
                      builder: (_) => const DokanPosSalesHistoryScreen(),
                    ),
                  );
                },
                onTapDetails: () {
                  Navigator.of(context).pop();
                  Navigator.of(context).push(
                    MaterialPageRoute(
                      builder: (_) => const DokanPosSalesDetailsScreen(),
                    ),
                  );
                },
                onTapClosing: () {
                  Navigator.of(context).pop();
                  Navigator.of(context).push(
                    MaterialPageRoute(
                      builder: (_) => const DokanPosDailyClosingScreen(),
                    ),
                  );
                },
              ),
            ),
          ),
        );
      },
      transitionBuilder: (context, animation, secondaryAnimation, child) {
        final offset = Tween<Offset>(
          begin: const Offset(-1, 0),
          end: Offset.zero,
        ).animate(CurvedAnimation(parent: animation, curve: Curves.easeOutCubic));
        return SlideTransition(position: offset, child: child);
      },
    );
  }

  void _showQuickNote(String message) {
    ScaffoldMessenger.of(context)
      ..clearSnackBars()
      ..showSnackBar(
        SnackBar(
          content: Text(message),
          backgroundColor: const Color(0xFF153B34),
          behavior: SnackBarBehavior.floating,
        ),
      );
  }

  void _showAlertDialog({
    required String title,
    required String message,
    required Color accent,
  }) {
    final isSuccess = accent == const Color(0xFF0C8C67);
    ScaffoldMessenger.of(context)
      ..clearSnackBars()
      ..showSnackBar(
        SnackBar(
          behavior: SnackBarBehavior.floating,
          margin: const EdgeInsets.fromLTRB(16, 0, 16, 16),
          duration: const Duration(seconds: 3),
          backgroundColor: isSuccess ? const Color(0xFF0C8C67) : Colors.white,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(18),
            side: BorderSide(color: accent.withValues(alpha: 0.45)),
          ),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                title,
                style: TextStyle(
                  color: isSuccess ? Colors.white : accent,
                  fontWeight: FontWeight.w900,
                  fontSize: 15,
                ),
              ),
              const SizedBox(height: 4),
              Text(
                message,
                style: TextStyle(
                  color: isSuccess ? Colors.white : Colors.red.shade700,
                  fontWeight: FontWeight.w700,
                  fontSize: 13,
                ),
              ),
            ],
          ),
        ),
    );
  }

  void _showEmptyCartNotice() {
    _showAlertDialog(
      title: 'কার্ট খালি',
      message: 'কার্ট খালি আছে। অনুগ্রহ করে পণ্য যোগ করুন।',
      accent: const Color(0xFF0C8C67),
    );
  }

  String? _validatePhoneField(String value, String label) {
    final text = value.trim();
    if (text.isEmpty) {
      return '$label পূরণ করুন।';
    }
    if (!RegExp(r'^[0-9]{11}$').hasMatch(text)) {
      return '$label ১১ সংখ্যার হতে হবে।';
    }
    return null;
  }

  String? _validateTransactionField(String value, String label) {
    final text = value.trim();
    if (text.isEmpty) {
      return '$label পূরণ করুন।';
    }
    if (text.length < 6) {
      return '$label কমপক্ষে ৬ অক্ষরের হতে হবে।';
    }
    if (text.length > 20) {
      return '$label ২০ অক্ষরের বেশি হতে পারবে না।';
    }
    if (!RegExp(r'^[0-9A-Za-z]+$').hasMatch(text)) {
      return '$label-এ শুধু সংখ্যা ও ইংরেজি অক্ষর ব্যবহার করুন।';
    }
    return null;
  }

  String? _validateCardLast4(String value) {
    final text = value.trim();
    if (text.isEmpty) {
      return 'কার্ডের শেষ ৪ সংখ্যা পূরণ করুন।';
    }
    if (text.length != 4) {
      return 'কার্ডের শেষ ৪ সংখ্যা ঠিক ৪টি হতে হবে।';
    }
    if (!RegExp(r'^[0-9]{4}$').hasMatch(text)) {
      return 'কার্ডের শেষ ৪ সংখ্যা কেবল সংখ্যা হতে হবে।';
    }
    return null;
  }

  String? _validateAccountField(String value, String label) {
    final text = value.trim();
    if (text.isEmpty) {
      return '$label পূরণ করুন।';
    }
    if (text.length < 8) {
      return '$label কমপক্ষে ৮ সংখ্যার হতে হবে।';
    }
    if (text.length > 20) {
      return '$label ২০ সংখ্যার বেশি হতে পারবে না।';
    }
    if (!RegExp(r'^[0-9]+$').hasMatch(text)) {
      return '$label শুধু সংখ্যা হতে হবে।';
    }
    return null;
  }

  Map<String, String> _validateCheckoutForm(DokanPosState state) {
    final errors = <String, String>{};

    if (state.cartCount == 0) {
      errors['cart'] = 'কার্ট খালি আছে। অনুগ্রহ করে পণ্য যোগ করুন।';
      return errors;
    }

    final method = state.paymentMethod;
    if (method == DokanPosPaymentMethod.cash) {
      if (state.customerName.trim().isEmpty) {
        errors['customerName'] = 'গ্রাহকের নাম পূরণ করুন।';
      }
      final phoneError = _validatePhoneField(state.customerNumber, 'গ্রাহকের মোবাইল নম্বর');
      if (phoneError != null) {
        errors['customerNumber'] = phoneError;
      }
      if (state.cashReceived <= 0) {
        errors['cashReceived'] = 'প্রাপ্ত নগদ পূরণ করুন।';
      } else if (state.cashReceived > state.total) {
        errors['cashReceived'] = 'প্রাপ্ত নগদ মোট টাকার চেয়ে বেশি হতে পারে না।';
      }
      return errors;
    }

    if (method == DokanPosPaymentMethod.bkash ||
        method == DokanPosPaymentMethod.nagad ||
        method == DokanPosPaymentMethod.rocket) {
      if (state.customerName.trim().isEmpty) {
        errors['customerName'] = 'গ্রাহকের নাম পূরণ করুন।';
      }
      final phoneError = _validatePhoneField(state.customerNumber, 'গ্রাহকের মোবাইল নম্বর');
      if (phoneError != null) {
        errors['customerNumber'] = phoneError;
      }
      final txnError = _validateTransactionField(state.transactionId, 'লেনদেন আইডি');
      if (txnError != null) {
        errors['transactionId'] = txnError;
      }
      return errors;
    }

    if (method == DokanPosPaymentMethod.card) {
      if (_cardHolderController.text.trim().isEmpty) {
        errors['cardHolder'] = 'কার্ডধারীর নাম পূরণ করুন।';
      }
      final last4Error = _validateCardLast4(_cardLast4Controller.text);
      if (last4Error != null) {
        errors['cardLast4'] = last4Error;
      }
      final approvalError = _validateTransactionField(_cardApprovalController.text, 'কার্ড অনুমোদন কোড');
      if (approvalError != null) {
        errors['cardApproval'] = approvalError;
      }
      return errors;
    }

    if (method == DokanPosPaymentMethod.bank) {
      if (_bankSenderController.text.trim().isEmpty) {
        errors['bankSender'] = 'প্রেরকের নাম পূরণ করুন।';
      }
      if (_bankNameController.text.trim().isEmpty) {
        errors['bankName'] = 'ব্যাংকের নাম পূরণ করুন।';
      }
      final accountError = _validateAccountField(_bankAccountController.text, 'ব্যাংক অ্যাকাউন্ট নম্বর');
      if (accountError != null) {
        errors['bankAccount'] = accountError;
      }
      final refError = _validateTransactionField(_bankReferenceController.text, 'ব্যাংক রেফারেন্স নম্বর');
      if (refError != null) {
        errors['bankReference'] = refError;
      }
      return errors;
    }

    return errors;
  }

  String _paymentLabel(DokanPosPaymentMethod method) {
    switch (method) {
      case DokanPosPaymentMethod.cash:
        return 'নগদ টাকা';
      case DokanPosPaymentMethod.bkash:
        return 'বিকাশ';
      case DokanPosPaymentMethod.rocket:
        return 'রকেট';
      case DokanPosPaymentMethod.nagad:
        return 'নগদ (মোবাইল)';
      case DokanPosPaymentMethod.card:
        return 'কার্ড';
      case DokanPosPaymentMethod.bank:
        return 'ব্যাংক';
    }
  }

  String _statusLabel(DokanPosOrderStatus status) {
    switch (status) {
      case DokanPosOrderStatus.paid:
        return 'পরিশোধিত';
      case DokanPosOrderStatus.due:
        return 'বাকি রয়েছে';
      case DokanPosOrderStatus.partiallyPaid:
        return 'আংশিক পরিশোধিত';
      case DokanPosOrderStatus.cancelled:
        return 'বাতিল';
    }
  }

  Color _statusColor(DokanPosOrderStatus status) {
    switch (status) {
      case DokanPosOrderStatus.paid:
        return const Color(0xFF0C8C67);
      case DokanPosOrderStatus.partiallyPaid:
        return const Color(0xFFC77700);
      case DokanPosOrderStatus.due:
      case DokanPosOrderStatus.cancelled:
        return const Color(0xFFB3261E);
    }
  }

  Future<void> _openCartSheet() async {
    final current = ref.read(dokanPosProvider);

    if (current.cartCount == 0) {
      _showEmptyCartNotice();
      return;
    }

    setState(() {
      _paymentFieldErrors = <String, String>{};
    });

    _discountController.text = current.discount.toString();
    _customerNameController.text = current.customerName;
    _customerNumberController.text = current.customerNumber;
    _paymentTransactionController.text = current.transactionId;
    _cashReceivedController.text = current.cashReceived == 0
        ? ''
        : current.cashReceived.toString();

    await showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) {
        return StatefulBuilder(
          builder: (context, setModalState) {
            return Consumer(
              builder: (context, ref, _) {
            final state = ref.watch(dokanPosProvider);
            final method = state.paymentMethod;
            final isCash = method == DokanPosPaymentMethod.cash;
            final checkoutStatus = isCash
                ? (state.cashReceived >= state.total
                    ? DokanPosOrderStatus.paid
                    : state.cashReceived > 0
                        ? DokanPosOrderStatus.partiallyPaid
                        : DokanPosOrderStatus.due)
                : DokanPosOrderStatus.paid;
            final statusColor = _statusColor(checkoutStatus);
            final dueVisible = isCash && state.cashReceived < state.total;
            final dueAmount = dueVisible ? state.total - state.cashReceived : 0;

            return SafeArea(
              top: false,
              child: Container(
                decoration: const BoxDecoration(
                  color: Color(0xFFF3F8F7),
                  borderRadius: BorderRadius.vertical(top: Radius.circular(28)),
                ),
                padding: EdgeInsets.only(
                  left: 16,
                  right: 16,
                  top: 14,
                  bottom: MediaQuery.of(context).viewInsets.bottom + 16,
                ),
                child: SingleChildScrollView(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Center(
                        child: Container(
                          width: 54,
                          height: 5,
                          decoration: BoxDecoration(
                            color: Colors.black12,
                            borderRadius: BorderRadius.circular(999),
                          ),
                        ),
                      ),
                      const SizedBox(height: 16),
                      Row(
                        children: [
                          const Icon(Icons.shopping_cart_outlined,
                              color: Color(0xFF006B53)),
                          const SizedBox(width: 10),
                          Expanded(
                            child: Text(
                              'কার্ট (${state.cartCount} পণ্য)',
                              style: const TextStyle(
                                fontSize: 18,
                                fontWeight: FontWeight.w800,
                                color: Colors.black,
                              ),
                            ),
                          ),
                          TextButton(
                            onPressed: () => Navigator.of(context).pop(),
                            child: const Text(
                              'বন্ধ',
                              style: TextStyle(color: Colors.black),
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 12),
                      Container(
                        width: double.infinity,
                        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
                        decoration: BoxDecoration(
                          color: statusColor.withValues(alpha: 0.10),
                          borderRadius: BorderRadius.circular(18),
                          border: Border.all(color: statusColor.withValues(alpha: 0.25)),
                        ),
                        child: Row(
                          children: [
                            Icon(
                              checkoutStatus == DokanPosOrderStatus.paid
                                  ? Icons.check_circle_outline
                                  : checkoutStatus == DokanPosOrderStatus.partiallyPaid
                                      ? Icons.info_outline
                                      : Icons.error_outline,
                              color: statusColor,
                            ),
                            const SizedBox(width: 10),
                            Expanded(
                              child: Text(
                                _statusLabel(checkoutStatus),
                                style: TextStyle(
                                  color: statusColor,
                                  fontSize: 16,
                                  fontWeight: FontWeight.w800,
                                ),
                              ),
                            ),
                            if (dueVisible)
                              Text(
                                '৳$dueAmount',
                                style: TextStyle(
                                  color: statusColor,
                                  fontSize: 16,
                                  fontWeight: FontWeight.w900,
                                ),
                              ),
                          ],
                        ),
                      ),
                      const SizedBox(height: 12),
                      ...state.cartQuantities.entries.map((entry) {
                        final product = _products.firstWhere(
                          (item) => item.id == entry.key,
                        );
                        return Padding(
                          padding: const EdgeInsets.only(bottom: 12),
                          child: Container(
                            decoration: BoxDecoration(
                              color: Colors.white,
                              borderRadius: BorderRadius.circular(20),
                              border: Border.all(color: const Color(0xFFD6E4E0)),
                            ),
                            padding: const EdgeInsets.all(14),
                            child: Row(
                              children: [
                                Container(
                                  width: 48,
                                  height: 48,
                                  decoration: BoxDecoration(
                                    color: const Color(0xFFF0F5F4),
                                    borderRadius: BorderRadius.circular(14),
                                  ),
                                  child: Icon(
                                    product.icon,
                                    color: const Color(0xFF006B53),
                                  ),
                                ),
                                const SizedBox(width: 12),
                                Expanded(
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Text(
                                        _banglaText(product.name),
                                        maxLines: 2,
                                        overflow: TextOverflow.ellipsis,
                                        softWrap: true,
                                        style: const TextStyle(
                                          fontSize: 16,
                                          fontWeight: FontWeight.w800,
                                          color: Colors.black,
                                        ),
                                      ),
                                      const SizedBox(height: 4),
                                      Text(
                                        '৳${product.price}',
                                        style: const TextStyle(
                                          fontSize: 14,
                                          fontWeight: FontWeight.w700,
                                          color: Colors.black,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                Container(
                                  padding: const EdgeInsets.symmetric(
                                    horizontal: 8,
                                    vertical: 8,
                                  ),
                                  decoration: BoxDecoration(
                                    color: const Color(0xFFE9F2F0),
                                    borderRadius: BorderRadius.circular(16),
                                  ),
                                  child: Row(
                                    mainAxisSize: MainAxisSize.min,
                                    children: [
                                      _CartStepperButton(
                                        icon: Icons.remove,
                                        onTap: () => ref
                                            .read(dokanPosProvider.notifier)
                                            .removeItem(product.id),
                                      ),
                                      const SizedBox(width: 12),
                                      Text(
                                        '${entry.value}',
                                        style: const TextStyle(
                                          fontSize: 18,
                                          fontWeight: FontWeight.w800,
                                          color: Colors.black,
                                        ),
                                      ),
                                      const SizedBox(width: 12),
                                      _CartStepperButton(
                                        icon: Icons.add,
                                        onTap: () => ref
                                            .read(dokanPosProvider.notifier)
                                            .addItem(product.id, stockLimit: product.stock),
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ),
                        );
                      }),
                      const SizedBox(height: 8),
                      Container(
                        width: double.infinity,
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(24),
                          border: Border.all(color: const Color(0xFFD6E4E0)),
                        ),
                        padding: const EdgeInsets.all(16),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const Text(
                              'মোট হিসাব',
                              style: TextStyle(
                                fontSize: 18,
                                fontWeight: FontWeight.w800,
                                color: Colors.black,
                              ),
                            ),
                            const SizedBox(height: 12),
                            _SummaryRow(
                              label: 'সাবটোটাল',
                              value: '৳${state.subtotal}',
                            ),
                            const SizedBox(height: 10),
                            _SummaryRow(
                              label: 'ডিসকাউন্ট',
                              value: '-৳${state.discountAmount}',
                              valueColor: const Color(0xFFB3261E),
                            ),
                            const SizedBox(height: 10),
                            _SummaryRow(
                              label: 'ট্যাক্স',
                              value: '৳${state.taxAmount}',
                            ),
                            const SizedBox(height: 10),
                            if (dueVisible)
                              _SummaryRow(
                              label: 'বাকি রয়েছে',
                                value: '৳$dueAmount',
                                valueColor: const Color(0xFFB3261E),
                              ),
                            const Padding(
                              padding: EdgeInsets.symmetric(vertical: 12),
                              child: Divider(height: 1),
                            ),
                            _SummaryRow(
                              label: 'সর্বমোট',
                              value: '৳${state.total}',
                              labelStyle: const TextStyle(
                                color: Colors.black,
                                fontSize: 18,
                                fontWeight: FontWeight.w800,
                              ),
                              valueStyle: const TextStyle(
                                color: Colors.black,
                                fontSize: 22,
                                fontWeight: FontWeight.w900,
                              ),
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(height: 14),
                      Container(
                        width: double.infinity,
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(24),
                          border: Border.all(color: const Color(0xFFD6E4E0)),
                        ),
                        padding: const EdgeInsets.all(16),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const Text(
                              'ডিসকাউন্ট (টাকা)',
                              style: TextStyle(
                                fontSize: 16,
                                fontWeight: FontWeight.w800,
                                color: Colors.black,
                              ),
                            ),
                            const SizedBox(height: 8),
                            TextField(
                              controller: _discountController,
                              keyboardType: TextInputType.number,
                              style: const TextStyle(color: Colors.black),
                              decoration: InputDecoration(
                                filled: true,
                                fillColor: const Color(0xFFF5F8F7),
                                hintText: 'যেমন 20',
                                hintStyle: const TextStyle(color: Colors.black54),
                                border: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(16),
                                  borderSide:
                                      const BorderSide(color: Color(0xFFD6E4E0)),
                                ),
                                enabledBorder: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(16),
                                  borderSide:
                                      const BorderSide(color: Color(0xFFD6E4E0)),
                                ),
                                focusedBorder: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(16),
                                  borderSide:
                                      const BorderSide(color: Color(0xFF006B53)),
                                ),
                              ),
                              onChanged: (value) => ref
                                  .read(dokanPosProvider.notifier)
                                  .setDiscount(value),
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(height: 14),
                      Container(
                        width: double.infinity,
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(24),
                          border: Border.all(color: const Color(0xFFD6E4E0)),
                        ),
                        padding: const EdgeInsets.all(16),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const Text(
                              'পেমেন্ট নির্বাচন',
                              style: TextStyle(
                                fontSize: 18,
                                fontWeight: FontWeight.w800,
                                color: Colors.black,
                              ),
                            ),
                            const SizedBox(height: 14),
                            Wrap(
                              spacing: 12,
                              runSpacing: 12,
                              children: const [
                                DokanPosPaymentMethod.cash,
                                DokanPosPaymentMethod.bkash,
                                DokanPosPaymentMethod.nagad,
                                DokanPosPaymentMethod.rocket,
                                DokanPosPaymentMethod.bank,
                                DokanPosPaymentMethod.card,
                              ].map((method) {
                                final selected = state.paymentMethod == method;
                                return _PaymentChip(
                                  label: _paymentLabel(method),
                                  selected: selected,
                                  onTap: () {
                                    ref
                                        .read(dokanPosProvider.notifier)
                                        .setPaymentMethod(method);
                                    setModalState(() {
                                      _paymentFieldErrors = <String, String>{};
                                    });
                                  },
                                );
                              }).toList(),
                            ),
                            const SizedBox(height: 16),
                            if (isCash ||
                                method == DokanPosPaymentMethod.bkash ||
                                method == DokanPosPaymentMethod.nagad ||
                                method == DokanPosPaymentMethod.rocket) ...[
                              const Text(
                                'গ্রাহকের নাম',
                                style: TextStyle(
                                  fontSize: 16,
                                  fontWeight: FontWeight.w800,
                                  color: Colors.black,
                                ),
                              ),
                              const SizedBox(height: 8),
                              TextField(
                                controller: _customerNameController,
                                style: const TextStyle(color: Colors.black),
                                decoration: _checkoutInputDecoration(
                                  'নাম লিখুন',
                                  errorText: _paymentFieldErrors['customerName'],
                                ),
                                onChanged: (value) {
                                  ref
                                      .read(dokanPosProvider.notifier)
                                      .setCustomerName(value);
                                  setModalState(() {
                                    _paymentFieldErrors.remove('customerName');
                                  });
                                },
                              ),
                              const SizedBox(height: 12),
                              const Text(
                                'গ্রাহকের নম্বর',
                                style: TextStyle(
                                  fontSize: 16,
                                  fontWeight: FontWeight.w800,
                                  color: Colors.black,
                                ),
                              ),
                              const SizedBox(height: 8),
                              TextField(
                                controller: _customerNumberController,
                                keyboardType: TextInputType.phone,
                                style: const TextStyle(color: Colors.black),
                                decoration: _checkoutInputDecoration(
                                  '১১ ডিজিট নম্বর',
                                  errorText: _paymentFieldErrors['customerNumber'],
                                ),
                                onChanged: (value) {
                                  ref
                                      .read(dokanPosProvider.notifier)
                                      .setCustomerNumber(value);
                                  setModalState(() {
                                    _paymentFieldErrors.remove('customerNumber');
                                  });
                                },
                              ),
                              const SizedBox(height: 12),
                            ],
                            if (!isCash &&
                                method != DokanPosPaymentMethod.card &&
                                method != DokanPosPaymentMethod.bank)
                              Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  const Text(
                                    'লেনদেন আইডি',
                                    style: TextStyle(
                                      fontSize: 16,
                                      fontWeight: FontWeight.w800,
                                      color: Colors.black,
                                    ),
                                  ),
                                  const SizedBox(height: 8),
                                  TextField(
                                    controller: _paymentTransactionController,
                                    style: const TextStyle(color: Colors.black),
                                    decoration: _checkoutInputDecoration(
                                      'TXN অথবা রেফারেন্স লিখুন',
                                      errorText: _paymentFieldErrors['transactionId'],
                                    ),
                                    onChanged: (value) {
                                      ref
                                          .read(dokanPosProvider.notifier)
                                          .setTransactionId(value);
                                      setModalState(() {
                                        _paymentFieldErrors.remove('transactionId');
                                      });
                                    },
                                  ),
                                ],
                              ),
                            if (isCash) ...[
                              const SizedBox(height: 12),
                              const Text(
                                'প্রাপ্ত নগদ',
                                style: TextStyle(
                                  fontSize: 16,
                                  fontWeight: FontWeight.w800,
                                  color: Colors.black,
                                ),
                              ),
                              const SizedBox(height: 8),
                              TextField(
                                controller: _cashReceivedController,
                                keyboardType: TextInputType.number,
                                style: const TextStyle(color: Colors.black),
                                decoration: _checkoutInputDecoration(
                                  'দেওয়া টাকা লিখুন',
                                  errorText: _paymentFieldErrors['cashReceived'],
                                ),
                                onChanged: (value) {
                                  ref
                                      .read(dokanPosProvider.notifier)
                                      .setCashReceived(value);
                                  setModalState(() {
                                    _paymentFieldErrors.remove('cashReceived');
                                  });
                                },
                              ),
                            ],
                            if (method == DokanPosPaymentMethod.card) ...[
                              const SizedBox(height: 12),
                              const Text(
                                'কার্ড তথ্য',
                                style: TextStyle(
                                  fontSize: 16,
                                  fontWeight: FontWeight.w800,
                                  color: Colors.black,
                                ),
                              ),
                              const SizedBox(height: 8),
                              _dialogTextField(
                                _cardHolderController,
                                'কার্ডধারীর নাম',
                                errorKey: 'cardHolder',
                                errorText: _paymentFieldErrors['cardHolder'],
                              ),
                              const SizedBox(height: 10),
                              _dialogTextField(
                                _cardLast4Controller,
                                'কার্ডের শেষ ৪ সংখ্যা',
                                errorKey: 'cardLast4',
                                errorText: _paymentFieldErrors['cardLast4'],
                              ),
                              const SizedBox(height: 10),
                              _dialogTextField(
                                _cardApprovalController,
                                'অনুমোদন কোড / ট্রানজেকশন',
                                errorKey: 'cardApproval',
                                errorText: _paymentFieldErrors['cardApproval'],
                              ),
                            ],
                            if (method == DokanPosPaymentMethod.bank) ...[
                              const SizedBox(height: 12),
                              const Text(
                                'ব্যাংক তথ্য',
                                style: TextStyle(
                                  fontSize: 16,
                                  fontWeight: FontWeight.w800,
                                  color: Colors.black,
                                ),
                              ),
                              const SizedBox(height: 8),
                              _dialogTextField(
                                _bankSenderController,
                                'প্রেরকের নাম',
                                errorKey: 'bankSender',
                                errorText: _paymentFieldErrors['bankSender'],
                              ),
                              const SizedBox(height: 10),
                              _dialogTextField(
                                _bankNameController,
                                'ব্যাংকের নাম',
                                errorKey: 'bankName',
                                errorText: _paymentFieldErrors['bankName'],
                              ),
                              const SizedBox(height: 10),
                              _dialogTextField(
                                _bankAccountController,
                                'অ্যাকাউন্ট নম্বর',
                                errorKey: 'bankAccount',
                                errorText: _paymentFieldErrors['bankAccount'],
                              ),
                              const SizedBox(height: 10),
                              _dialogTextField(
                                _bankReferenceController,
                                'রেফারেন্স / স্লিপ নম্বর',
                                errorKey: 'bankReference',
                                errorText: _paymentFieldErrors['bankReference'],
                              ),
                            ],
                          ],
                        ),
                      ),
                      const SizedBox(height: 14),
                      Container(
                        width: double.infinity,
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(24),
                          border: Border.all(color: const Color(0xFFD6E4E0)),
                        ),
                        padding: const EdgeInsets.all(16),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                const Text(
                                  'নগদ ও বাকি তালিকা',
                                  style: TextStyle(
                                    fontSize: 18,
                                    fontWeight: FontWeight.w800,
                                    color: Colors.black,
                                  ),
                                ),
                                TextButton(
                                  onPressed: () {
                                    Navigator.of(context).push(
                                      MaterialPageRoute(
                                        builder: (_) => const DokanDueManagementScreen(),
                                      ),
                                    );
                                  },
                                  child: const Text(
                                    'বাকি আদায়',
                                    style: TextStyle(color: Colors.black),
                                  ),
                                ),
                              ],
                            ),
                            const SizedBox(height: 6),
                            Row(
                              children: [
                                Expanded(
                                  child: _SummaryRow(
                                    label: 'পরিশোধিত অর্ডার',
                                    value: '${state.paidOrders.length}',
                                  ),
                                ),
                                const SizedBox(width: 12),
                                Expanded(
                                  child: _SummaryRow(
                                    label: 'বাকি অর্ডার',
                                    value: '${state.dueOrders.length}',
                                    valueColor: const Color(0xFFB3261E),
                                  ),
                                ),
                              ],
                            ),
                            const SizedBox(height: 10),
                            _SummaryRow(
                              label: 'মোট বাকি',
                              value: '৳${state.totalOutstandingDueAmount}',
                              valueColor: const Color(0xFFB3261E),
                            ),
                            const SizedBox(height: 12),
                            const Text(
                              'পরিশোধিত অর্ডার',
                              style: TextStyle(
                                color: Colors.black,
                                fontWeight: FontWeight.w800,
                              ),
                            ),
                            const SizedBox(height: 8),
                            if (state.paidOrders.isEmpty)
                              const Text(
                                'এখনো কোনো পরিশোধিত অর্ডার নেই',
                                style: TextStyle(color: Colors.black87),
                              )
                            else
                              ...state.paidOrders.take(2).map(
                                    (record) => _OrderRegisterTile(
                                      record: record,
                                      accent: const Color(0xFF0C8C67),
                                    ),
                                  ),
                            const SizedBox(height: 10),
                            const Text(
                              'বাকি অর্ডার',
                              style: TextStyle(
                                color: Colors.black,
                                fontWeight: FontWeight.w800,
                              ),
                            ),
                            const SizedBox(height: 8),
                            if (state.dueOrders.isEmpty)
                              const Text(
                                'এখনো কোনো বাকি অর্ডার নেই',
                                style: TextStyle(color: Colors.black87),
                              )
                            else
                              ...state.dueOrders.take(3).map(
                                    (record) => _OrderRegisterTile(
                                      record: record,
                                      accent: const Color(0xFFB3261E),
                                      showDueAmount: true,
                                    ),
                                  ),
                          ],
                        ),
                      ),
                      const SizedBox(height: 16),
                      Row(
                        children: [
                          Expanded(
                            child: OutlinedButton(
                              onPressed: () {
                                ref.read(dokanPosProvider.notifier).cancelCheckout();
                                Navigator.of(context).pop();
                                _showAlertDialog(
                                  title: 'পেমেন্ট বাতিল',
                                  message: 'পেমেন্ট সম্পন্ন হয়নি।',
                                  accent: const Color(0xFFB3261E),
                                );
                              },
                              style: OutlinedButton.styleFrom(
                                side: const BorderSide(color: Color(0xFF006B53)),
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(18),
                                ),
                                padding:
                                    const EdgeInsets.symmetric(vertical: 16),
                              ),
                              child: const Text(
                                'পেমেন্ট বাতিল',
                                style: TextStyle(color: Colors.black),
                              ),
                            ),
                          ),
                          const SizedBox(width: 12),
                          Expanded(
                            child: ElevatedButton(
                              onPressed: () {
                                final currentState = ref.read(dokanPosProvider);
                                final validationErrors =
                                    _validateCheckoutForm(currentState);
                                if (validationErrors.isNotEmpty) {
                                  setModalState(() {
                                    _paymentFieldErrors = validationErrors;
                                  });
                                  return;
                                }
                                setModalState(() {
                                  _paymentFieldErrors = <String, String>{};
                                });

                                final confirmationMethod = currentState.paymentMethod;
                                final total = currentState.total;
                                final dueAmount = currentState.paymentMethod == DokanPosPaymentMethod.cash
                                    ? total - currentState.cashReceived
                                    : 0;
                                final checkoutStatus = currentState.paymentMethod == DokanPosPaymentMethod.cash
                                    ? (currentState.cashReceived >= currentState.total
                                        ? DokanPosOrderStatus.paid
                                        : DokanPosOrderStatus.partiallyPaid)
                                    : DokanPosOrderStatus.paid;

                                ref.read(dokanPosProvider.notifier).confirmCheckout();
                                ref.read(dokanPosProvider.notifier).resetAfterCheckout();
                                _discountController.text = '0';
                                _paymentTransactionController.clear();
                                _customerNameController.clear();
                                _customerNumberController.clear();
                                _cashReceivedController.clear();
                                _cardHolderController.clear();
                                _cardLast4Controller.clear();
                                _cardApprovalController.clear();
                                _cardBankController.clear();
                                _bankSenderController.clear();
                                _bankNameController.clear();
                                _bankAccountController.clear();
                                _bankReferenceController.clear();
                                _bankRoutingController.clear();
                                Navigator.of(context).pop();
                                _showPaymentSuccess(
                                  total,
                                  confirmationMethod,
                                  checkoutStatus,
                                  dueAmount,
                                );
                              },
                              style: ElevatedButton.styleFrom(
                                backgroundColor: const Color(0xFF006B53),
                                foregroundColor: Colors.white,
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(18),
                                ),
                                padding:
                                    const EdgeInsets.symmetric(vertical: 16),
                              ),
                              child: const Text('পেমেন্ট সম্পন্ন'),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
            );
          },
            );
          },
        );
      },
    );
  }

  Future<void> _showPaymentSuccess(
    int total,
    DokanPosPaymentMethod method,
    DokanPosOrderStatus status,
    int dueAmount,
  ) {
    return showDialog<void>(
      context: context,
      builder: (context) {
        return AlertDialog(
          backgroundColor: Colors.white,
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
          title: const Text(
            'পেমেন্ট সম্পন্ন',
            style: TextStyle(color: Colors.black, fontWeight: FontWeight.w800),
          ),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                _statusLabel(status),
                style: TextStyle(
                  color: _statusColor(status),
                  fontWeight: FontWeight.w800,
                  fontSize: 16,
                ),
              ),
              const SizedBox(height: 6),
              Text(
                dueAmount > 0
                    ? '৳$total এর মধ্যে ৳$dueAmount বাকি রয়েছে। ${_paymentLabel(method)} মাধ্যমে আংশিক পরিশোধিত হয়েছে।'
                    : '৳$total ${_paymentLabel(method)} মাধ্যমে সফলভাবে গ্রহণ করা হয়েছে।',
                style: const TextStyle(color: Colors.black87),
              ),
            ],
          ),
          actionsOverflowButtonSpacing: 8,
          insetPadding: const EdgeInsets.symmetric(horizontal: 18, vertical: 24),
          actionsAlignment: MainAxisAlignment.end,
          actionsPadding: const EdgeInsets.only(left: 16, right: 16, bottom: 12),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(context).pop(),
              child: const Text('ঠিক আছে', style: TextStyle(color: Colors.black)),
            ),
          ],
        );
      },
    );
  }

  Widget _dialogTextField(
    TextEditingController controller,
    String hint, {
    String? errorKey,
    String? errorText,
  }) {
    return TextField(
      controller: controller,
      style: const TextStyle(color: Colors.black),
      onChanged: (_) {
        if (errorKey != null) {
          _clearPaymentFieldError(errorKey);
        }
      },
      decoration: _checkoutInputDecoration(
        hint,
        errorText: errorText,
      ),
    );
  }

  InputDecoration _checkoutInputDecoration(
    String hint, {
    String? errorText,
  }) {
    final hasError = errorText != null;
    return InputDecoration(
      filled: true,
      fillColor: hasError ? const Color(0xFFFFF5F5) : const Color(0xFFF5F8F7),
      hintText: hint,
      hintStyle: const TextStyle(color: Colors.black54),
      errorText: errorText,
      errorMaxLines: 2,
      errorStyle: const TextStyle(
        color: Color(0xFFB3261E),
        fontWeight: FontWeight.w700,
        fontSize: 12,
      ),
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(16),
        borderSide: BorderSide(
          color: hasError ? const Color(0xFFB3261E) : const Color(0xFFD6E4E0),
        ),
      ),
      enabledBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(16),
        borderSide: BorderSide(
          color: hasError ? const Color(0xFFB3261E) : const Color(0xFFD6E4E0),
        ),
      ),
      focusedBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(16),
        borderSide: BorderSide(
          color: hasError ? const Color(0xFFB3261E) : const Color(0xFF006B53),
        ),
      ),
      errorBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(16),
        borderSide: const BorderSide(color: Color(0xFFB3261E)),
      ),
      focusedErrorBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(16),
        borderSide: const BorderSide(color: Color(0xFFB3261E), width: 2),
      ),
    );
  }

  void _clearPaymentFieldError(String key) {
    if (!_paymentFieldErrors.containsKey(key)) {
      return;
    }
    setState(() {
      _paymentFieldErrors.remove(key);
    });
  }

  @override
  Widget build(BuildContext context) {
    final products = _visibleProducts;
    final cartCount = ref.watch(dokanPosProvider.select((state) => state.cartCount));
    final grandTotal = ref.watch(dokanPosProvider.select((state) => state.total));

    return Scaffold(
      backgroundColor: const Color(0xFFF2F7F6),
      body: SafeArea(
        child: Stack(
          children: [
            SingleChildScrollView(
              physics: const BouncingScrollPhysics(),
              padding: const EdgeInsets.fromLTRB(16, 14, 16, 220),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  _buildTopBar(),
                  const SizedBox(height: 14),
                  _buildSearchRow(),
                  const SizedBox(height: 16),
                  SizedBox(
                    height: 46,
                    child: ListView.separated(
                      scrollDirection: Axis.horizontal,
                      itemCount: _categories.length,
                      separatorBuilder: (context, index) => const SizedBox(width: 12),
                      itemBuilder: (context, index) {
                        final selected = _selectedCategoryIndex == index;
                        return _CategoryChip(
                          label: _categories[index].label,
                          selected: selected,
                          onTap: () {
                            setState(() {
                              _selectedCategoryIndex = index;
                            });
                          },
                        );
                      },
                    ),
                  ),
                  const SizedBox(height: 16),
                  Text(
                    'পণ্যসমূহ',
                    style: TextStyle(
                    color: Colors.black87,
                      fontSize: 20,
                      fontWeight: FontWeight.w800,
                    ),
                  ),
                  const SizedBox(height: 12),
                  if (products.isEmpty)
                    Container(
                      width: double.infinity,
                      padding: const EdgeInsets.all(24),
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(24),
                        border: Border.all(color: const Color(0xFFD6E4E0)),
                      ),
                      child: const Column(
                        children: [
                          Icon(Icons.search_off_outlined,
                              size: 40, color: Colors.black),
                          SizedBox(height: 10),
                          Text(
                            'কোনো পণ্য পাওয়া যায়নি',
                            style: TextStyle(
                              color: Colors.black,
                              fontWeight: FontWeight.w700,
                            ),
                          ),
                        ],
                      ),
                    )
                  else
                    GridView.builder(
                      shrinkWrap: true,
                      physics: const NeverScrollableScrollPhysics(),
                      itemCount: products.length,
                      gridDelegate:
                          const SliverGridDelegateWithFixedCrossAxisCount(
                        crossAxisCount: 2,
                        crossAxisSpacing: 12,
                        mainAxisSpacing: 12,
                        childAspectRatio: 0.72,
                      ),
                      itemBuilder: (context, index) {
                        final product = products[index];
                        final quantity = ref.watch(
                          dokanPosProvider.select((state) => state.cartQuantities[product.id] ?? 0),
                        );
                        return _ProductCard(
                          product: product,
                          quantity: quantity,
                          onAdd: () => _addToCart(product),
                          onRemove: () => _removeFromCart(product),
                        );
                      },
                    ),
                ],
              ),
            ),
            Positioned(
              left: 16,
              right: 16,
              bottom: 16,
              child: SafeArea(
                top: false,
                child: _CartDock(
                  count: cartCount,
                  total: grandTotal,
                  onTap: _openCartSheet,
                ),
              ),
            ),
          ],
        ),
      ),
      bottomNavigationBar: SafeArea(
        top: false,
        child: Container(
          margin: const EdgeInsets.fromLTRB(16, 0, 16, 12),
          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 10),
          decoration: BoxDecoration(
            color: const Color(0xFFEAF2F0),
            borderRadius: BorderRadius.circular(22),
            border: Border.all(color: const Color(0xFFD6E4E0)),
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: [
              _BottomNavButton(
                icon: Icons.home_outlined,
                label: 'হোম',
                selected: false,
                onTap: () => Navigator.of(context).popUntil((r) => r.isFirst),
              ),
              _BottomNavButton(
                icon: Icons.point_of_sale_outlined,
                label: 'বিক্রয়',
                selected: true,
                onTap: () => Navigator.of(context).pushReplacement(
                  MaterialPageRoute(
                    builder: (_) => DokanPosMainScreen(key: UniqueKey()),
                  ),
                ),
              ),
              _BottomNavButton(
                icon: Icons.inventory_2_outlined,
                label: 'পণ্য',
                selected: false,
                onTap: () => Navigator.of(context).pushReplacement(
                  MaterialPageRoute(
                    builder: (_) => const DokanProductListScreen(),
                  ),
                ),
              ),
              _BottomNavButton(
                icon: Icons.bar_chart_outlined,
                label: 'রিপোর্ট',
                selected: false,
                onTap: () => Navigator.of(context).pushReplacement(
                  MaterialPageRoute(
                    builder: (_) => const DokanReportsHomeScreen(),
                  ),
                ),
              ),
              _BottomNavButton(
                icon: Icons.more_horiz,
                label: 'আরও',
                selected: false,
                onTap: () => Navigator.of(context).pushReplacement(
                  MaterialPageRoute(
                    builder: (_) => const DokanAroOptionScreen(),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildTopBar() {
    return Container(
      padding: const EdgeInsets.fromLTRB(12, 12, 12, 12),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(24),
        border: Border.all(color: const Color(0xFFDCE7E4)),
      ),
      child: Row(
        children: [
          _TopIconButton(
            icon: Icons.menu,
            onTap: _openSalesSideMenu,
          ),
          const SizedBox(width: 8),
          const Expanded(
            child: Center(
              child: Text(
                'বিক্রয় করুন',
                style: TextStyle(
                  color: Color(0xFF006B53),
                  fontSize: 24,
                  fontWeight: FontWeight.w900,
                ),
              ),
            ),
          ),
          const SizedBox(width: 8),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
            decoration: BoxDecoration(
              color: const Color(0xFFE9F2F0),
              borderRadius: BorderRadius.circular(999),
            ),
            child: const Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(Icons.circle, size: 10, color: Color(0xFF006B53)),
                SizedBox(width: 6),
                Text(
                  'ONLINE',
                  style: TextStyle(
                    color: Colors.black,
                    fontWeight: FontWeight.w800,
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(width: 10),
          _TopIconButton(
            icon: Icons.mic_none_rounded,
            onTap: () => _showQuickNote('ভয়েস সার্চ'),
          ),
        ],
      ),
    );
  }

  Widget _buildSearchRow() {
    return Row(
      children: [
        Expanded(
          child: Container(
            height: 58,
            padding: const EdgeInsets.symmetric(horizontal: 16),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(18),
              border: Border.all(color: const Color(0xFFD6E4E0)),
            ),
          child: TextField(
              controller: _searchController,
              style: const TextStyle(color: Colors.black),
              cursorColor: const Color(0xFF006B53),
              decoration: const InputDecoration(
                border: InputBorder.none,
                icon: Icon(Icons.search, color: Colors.black54),
                hintText: 'পণ্য খুঁজুন বা স্ক্যান করুন...',
                hintStyle: TextStyle(color: Colors.black54),
              ),
            ),
          ),
        ),
        const SizedBox(width: 12),
        Container(
          height: 58,
          width: 58,
          decoration: BoxDecoration(
            color: const Color(0xFF006B53),
            borderRadius: BorderRadius.circular(18),
          ),
          child: IconButton(
            onPressed: () => _showQuickNote('স্ক্যানার'),
            icon: const Icon(Icons.qr_code_scanner, color: Colors.white),
          ),
        ),
      ],
    );
  }

}

class _PosSalesSideMenu extends StatelessWidget {
  const _PosSalesSideMenu({
    required this.onClose,
    required this.onTapHistory,
    required this.onTapDetails,
    required this.onTapClosing,
  });

  final VoidCallback onClose;
  final VoidCallback onTapHistory;
  final VoidCallback onTapDetails;
  final VoidCallback onTapClosing;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: MediaQuery.sizeOf(context).width * 0.82,
      height: MediaQuery.sizeOf(context).height,
      decoration: const BoxDecoration(
        color: Color(0xFFF7FBFA),
        borderRadius: BorderRadius.only(
          topRight: Radius.circular(28),
          bottomRight: Radius.circular(28),
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(18, 18, 18, 12),
            child: Row(
              children: [
                const Expanded(
                  child: Text(
                    'বিক্রয় মেনু',
                    style: TextStyle(
                      color: Colors.black,
                      fontSize: 22,
                      fontWeight: FontWeight.w900,
                    ),
                  ),
                ),
                _SideMenuIconButton(
                  icon: Icons.close,
                  onTap: onClose,
                ),
              ],
            ),
          ),
          const Padding(
            padding: EdgeInsets.symmetric(horizontal: 18),
            child: Text(
              'বিক্রয় সম্পর্কিত দ্রুত প্রবেশপথ',
              style: TextStyle(
                color: Color(0xFF5D6D67),
                fontSize: 13,
                fontWeight: FontWeight.w600,
              ),
            ),
          ),
          const SizedBox(height: 18),
          Expanded(
            child: ListView(
              padding: const EdgeInsets.fromLTRB(14, 0, 14, 18),
              children: [
                _PosSideMenuTile(
                  icon: Icons.history,
                  title: 'বিক্রয় ইতিহাস',
                  subtitle: 'পূর্বের বিক্রয় তালিকা দেখুন',
                  onTap: onTapHistory,
                ),
                const SizedBox(height: 12),
                _PosSideMenuTile(
                  icon: Icons.receipt_long_outlined,
                  title: 'বিক্রয় বিস্তারিত',
                  subtitle: 'একটি বিক্রয়ের পূর্ণ তথ্য দেখুন',
                  onTap: onTapDetails,
                ),
                const SizedBox(height: 12),
                _PosSideMenuTile(
                  icon: Icons.event_available_outlined,
                  title: 'দৈনিক ক্লোজিং',
                  subtitle: 'আজকের বিক্রয় ও বন্ধের সারাংশ',
                  onTap: onTapClosing,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _PosSideMenuTile extends StatelessWidget {
  const _PosSideMenuTile({
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.onTap,
  });

  final IconData icon;
  final String title;
  final String subtitle;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.white,
      borderRadius: BorderRadius.circular(22),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(22),
        child: Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(22),
            border: Border.all(color: const Color(0xFFD9E6E2)),
          ),
          child: Row(
            children: [
              Container(
                width: 48,
                height: 48,
                decoration: BoxDecoration(
                  color: const Color(0xFFEAF2F0),
                  borderRadius: BorderRadius.circular(16),
                ),
                child: Icon(icon, color: const Color(0xFF006B53)),
              ),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      title,
                      style: const TextStyle(
                        color: Colors.black,
                        fontSize: 16,
                        fontWeight: FontWeight.w800,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      subtitle,
                      style: const TextStyle(
                        color: Color(0xFF5D6D67),
                        fontSize: 13,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 8),
              const Icon(Icons.arrow_forward_ios_rounded,
                  size: 16, color: Color(0xFF7B8C86)),
            ],
          ),
        ),
      ),
    );
  }
}

class _SideMenuIconButton extends StatelessWidget {
  const _SideMenuIconButton({required this.icon, required this.onTap});

  final IconData icon;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: const Color(0xFFF1F6F4),
      borderRadius: BorderRadius.circular(14),
      child: InkWell(
        borderRadius: BorderRadius.circular(14),
        onTap: onTap,
        child: SizedBox(
          width: 42,
          height: 42,
          child: Icon(icon, color: const Color(0xFF006B53)),
        ),
      ),
    );
  }
}

class DokanPosSalesHistoryScreen extends StatelessWidget {
  const DokanPosSalesHistoryScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return const _DokanSalesHistoryScreen();
  }
}

class DokanPosSalesDetailsScreen extends StatelessWidget {
  const DokanPosSalesDetailsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return const _SalesHistoryDummyScreen();
  }
}

class DokanPosDailyClosingScreen extends StatelessWidget {
  const DokanPosDailyClosingScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return const _DailyClosingScreen();
  }
}

class _DailyClosingScreen extends StatefulWidget {
  const _DailyClosingScreen();

  @override
  State<_DailyClosingScreen> createState() => _DailyClosingScreenState();
}

class _DailyClosingScreenState extends State<_DailyClosingScreen> {
  final TextEditingController _cashController = TextEditingController(text: '0.00');

  static const int _expectedCash = 3450;

  @override
  void dispose() {
    _cashController.dispose();
    super.dispose();
  }

  int _parseAmount(String input) {
    final normalized = input
        .replaceAll('৳', '')
        .replaceAll(',', '')
        .replaceAll(' ', '')
        .replaceAll('০', '0')
        .replaceAll('১', '1')
        .replaceAll('২', '2')
        .replaceAll('৩', '3')
        .replaceAll('৪', '4')
        .replaceAll('৫', '5')
        .replaceAll('৬', '6')
        .replaceAll('৭', '7')
        .replaceAll('৮', '8')
        .replaceAll('৯', '9');
    final value = double.tryParse(normalized);
    if (value == null) {
      return 0;
    }
    return value.round();
  }

  Widget _bottomNav() {
    return SafeArea(
      top: false,
      child: Container(
        padding: const EdgeInsets.fromLTRB(14, 12, 14, 12),
        decoration: const BoxDecoration(
          color: Color(0xFFEAF2F0),
          border: Border(
            top: BorderSide(color: Color(0xFFD7E5E0)),
          ),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            _SalesBottomNavItem(
              icon: Icons.home_outlined,
              label: 'হোম',
              selected: false,
              onTap: () => Navigator.of(context).popUntil((r) => r.isFirst),
            ),
            _SalesBottomNavItem(
              icon: Icons.point_of_sale_outlined,
              label: 'বিক্রয়',
              selected: true,
              onTap: () => Navigator.of(context).pop(),
            ),
            _SalesBottomNavItem(
              icon: Icons.inventory_2_outlined,
              label: 'পণ্য',
              selected: false,
              onTap: () => Navigator.of(context).pushReplacement(
                MaterialPageRoute(builder: (_) => const DokanProductListScreen()),
              ),
            ),
            _SalesBottomNavItem(
              icon: Icons.bar_chart_outlined,
              label: 'রিপোর্ট',
              selected: false,
              onTap: () => Navigator.of(context).pushReplacement(
                MaterialPageRoute(builder: (_) => const DokanReportsHomeScreen()),
              ),
            ),
            _SalesBottomNavItem(
              icon: Icons.more_horiz,
              label: 'আরও',
              selected: false,
              onTap: () => Navigator.of(context).pushReplacement(
                MaterialPageRoute(builder: (_) => const DokanAroOptionScreen()),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _topSaleRow({
    required String rank,
    required String name,
    required String quantity,
    required String detail,
    required Color badgeColor,
    required Color badgeTextColor,
  }) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: const Color(0xFFD9E6E2)),
      ),
      child: Row(
        children: [
          Container(
            width: 48,
            height: 48,
            decoration: BoxDecoration(
              color: badgeColor,
              shape: BoxShape.circle,
            ),
            alignment: Alignment.center,
            child: Text(
              rank,
              style: TextStyle(
                color: badgeTextColor,
                fontSize: 18,
                fontWeight: FontWeight.w900,
              ),
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  name,
                  style: const TextStyle(
                    color: Color(0xFF141F22),
                    fontSize: 16,
                    fontWeight: FontWeight.w900,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  detail,
                  style: const TextStyle(
                    color: Color(0xFF6F7D78),
                    fontSize: 13,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ],
            ),
          ),
          Text(
            quantity,
            style: const TextStyle(
              color: Color(0xFF00694C),
              fontSize: 18,
              fontWeight: FontWeight.w900,
            ),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final enteredCash = _parseAmount(_cashController.text);
    final isMatched = enteredCash == _expectedCash;
    final diff = (enteredCash - _expectedCash).abs();

    return Scaffold(
      backgroundColor: const Color(0xFFF3F8F7),
      resizeToAvoidBottomInset: true,
      body: SafeArea(
        bottom: false,
        child: ListView(
          padding: const EdgeInsets.fromLTRB(16, 12, 16, 20),
          keyboardDismissBehavior: ScrollViewKeyboardDismissBehavior.onDrag,
          children: [
            Container(
              height: 82,
              padding: const EdgeInsets.symmetric(horizontal: 14),
              decoration: BoxDecoration(
                color: const Color(0xFFF3FAFB),
                borderRadius: BorderRadius.circular(0),
                border: Border.all(color: const Color(0xFFD9E6E2)),
              ),
              child: Row(
                children: [
                  Material(
                    color: Colors.white,
                    shape: const CircleBorder(),
                    child: InkWell(
                      customBorder: const CircleBorder(),
                      onTap: () => Navigator.of(context).pop(),
                      child: const SizedBox(
                        width: 44,
                        height: 44,
                        child: Icon(Icons.arrow_back, color: Color(0xFF3D4943)),
                      ),
                    ),
                  ),
                  const Expanded(
                    child: Center(
                      child: Text(
                        'দৈনিক ক্লোজিং',
                        style: TextStyle(
                          color: Color(0xFF00694C),
                          fontSize: 24,
                          fontWeight: FontWeight.w900,
                        ),
                      ),
                    ),
                  ),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                    decoration: BoxDecoration(
                      color: const Color(0xFFE1F5E7),
                      borderRadius: BorderRadius.circular(999),
                    ),
                    child: const Text(
                      '২৩ মে ২০২৬',
                      style: TextStyle(
                        color: Color(0xFF0C8C67),
                        fontWeight: FontWeight.w900,
                      ),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 16),
            Container(
              padding: const EdgeInsets.all(18),
              decoration: BoxDecoration(
                gradient: const LinearGradient(
                  colors: [Color(0xFF1D9E75), Color(0xFF00694C)],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                borderRadius: BorderRadius.circular(24),
                boxShadow: [
                  BoxShadow(
                    color: const Color(0xFF0B5B42).withValues(alpha: 0.18),
                    blurRadius: 18,
                    offset: const Offset(0, 10),
                  ),
                ],
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'আজকের সারসংক্ষেপ',
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 18,
                      fontWeight: FontWeight.w900,
                    ),
                  ),
                  const SizedBox(height: 10),
                  const Text(
                    '৳ ৪,৮৫০',
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 30,
                      fontWeight: FontWeight.w900,
                    ),
                  ),
                  const SizedBox(height: 18),
                  Container(height: 1, color: Colors.white.withValues(alpha: 0.18)),
                  const SizedBox(height: 14),
                  Row(
                    children: [
                      Expanded(
                        child: Column(
                          children: const [
                            Text(
                              'বিক্রয়',
                              style: TextStyle(
                                color: Colors.white,
                                fontSize: 16,
                                fontWeight: FontWeight.w700,
                              ),
                            ),
                            SizedBox(height: 8),
                            Text(
                              '৩২টি',
                              style: TextStyle(
                                color: Colors.white,
                                fontSize: 22,
                                fontWeight: FontWeight.w900,
                              ),
                            ),
                          ],
                        ),
                      ),
                      Container(width: 1, height: 56, color: Colors.white.withValues(alpha: 0.18)),
                      Expanded(
                        child: Column(
                          children: const [
                            Text(
                              'লাভ',
                              style: TextStyle(
                                color: Colors.white,
                                fontSize: 16,
                                fontWeight: FontWeight.w700,
                              ),
                            ),
                            SizedBox(height: 8),
                            Text(
                              '৳১,২৪০',
                              style: TextStyle(
                                color: Colors.white,
                                fontSize: 22,
                                fontWeight: FontWeight.w900,
                              ),
                            ),
                          ],
                        ),
                      ),
                      Container(width: 1, height: 56, color: Colors.white.withValues(alpha: 0.18)),
                      Expanded(
                        child: Column(
                          children: const [
                            Text(
                              'বাকি',
                              style: TextStyle(
                                color: Colors.white,
                                fontSize: 16,
                                fontWeight: FontWeight.w700,
                              ),
                            ),
                            SizedBox(height: 8),
                            Text(
                              '৳৬৭৫',
                              style: TextStyle(
                                color: Colors.white,
                                fontSize: 22,
                                fontWeight: FontWeight.w900,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
            const SizedBox(height: 16),
            _DetailSectionCard(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'নগদ হিসাব মিলান',
                    style: TextStyle(
                      color: Color(0xFF141F22),
                      fontSize: 20,
                      fontWeight: FontWeight.w900,
                    ),
                  ),
                  const SizedBox(height: 14),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
                    decoration: BoxDecoration(
                      color: const Color(0xFFEAF3F6),
                      borderRadius: BorderRadius.circular(16),
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        const Text(
                          'প্রত্যাশিত নগদ:',
                          style: TextStyle(
                            color: Color(0xFF5F6A66),
                            fontSize: 15,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                        Text(
                          _formatCurrency(_expectedCash),
                          style: const TextStyle(
                            color: Color(0xFF00694C),
                            fontSize: 18,
                            fontWeight: FontWeight.w900,
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 14),
                  const Text(
                    'বাস্তব নগদ গণনা',
                    style: TextStyle(
                      color: Color(0xFF141F22),
                      fontSize: 16,
                      fontWeight: FontWeight.w800,
                    ),
                  ),
                  const SizedBox(height: 10),
                  TextField(
                    controller: _cashController,
                    keyboardType: const TextInputType.numberWithOptions(decimal: true),
                    onChanged: (_) => setState(() {}),
                    style: const TextStyle(
                      color: Color(0xFF141F22),
                      fontWeight: FontWeight.w800,
                    ),
                    decoration: InputDecoration(
                      hintText: '৳ ০.০০',
                      hintStyle: const TextStyle(color: Color(0xFF7C8A84)),
                      filled: true,
                      fillColor: Colors.white,
                      contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(14),
                        borderSide: const BorderSide(color: Color(0xFFD9E6E2)),
                      ),
                      enabledBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(14),
                        borderSide: const BorderSide(color: Color(0xFFD9E6E2)),
                      ),
                      focusedBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(14),
                        borderSide: const BorderSide(color: Color(0xFF00694C), width: 1.6),
                      ),
                    ),
                  ),
                  const SizedBox(height: 14),
                  Container(
                    width: double.infinity,
                    padding: const EdgeInsets.all(14),
                    decoration: BoxDecoration(
                      color: isMatched ? const Color(0xFFE5F7ED) : const Color(0xFFFDEEEF),
                      borderRadius: BorderRadius.circular(16),
                      border: Border.all(
                        color: isMatched ? const Color(0xFFBDE7C9) : const Color(0xFFF4D2D5),
                      ),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            Icon(
                              isMatched ? Icons.check_circle_outline : Icons.warning_amber_rounded,
                              color: isMatched ? const Color(0xFF0C8C67) : const Color(0xFFD43B3B),
                            ),
                            const SizedBox(width: 10),
                            Text(
                              isMatched ? 'হিসাব মিলেছে' : 'হিসাব মিলছে না',
                              style: TextStyle(
                                color: isMatched ? const Color(0xFF0C8C67) : const Color(0xFFD43B3B),
                                fontSize: 16,
                                fontWeight: FontWeight.w900,
                              ),
                            ),
                          ],
                        ),
                        if (!isMatched) ...[
                          const SizedBox(height: 8),
                          Text(
                            'পার্থক্য: ${_formatCurrency(diff)}',
                            style: const TextStyle(
                              color: Color(0xFFD43B3B),
                              fontSize: 15,
                              fontWeight: FontWeight.w800,
                            ),
                          ),
                        ],
                      ],
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 16),
            _DetailSectionCard(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'পেমেন্ট ভাঙনি',
                    style: TextStyle(
                      color: Color(0xFF141F22),
                      fontSize: 20,
                      fontWeight: FontWeight.w900,
                    ),
                  ),
                  const SizedBox(height: 14),
                  _PaymentBreakdownRow(
                    icon: Icons.payments_outlined,
                    title: 'নগদ (Cash)',
                    amount: '৳ ৩,৪৫০',
                    accent: const Color(0xFF0C8C67),
                  ),
                  const SizedBox(height: 12),
                  _PaymentBreakdownRow(
                    icon: Icons.account_balance_wallet_outlined,
                    title: 'বিকাশ/নগদ',
                    amount: '৳ ৭২৫',
                    accent: const Color(0xFF2D73FF),
                  ),
                  const SizedBox(height: 12),
                  _PaymentBreakdownRow(
                    icon: Icons.receipt_long_outlined,
                    title: 'বাকি (Due)',
                    amount: '৳ ৬৭৫',
                    accent: const Color(0xFFD43B3B),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 16),
            _DetailSectionCard(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'আজকের সেরা বিক্রয়',
                    style: TextStyle(
                      color: Color(0xFF141F22),
                      fontSize: 20,
                      fontWeight: FontWeight.w900,
                    ),
                  ),
                  const SizedBox(height: 14),
                  _topSaleRow(
                    rank: '১',
                    name: 'মিনিকেট চাল',
                    quantity: '৪৮টি',
                    detail: 'প্যাকিং ২ কেজি',
                    badgeColor: const Color(0xFFFFF3C4),
                    badgeTextColor: const Color(0xFFAA7A00),
                  ),
                  const SizedBox(height: 12),
                  _topSaleRow(
                    rank: '২',
                    name: 'সয়াবিন তেল',
                    quantity: '২৪টি',
                    detail: 'পুষ্টি ৫ লিটার',
                    badgeColor: const Color(0xFFEFF2F7),
                    badgeTextColor: const Color(0xFF6F7D78),
                  ),
                  const SizedBox(height: 12),
                  _topSaleRow(
                    rank: '৩',
                    name: 'কোকা কোলা',
                    quantity: '৩৬টি',
                    detail: '৫০০ মি.লি.',
                    badgeColor: const Color(0xFFFFE7CC),
                    badgeTextColor: const Color(0xFFB76400),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
      bottomNavigationBar: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          SafeArea(
            top: false,
            bottom: false,
            child: Padding(
              padding: const EdgeInsets.fromLTRB(16, 0, 16, 12),
              child: SizedBox(
                width: double.infinity,
                height: 58,
                child: ElevatedButton(
                  onPressed: () {
                    Navigator.of(context).push(
                      MaterialPageRoute(
                        builder: (_) => _DailyClosingSuccessScreen(
                          dateText: '২৩ মে ২০২৬',
                          salesText: '৳ ৪,৮৫০',
                          profitText: '৳ ১,২৪০',
                          dueText: '৳ ৬৭৫',
                        ),
                      ),
                    );
                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFF00694C),
                    foregroundColor: Colors.white,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(18),
                    ),
                  ),
                  child: const Text(
                    'ক্লোজিং সম্পন্ন করুন',
                    style: TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.w900,
                    ),
                  ),
                ),
              ),
            ),
          ),
          _bottomNav(),
        ],
      ),
    );
  }
}

class _PaymentBreakdownRow extends StatelessWidget {
  const _PaymentBreakdownRow({
    required this.icon,
    required this.title,
    required this.amount,
    required this.accent,
  });

  final IconData icon;
  final String title;
  final String amount;
  final Color accent;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: const Color(0xFFD9E6E2)),
      ),
      child: Row(
        children: [
          Icon(icon, color: accent, size: 24),
          const SizedBox(width: 12),
          Expanded(
            child: Text(
              title,
              style: const TextStyle(
                color: Color(0xFF141F22),
                fontSize: 16,
                fontWeight: FontWeight.w800,
              ),
            ),
          ),
          Text(
            amount,
            style: TextStyle(
              color: accent,
              fontSize: 18,
              fontWeight: FontWeight.w900,
            ),
          ),
        ],
      ),
    );
  }
}

class _DailyClosingSuccessScreen extends StatelessWidget {
  const _DailyClosingSuccessScreen({
    required this.dateText,
    required this.salesText,
    required this.profitText,
    required this.dueText,
  });

  final String dateText;
  final String salesText;
  final String profitText;
  final String dueText;

  Widget _bottomNav(BuildContext context) {
    return SafeArea(
      top: false,
      child: Container(
        padding: const EdgeInsets.fromLTRB(14, 12, 14, 12),
        decoration: const BoxDecoration(
          color: Color(0xFFEAF2F0),
          border: Border(
            top: BorderSide(color: Color(0xFFD7E5E0)),
          ),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            _SalesBottomNavItem(
              icon: Icons.home_outlined,
              label: 'হোম',
              selected: false,
              onTap: () => Navigator.of(context).popUntil((r) => r.isFirst),
            ),
            _SalesBottomNavItem(
              icon: Icons.point_of_sale_outlined,
              label: 'বিক্রয়',
              selected: true,
              onTap: () => Navigator.of(context).pop(),
            ),
            _SalesBottomNavItem(
              icon: Icons.inventory_2_outlined,
              label: 'পণ্য',
              selected: false,
              onTap: () => Navigator.of(context).pushReplacement(
                MaterialPageRoute(builder: (_) => const DokanProductListScreen()),
              ),
            ),
            _SalesBottomNavItem(
              icon: Icons.bar_chart_outlined,
              label: 'রিপোর্ট',
              selected: false,
              onTap: () => Navigator.of(context).pushReplacement(
                MaterialPageRoute(builder: (_) => const DokanReportsHomeScreen()),
              ),
            ),
            _SalesBottomNavItem(
              icon: Icons.more_horiz,
              label: 'আরও',
              selected: false,
              onTap: () => Navigator.of(context).pushReplacement(
                MaterialPageRoute(builder: (_) => const DokanAroOptionScreen()),
              ),
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF3F8F7),
      body: SafeArea(
        bottom: false,
        child: ListView(
          padding: const EdgeInsets.fromLTRB(16, 12, 16, 16),
          children: [
            Container(
              height: 82,
              padding: const EdgeInsets.symmetric(horizontal: 14),
              decoration: BoxDecoration(
                color: const Color(0xFFF3FAFB),
                border: Border.all(color: const Color(0xFFD9E6E2)),
              ),
              child: Row(
                children: [
                  Material(
                    color: Colors.white,
                    shape: const CircleBorder(),
                    child: InkWell(
                      customBorder: const CircleBorder(),
                      onTap: () => Navigator.of(context).pop(),
                      child: const SizedBox(
                        width: 44,
                        height: 44,
                        child: Icon(Icons.arrow_back, color: Color(0xFF3D4943)),
                      ),
                    ),
                  ),
                  const Expanded(
                    child: Center(
                      child: Text(
                        'দৈনিক ক্লোজিং',
                        style: TextStyle(
                          color: Color(0xFF00694C),
                          fontSize: 24,
                          fontWeight: FontWeight.w900,
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(width: 44),
                ],
              ),
            ),
            const SizedBox(height: 20),
            Container(
              padding: const EdgeInsets.all(24),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(26),
                border: Border.all(color: const Color(0xFFD9E6E2)),
              ),
              child: Column(
                children: [
                  Container(
                    width: 88,
                    height: 88,
                    decoration: const BoxDecoration(
                      color: Color(0xFFE5F7ED),
                      shape: BoxShape.circle,
                    ),
                    child: const Icon(Icons.check_circle, color: Color(0xFF0C8C67), size: 56),
                  ),
                  const SizedBox(height: 16),
                  const Text(
                    'দৈনিক ক্লোজিং সম্পন্ন হয়েছে',
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      color: Color(0xFF141F22),
                      fontSize: 22,
                      fontWeight: FontWeight.w900,
                    ),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    dateText,
                    style: const TextStyle(
                      color: Color(0xFF6F7D78),
                      fontSize: 16,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                  const SizedBox(height: 16),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                    decoration: BoxDecoration(
                      color: const Color(0xFFEAF7F0),
                      borderRadius: BorderRadius.circular(999),
                    ),
                    child: const Text(
                      'ক্লোজিং সফল',
                      style: TextStyle(
                        color: Color(0xFF0C8C67),
                        fontWeight: FontWeight.w900,
                      ),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 16),
            _DetailSectionCard(
              child: Column(
                children: [
                  _InvoiceInfoRow(icon: Icons.point_of_sale_outlined, label: 'আজকের বিক্রয়', value: salesText),
                  const SizedBox(height: 14),
                  _InvoiceInfoRow(icon: Icons.show_chart_outlined, label: 'লাভ', value: profitText),
                  const SizedBox(height: 14),
                  _InvoiceInfoRow(icon: Icons.receipt_long_outlined, label: 'বাকি', value: dueText),
                ],
              ),
            ),
            const SizedBox(height: 16),
            SizedBox(
              height: 58,
              width: double.infinity,
              child: ElevatedButton(
                onPressed: () => Navigator.of(context).pushAndRemoveUntil(
                  MaterialPageRoute(builder: (_) => const _DokanSalesHistoryScreen()),
                  (route) => false,
                ),
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFF00694C),
                  foregroundColor: Colors.white,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(18),
                  ),
                ),
                child: const Text(
                  'বিক্রয় ইতিহাসে ফিরুন',
                  style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.w900,
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
      bottomNavigationBar: _bottomNav(context),
    );
  }
}

class _DokanSalesHistoryScreen extends ConsumerStatefulWidget {
  const _DokanSalesHistoryScreen();

  @override
  ConsumerState<_DokanSalesHistoryScreen> createState() =>
      _DokanSalesHistoryScreenState();
}

class _DokanSalesHistoryScreenState extends ConsumerState<_DokanSalesHistoryScreen> {
  int _selectedFilterIndex = 0;
  int _selectedAmountIndex = 0;
  int _selectedStatusIndex = 0;
  bool _showSearchPanel = false;
  bool _showFilterPanel = false;
  final TextEditingController _searchController = TextEditingController();

  static const List<_SalesFilter> _filters = <_SalesFilter>[
    _SalesFilter(label: 'আজ'),
    _SalesFilter(label: 'গতকাল'),
    _SalesFilter(label: 'এই সপ্তাহ'),
    _SalesFilter(label: 'এই মাস'),
    _SalesFilter(label: 'সব'),
  ];

  static const List<String> _statusFilters = <String>[
    'সব অবস্থা',
    'সম্পূর্ণ পরিশোধ',
    'বাকি আছে',
    'আংশিক পরিশোধ',
  ];

  static const List<String> _amountFilters = <String>[
    'সব পরিমাণ',
    '৳১,০০০ এর নিচে',
    '৳১,০০০ - ৳৫,০০০',
    '৳৫,০০০ এর বেশি',
  ];

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final orders = ref.watch(dokanPosProvider.select((state) => state.orders));
    final filteredGroups = _groupOrders(_filterOrders(orders));
    final hasItems = filteredGroups.any((group) => group.items.isNotEmpty);

    return Scaffold(
      backgroundColor: const Color(0xFFF3F8F7),
      resizeToAvoidBottomInset: true,
      body: SafeArea(
        child: ListView(
          padding: EdgeInsets.fromLTRB(
            0,
            0,
            0,
            MediaQuery.of(context).viewInsets.bottom + 96,
          ),
          keyboardDismissBehavior: ScrollViewKeyboardDismissBehavior.onDrag,
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 12, 16, 0),
              child: _SalesHeaderBar(
                onBack: () => Navigator.of(context).pushReplacement(
                  MaterialPageRoute(
                    builder: (_) => DokanPosMainScreen(key: UniqueKey()),
                  ),
                ),
                onSearch: () {
                  Navigator.of(context).push(
                    MaterialPageRoute(
                      builder: (_) => const _SalesSearchScreen(),
                    ),
                  );
                },
                onFilter: () async {
                  final selection = await Navigator.of(context).push<_HistoryFilterSelection>(
                    MaterialPageRoute(
                      builder: (_) => const _SalesFilterScreen(),
                    ),
                  );
                  if (!mounted || selection == null) {
                    return;
                  }
                  setState(() {
                    _selectedFilterIndex = selection.timeIndex;
                    _selectedStatusIndex = selection.statusIndex;
                    _selectedAmountIndex = selection.rangeIndex;
                    _showSearchPanel = false;
                    _showFilterPanel = false;
                  });
                },
              ),
            ),
            const SizedBox(height: 12),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: _SalesSummaryStrip(
                todaySales: _banglaDigits('8450'),
                totalSales: _banglaDigits('32'),
                totalProfit: _banglaDigits('91280'),
              ),
            ),
            const SizedBox(height: 12),
            if (_showSearchPanel)
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                child: _SalesSearchInlinePanel(
                  controller: _searchController,
                  onChanged: (_) => setState(() {}),
                  onClear: () {
                    setState(() {
                      _searchController.clear();
                    });
                  },
                ),
              ),
            if (_showSearchPanel) const SizedBox(height: 12),
            if (_showFilterPanel)
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                child: _SalesFilterInlinePanel(
                  selectedStatusIndex: _selectedStatusIndex,
                  selectedAmountIndex: _selectedAmountIndex,
                  statusFilters: _statusFilters,
                  amountFilters: _amountFilters,
                  onStatusTap: (index) {
                    setState(() {
                      _selectedStatusIndex = index;
                    });
                  },
                  onAmountTap: (index) {
                    setState(() {
                      _selectedAmountIndex = index;
                    });
                  },
                  onReset: () {
                    setState(() {
                      _selectedStatusIndex = 0;
                      _selectedFilterIndex = 0;
                      _selectedAmountIndex = 0;
                    });
                  },
                ),
              ),
            if (_showFilterPanel) const SizedBox(height: 12),
            SizedBox(
              height: 48,
              child: ListView.separated(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                scrollDirection: Axis.horizontal,
                itemCount: _filters.length,
                separatorBuilder: (context, index) => const SizedBox(width: 12),
                itemBuilder: (context, index) {
                  final selected = _selectedFilterIndex == index;
                  return _FilterChipButton(
                    label: _filters[index].label,
                    selected: selected,
                    onTap: () {
                      setState(() {
                        _selectedFilterIndex = index;
                      });
                    },
                  );
                },
              ),
            ),
            if (_hasActiveFilters)
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 12, 16, 0),
                child: _ActiveFilterSummary(
                  searchText: _searchController.text.trim(),
                  timeLabel: _filters[_selectedFilterIndex].label,
                  statusLabel: _statusFilters[_selectedStatusIndex],
                  amountLabel: _amountFilters[_selectedAmountIndex],
                  onClearAll: () {
                    setState(() {
                      _searchController.clear();
                      _selectedFilterIndex = 0;
                      _selectedStatusIndex = 0;
                      _selectedAmountIndex = 0;
                    });
                  },
                ),
              ),
            const SizedBox(height: 14),
            if (hasItems)
              ...filteredGroups.map(
                (group) => Padding(
                  padding: const EdgeInsets.fromLTRB(16, 0, 16, 18),
                  child: _SalesGroupSection(group: group),
                ),
              )
            else
              const Padding(
                padding: EdgeInsets.symmetric(horizontal: 16),
                child: _SalesEmptyState(),
              ),
          ],
        ),
      ),
      bottomNavigationBar: SafeArea(
        top: false,
        child: Container(
          margin: const EdgeInsets.fromLTRB(0, 0, 0, 0),
          padding: const EdgeInsets.fromLTRB(14, 12, 14, 12),
          decoration: const BoxDecoration(
            color: Color(0xFFEAF2F0),
            border: Border(
              top: BorderSide(color: Color(0xFFD7E5E0)),
            ),
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              _SalesBottomNavItem(
                icon: Icons.home_outlined,
                label: 'হোম',
                selected: false,
                onTap: () => Navigator.of(context).push(
                  MaterialPageRoute(
                    builder: (_) => const DokanHomeDashboardScreen(),
                  ),
                ),
              ),
              _SalesBottomNavItem(
                icon: Icons.point_of_sale_outlined,
                label: 'বিক্রয়',
                selected: true,
                onTap: () => Navigator.of(context).push(
                  MaterialPageRoute(
                    builder: (_) => const _DokanSalesHistoryScreen(),
                  ),
                ),
              ),
              _SalesBottomNavItem(
                icon: Icons.inventory_2_outlined,
                label: 'পণ্য',
                selected: false,
                onTap: () => Navigator.of(context).pushReplacement(
                  MaterialPageRoute(
                    builder: (_) => const DokanProductListScreen(),
                  ),
                ),
              ),
              _SalesBottomNavItem(
                icon: Icons.bar_chart_outlined,
                label: 'রিপোর্ট',
                selected: false,
                onTap: () => Navigator.of(context).pushReplacement(
                  MaterialPageRoute(
                    builder: (_) => const DokanReportsHomeScreen(),
                  ),
                ),
              ),
              _SalesBottomNavItem(
                icon: Icons.more_horiz,
                label: 'আরও',
                selected: false,
                onTap: () => Navigator.of(context).pushReplacement(
                  MaterialPageRoute(
                    builder: (_) => const DokanAroOptionScreen(),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  bool get _hasActiveFilters {
    return _searchController.text.trim().isNotEmpty ||
        _selectedFilterIndex != 0 ||
        _selectedStatusIndex != 0 ||
        _selectedAmountIndex != 0;
  }

  List<_SalesItem> _filterOrders(List<DokanPosOrderRecord> orders) {
    final query = _searchController.text.trim().toLowerCase();

    return orders.where((order) {
      final matchesSearch = query.isEmpty ||
          order.customerName.toLowerCase().contains(query) ||
          order.customerNumber.toLowerCase().contains(query) ||
          order.summary.toLowerCase().contains(query) ||
          order.id.toLowerCase().contains(query) ||
          dokanPosPaymentMethodLabel(order.paymentMethod).toLowerCase().contains(query);

      final matchesStatus = switch (_selectedStatusIndex) {
        0 => true,
        1 => order.status == DokanPosOrderStatus.paid,
        2 => order.status == DokanPosOrderStatus.due,
        3 => order.status == DokanPosOrderStatus.partiallyPaid,
        _ => true,
      };

      final matchesTime = switch (_selectedFilterIndex) {
        0 => _isSameDay(order.createdAt, DateTime.now()),
        1 => _isSameDay(order.createdAt, DateTime.now().subtract(const Duration(days: 1))),
        2 => _isSameWeek(order.createdAt, DateTime.now()),
        3 => _isSameMonth(order.createdAt, DateTime.now()),
        4 => true,
        _ => true,
      };

      final matchesAmount = switch (_selectedAmountIndex) {
        0 => true,
        1 => order.totalAmount < 1000,
        2 => order.totalAmount >= 1000 && order.totalAmount <= 5000,
        3 => order.totalAmount > 5000,
        _ => true,
      };

      return matchesSearch && matchesStatus && matchesTime && matchesAmount;
    }).map(_salesItemFromOrder).toList(growable: false);
  }

  List<_SalesGroup> _groupOrders(List<_SalesItem> items) {
    final today = <_SalesItem>[];
    final yesterday = <_SalesItem>[];
    final others = <_SalesItem>[];

    final now = DateTime.now();
    final todayDate = DateTime(now.year, now.month, now.day);
    final yesterdayDate = todayDate.subtract(const Duration(days: 1));

    for (final item in items) {
      final createdAt =
          item.createdAt ?? DateTime.fromMillisecondsSinceEpoch(0);
      final day = DateTime(createdAt.year, createdAt.month, createdAt.day);
      if (day == todayDate) {
        today.add(item);
      } else if (day == yesterdayDate) {
        yesterday.add(item);
      } else {
        others.add(item);
      }
    }

    final groups = <_SalesGroup>[];
    if (today.isNotEmpty) {
      groups.add(_SalesGroup(title: 'আজকে', items: today));
    }
    if (yesterday.isNotEmpty) {
      groups.add(_SalesGroup(title: 'গতকাল', items: yesterday));
    }
    if (others.isNotEmpty) {
      groups.add(_SalesGroup(title: 'অন্যান্য', items: others));
    }
    return groups;
  }

  _SalesItem _salesItemFromOrder(DokanPosOrderRecord order) {
    final statusLabel = switch (order.status) {
      DokanPosOrderStatus.paid => 'সম্পূর্ণ পরিশোধ',
      DokanPosOrderStatus.due => 'বাকি আছে',
      DokanPosOrderStatus.partiallyPaid => 'আংশিক পরিশোধ',
      DokanPosOrderStatus.cancelled => 'বাতিল',
    };

    final status = switch (order.status) {
      DokanPosOrderStatus.paid => _SalesStatus.paid,
      DokanPosOrderStatus.due => _SalesStatus.due,
      DokanPosOrderStatus.partiallyPaid => _SalesStatus.partial,
      DokanPosOrderStatus.cancelled => _SalesStatus.due,
    };

    final shortTime = _formatBanglaTime(order.createdAt);
    final itemCount = '১টি অর্ডার';
    final referenceId =
        'রেফ: ${_banglaDigits((order.createdAt.microsecondsSinceEpoch % 10000).toString().padLeft(4, '0'))}';
    final amount = order.totalAmount;
    final profit = (order.totalAmount * 0.18).round();

    return _SalesItem(
      customerName: order.customerName,
      amount: amount,
      profit: profit,
      statusLabel: statusLabel,
      status: status,
      timeText: '$itemCount • $shortTime',
      referenceId: referenceId,
      createdAt: order.createdAt,
    );
  }

  bool _isSameDay(DateTime a, DateTime b) {
    return a.year == b.year && a.month == b.month && a.day == b.day;
  }

  bool _isSameWeek(DateTime a, DateTime b) {
    final aMonday = DateTime(a.year, a.month, a.day - (a.weekday - 1));
    final bMonday = DateTime(b.year, b.month, b.day - (b.weekday - 1));
    return _isSameDay(aMonday, bMonday);
  }

  bool _isSameMonth(DateTime a, DateTime b) {
    return a.year == b.year && a.month == b.month;
  }

  String _formatBanglaTime(DateTime dateTime) {
    final hour = dateTime.hour % 12 == 0 ? 12 : dateTime.hour % 12;
    final minute = dateTime.minute.toString().padLeft(2, '0');
    final period = dateTime.hour >= 12 ? 'সন্ধ্যা' : 'সকাল';
    return '$period ${_banglaDigits(hour.toString())}:${_banglaDigits(minute)}';
  }
}

class _SalesHeaderBar extends StatelessWidget {
  const _SalesHeaderBar({
    required this.onBack,
    required this.onSearch,
    required this.onFilter,
  });

  final VoidCallback onBack;
  final VoidCallback onSearch;
  final VoidCallback onFilter;

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 84,
      padding: const EdgeInsets.symmetric(horizontal: 12),
      decoration: BoxDecoration(
        color: const Color(0xFFF3FAFB),
        borderRadius: BorderRadius.circular(2),
        border: Border.all(color: const Color(0xFFD9E6E2)),
      ),
      child: Row(
        children: [
          _HistoryIconButton(
            icon: Icons.arrow_back,
            onTap: onBack,
          ),
          const Expanded(
            child: Center(
              child: Text(
                'বিক্রয় ইতিহাস',
                style: TextStyle(
                  color: Color(0xFF006B53),
                  fontSize: 24,
                  fontWeight: FontWeight.w900,
                ),
              ),
            ),
          ),
          _HistoryIconButton(
            icon: Icons.filter_alt_outlined,
            onTap: onFilter,
          ),
          const SizedBox(width: 10),
          _HistoryIconButton(
            icon: Icons.search,
            onTap: onSearch,
          ),
        ],
      ),
    );
  }
}

class _SalesSummaryStrip extends StatelessWidget {
  const _SalesSummaryStrip({
    required this.todaySales,
    required this.totalSales,
    required this.totalProfit,
  });

  final String todaySales;
  final String totalSales;
  final String totalProfit;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 14),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [Color(0xFF1D9E75), Color(0xFF00694C)],
          begin: Alignment.centerLeft,
          end: Alignment.centerRight,
        ),
        borderRadius: BorderRadius.circular(0),
        boxShadow: [
          BoxShadow(
            color: const Color(0xFF0B5B42).withValues(alpha: 0.22),
            blurRadius: 18,
            offset: const Offset(0, 10),
          ),
        ],
      ),
      child: Row(
        children: [
          Expanded(
            child: _SummaryMetric(
              title: 'আজকের বিক্রয়',
              value: '৳$todaySales',
            ),
          ),
          Container(width: 1, height: 64, color: Colors.white.withValues(alpha: 0.18)),
          Expanded(
            child: _SummaryMetric(
              title: 'মোট বিক্রয়',
              value: '$totalSalesটি',
              alignEnd: true,
            ),
          ),
          Container(width: 1, height: 64, color: Colors.white.withValues(alpha: 0.18)),
          Expanded(
            child: _SummaryMetric(
              title: 'মোট লাভ',
              value: '৳$totalProfit',
              alignEnd: true,
            ),
          ),
        ],
      ),
    );
  }
}

class _SummaryMetric extends StatelessWidget {
  const _SummaryMetric({
    required this.title,
    required this.value,
    this.alignEnd = false,
  });

  final String title;
  final String value;
  final bool alignEnd;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 10),
      child: Column(
        crossAxisAlignment:
            alignEnd ? CrossAxisAlignment.end : CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Text(
            title,
            style: TextStyle(
              color: Colors.white.withValues(alpha: 0.82),
              fontSize: 15,
              fontWeight: FontWeight.w800,
            ),
          ),
          const SizedBox(height: 6),
          Text(
            value,
            style: const TextStyle(
              color: Colors.white,
              fontSize: 22,
              fontWeight: FontWeight.w900,
            ),
          ),
        ],
      ),
    );
  }
}

class _FilterChipButton extends StatelessWidget {
  const _FilterChipButton({
    required this.label,
    required this.selected,
    required this.onTap,
  });

  final String label;
  final bool selected;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: selected ? const Color(0xFF00694C) : const Color(0xFFE6EDF0),
      borderRadius: BorderRadius.circular(999),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(999),
        child: Container(
          constraints: const BoxConstraints(minWidth: 84),
          padding: const EdgeInsets.symmetric(horizontal: 22, vertical: 14),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(999),
            border: Border.all(
              color: selected ? const Color(0xFF00694C) : const Color(0xFFE6EDF0),
            ),
          ),
          child: Center(
            child: Text(
              label,
              style: TextStyle(
                color: selected ? Colors.white : const Color(0xFF3D4943),
                fontSize: 16,
                fontWeight: FontWeight.w800,
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class _SalesGroupSection extends StatelessWidget {
  const _SalesGroupSection({required this.group});

  final _SalesGroup group;

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Text(
              '${group.title} — ${_banglaDigits(group.items.length.toString())}টি বিক্রয়',
              style: const TextStyle(
                color: Color(0xFF3D4943),
                fontSize: 18,
                fontWeight: FontWeight.w800,
              ),
            ),
            const SizedBox(width: 10),
            const Expanded(
              child: Divider(
                color: Color(0xFFC8D5D0),
                thickness: 1,
                height: 1,
              ),
            ),
          ],
        ),
        const SizedBox(height: 14),
        ListView.separated(
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          itemCount: group.items.length,
          separatorBuilder: (context, index) => const SizedBox(height: 12),
          itemBuilder: (context, index) {
            return _SalesCard(item: group.items[index]);
          },
        ),
      ],
    );
  }
}

class _SalesCard extends StatelessWidget {
  const _SalesCard({required this.item});

  final _SalesItem item;

  @override
  Widget build(BuildContext context) {
    final color = switch (item.status) {
      _SalesStatus.paid => const Color(0xFFD8F3DF),
      _SalesStatus.due => const Color(0xFFF8D9DB),
      _SalesStatus.partial => const Color(0xFFF7D9EA),
    };
    final iconColor = switch (item.status) {
      _SalesStatus.paid => const Color(0xFF0C8C67),
      _SalesStatus.due => const Color(0xFFD43B3B),
      _SalesStatus.partial => const Color(0xFFC2185B),
    };
    final amountColor = switch (item.status) {
      _SalesStatus.due => const Color(0xFF141F22),
      _SalesStatus.partial => const Color(0xFF0F7B57),
      _SalesStatus.paid => const Color(0xFF141F22),
    };

    return Material(
      color: Colors.white,
      borderRadius: BorderRadius.circular(18),
      child: InkWell(
        onTap: () => Navigator.of(context).push(
          MaterialPageRoute(
            builder: (_) => const _SalesHistoryDummyScreen(),
          ),
        ),
        borderRadius: BorderRadius.circular(18),
        child: Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(18),
            border: Border.all(color: const Color(0xFFD9E6E2)),
            boxShadow: [
              BoxShadow(
                color: const Color(0xFFB9C8C3).withValues(alpha: 0.10),
                blurRadius: 10,
                offset: const Offset(0, 6),
              ),
            ],
          ),
          child: Row(
            children: [
              Container(
                width: 60,
                height: 60,
                decoration: BoxDecoration(
                  color: color,
                  shape: BoxShape.circle,
                ),
                child: Icon(
                  item.status == _SalesStatus.partial
                      ? Icons.receipt_long_outlined
                      : item.status == _SalesStatus.due
                          ? Icons.book_outlined
                          : Icons.payments_outlined,
                  color: iconColor,
                  size: 30,
                ),
              ),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      item.customerName,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                        color: Color(0xFF141F22),
                        fontSize: 18,
                        fontWeight: FontWeight.w900,
                      ),
                    ),
                    const SizedBox(height: 8),
                    Text(
                      item.timeText,
                      style: const TextStyle(
                        color: Color(0xFF3D4943),
                        fontSize: 16,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    const SizedBox(height: 6),
                    Text(
                      item.referenceId,
                      style: const TextStyle(
                        color: Color(0xFF6F7D78),
                        fontSize: 13,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 12),
              Column(
                crossAxisAlignment: CrossAxisAlignment.end,
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    '৳${_banglaDigits(item.amount.toString())}',
                    style: TextStyle(
                      color: amountColor,
                      fontSize: 20,
                      fontWeight: FontWeight.w900,
                    ),
                  ),
                  const SizedBox(height: 18),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                    decoration: BoxDecoration(
                      color: switch (item.status) {
                        _SalesStatus.paid => const Color(0xFFE1F5E7),
                        _SalesStatus.due => const Color(0xFFFDE7E7),
                        _SalesStatus.partial => const Color(0xFFFDE7F2),
                      },
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(
                        color: switch (item.status) {
                          _SalesStatus.paid => const Color(0xFFA8E0B6),
                          _SalesStatus.due => const Color(0xFFF0B5B5),
                          _SalesStatus.partial => const Color(0xFFF0B5CF),
                        },
                      ),
                    ),
                    child: Text(
                      item.statusLabel,
                      style: TextStyle(
                        color: iconColor,
                        fontSize: 12,
                        fontWeight: FontWeight.w800,
                      ),
                    ),
                  ),
                  const SizedBox(height: 6),
                  Text(
                    'লাভ ৳${_banglaDigits(item.profit.toString())}',
                    style: const TextStyle(
                      color: Color(0xFF0F7B57),
                      fontSize: 14,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _SalesEmptyState extends StatelessWidget {
  const _SalesEmptyState();

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Container(
        width: double.infinity,
        padding: const EdgeInsets.all(24),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: const Color(0xFFD9E6E2)),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: const [
            Icon(Icons.warning_amber_rounded, size: 44, color: Color(0xFF0C8C67)),
            SizedBox(height: 10),
            Text(
              '??? ?????? ????? ?????',
              style: TextStyle(
                color: Color(0xFF141F22),
                fontSize: 16,
                fontWeight: FontWeight.w800,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _SalesBottomNavItem extends StatelessWidget {
  const _SalesBottomNavItem({
    required this.icon,
    required this.label,
    required this.selected,
    required this.onTap,
  });

  final IconData icon;
  final String label;
  final bool selected;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final color = selected ? const Color(0xFF00694C) : const Color(0xFF3D4943);
    return Expanded(
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: onTap,
          borderRadius: BorderRadius.circular(16),
          child: Padding(
            padding: const EdgeInsets.symmetric(vertical: 6),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(icon, color: color, size: 28),
                const SizedBox(height: 4),
                Text(
                  label,
                  style: TextStyle(
                    color: color,
                    fontSize: 14,
                    fontWeight: FontWeight.w800,
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _SalesHistoryDummyScreen extends StatelessWidget {
  const _SalesHistoryDummyScreen();

  static const List<_SaleDetailProduct> _products = <_SaleDetailProduct>[
    _SaleDetailProduct(
      icon: '🌾',
      name: 'মিনিকেট চাল ১কেজি',
      quantity: 2,
      price: 75,
      total: 150,
    ),
    _SaleDetailProduct(
      icon: '🛢',
      name: 'সয়াবিন তেল ১লি',
      quantity: 1,
      price: 165,
      total: 165,
    ),
    _SaleDetailProduct(
      icon: '🧼',
      name: 'লাক্স সাবান ১০০গ্রা',
      quantity: 1,
      price: 58,
      total: 58,
    ),
    _SaleDetailProduct(
      icon: '🥤',
      name: 'কোকা কোলা ২৫০মি',
      quantity: 2,
      price: 35,
      total: 70,
    ),
  ];

  void _showMessage(BuildContext context, String message, {bool success = true}) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        behavior: SnackBarBehavior.floating,
        backgroundColor: success ? const Color(0xFF0C8C67) : const Color(0xFFD43B3B),
        content: Text(message),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      resizeToAvoidBottomInset: true,
      body: SafeArea(
        bottom: false,
        child: ListView(
          padding: const EdgeInsets.fromLTRB(16, 16, 16, 24),
          children: [
            Container(
              padding: const EdgeInsets.fromLTRB(14, 14, 14, 14),
              decoration: BoxDecoration(
                color: const Color(0xFFF3FAFB),
                borderRadius: BorderRadius.circular(24),
                border: Border.all(color: const Color(0xFFD9E6E2)),
              ),
              child: Row(
                children: [
                  Material(
                    color: Colors.white,
                    shape: const CircleBorder(),
                    child: InkWell(
                      customBorder: const CircleBorder(),
                      onTap: () => Navigator.of(context).pushReplacement(
                        MaterialPageRoute(
                          builder: (_) => DokanPosMainScreen(key: UniqueKey()),
                        ),
                      ),
                      child: const SizedBox(
                        width: 44,
                        height: 44,
                        child: Icon(Icons.arrow_back, color: Color(0xFF3D4943)),
                      ),
                    ),
                  ),
                  const Expanded(
                    child: Center(
                      child: Text(
                        'বিক্রয় বিস্তারিত',
                        style: TextStyle(
                          color: Color(0xFF00694C),
                          fontSize: 24,
                          fontWeight: FontWeight.w900,
                        ),
                      ),
                    ),
                  ),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                    decoration: BoxDecoration(
                      color: const Color(0xFFE1F5E7),
                      borderRadius: BorderRadius.circular(999),
                    ),
                    child: const Text(
                      'সম্পন্ন',
                      style: TextStyle(
                        color: Color(0xFF0C8C67),
                        fontWeight: FontWeight.w900,
                      ),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 14),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
              decoration: BoxDecoration(
                color: const Color(0xFFE8F4EF),
                borderRadius: BorderRadius.circular(0),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  const Row(
                    children: [
                      Icon(Icons.check_circle, color: Color(0xFF0C8C67)),
                      SizedBox(width: 10),
                      Text(
                        'সম্পন্ন',
                        style: TextStyle(
                          color: Color(0xFF0C8C67),
                          fontSize: 18,
                          fontWeight: FontWeight.w800,
                        ),
                      ),
                    ],
                  ),
                  Text(
                    'Invoice #০০২৩',
                    style: TextStyle(
                      color: Colors.black.withValues(alpha: 0.8),
                      fontSize: 18,
                      fontWeight: FontWeight.w900,
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 18),
            _DetailSectionCard(
              child: Column(
                children: const [
                  _InvoiceInfoRow(icon: Icons.calendar_today_outlined, label: 'তারিখ', value: '২৩ মে ২০২৬, ৯:৪১ AM'),
                  SizedBox(height: 18),
                  _InvoiceInfoRow(icon: Icons.payments_outlined, label: 'পেমেন্ট', value: 'নগদ'),
                  SizedBox(height: 18),
                  _InvoiceInfoRow(icon: Icons.person_outline, label: 'খদ্দের', value: 'করিম সাহেব'),
                  SizedBox(height: 18),
                  _InvoiceInfoRow(icon: Icons.badge_outlined, label: 'বিক্রেতা', value: 'রহিম উদ্দিন (মালিক)'),
                ],
              ),
            ),
            const SizedBox(height: 18),
            const Text(
              'পণ্য তালিকা',
              style: TextStyle(
                color: Color(0xFF141F22),
                fontSize: 22,
                fontWeight: FontWeight.w900,
              ),
            ),
            const SizedBox(height: 14),
            ..._products.map(
              (product) => Padding(
                padding: const EdgeInsets.only(bottom: 12),
                child: _DetailProductCard(product: product),
              ),
            ),
            const SizedBox(height: 6),
            _DetailSectionCard(
              child: Column(
                children: [
                  const _SummaryAmountRow(label: 'উপমোট', value: '৳৪৪৩'),
                  const SizedBox(height: 14),
                  const _SummaryAmountRow(label: 'ডিসকাউন্ট (৫%)', value: '−৳২২', valueColor: Color(0xFFD43B3B)),
                  const SizedBox(height: 14),
                  const Divider(color: Color(0xFFD9E6E2), height: 1),
                  const SizedBox(height: 14),
                  const _SummaryAmountRow(label: 'সর্বমোট', value: '৳৪২১', emphasis: true),
                  const SizedBox(height: 18),
                  const Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        'ক্রয়মূল্য',
                        style: TextStyle(
                          color: Color(0xFF6F7D78),
                          fontSize: 14,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                      Text(
                        '৳৩৩৬',
                        style: TextStyle(
                          color: Color(0xFF141F22),
                          fontSize: 16,
                          fontWeight: FontWeight.w800,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 8),
                  const Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        'মুনাফা',
                        style: TextStyle(
                          color: Color(0xFF0C8C67),
                          fontSize: 14,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                      Text(
                        '৳৮৫',
                        style: TextStyle(
                          color: Color(0xFF0C8C67),
                          fontSize: 16,
                          fontWeight: FontWeight.w900,
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
            const SizedBox(height: 18),
            Row(
              children: [
                Expanded(
                  child: _DetailActionTile(
                    label: 'প্রিন্ট',
                    icon: Icons.print_outlined,
                    onTap: () => _showMessage(context, 'প্রিন্টের অনুরোধ পাঠানো হয়েছে'),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: _DetailActionTile(
                    label: 'PDF',
                    icon: Icons.picture_as_pdf_outlined,
                    onTap: () => _showMessage(context, 'PDF তৈরি করা হয়েছে'),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: _DetailActionTile(
                    label: 'WhatsApp',
                    icon: Icons.chat_bubble_outline,
                    filled: true,
                    onTap: () => _showMessage(context, 'WhatsApp-এ শেয়ার প্রস্তুত'),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 18),
            SizedBox(
              width: double.infinity,
              child: OutlinedButton(
                onPressed: () {
                  Navigator.of(context).push(
                    MaterialPageRoute(
                      builder: (_) => const _SalesCancellationScreen(),
                    ),
                  );
                },
                style: OutlinedButton.styleFrom(
                  side: const BorderSide(color: Color(0xFFF2C7C7), width: 2),
                  foregroundColor: const Color(0xFFD43B3B),
                  padding: const EdgeInsets.symmetric(vertical: 18),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
                ),
                child: const Text(
                  'বিক্রয় বাতিল করুন',
                  style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.w900,
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
      bottomNavigationBar: SafeArea(
        top: false,
        child: Container(
          padding: const EdgeInsets.fromLTRB(14, 12, 14, 12),
          decoration: const BoxDecoration(
            color: Color(0xFFEAF2F0),
            border: Border(
              top: BorderSide(color: Color(0xFFD7E5E0)),
            ),
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              _SalesBottomNavItem(
                icon: Icons.home_outlined,
                label: 'হোম',
                selected: false,
                onTap: () => Navigator.of(context).popUntil((r) => r.isFirst),
              ),
              _SalesBottomNavItem(
                icon: Icons.point_of_sale_outlined,
                label: 'বিক্রয়',
                selected: true,
                onTap: () => Navigator.of(context).pop(),
              ),
              _SalesBottomNavItem(
                icon: Icons.inventory_2_outlined,
                label: 'পণ্য',
                selected: false,
                onTap: () => Navigator.of(context).pushReplacement(
                  MaterialPageRoute(builder: (_) => const DokanProductListScreen()),
                ),
              ),
              _SalesBottomNavItem(
                icon: Icons.bar_chart_outlined,
                label: 'রিপোর্ট',
                selected: false,
                onTap: () => Navigator.of(context).pushReplacement(
                  MaterialPageRoute(builder: (_) => const DokanReportsHomeScreen()),
                ),
              ),
              _SalesBottomNavItem(
                icon: Icons.more_horiz,
                label: 'আরও',
                selected: false,
                onTap: () => Navigator.of(context).pushReplacement(
                  MaterialPageRoute(builder: (_) => const DokanAroOptionScreen()),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _SalesCancellationScreen extends StatefulWidget {
  const _SalesCancellationScreen();

  @override
  State<_SalesCancellationScreen> createState() => _SalesCancellationScreenState();
}

class _SalesCancellationScreenState extends State<_SalesCancellationScreen> {
  int _refundMethodIndex = 0;
  String _selectedReason = 'খদ্দের ফেরত দিয়েছেন';
  final TextEditingController _notesController = TextEditingController();

  static const List<String> _refundMethods = <String>[
    'নগদ ফেরত',
    'bKash/Nagad এ ফেরত',
    'পরে কেনাকাটায় বাদ দিন',
  ];

  static const List<String> _reasons = <String>[
    'খদ্দের ফেরত দিয়েছেন',
    'ভুল বিল হয়েছে',
    'ডুপ্লিকেট বিক্রয়',
    'অন্যান্য',
  ];

  @override
  void dispose() {
    _notesController.dispose();
    super.dispose();
  }

  void _goToSuccessPage() {
    Navigator.of(context).push(
      MaterialPageRoute(
        builder: (_) => _SalesCancellationSuccessScreen(
          refundMethod: _refundMethods[_refundMethodIndex],
        ),
      ),
    );
  }

  Widget _bottomNav() {
    return SafeArea(
      top: false,
      child: Container(
        padding: const EdgeInsets.fromLTRB(14, 12, 14, 12),
        decoration: const BoxDecoration(
          color: Color(0xFFEAF2F0),
          border: Border(
            top: BorderSide(color: Color(0xFFD7E5E0)),
          ),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            _SalesBottomNavItem(
              icon: Icons.home_outlined,
              label: 'হোম',
              selected: false,
              onTap: () => Navigator.of(context).popUntil((r) => r.isFirst),
            ),
            _SalesBottomNavItem(
              icon: Icons.point_of_sale_outlined,
              label: 'বিক্রয়',
              selected: true,
              onTap: () => Navigator.of(context).pop(),
            ),
            _SalesBottomNavItem(
              icon: Icons.inventory_2_outlined,
              label: 'পণ্য',
              selected: false,
              onTap: () => Navigator.of(context).pushReplacement(
                MaterialPageRoute(builder: (_) => const DokanProductListScreen()),
              ),
            ),
            _SalesBottomNavItem(
              icon: Icons.bar_chart_outlined,
              label: 'রিপোর্ট',
              selected: false,
              onTap: () => Navigator.of(context).pushReplacement(
                MaterialPageRoute(builder: (_) => const DokanReportsHomeScreen()),
              ),
            ),
            _SalesBottomNavItem(
              icon: Icons.more_horiz,
              label: 'আরও',
              selected: false,
              onTap: () => Navigator.of(context).pushReplacement(
                MaterialPageRoute(builder: (_) => const DokanAroOptionScreen()),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _refundOption(String label, int index) {
    final selected = _refundMethodIndex == index;
    return Material(
      color: Colors.transparent,
      child: InkWell(
        borderRadius: BorderRadius.circular(16),
        onTap: () => setState(() => _refundMethodIndex = index),
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
          decoration: BoxDecoration(
            color: selected ? const Color(0xFFF0FAF5) : Colors.white,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(
              color: selected ? const Color(0xFF00694C) : const Color(0xFFD9E6E2),
              width: selected ? 2 : 1,
            ),
          ),
          child: Row(
            children: [
              Icon(
                index == 0
                    ? Icons.payments_outlined
                    : index == 1
                        ? Icons.account_balance_wallet_outlined
                        : Icons.remove_circle_outline,
                color: const Color(0xFF3D4943),
                size: 22,
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Text(
                  label,
                  style: const TextStyle(
                    color: Color(0xFF141F22),
                    fontSize: 16,
                    fontWeight: FontWeight.w800,
                  ),
                ),
              ),
              AnimatedContainer(
                duration: const Duration(milliseconds: 180),
                width: 26,
                height: 26,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  border: Border.all(
                    color: selected ? const Color(0xFF00694C) : const Color(0xFF9AA8A2),
                    width: 2,
                  ),
                ),
                padding: const EdgeInsets.all(4),
                child: AnimatedContainer(
                  duration: const Duration(milliseconds: 180),
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: selected ? const Color(0xFF00694C) : Colors.transparent,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      resizeToAvoidBottomInset: true,
      body: SafeArea(
        bottom: false,
        child: ListView(
          padding: const EdgeInsets.fromLTRB(16, 12, 16, 16),
          children: [
            Container(
              height: 82,
              padding: const EdgeInsets.symmetric(horizontal: 14),
              decoration: BoxDecoration(
                color: const Color(0xFFF3FAFB),
                borderRadius: BorderRadius.circular(0),
                border: Border.all(color: const Color(0xFFD9E6E2)),
              ),
              child: Row(
                children: [
                  Material(
                    color: Colors.white,
                    shape: const CircleBorder(),
                    child: InkWell(
                      customBorder: const CircleBorder(),
                      onTap: () => Navigator.of(context).pop(),
                      child: const SizedBox(
                        width: 44,
                        height: 44,
                        child: Icon(Icons.arrow_back, color: Color(0xFF3D4943)),
                      ),
                    ),
                  ),
                  const Expanded(
                    child: Center(
                      child: Text(
                        'বিক্রয় বাতিল',
                        style: TextStyle(
                          color: Color(0xFF00694C),
                          fontSize: 24,
                          fontWeight: FontWeight.w900,
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(width: 44),
                ],
              ),
            ),
            const SizedBox(height: 16),
            Container(
              padding: const EdgeInsets.all(18),
              decoration: BoxDecoration(
                color: const Color(0xFFFDEEEF),
                borderRadius: BorderRadius.circular(24),
                border: Border.all(color: const Color(0xFFF4D2D5)),
              ),
              child: Column(
                children: [
                  const Icon(Icons.warning_amber_rounded, color: Color(0xFFD43B3B), size: 56),
                  const SizedBox(height: 10),
                  const Text(
                    'এই বিক্রয় বাতিল করবেন?',
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      color: Color(0xFFD43B3B),
                      fontSize: 22,
                      fontWeight: FontWeight.w900,
                    ),
                  ),
                  const SizedBox(height: 8),
                  const Text(
                    'বাতিল করলে স্টক ফিরে আসবে এবং এই বিক্রয়ের রেকর্ড মুছে যাবে',
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      color: Color(0xFF5F6A66),
                      fontSize: 15,
                      height: 1.5,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                  const SizedBox(height: 16),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 14),
                    decoration: BoxDecoration(
                      color: Colors.white.withValues(alpha: 0.7),
                      borderRadius: BorderRadius.circular(18),
                    ),
                    child: Text(
                      'Invoice #০০২৩ — ৳৪২১',
                      style: const TextStyle(
                        color: Color(0xFFB61F2A),
                        fontSize: 18,
                        fontWeight: FontWeight.w900,
                      ),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 16),
            _DetailSectionCard(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'রিফান্ড পদ্ধতি',
                    style: TextStyle(
                      color: Color(0xFF141F22),
                      fontSize: 18,
                      fontWeight: FontWeight.w900,
                    ),
                  ),
                  const SizedBox(height: 14),
                  ...List.generate(
                    _refundMethods.length,
                    (index) => Padding(
                      padding: EdgeInsets.only(bottom: index == _refundMethods.length - 1 ? 0 : 12),
                      child: _refundOption(_refundMethods[index], index),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 16),
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(20),
                border: Border.all(color: const Color(0xFFD9E6E2)),
                boxShadow: const [],
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'বাতিলের কারণ',
                    style: TextStyle(
                      color: Color(0xFF141F22),
                      fontSize: 18,
                      fontWeight: FontWeight.w900,
                    ),
                  ),
                  const SizedBox(height: 12),
                  DropdownButtonFormField<String>(
                    initialValue: _selectedReason,
                    decoration: InputDecoration(
                      filled: true,
                      fillColor: Colors.white,
                      contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(14),
                        borderSide: const BorderSide(color: Color(0xFFD9E6E2)),
                      ),
                      enabledBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(14),
                        borderSide: const BorderSide(color: Color(0xFFD9E6E2)),
                      ),
                      focusedBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(14),
                        borderSide: const BorderSide(color: Color(0xFF00694C), width: 1.6),
                      ),
                    ),
                    icon: const Icon(Icons.keyboard_arrow_down_rounded, color: Color(0xFF6F7D78)),
                    dropdownColor: Colors.white,
                    items: _reasons
                        .map(
                          (reason) => DropdownMenuItem<String>(
                            value: reason,
                            child: Text(
                              reason,
                              style: const TextStyle(
                                color: Color(0xFF141F22),
                                fontWeight: FontWeight.w700,
                              ),
                            ),
                          ),
                        )
                        .toList(),
                    onChanged: (value) {
                      if (value == null) return;
                      setState(() => _selectedReason = value);
                    },
                  ),
                  const SizedBox(height: 16),
                  const Text(
                    'অতিরিক্ত নোট',
                    style: TextStyle(
                      color: Color(0xFF141F22),
                      fontSize: 18,
                      fontWeight: FontWeight.w900,
                    ),
                  ),
                  const SizedBox(height: 12),
                  TextField(
                    controller: _notesController,
                    maxLines: 4,
                    style: const TextStyle(
                      color: Color(0xFF141F22),
                      fontWeight: FontWeight.w700,
                    ),
                    cursorColor: const Color(0xFF00694C),
                    decoration: InputDecoration(
                      hintText: 'বিস্তারিত লিখুন...',
                      hintStyle: const TextStyle(color: Color(0xFF7C8A84)),
                      filled: true,
                      fillColor: Colors.white,
                      contentPadding: const EdgeInsets.all(16),
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(14),
                        borderSide: const BorderSide(color: Color(0xFFD9E6E2)),
                      ),
                      enabledBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(14),
                        borderSide: const BorderSide(color: Color(0xFFD9E6E2)),
                      ),
                      focusedBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(14),
                        borderSide: const BorderSide(color: Color(0xFF00694C), width: 1.6),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 16),
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: const Color(0xFF0F8F68),
                borderRadius: BorderRadius.circular(24),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    '✓ স্টকে ফিরে আসবে:',
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 18,
                      fontWeight: FontWeight.w900,
                    ),
                  ),
                  const SizedBox(height: 12),
                  ..._SalesHistoryDummyScreen._products.map(
                    (product) => Padding(
                      padding: const EdgeInsets.only(bottom: 10),
                      child: Container(
                        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
                        decoration: BoxDecoration(
                          color: Colors.white.withValues(alpha: 0.14),
                          borderRadius: BorderRadius.circular(16),
                        ),
                        child: Row(
                          children: [
                            Container(
                              width: 40,
                              height: 40,
                              decoration: const BoxDecoration(
                                color: Colors.white,
                                shape: BoxShape.circle,
                              ),
                              alignment: Alignment.center,
                              child: Text(product.icon, style: const TextStyle(fontSize: 20)),
                            ),
                            const SizedBox(width: 12),
                            Expanded(
                              child: Text(
                                product.name,
                                style: const TextStyle(
                                  color: Colors.white,
                                  fontSize: 15,
                                  fontWeight: FontWeight.w800,
                                ),
                              ),
                            ),
                            Text(
                              '+${_banglaDigits(product.quantity.toString())}টি',
                              style: const TextStyle(
                                color: Colors.white,
                                fontSize: 16,
                                fontWeight: FontWeight.w900,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 18),
            Row(
              children: [
                Expanded(
                  child: SizedBox(
                    height: 58,
                    child: OutlinedButton(
                      onPressed: () => Navigator.of(context).pop(),
                      style: OutlinedButton.styleFrom(
                        side: const BorderSide(color: Color(0xFFC9D4D0), width: 1.6),
                        foregroundColor: const Color(0xFF3D4943),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(18),
                        ),
                      ),
                      child: const Text(
                        'বাতিল করব না',
                        style: TextStyle(fontSize: 16, fontWeight: FontWeight.w900),
                      ),
                    ),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: SizedBox(
                    height: 58,
                    child: ElevatedButton(
                      onPressed: _goToSuccessPage,
                      style: ElevatedButton.styleFrom(
                        backgroundColor: const Color(0xFFD84A4A),
                        foregroundColor: Colors.white,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(18),
                        ),
                      ),
                      child: const Text(
                        'বিক্রয় বাতিল করুন',
                        style: TextStyle(fontSize: 16, fontWeight: FontWeight.w900),
                      ),
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 16),
          ],
        ),
      ),
      bottomNavigationBar: _bottomNav(),
    );
  }
}

class _SalesCancellationSuccessScreen extends StatelessWidget {
  const _SalesCancellationSuccessScreen({required this.refundMethod});

  final String refundMethod;

  Widget _bottomNav(BuildContext context) {
    return SafeArea(
      top: false,
      child: Container(
        padding: const EdgeInsets.fromLTRB(14, 12, 14, 12),
        decoration: const BoxDecoration(
          color: Color(0xFFEAF2F0),
          border: Border(
            top: BorderSide(color: Color(0xFFD7E5E0)),
          ),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            _SalesBottomNavItem(
              icon: Icons.home_outlined,
              label: 'হোম',
              selected: false,
              onTap: () => Navigator.of(context).popUntil((r) => r.isFirst),
            ),
            _SalesBottomNavItem(
              icon: Icons.point_of_sale_outlined,
              label: 'বিক্রয়',
              selected: true,
              onTap: () => Navigator.of(context).pop(),
            ),
            _SalesBottomNavItem(
              icon: Icons.inventory_2_outlined,
              label: 'পণ্য',
              selected: false,
              onTap: () => Navigator.of(context).pushReplacement(
                MaterialPageRoute(builder: (_) => const DokanProductListScreen()),
              ),
            ),
            _SalesBottomNavItem(
              icon: Icons.bar_chart_outlined,
              label: 'রিপোর্ট',
              selected: false,
              onTap: () => Navigator.of(context).pushReplacement(
                MaterialPageRoute(builder: (_) => const DokanReportsHomeScreen()),
              ),
            ),
            _SalesBottomNavItem(
              icon: Icons.more_horiz,
              label: 'আরও',
              selected: false,
              onTap: () => Navigator.of(context).pushReplacement(
                MaterialPageRoute(builder: (_) => const DokanAroOptionScreen()),
              ),
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF3F8F7),
      body: SafeArea(
        bottom: false,
        child: ListView(
          padding: const EdgeInsets.fromLTRB(16, 12, 16, 16),
          children: [
            Container(
              height: 82,
              padding: const EdgeInsets.symmetric(horizontal: 14),
              decoration: BoxDecoration(
                color: const Color(0xFFF3FAFB),
                borderRadius: BorderRadius.circular(0),
                border: Border.all(color: const Color(0xFFD9E6E2)),
              ),
              child: Row(
                children: [
                  Material(
                    color: Colors.white,
                    shape: const CircleBorder(),
                    child: InkWell(
                      customBorder: const CircleBorder(),
                      onTap: () => Navigator.of(context).pop(),
                      child: const SizedBox(
                        width: 44,
                        height: 44,
                        child: Icon(Icons.arrow_back, color: Color(0xFF3D4943)),
                      ),
                    ),
                  ),
                  const Expanded(
                    child: Center(
                      child: Text(
                        'বিক্রয় বাতিল',
                        style: TextStyle(
                          color: Color(0xFF00694C),
                          fontSize: 24,
                          fontWeight: FontWeight.w900,
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(width: 44),
                ],
              ),
            ),
            const SizedBox(height: 20),
            Container(
              padding: const EdgeInsets.all(24),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(26),
                border: Border.all(color: const Color(0xFFD9E6E2)),
                boxShadow: [
                  BoxShadow(
                    color: const Color(0xFFB9C8C3).withValues(alpha: 0.08),
                    blurRadius: 18,
                    offset: const Offset(0, 8),
                  ),
                ],
              ),
              child: Column(
                children: [
                  Container(
                    width: 88,
                    height: 88,
                    decoration: const BoxDecoration(
                      color: Color(0xFFE5F7ED),
                      shape: BoxShape.circle,
                    ),
                    child: const Icon(Icons.check_circle, color: Color(0xFF0C8C67), size: 56),
                  ),
                  const SizedBox(height: 16),
                  const Text(
                    'বিক্রয় সফলভাবে বাতিল হয়েছে',
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      color: Color(0xFF141F22),
                      fontSize: 22,
                      fontWeight: FontWeight.w900,
                    ),
                  ),
                  const SizedBox(height: 10),
                  const Text(
                    'Invoice #০০২৩',
                    style: TextStyle(
                      color: Color(0xFF00694C),
                      fontSize: 16,
                      fontWeight: FontWeight.w800,
                    ),
                  ),
                  const SizedBox(height: 16),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                    decoration: BoxDecoration(
                      color: const Color(0xFFEAF7F0),
                      borderRadius: BorderRadius.circular(999),
                    ),
                    child: const Text(
                      'বাতিল সম্পন্ন',
                      style: TextStyle(
                        color: Color(0xFF0C8C67),
                        fontWeight: FontWeight.w900,
                      ),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 16),
            _DetailSectionCard(
              child: Column(
                children: [
                  _InvoiceInfoRow(icon: Icons.payments_outlined, label: 'রিফান্ড পদ্ধতি', value: refundMethod),
                  const SizedBox(height: 14),
                  const _InvoiceInfoRow(icon: Icons.receipt_long_outlined, label: 'Invoice', value: '০০২৩'),
                  const SizedBox(height: 14),
                  const _InvoiceInfoRow(icon: Icons.currency_bitcoin_outlined, label: 'Total Refund', value: '৳৪২১'),
                ],
              ),
            ),
            const SizedBox(height: 16),
            Container(
              padding: const EdgeInsets.all(18),
              decoration: BoxDecoration(
                color: const Color(0xFFEAF7F0),
                borderRadius: BorderRadius.circular(22),
                border: Border.all(color: const Color(0xFFD7E5E0)),
              ),
              child: const Text(
                'পণ্যগুলো স্টকে ফেরত যোগ করা হয়েছে',
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: Color(0xFF0C8C67),
                  fontSize: 16,
                  fontWeight: FontWeight.w800,
                ),
              ),
            ),
            const SizedBox(height: 18),
            SizedBox(
              height: 58,
              width: double.infinity,
              child: ElevatedButton(
                onPressed: () {
                  Navigator.of(context).pushAndRemoveUntil(
                    MaterialPageRoute(builder: (_) => const _DokanSalesHistoryScreen()),
                    (route) => false,
                  );
                },
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFF00694C),
                  foregroundColor: Colors.white,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(18),
                  ),
                ),
                child: const Text(
                  'বিক্রয় ইতিহাসে ফিরুন',
                  style: TextStyle(fontSize: 16, fontWeight: FontWeight.w900),
                ),
              ),
            ),
            const SizedBox(height: 16),
          ],
        ),
      ),
      bottomNavigationBar: _bottomNav(context),
    );
  }
}

class _DetailSectionCard extends StatelessWidget {
  const _DetailSectionCard({required this.child});

  final Widget child;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: const Color(0xFFD9E6E2)),
        boxShadow: [
          BoxShadow(
            color: const Color(0xFFB9C8C3).withValues(alpha: 0.08),
            blurRadius: 12,
            offset: const Offset(0, 6),
          ),
        ],
      ),
      child: child,
    );
  }
}

class _InvoiceInfoRow extends StatelessWidget {
  const _InvoiceInfoRow({required this.icon, required this.label, required this.value});

  final IconData icon;
  final String label;
  final String value;

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Icon(icon, color: const Color(0xFF6F7D78), size: 26),
        const SizedBox(width: 14),
        Text(
          label,
          style: const TextStyle(
            color: Color(0xFF6F7D78),
            fontSize: 16,
            fontWeight: FontWeight.w700,
          ),
        ),
        const Spacer(),
        Flexible(
          child: Text(
            value,
            textAlign: TextAlign.end,
            style: const TextStyle(
              color: Color(0xFF141F22),
              fontSize: 16,
              fontWeight: FontWeight.w800,
            ),
          ),
        ),
      ],
    );
  }
}

class _SaleDetailProduct {
  const _SaleDetailProduct({
    required this.icon,
    required this.name,
    required this.quantity,
    required this.price,
    required this.total,
  });

  final String icon;
  final String name;
  final int quantity;
  final int price;
  final int total;
}

class _DetailProductCard extends StatelessWidget {
  const _DetailProductCard({required this.product});

  final _SaleDetailProduct product;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: const Color(0xFFD9E6E2)),
        boxShadow: [
          BoxShadow(
            color: const Color(0xFFB9C8C3).withValues(alpha: 0.08),
            blurRadius: 12,
            offset: const Offset(0, 6),
          ),
        ],
      ),
      child: Row(
        children: [
          Container(
            width: 58,
            height: 58,
            decoration: const BoxDecoration(
              color: Color(0xFFEAF2F0),
              shape: BoxShape.circle,
            ),
            alignment: Alignment.center,
            child: Text(
              product.icon,
              style: const TextStyle(fontSize: 26),
            ),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  product.name,
                  style: const TextStyle(
                    color: Color(0xFF141F22),
                    fontSize: 16,
                    fontWeight: FontWeight.w900,
                  ),
                ),
                const SizedBox(height: 6),
                Text(
                  'পরিমাণ: ${_banglaDigits(product.quantity.toString())} × ${_formatCurrency(product.price)}',
                  style: const TextStyle(
                    color: Color(0xFF3D4943),
                    fontSize: 14,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(width: 10),
          Text(
            _formatCurrency(product.total),
            style: const TextStyle(
              color: Color(0xFF141F22),
              fontSize: 16,
              fontWeight: FontWeight.w900,
            ),
          ),
        ],
      ),
    );
  }
}

class _SummaryAmountRow extends StatelessWidget {
  const _SummaryAmountRow({
    required this.label,
    required this.value,
    this.valueColor = const Color(0xFF141F22),
    this.emphasis = false,
  });

  final String label;
  final String value;
  final Color valueColor;
  final bool emphasis;

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(
          label,
          style: TextStyle(
            color: const Color(0xFF6F7D78),
            fontSize: emphasis ? 18 : 14,
            fontWeight: FontWeight.w700,
          ),
        ),
        Text(
          value,
          style: TextStyle(
            color: valueColor,
            fontSize: emphasis ? 28 : 16,
            fontWeight: FontWeight.w900,
          ),
        ),
      ],
    );
  }
}

class _DetailActionTile extends StatelessWidget {
  const _DetailActionTile({
    required this.label,
    required this.icon,
    required this.onTap,
    this.filled = false,
  });

  final String label;
  final IconData icon;
  final VoidCallback onTap;
  final bool filled;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: filled ? const Color(0xFF2FD16A) : Colors.white,
      borderRadius: BorderRadius.circular(18),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(18),
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 18),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(18),
            border: Border.all(
              color: filled ? const Color(0xFF2FD16A) : const Color(0xFF0C8C67),
              width: 2,
            ),
          ),
          child: Column(
            children: [
              Icon(icon, color: filled ? Colors.white : const Color(0xFF0C8C67), size: 30),
              const SizedBox(height: 8),
              Text(
                label,
                style: TextStyle(
                  color: filled ? Colors.white : const Color(0xFF0C8C67),
                  fontSize: 16,
                  fontWeight: FontWeight.w900,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _SalesSearchInlinePanel extends StatelessWidget {
  const _SalesSearchInlinePanel({
    required this.controller,
    required this.onChanged,
    required this.onClear,
  });

  final TextEditingController controller;
  final ValueChanged<String> onChanged;
  final VoidCallback onClear;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: const Color(0xFFD9E6E2)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'বিক্রয় খোঁজ',
            style: TextStyle(
              color: Color(0xFF141F22),
              fontSize: 16,
              fontWeight: FontWeight.w900,
            ),
          ),
          const SizedBox(height: 10),
          Container(
            height: 54,
            padding: const EdgeInsets.symmetric(horizontal: 14),
            decoration: BoxDecoration(
              color: const Color(0xFFF6FAF8),
              borderRadius: BorderRadius.circular(16),
              border: Border.all(color: const Color(0xFFD9E6E2)),
            ),
            child: Row(
              children: [
                const Icon(Icons.search, color: Color(0xFF3D4943)),
                const SizedBox(width: 10),
                Expanded(
                  child: TextField(
                    controller: controller,
                    onChanged: onChanged,
                    style: const TextStyle(color: Colors.black),
                    cursorColor: const Color(0xFF00694C),
                    decoration: const InputDecoration(
                      border: InputBorder.none,
                      hintText: 'নাম, নম্বর, রেফারেন্স লিখুন',
                      hintStyle: TextStyle(color: Color(0xFF6F7D78)),
                    ),
                  ),
                ),
                Material(
                  color: const Color(0xFFEAF2F0),
                  borderRadius: BorderRadius.circular(12),
                  child: InkWell(
                    onTap: onClear,
                    borderRadius: BorderRadius.circular(12),
                    child: const Padding(
                      padding: EdgeInsets.all(10),
                      child: Icon(Icons.close, color: Color(0xFF00694C), size: 18),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _ActiveFilterSummary extends StatelessWidget {
  const _ActiveFilterSummary({
    required this.searchText,
    required this.timeLabel,
    required this.statusLabel,
    required this.amountLabel,
    required this.onClearAll,
  });

  final String searchText;
  final String timeLabel;
  final String statusLabel;
  final String amountLabel;
  final VoidCallback onClearAll;

  @override
  Widget build(BuildContext context) {
    final chips = <Widget>[];
    if (searchText.isNotEmpty) {
      chips.add(_SummaryChip(label: 'খোঁজ: $searchText'));
    }
    if (timeLabel != 'আজ') {
      chips.add(_SummaryChip(label: 'সময়: $timeLabel'));
    }
    if (statusLabel != 'সব অবস্থা') {
      chips.add(_SummaryChip(label: 'অবস্থা: $statusLabel'));
    }
    if (amountLabel != 'সব পরিমাণ') {
      chips.add(_SummaryChip(label: 'পরিমাণ: $amountLabel'));
    }

    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: const Color(0xFFD9E6E2)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const Text(
                'সক্রিয় ফিল্টার',
                style: TextStyle(
                  color: Color(0xFF141F22),
                  fontSize: 15,
                  fontWeight: FontWeight.w900,
                ),
              ),
              const Spacer(),
              TextButton(
                onPressed: onClearAll,
                child: const Text(
                  'সব মুছুন',
                  style: TextStyle(
                    color: Color(0xFFB3261E),
                    fontWeight: FontWeight.w800,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 8),
          Wrap(
            spacing: 10,
            runSpacing: 10,
            children: chips.isEmpty
                ? const [
                    _SummaryChip(label: 'কোনো ফিল্টার সক্রিয় নয়'),
                  ]
                : chips,
          ),
        ],
      ),
    );
  }
}

class _SummaryChip extends StatelessWidget {
  const _SummaryChip({required this.label});

  final String label;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      decoration: BoxDecoration(
        color: const Color(0xFFEAF2F0),
        borderRadius: BorderRadius.circular(999),
        border: Border.all(color: const Color(0xFFD9E6E2)),
      ),
      child: Text(
        label,
        style: const TextStyle(
          color: Color(0xFF00694C),
          fontSize: 12,
          fontWeight: FontWeight.w800,
        ),
      ),
    );
  }
}

class _SalesFilterInlinePanel extends StatelessWidget {
  const _SalesFilterInlinePanel({
    required this.selectedStatusIndex,
    required this.selectedAmountIndex,
    required this.statusFilters,
    required this.amountFilters,
    required this.onStatusTap,
    required this.onAmountTap,
    required this.onReset,
  });

  final int selectedStatusIndex;
  final int selectedAmountIndex;
  final List<String> statusFilters;
  final List<String> amountFilters;
  final ValueChanged<int> onStatusTap;
  final ValueChanged<int> onAmountTap;
  final VoidCallback onReset;

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (context, constraints) {
        final narrow = constraints.maxWidth < 360;
        return Container(
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: const Color(0xFFD9E6E2)),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisSize: MainAxisSize.min,
            children: [
              Row(
                children: [
                  const Expanded(
                    child: Text(
                      'ফিল্টার',
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(
                        color: Color(0xFF141F22),
                        fontSize: 16,
                        fontWeight: FontWeight.w900,
                      ),
                    ),
                  ),
                  TextButton(
                    onPressed: onReset,
                    style: TextButton.styleFrom(
                      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
                      minimumSize: const Size(0, 0),
                      tapTargetSize: MaterialTapTargetSize.shrinkWrap,
                    ),
                    child: const Text(
                      'রিসেট',
                      style: TextStyle(
                        color: Color(0xFFB3261E),
                        fontWeight: FontWeight.w800,
                      ),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 8),
              const Text(
                'পরিশোধ অবস্থা',
                style: TextStyle(
                  color: Color(0xFF3D4943),
                  fontSize: 13,
                  fontWeight: FontWeight.w800,
                ),
              ),
              const SizedBox(height: 10),
              if (narrow)
                Column(
                  children: List.generate(statusFilters.length, (index) {
                    return Padding(
                      padding: EdgeInsets.only(
                        bottom: index == statusFilters.length - 1 ? 0 : 10,
                      ),
                      child: _FilterListTile(
                        title: statusFilters[index],
                        selected: selectedStatusIndex == index,
                        onTap: () => onStatusTap(index),
                      ),
                    );
                  }),
                )
              else
                Wrap(
                  spacing: 10,
                  runSpacing: 10,
                  children: List.generate(statusFilters.length, (index) {
                    return _FilterChoiceChip(
                      label: statusFilters[index],
                      selected: selectedStatusIndex == index,
                      onTap: () => onStatusTap(index),
                    );
                  }),
                ),
              const SizedBox(height: 14),
              const Text(
                'পরিমাণ সীমা',
                style: TextStyle(
                  color: Color(0xFF3D4943),
                  fontSize: 13,
                  fontWeight: FontWeight.w800,
                ),
              ),
              const SizedBox(height: 10),
              Column(
                children: List.generate(amountFilters.length, (index) {
                  return Padding(
                    padding: EdgeInsets.only(
                      bottom: index == amountFilters.length - 1 ? 0 : 10,
                    ),
                    child: _FilterListTile(
                      title: amountFilters[index],
                      selected: selectedAmountIndex == index,
                      onTap: () => onAmountTap(index),
                    ),
                  );
                }),
              ),
            ],
          ),
        );
      },
    );
  }
}

class _SalesSearchScreen extends ConsumerStatefulWidget {
  const _SalesSearchScreen();

  @override
  ConsumerState<_SalesSearchScreen> createState() => _SalesSearchScreenState();
}

class _SalesSearchScreenState extends ConsumerState<_SalesSearchScreen> {
  final TextEditingController _searchController = TextEditingController();
  int _selectedMode = 0;

  static const List<String> _modes = <String>[
    'সব',
    'নগদ',
    'বাকি',
    'আংশিক',
    'আজ',
  ];

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  bool _isToday(DateTime dateTime) {
    final now = DateTime.now();
    return dateTime.year == now.year &&
        dateTime.month == now.month &&
        dateTime.day == now.day;
  }

  String _formatBanglaTime(DateTime dateTime) {
    final hour = dateTime.hour % 12 == 0 ? 12 : dateTime.hour % 12;
    final minute = dateTime.minute.toString().padLeft(2, '0');
    final period = dateTime.hour >= 12 ? 'দুপুর' : 'সকাল';
    return '$period ${_banglaDigits(hour.toString())}:${_banglaDigits(minute)}';
  }

  Color _statusBackground(DokanPosOrderStatus status) {
    return switch (status) {
      DokanPosOrderStatus.paid => const Color(0xFFE1F5E7),
      DokanPosOrderStatus.due => const Color(0xFFFDE7E7),
      DokanPosOrderStatus.partiallyPaid => const Color(0xFFFDE7F2),
      DokanPosOrderStatus.cancelled => const Color(0xFFFDE7E7),
    };
  }

  Color _statusTextColor(DokanPosOrderStatus status) {
    return switch (status) {
      DokanPosOrderStatus.paid => const Color(0xFF0C8C67),
      DokanPosOrderStatus.due => const Color(0xFFD43B3B),
      DokanPosOrderStatus.partiallyPaid => const Color(0xFFC2185B),
      DokanPosOrderStatus.cancelled => const Color(0xFFD43B3B),
    };
  }

  String _statusLabel(DokanPosOrderStatus status) {
    return switch (status) {
      DokanPosOrderStatus.paid => 'সম্পূর্ণ পরিশোধ',
      DokanPosOrderStatus.due => 'বাকি আছে',
      DokanPosOrderStatus.partiallyPaid => 'আংশিক পরিশোধ',
      DokanPosOrderStatus.cancelled => 'বাতিল',
    };
  }

  @override
  Widget build(BuildContext context) {
    final orders = ref.watch(dokanPosProvider.select((state) => state.orders));
    final query = _searchController.text.trim().toLowerCase();

    final filteredOrders = orders.where((order) {
      final matchesMode = switch (_selectedMode) {
        0 => true,
        1 => order.paymentMethod == DokanPosPaymentMethod.cash,
        2 => order.status == DokanPosOrderStatus.due,
        3 => order.status == DokanPosOrderStatus.partiallyPaid,
        4 => _isToday(order.createdAt),
        _ => true,
      };

      final matchesQuery = query.isEmpty ||
          order.customerName.toLowerCase().contains(query) ||
          order.customerNumber.toLowerCase().contains(query) ||
          order.summary.toLowerCase().contains(query) ||
          order.id.toLowerCase().contains(query) ||
          dokanPosPaymentMethodLabel(order.paymentMethod).toLowerCase().contains(query);

      return matchesMode && matchesQuery;
    }).toList(growable: false)
      ..sort((a, b) => b.createdAt.compareTo(a.createdAt));

    return Scaffold(
      backgroundColor: const Color(0xFFF3F8F7),
      resizeToAvoidBottomInset: true,
      body: SafeArea(
        child: ListView(
          padding: EdgeInsets.fromLTRB(
            0,
            0,
            0,
            MediaQuery.of(context).viewInsets.bottom + 96,
          ),
          keyboardDismissBehavior: ScrollViewKeyboardDismissBehavior.onDrag,
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 12, 16, 0),
              child: Row(
                children: [
                  _HistoryIconButton(
                    icon: Icons.arrow_back,
                    onTap: () => Navigator.of(context).pop(),
                  ),
                  const SizedBox(width: 12),
                  const Expanded(
                    child: Text(
                      'বিক্রয় খোঁজ',
                      style: TextStyle(
                        color: Color(0xFF00694C),
                        fontSize: 24,
                        fontWeight: FontWeight.w900,
                      ),
                    ),
                  ),
                  _HistoryIconButton(
                    icon: Icons.tune,
                    onTap: () => Navigator.of(context).push(
                      MaterialPageRoute(
                        builder: (_) => const _SalesFilterScreen(),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 14),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  gradient: const LinearGradient(
                    colors: [Color(0xFF1D9E75), Color(0xFF00694C)],
                    begin: Alignment.centerLeft,
                    end: Alignment.centerRight,
                  ),
                  borderRadius: BorderRadius.circular(20),
                ),
                child: const Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'দ্রুত বিক্রয় খুঁজুন',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 18,
                        fontWeight: FontWeight.w900,
                      ),
                    ),
                    SizedBox(height: 6),
                    Text(
                      'নাম, রেফারেন্স, সময়, বা পরিশোধ অবস্থা দিয়ে খোঁজ করুন।',
                      style: TextStyle(
                        color: Colors.white70,
                        fontSize: 13,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 14),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: Container(
                height: 58,
                padding: const EdgeInsets.symmetric(horizontal: 16),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(18),
                  border: Border.all(color: const Color(0xFFD9E6E2)),
                ),
                child: TextField(
                  controller: _searchController,
                  style: const TextStyle(color: Colors.black),
                  cursorColor: const Color(0xFF00694C),
                  onChanged: (_) => setState(() {}),
                  decoration: const InputDecoration(
                    border: InputBorder.none,
                    icon: Icon(Icons.search, color: Color(0xFF3D4943)),
                    hintText: 'নাম, রেফারেন্স, বা পণ্য লিখুন',
                    hintStyle: TextStyle(color: Color(0xFF6F7D78)),
                  ),
                ),
              ),
            ),
            const SizedBox(height: 14),
            SizedBox(
              height: 46,
              child: ListView.separated(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                scrollDirection: Axis.horizontal,
                itemCount: _modes.length,
                separatorBuilder: (context, index) => const SizedBox(width: 10),
                itemBuilder: (context, index) {
                  final selected = _selectedMode == index;
                  return _FilterChipButton(
                    label: _modes[index],
                    selected: selected,
                    onTap: () {
                      setState(() {
                        _selectedMode = index;
                      });
                    },
                  );
                },
              ),
            ),
            const SizedBox(height: 14),
            ...filteredOrders.map((order) {
              final timeText = _formatBanglaTime(order.createdAt);
              return Padding(
                padding: const EdgeInsets.fromLTRB(16, 0, 16, 12),
                child: Material(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(18),
                  child: InkWell(
                    onTap: () => Navigator.of(context).push(
                      MaterialPageRoute(
                        builder: (_) => const _SalesHistoryDummyScreen(),
                      ),
                    ),
                    borderRadius: BorderRadius.circular(18),
                    child: Container(
                      padding: const EdgeInsets.all(16),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(18),
                        border: Border.all(color: const Color(0xFFD9E6E2)),
                      ),
                      child: Row(
                        children: [
                          Container(
                            width: 54,
                            height: 54,
                            decoration: const BoxDecoration(
                              color: Color(0xFFEAF2F0),
                              shape: BoxShape.circle,
                            ),
                            child: const Icon(
                              Icons.receipt_long_outlined,
                              color: Color(0xFF0C8C67),
                            ),
                          ),
                          const SizedBox(width: 14),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  order.customerName,
                                  style: const TextStyle(
                                    color: Color(0xFF141F22),
                                    fontSize: 18,
                                    fontWeight: FontWeight.w900,
                                  ),
                                ),
                                const SizedBox(height: 6),
                                Text(
                                  order.summary,
                                  style: const TextStyle(
                                    color: Color(0xFF3D4943),
                                    fontSize: 14,
                                    fontWeight: FontWeight.w600,
                                  ),
                                ),
                                const SizedBox(height: 6),
                                Text(
                                  '${order.customerNumber} • $timeText • ${dokanPosPaymentMethodLabel(order.paymentMethod)}',
                                  style: const TextStyle(
                                    color: Color(0xFF6F7D78),
                                    fontSize: 12,
                                    fontWeight: FontWeight.w600,
                                  ),
                                ),
                              ],
                            ),
                          ),
                          const SizedBox(width: 10),
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.end,
                            children: [
                              Text(
                                _formatCurrency(order.totalAmount),
                                style: const TextStyle(
                                  color: Color(0xFF141F22),
                                  fontSize: 20,
                                  fontWeight: FontWeight.w900,
                                ),
                              ),
                              const SizedBox(height: 10),
                              Container(
                                padding: const EdgeInsets.symmetric(
                                  horizontal: 10,
                                  vertical: 6,
                                ),
                                decoration: BoxDecoration(
                                  color: _statusBackground(order.status),
                                  borderRadius: BorderRadius.circular(10),
                                ),
                                child: Text(
                                  _statusLabel(order.status),
                                  style: TextStyle(
                                    color: _statusTextColor(order.status),
                                    fontSize: 12,
                                    fontWeight: FontWeight.w800,
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              );
            }),
            if (filteredOrders.isEmpty)
              const Padding(
                padding: EdgeInsets.fromLTRB(16, 10, 16, 0),
                child: _SalesEmptyState(),
              ),
          ],
        ),
      ),
    );
  }
}

class _HistoryFilterSelection {
  const _HistoryFilterSelection({
    required this.timeIndex,
    required this.statusIndex,
    required this.rangeIndex,
  });

  final int timeIndex;
  final int statusIndex;
  final int rangeIndex;
}

class _SalesFilterScreen extends StatefulWidget {
  const _SalesFilterScreen();

  @override
  State<_SalesFilterScreen> createState() => _SalesFilterScreenState();
}

class _SalesFilterScreenState extends State<_SalesFilterScreen> {
  int _selectedTime = 0;
  int _selectedStatus = 0;
  int _selectedRange = 0;

  static const List<String> _times = <String>[
    'আজ',
    'গতকাল',
    'এই সপ্তাহ',
    'এই মাস',
  ];

  static const List<String> _statuses = <String>[
    'সব অবস্থা',
    'সম্পূর্ণ পরিশোধ',
    'বাকি আছে',
    'আংশিক পরিশোধ',
  ];

  static const List<String> _ranges = <String>[
    'সব পরিমাণ',
    '৳১,০০০ এর নিচে',
    '৳১,০০০ - ৳৫,০০০',
    '৳৫,০০০ এর বেশি',
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF3F8F7),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.only(bottom: 16),
          keyboardDismissBehavior: ScrollViewKeyboardDismissBehavior.onDrag,
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 12, 16, 0),
              child: Row(
                children: [
                  _HistoryIconButton(
                    icon: Icons.arrow_back,
                    onTap: () => Navigator.of(context).pop(),
                  ),
                  const SizedBox(width: 12),
                  const Expanded(
                    child: Text(
                      'ফিল্টার',
                      style: TextStyle(
                        color: Color(0xFF00694C),
                        fontSize: 24,
                        fontWeight: FontWeight.w900,
                      ),
                    ),
                  ),
                  _HistoryIconButton(
                    icon: Icons.restart_alt,
                    onTap: () {
                      setState(() {
                        _selectedTime = 0;
                        _selectedStatus = 0;
                        _selectedRange = 0;
                      });
                    },
                  ),
                ],
              ),
            ),
            const SizedBox(height: 14),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  gradient: const LinearGradient(
                    colors: [Color(0xFF1D9E75), Color(0xFF00694C)],
                    begin: Alignment.centerLeft,
                    end: Alignment.centerRight,
                  ),
                  borderRadius: BorderRadius.circular(20),
                ),
                child: const Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'বিক্রয় ফিল্টার করুন',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 18,
                        fontWeight: FontWeight.w900,
                      ),
                    ),
                    SizedBox(height: 6),
                    Text(
                      'সময়, অবস্থা, এবং পরিমাণ অনুযায়ী তালিকা সাজান।',
                      style: TextStyle(
                        color: Colors.white70,
                        fontSize: 13,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 16),
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
              child: Column(
                children: [
                  _FilterSectionCard(
                    title: 'সময় নির্বাচন',
                    child: Wrap(
                      spacing: 10,
                      runSpacing: 10,
                      children: List.generate(_times.length, (index) {
                        return _FilterChoiceChip(
                          label: _times[index],
                          selected: _selectedTime == index,
                          onTap: () {
                            setState(() {
                              _selectedTime = index;
                            });
                          },
                        );
                      }),
                    ),
                  ),
                  const SizedBox(height: 14),
                  _FilterSectionCard(
                    title: 'পরিশোধ অবস্থা',
                    child: Column(
                      children: List.generate(_statuses.length, (index) {
                        return Padding(
                          padding: EdgeInsets.only(
                            bottom: index == _statuses.length - 1 ? 0 : 10,
                          ),
                          child: _FilterListTile(
                            title: _statuses[index],
                            selected: _selectedStatus == index,
                            onTap: () {
                              setState(() {
                                _selectedStatus = index;
                              });
                            },
                          ),
                        );
                      }),
                    ),
                  ),
                  const SizedBox(height: 14),
                  _FilterSectionCard(
                    title: 'পরিমাণ সীমা',
                    child: Column(
                      children: List.generate(_ranges.length, (index) {
                        return Padding(
                          padding: EdgeInsets.only(
                            bottom: index == _ranges.length - 1 ? 0 : 10,
                          ),
                          child: _FilterListTile(
                            title: _ranges[index],
                            selected: _selectedRange == index,
                            onTap: () {
                              setState(() {
                                _selectedRange = index;
                              });
                            },
                          ),
                        );
                      }),
                    ),
                  ),
                  const SizedBox(height: 16),
                  Row(
                    children: [
                      Expanded(
                        child: _FilterActionButton(
                          label: 'রিসেট',
                          filled: false,
                          onTap: () {
                            setState(() {
                              _selectedTime = 0;
                              _selectedStatus = 0;
                              _selectedRange = 0;
                            });
                          },
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: _FilterActionButton(
                          label: 'ফলাফল দেখুন',
                          filled: true,
                          onTap: () => Navigator.of(context).pop(
                            _HistoryFilterSelection(
                              timeIndex: _selectedTime,
                              statusIndex: _selectedStatus,
                              rangeIndex: _selectedRange,
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _FilterSectionCard extends StatelessWidget {
  const _FilterSectionCard({
    required this.title,
    required this.child,
  });

  final String title;
  final Widget child;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: const Color(0xFFD9E6E2)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            title,
            style: const TextStyle(
              color: Color(0xFF141F22),
              fontSize: 16,
              fontWeight: FontWeight.w900,
            ),
          ),
          const SizedBox(height: 14),
          child,
        ],
      ),
    );
  }
}

class _FilterChoiceChip extends StatelessWidget {
  const _FilterChoiceChip({
    required this.label,
    required this.selected,
    required this.onTap,
  });

  final String label;
  final bool selected;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: selected ? const Color(0xFF00694C) : const Color(0xFFF0F5F4),
      borderRadius: BorderRadius.circular(999),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(999),
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(999),
            border: Border.all(
              color: selected ? const Color(0xFF00694C) : const Color(0xFFD9E6E2),
            ),
          ),
          child: Text(
            label,
            style: TextStyle(
              color: selected ? Colors.white : const Color(0xFF3D4943),
              fontSize: 14,
              fontWeight: FontWeight.w800,
            ),
          ),
        ),
      ),
    );
  }
}

class _FilterListTile extends StatelessWidget {
  const _FilterListTile({
    required this.title,
    required this.selected,
    required this.onTap,
  });

  final String title;
  final bool selected;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: selected ? const Color(0xFFE6F4EF) : const Color(0xFFF7FAF9),
      borderRadius: BorderRadius.circular(16),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(16),
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(16),
            border: Border.all(
              color: selected ? const Color(0xFF00694C) : const Color(0xFFD9E6E2),
            ),
          ),
          child: Row(
            children: [
              Icon(
                selected ? Icons.radio_button_checked : Icons.radio_button_off,
                color: selected ? const Color(0xFF00694C) : const Color(0xFF6F7D78),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Text(
                  title,
                  style: const TextStyle(
                    color: Color(0xFF141F22),
                    fontSize: 14,
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _FilterActionButton extends StatelessWidget {
  const _FilterActionButton({
    required this.label,
    required this.filled,
    required this.onTap,
  });

  final String label;
  final bool filled;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: filled ? const Color(0xFF00694C) : Colors.white,
      borderRadius: BorderRadius.circular(16),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(16),
        child: Container(
          height: 52,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(16),
            border: Border.all(
              color: filled ? const Color(0xFF00694C) : const Color(0xFFD9E6E2),
            ),
          ),
          child: Center(
            child: Text(
              label,
              style: TextStyle(
                color: filled ? Colors.white : const Color(0xFF00694C),
                fontSize: 15,
                fontWeight: FontWeight.w900,
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class _HistoryIconButton extends StatelessWidget {
  const _HistoryIconButton({required this.icon, required this.onTap});

  final IconData icon;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(12),
        child: SizedBox(
          width: 44,
          height: 44,
          child: Icon(icon, color: const Color(0xFF3D4943), size: 28),
        ),
      ),
    );
  }
}

class _SalesFilter {
  const _SalesFilter({required this.label});

  final String label;
}

class _SalesGroup {
  const _SalesGroup({required this.title, required this.items});

  final String title;
  final List<_SalesItem> items;
}

enum _SalesStatus { paid, due, partial }

class _SalesItem {
  const _SalesItem({
    required this.customerName,
    required this.amount,
    required this.profit,
    required this.statusLabel,
    required this.status,
    required this.timeText,
    required this.referenceId,
    this.createdAt,
  });

  final String customerName;
  final int amount;
  final int profit;
  final String statusLabel;
  final _SalesStatus status;
  final String timeText;
  final String referenceId;
  final DateTime? createdAt;
}

class _TopIconButton extends StatelessWidget {
  const _TopIconButton({required this.icon, required this.onTap});

  final IconData icon;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: const Color(0xFFF1F6F4),
      shape: const CircleBorder(),
      child: InkWell(
        customBorder: const CircleBorder(),
        onTap: onTap,
        child: SizedBox(
          width: 42,
          height: 42,
          child: Center(
            child: Icon(icon, color: Colors.black),
          ),
        ),
      ),
    );
  }
}

class _CategoryChip extends StatelessWidget {
  const _CategoryChip({
    required this.label,
    required this.selected,
    required this.onTap,
  });

  final String label;
  final bool selected;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(999),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 12),
        decoration: BoxDecoration(
        color: selected ? const Color(0xFFE1F0EC) : Colors.white,
          borderRadius: BorderRadius.circular(999),
          border: Border.all(color: const Color(0xFFD6E4E0)),
        ),
        child: Center(
          child: Text(
            label,
            style: TextStyle(
              color: Colors.black,
              fontWeight: FontWeight.w800,
            ),
          ),
        ),
      ),
    );
  }
}

class _ProductCard extends StatelessWidget {
  const _ProductCard({
    required this.product,
    required this.quantity,
    required this.onAdd,
    required this.onRemove,
  });

  final _Product product;
  final int quantity;
  final VoidCallback onAdd;
  final VoidCallback onRemove;

  @override
  Widget build(BuildContext context) {
    final selected = quantity > 0;
    return InkWell(
      onTap: onAdd,
      borderRadius: BorderRadius.circular(24),
      child: Container(
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(24),
          border: Border.all(
            color: selected ? const Color(0xFF006B53) : const Color(0xFFD6E4E0),
          ),
          boxShadow: const [
            BoxShadow(
              color: Color(0x14000000),
              blurRadius: 20,
              offset: Offset(0, 10),
            ),
          ],
        ),
        padding: const EdgeInsets.all(14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Container(
                  width: 40,
                  height: 40,
                  decoration: BoxDecoration(
                    color: const Color(0xFFF4F8F7),
                    borderRadius: BorderRadius.circular(14),
                  ),
                  child: Icon(product.icon, color: const Color(0xFF006B53)),
                ),
                if (selected)
                  Container(
                    padding:
                        const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                    decoration: BoxDecoration(
                      color: const Color(0xFFE9F2F0),
                      borderRadius: BorderRadius.circular(999),
                    ),
                    child: Text(
                      'x$quantity',
                      style: const TextStyle(
                        color: Colors.black,
                        fontWeight: FontWeight.w900,
                      ),
                    ),
                  ),
              ],
            ),
            const SizedBox(height: 12),
            Expanded(
              child: Text(
                _banglaText(product.name),
                maxLines: 4,
                overflow: TextOverflow.ellipsis,
                softWrap: true,
                style: const TextStyle(
                  color: Colors.black,
                  fontSize: 14,
                  fontWeight: FontWeight.w800,
                  height: 1.15,
                ),
              ),
            ),
            const SizedBox(height: 8),
            Text(
              '৳${product.price}',
              style: const TextStyle(
                color: Colors.black,
                fontSize: 16,
                fontWeight: FontWeight.w900,
              ),
            ),
            const SizedBox(height: 4),
            Text(
              'স্টক আছে: ${product.stock}',
              style: const TextStyle(
                color: Colors.black,
                fontSize: 12,
                fontWeight: FontWeight.w600,
              ),
            ),
            const SizedBox(height: 10),
            Row(
              children: [
                Expanded(
                  child: OutlinedButton(
                    onPressed: onAdd,
                    style: OutlinedButton.styleFrom(
                      side: const BorderSide(color: Color(0xFF006B53)),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(14),
                      ),
                      foregroundColor: Colors.black,
                    ),
                    child: const Text(
                  'যোগ',
                  style: TextStyle(color: Colors.black),
                    ),
                  ),
                ),
                const SizedBox(width: 8),
                InkWell(
                  onTap: selected ? onRemove : null,
                  borderRadius: BorderRadius.circular(14),
                  child: Container(
                    width: 40,
                    height: 40,
                    decoration: BoxDecoration(
                      color: const Color(0xFFF4F8F7),
                      borderRadius: BorderRadius.circular(14),
                    ),
                    child: const Icon(Icons.remove, color: Colors.black),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class _SummaryRow extends StatelessWidget {
  const _SummaryRow({
    required this.label,
    required this.value,
    this.labelStyle,
    this.valueStyle,
    this.valueColor,
  });

  final String label;
  final String value;
  final TextStyle? labelStyle;
  final TextStyle? valueStyle;
  final Color? valueColor;

  @override
  Widget build(BuildContext context) {
    final style = labelStyle ??
        const TextStyle(
          color: Colors.black,
          fontSize: 15,
          fontWeight: FontWeight.w700,
        );
    final valueTextStyle = valueStyle ??
        TextStyle(
          color: valueColor ?? Colors.black,
          fontSize: 16,
          fontWeight: FontWeight.w900,
        );
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(label, style: style),
        Text(value, style: valueTextStyle),
      ],
    );
  }
}

class _PaymentChip extends StatelessWidget {
  const _PaymentChip({
    required this.label,
    required this.selected,
    required this.onTap,
  });

  final String label;
  final bool selected;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(18),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 14),
        decoration: BoxDecoration(
          color: selected ? const Color(0xFFE1F0EC) : const Color(0xFFF4F7F6),
          borderRadius: BorderRadius.circular(18),
          border: Border.all(
            color: selected ? const Color(0xFF006B53) : const Color(0xFFD6E4E0),
          ),
        ),
        child: Text(
          label,
          style: const TextStyle(
            color: Colors.black,
            fontWeight: FontWeight.w800,
          ),
        ),
      ),
    );
  }
}

class _CartStepperButton extends StatelessWidget {
  const _CartStepperButton({
    required this.icon,
    required this.onTap,
  });

  final IconData icon;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(12),
      child: Container(
        width: 36,
        height: 36,
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: const Color(0xFFD6E4E0)),
        ),
        child: Icon(icon, color: Colors.black),
      ),
    );
  }
}

class _CartDock extends StatelessWidget {
  const _CartDock({
    required this.count,
    required this.total,
    required this.onTap,
  });

  final int count;
  final int total;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final isEmpty = count == 0;
    return Material(
      color: isEmpty ? const Color(0xFF0C8C67) : const Color(0xFF24333A),
      elevation: 16,
      borderRadius: BorderRadius.circular(24),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(24),
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
          child: Row(
            children: [
              Container(
                width: 46,
                height: 46,
                decoration: BoxDecoration(
                  color: const Color(0xFF0C8C67),
                  borderRadius: BorderRadius.circular(16),
                ),
                child: const Icon(Icons.shopping_bag_outlined, color: Colors.white),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      isEmpty
                          ? 'কার্ট খালি আছে। অনুগ্রহ করে পণ্য যোগ করুন।'
                          : 'কার্টে $count পণ্য আছে',
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      softWrap: true,
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 18,
                        fontWeight: FontWeight.w900,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      '৳$total',
                      style: const TextStyle(
                        color: Colors.white70,
                        fontSize: 14,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 12),
              ElevatedButton(
                onPressed: onTap,
                style: ElevatedButton.styleFrom(
                  backgroundColor: isEmpty
                      ? const Color(0xFFFFFFFF).withValues(alpha: 0.14)
                      : const Color(0xFF0C8C67),
                  foregroundColor: Colors.white,
                  elevation: 0,
                  padding:
                      const EdgeInsets.symmetric(horizontal: 18, vertical: 14),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(16),
                  ),
                ),
                child: const Text(
                  'কার্ট দেখুন →',
                  style: TextStyle(fontWeight: FontWeight.w800),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _BottomNavButton extends StatelessWidget {
  const _BottomNavButton({
    required this.icon,
    required this.label,
    required this.onTap,
    this.selected = false,
  });

  final IconData icon;
  final String label;
  final VoidCallback onTap;
  final bool selected;

  @override
  Widget build(BuildContext context) {
    final color = selected ? const Color(0xFF006B53) : Colors.black87;
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(16),
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 4),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(icon, color: color),
            const SizedBox(height: 2),
            Text(
              label,
              style: TextStyle(
                color: color,
                fontWeight: selected ? FontWeight.w800 : FontWeight.w700,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _OrderRegisterTile extends StatelessWidget {
  const _OrderRegisterTile({
    required this.record,
    required this.accent,
    this.showDueAmount = false,
  });

  final DokanPosOrderRecord record;
  final Color accent;
  final bool showDueAmount;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: Container(
        decoration: BoxDecoration(
          color: const Color(0xFFF5F8F7),
          borderRadius: BorderRadius.circular(18),
          border: Border.all(color: accent.withValues(alpha: 0.25)),
        ),
        padding: const EdgeInsets.all(12),
        child: Row(
          children: [
            Container(
              width: 38,
              height: 38,
              decoration: BoxDecoration(
                color: accent.withValues(alpha: 0.12),
                shape: BoxShape.circle,
              ),
              child: Icon(
                record.status == DokanPosOrderStatus.paid
                    ? Icons.check
                    : record.status == DokanPosOrderStatus.partiallyPaid
                        ? Icons.timelapse_outlined
                        : Icons.error_outline,
                color: accent,
                size: 20,
              ),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    record.customerName,
                    style: const TextStyle(
                      color: Colors.black,
                      fontWeight: FontWeight.w800,
                    ),
                  ),
                  const SizedBox(height: 2),
                  Text(
                    record.customerNumber.isEmpty
                        ? record.summary
                        : '${record.customerNumber}  •  ${dokanPosPaymentMethodLabel(record.paymentMethod)}',
                    style: const TextStyle(color: Colors.black87),
                  ),
                  const SizedBox(height: 2),
                  Text(
                    _orderStatusLabel(record.status),
                    style: TextStyle(
                      color: accent,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                ],
              ),
            ),
            Column(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                Text(
                  '৳${record.totalAmount}',
                  style: const TextStyle(
                    color: Colors.black,
                    fontWeight: FontWeight.w900,
                  ),
                ),
                if (showDueAmount)
                  Text(
                    'বাকি ৳${record.dueAmount}',
                    style: TextStyle(
                      color: accent,
                      fontWeight: FontWeight.w800,
                    ),
                  ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  String _orderStatusLabel(DokanPosOrderStatus status) {
    switch (status) {
      case DokanPosOrderStatus.paid:
        return 'পরিশোধিত';
      case DokanPosOrderStatus.due:
        return 'বাকি রয়েছে';
      case DokanPosOrderStatus.partiallyPaid:
        return 'আংশিক পরিশোধিত';
      case DokanPosOrderStatus.cancelled:
        return 'বাতিল';
    }
  }
}

Future<int?> _showDueAmountSheet(
  BuildContext context, {
  required String title,
  required String hint,
  required int maxAmount,
  required String confirmLabel,
  String warningText = 'বেশি টাকা দেওয়া যাবে না',
}) async {
  final controller = TextEditingController();
  return showModalBottomSheet<int>(
    context: context,
    isScrollControlled: true,
    useSafeArea: true,
    backgroundColor: Colors.transparent,
    builder: (sheetContext) {
      String? errorText;
      return StatefulBuilder(
        builder: (context, setSheetState) {
          return DraggableScrollableSheet(
            expand: false,
            minChildSize: 0.34,
            initialChildSize: 0.58,
            maxChildSize: 0.95,
            builder: (context, scrollController) {
              return AnimatedPadding(
                duration: const Duration(milliseconds: 180),
                curve: Curves.easeOut,
                padding: EdgeInsets.only(bottom: MediaQuery.of(sheetContext).viewInsets.bottom + 16),
                child: Container(
                  width: double.infinity,
                  decoration: const BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.vertical(top: Radius.circular(28)),
                  ),
                  child: SingleChildScrollView(
                    controller: scrollController,
                    keyboardDismissBehavior: ScrollViewKeyboardDismissBehavior.onDrag,
                    physics: const ClampingScrollPhysics(),
                    child: Padding(
                      padding: const EdgeInsets.fromLTRB(16, 12, 16, 16),
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Center(
                            child: Container(
                              width: 44,
                              height: 4,
                              decoration: BoxDecoration(
                                color: const Color(0xFFD6E4E0),
                                borderRadius: BorderRadius.circular(999),
                              ),
                            ),
                          ),
                          const SizedBox(height: 14),
                          Text(
                            title,
                            style: const TextStyle(
                              color: Colors.black,
                              fontSize: 18,
                              fontWeight: FontWeight.w900,
                            ),
                          ),
                          const SizedBox(height: 12),
                          TextField(
                            controller: controller,
                            keyboardType: TextInputType.number,
                            style: const TextStyle(color: Colors.black),
                            decoration: InputDecoration(
                              hintText: hint,
                              filled: true,
                              fillColor: const Color(0xFFF7FAF9),
                              border: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(18),
                                borderSide: const BorderSide(color: Color(0xFFD6E4E0)),
                              ),
                              enabledBorder: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(18),
                                borderSide: const BorderSide(color: Color(0xFFD6E4E0)),
                              ),
                              focusedBorder: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(18),
                                borderSide: const BorderSide(color: Color(0xFF0C8C67), width: 1.4),
                              ),
                            ),
                          ),
                          if (errorText != null) ...[
                            const SizedBox(height: 10),
                            Container(
                              width: double.infinity,
                              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
                              decoration: BoxDecoration(
                                color: const Color(0xFFFFF3F3),
                                borderRadius: BorderRadius.circular(14),
                                border: Border.all(color: const Color(0xFFB3261E)),
                              ),
                              child: Text(
                                errorText!,
                                style: const TextStyle(
                                  color: Color(0xFFB3261E),
                                  fontWeight: FontWeight.w800,
                                ),
                              ),
                            ),
                          ],
                          const SizedBox(height: 16),
                          Row(
                            children: [
                              Expanded(
                                child: OutlinedButton(
                                  onPressed: () => Navigator.of(sheetContext).pop(),
                                  style: OutlinedButton.styleFrom(
                                    foregroundColor: Colors.black87,
                                    side: const BorderSide(color: Color(0xFFD6E4E0)),
                                    padding: const EdgeInsets.symmetric(vertical: 14),
                                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                                  ),
                                  child: const Text('বাতিল', style: TextStyle(fontWeight: FontWeight.w800)),
                                ),
                              ),
                              const SizedBox(width: 10),
                              Expanded(
                                child: ElevatedButton(
                                  onPressed: () {
                                    final amount = int.tryParse(controller.text.trim()) ?? 0;
                                    if (amount <= 0) {
                                      setSheetState(() => errorText = 'পরিমাণ ০ এর বেশি হতে হবে');
                                      return;
                                    }
                                    if (amount > maxAmount) {
                                      setSheetState(() => errorText = warningText);
                                      return;
                                    }
                                    Navigator.of(sheetContext).pop(amount);
                                  },
                                  style: ElevatedButton.styleFrom(
                                    backgroundColor: const Color(0xFF0C8C67),
                                    foregroundColor: Colors.white,
                                    padding: const EdgeInsets.symmetric(vertical: 14),
                                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                                  ),
                                  child: Text(confirmLabel, style: const TextStyle(fontWeight: FontWeight.w800)),
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              );
            },
          );
        },
      );
    },
  );
}

Future<Map<String, String>?> _showNewDueRecordSheet(BuildContext context) async {
  final nameController = TextEditingController();
  final numberController = TextEditingController();
  final amountController = TextEditingController();

  return showModalBottomSheet<Map<String, String>>(
    context: context,
    isScrollControlled: true,
    useSafeArea: true,
    backgroundColor: Colors.transparent,
    builder: (sheetContext) {
      String? nameError;
      String? numberError;
      String? amountError;
      return StatefulBuilder(
        builder: (context, setSheetState) {
          return DraggableScrollableSheet(
            expand: false,
            minChildSize: 0.34,
            initialChildSize: 0.68,
            maxChildSize: 0.96,
            builder: (context, scrollController) {
              return AnimatedPadding(
                duration: const Duration(milliseconds: 180),
                curve: Curves.easeOut,
                padding: EdgeInsets.only(bottom: MediaQuery.of(sheetContext).viewInsets.bottom + 16),
                child: Container(
                  width: double.infinity,
                  decoration: const BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.vertical(top: Radius.circular(28)),
                  ),
                  child: SingleChildScrollView(
                    controller: scrollController,
                    keyboardDismissBehavior: ScrollViewKeyboardDismissBehavior.onDrag,
                    physics: const ClampingScrollPhysics(),
                    child: Padding(
                      padding: const EdgeInsets.fromLTRB(16, 12, 16, 16),
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Center(
                            child: Container(
                              width: 44,
                              height: 4,
                              decoration: BoxDecoration(
                                color: const Color(0xFFD6E4E0),
                                borderRadius: BorderRadius.circular(999),
                              ),
                            ),
                          ),
                          const SizedBox(height: 14),
                          const Text(
                            'নতুন বাকি যোগ করুন',
                            style: TextStyle(
                              color: Colors.black,
                              fontSize: 18,
                              fontWeight: FontWeight.w900,
                            ),
                          ),
                          const SizedBox(height: 12),
                          TextField(
                            controller: nameController,
                            style: const TextStyle(color: Colors.black),
                            decoration: InputDecoration(
                              labelText: 'নাম',
                              errorText: nameError,
                              filled: true,
                              fillColor: nameError != null ? const Color(0xFFFFF3F3) : const Color(0xFFF7FAF9),
                              border: OutlineInputBorder(borderRadius: BorderRadius.circular(18)),
                            ),
                          ),
                          const SizedBox(height: 10),
                          TextField(
                            controller: numberController,
                            keyboardType: TextInputType.phone,
                            style: const TextStyle(color: Colors.black),
                            decoration: InputDecoration(
                              labelText: 'নম্বর',
                              errorText: numberError,
                              filled: true,
                              fillColor: numberError != null ? const Color(0xFFFFF3F3) : const Color(0xFFF7FAF9),
                              border: OutlineInputBorder(borderRadius: BorderRadius.circular(18)),
                            ),
                          ),
                          const SizedBox(height: 10),
                          TextField(
                            controller: amountController,
                            keyboardType: TextInputType.number,
                            style: const TextStyle(color: Colors.black),
                            decoration: InputDecoration(
                              labelText: 'বাকি টাকার পরিমাণ',
                              errorText: amountError,
                              filled: true,
                              fillColor: amountError != null ? const Color(0xFFFFF3F3) : const Color(0xFFF7FAF9),
                              border: OutlineInputBorder(borderRadius: BorderRadius.circular(18)),
                            ),
                          ),
                          const SizedBox(height: 16),
                          Row(
                            children: [
                              Expanded(
                                child: OutlinedButton(
                                  onPressed: () => Navigator.of(sheetContext).pop(),
                                  style: OutlinedButton.styleFrom(
                                    foregroundColor: Colors.black87,
                                    side: const BorderSide(color: Color(0xFFD6E4E0)),
                                    padding: const EdgeInsets.symmetric(vertical: 14),
                                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                                  ),
                                  child: const Text('বাতিল', style: TextStyle(fontWeight: FontWeight.w800)),
                                ),
                              ),
                              const SizedBox(width: 10),
                              Expanded(
                                child: ElevatedButton(
                                  onPressed: () {
                                    final name = nameController.text.trim();
                                    final number = numberController.text.trim();
                                    final amount = int.tryParse(amountController.text.trim()) ?? 0;
                                    final nextNameError = name.isEmpty
                                        ? 'নাম লিখুন'
                                        : RegExp(r'^[0-9]+$').hasMatch(name)
                                            ? 'নামে সংখ্যা ব্যবহার করা যাবে না'
                                            : null;
                                    final nextNumberError = RegExp(r'^[0-9]{11}$').hasMatch(number)
                                        ? null
                                        : '১১ সংখ্যার সঠিক নম্বর লিখুন';
                                    final nextAmountError = amount > 0 ? null : 'বাকি টাকার পরিমাণ সঠিক নয়';

                                    if (nextNameError != null || nextNumberError != null || nextAmountError != null) {
                                      setSheetState(() {
                                        nameError = nextNameError;
                                        numberError = nextNumberError;
                                        amountError = nextAmountError;
                                      });
                                      return;
                                    }

                                    Navigator.of(sheetContext).pop(<String, String>{
                                      'name': name,
                                      'number': number,
                                      'amount': amount.toString(),
                                    });
                                  },
                                  style: ElevatedButton.styleFrom(
                                    backgroundColor: const Color(0xFF0C8C67),
                                    foregroundColor: Colors.white,
                                    padding: const EdgeInsets.symmetric(vertical: 14),
                                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                                  ),
                                  child: const Text('সংরক্ষণ', style: TextStyle(fontWeight: FontWeight.w800)),
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              );
            },
          );
        },
      );
    },
  );
}

String _dueDateLabel(DateTime date) {
  const months = <String>[
    'জানুয়ারি',
    'ফেব্রুয়ারি',
    'মার্চ',
    'এপ্রিল',
    'মে',
    'জুন',
    'জুলাই',
    'আগস্ট',
    'সেপ্টেম্বর',
    'অক্টোবর',
    'নভেম্বর',
    'ডিসেম্বর',
  ];
  return '${_banglaDigits(date.day.toString())} ${months[date.month - 1]} ${_banglaDigits(date.year.toString())}';
}

class _DueCustomerSummary {
  const _DueCustomerSummary({
    required this.customerName,
    required this.customerNumber,
    required this.totalDue,
    required this.orders,
    required this.lastPaymentAt,
  });

  final String customerName;
  final String customerNumber;
  final int totalDue;
  final List<DokanPosOrderRecord> orders;
  final DateTime? lastPaymentAt;
}

List<_DueCustomerSummary> _buildDueCustomers(DokanPosState state) {
  final grouped = <String, List<DokanPosOrderRecord>>{};
  for (final order in state.dueOrders) {
    final key = order.customerNumber.trim().isEmpty ? order.customerName.trim() : order.customerNumber.trim();
    grouped.putIfAbsent(key, () => <DokanPosOrderRecord>[]).add(order);
  }

  final customers = grouped.entries.map((entry) {
    final orders = entry.value
      ..sort((a, b) => b.createdAt.compareTo(a.createdAt));
    final due = orders.fold<int>(0, (sum, item) => sum + item.dueAmount);
    return _DueCustomerSummary(
      customerName: orders.first.customerName,
      customerNumber: orders.first.customerNumber,
      totalDue: due,
      orders: List<DokanPosOrderRecord>.unmodifiable(orders),
      lastPaymentAt: orders.first.createdAt,
    );
  }).toList()
    ..sort((a, b) => b.totalDue.compareTo(a.totalDue));

  return customers;
}

class DokanDueManagementScreen extends ConsumerStatefulWidget {
  const DokanDueManagementScreen({super.key});

  @override
  ConsumerState<DokanDueManagementScreen> createState() => _DokanDueManagementScreenState();
}

class _DokanDueManagementScreenState extends ConsumerState<DokanDueManagementScreen> {
  String? _selectedCustomerNumber;

  @override
  Widget build(BuildContext context) {
    final state = ref.watch(dokanPosProvider);
    final customers = _buildDueCustomers(state);
    final activeCustomer = customers.isEmpty
        ? null
        : customers.firstWhere(
            (item) => item.customerNumber == _selectedCustomerNumber,
            orElse: () => customers.first,
          );

    return Scaffold(
      backgroundColor: const Color(0xFFF4F8F6),
      appBar: AppBar(
        backgroundColor: const Color(0xFFF7FBFA),
        elevation: 0,
        leading: IconButton(
          onPressed: () => Navigator.of(context).maybePop(),
          icon: const Icon(Icons.arrow_back_rounded, color: Colors.black),
        ),
        iconTheme: const IconThemeData(color: Colors.black),
        title: const Text(
          'বাকি আদায়',
          style: TextStyle(
            color: Color(0xFF006B53),
            fontWeight: FontWeight.w900,
          ),
        ),
      ),
      body: ListView.builder(
        padding: const EdgeInsets.fromLTRB(16, 14, 16, 120),
        itemCount: customers.isEmpty ? 1 : customers.length + 1,
        itemBuilder: (context, index) {
          if (customers.isEmpty) {
            return const _DueEmptyState();
          }
          if (index == 0) {
            return Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                gradient: const LinearGradient(
                  colors: [Color(0xFF0C8C67), Color(0xFF0A6A4F)],
                ),
                borderRadius: BorderRadius.circular(22),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'বাকি গ্রাহক',
                    style: TextStyle(color: Colors.white, fontWeight: FontWeight.w800),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    '${_banglaDigits(customers.length.toString())} জন',
                    style: const TextStyle(color: Colors.white, fontSize: 28, fontWeight: FontWeight.w900),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    'মোট বাকি ${_formatCurrency(customers.fold<int>(0, (sum, item) => sum + item.totalDue))}',
                    style: const TextStyle(color: Colors.white70, fontWeight: FontWeight.w700),
                  ),
                ],
              ),
            );
          }
          final customer = customers[index - 1];
          final selected = activeCustomer?.customerNumber == customer.customerNumber;
          return Padding(
            padding: const EdgeInsets.only(top: 12),
            child: _DueCustomerCard(
              customer: customer,
              selected: selected,
              onTap: () {
                setState(() => _selectedCustomerNumber = customer.customerNumber);
                Navigator.of(context).push(
                  MaterialPageRoute(
                    builder: (_) => DokanDueDetailScreen(customerNumber: customer.customerNumber),
                  ),
                );
              },
            ),
          );
        },
      ),
      bottomNavigationBar: SafeArea(
        top: false,
        child: AnimatedPadding(
          duration: const Duration(milliseconds: 180),
          curve: Curves.easeOut,
          padding: EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom),
          child: Container(
            padding: const EdgeInsets.fromLTRB(16, 10, 16, 12),
            decoration: const BoxDecoration(
              color: Color(0xFFF7FBFA),
              border: Border(top: BorderSide(color: Color(0xFFD6E4E0))),
            ),
            child: ElevatedButton(
              onPressed: () async {
                final result = await _showNewDueRecordSheet(context);
                if (!context.mounted || result == null) return;
                ref.read(dokanPosProvider.notifier).addCustomerDueAmount(
                      customerName: result['name'] ?? '',
                      customerNumber: result['number'] ?? '',
                      amount: int.tryParse(result['amount'] ?? '0') ?? 0,
                    );
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFF0C8C67),
                foregroundColor: Colors.white,
                padding: const EdgeInsets.symmetric(vertical: 14),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
              ),
              child: const Text('নতুন বাকি যোগ করুন', style: TextStyle(fontWeight: FontWeight.w800)),
            ),
          ),
        ),
      ),
    );
  }
}

class DokanDueDetailScreen extends ConsumerStatefulWidget {
  const DokanDueDetailScreen({super.key, required this.customerNumber});

  final String customerNumber;

  @override
  ConsumerState<DokanDueDetailScreen> createState() => _DokanDueDetailScreenState();
}

class _DokanDueDetailScreenState extends ConsumerState<DokanDueDetailScreen> {
  @override
  Widget build(BuildContext context) {
    final state = ref.watch(dokanPosProvider);
    final orders = state.orders
        .where((order) => order.customerNumber == widget.customerNumber)
        .toList(growable: false)
      ..sort((a, b) => b.createdAt.compareTo(a.createdAt));
    final totalDue = orders.fold<int>(0, (sum, order) => sum + order.dueAmount);
    final customerName = orders.isEmpty ? 'গ্রাহক' : orders.first.customerName;
    final lastPayment = orders.isEmpty ? null : orders.first.createdAt;

    return Scaffold(
      backgroundColor: const Color(0xFFF4F8F6),
      appBar: AppBar(
        backgroundColor: const Color(0xFFF7FBFA),
        elevation: 0,
        leading: IconButton(
          onPressed: () => Navigator.of(context).maybePop(),
          icon: const Icon(Icons.arrow_back_rounded, color: Colors.black),
        ),
        iconTheme: const IconThemeData(color: Colors.black),
        title: Text(
          customerName,
          style: const TextStyle(
            color: Color(0xFF006B53),
            fontWeight: FontWeight.w900,
          ),
        ),
      ),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(16, 14, 16, 120),
        children: [
          Container(
            padding: const EdgeInsets.all(18),
            decoration: BoxDecoration(
              gradient: const LinearGradient(
                colors: [Color(0xFF0C8C67), Color(0xFF0A6A4F)],
              ),
              borderRadius: BorderRadius.circular(24),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'মোট বাকি',
                  style: TextStyle(color: Colors.white, fontWeight: FontWeight.w800),
                ),
                const SizedBox(height: 8),
                Text(
                  _formatCurrency(totalDue),
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 32,
                    fontWeight: FontWeight.w900,
                  ),
                ),
                const SizedBox(height: 8),
                Text(
                  lastPayment == null ? 'কোনো ট্রানজেকশন নেই' : 'সর্বশেষ আপডেট ${_dueDateLabel(lastPayment)}',
                  style: const TextStyle(color: Colors.white70, fontWeight: FontWeight.w700),
                ),
              ],
            ),
          ),
          const SizedBox(height: 14),
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(20),
              border: Border.all(color: const Color(0xFFD6E4E0)),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'ট্রানজেকশন / বাকি ইতিহাস',
                  style: TextStyle(
                    color: Colors.black,
                    fontSize: 16,
                    fontWeight: FontWeight.w900,
                  ),
                ),
                const SizedBox(height: 12),
                if (orders.isEmpty)
                  const Padding(
                    padding: EdgeInsets.symmetric(vertical: 16),
                    child: Text(
                      'এই গ্রাহকের কোনো রেকর্ড পাওয়া যায়নি',
                      style: TextStyle(color: Colors.black87, fontWeight: FontWeight.w700),
                    ),
                  )
                else
                  ListView.builder(
                    itemCount: orders.length,
                    shrinkWrap: true,
                    physics: const NeverScrollableScrollPhysics(),
                    itemBuilder: (context, index) => _DueHistoryTile(record: orders[index]),
                  ),
              ],
            ),
          ),
        ],
      ),
      bottomNavigationBar: SafeArea(
        top: false,
        child: AnimatedPadding(
          duration: const Duration(milliseconds: 180),
          curve: Curves.easeOut,
          padding: EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom),
          child: Container(
            padding: const EdgeInsets.fromLTRB(16, 10, 16, 12),
            decoration: const BoxDecoration(
              color: Color(0xFFF7FBFA),
              border: Border(top: BorderSide(color: Color(0xFFD6E4E0))),
            ),
            child: Row(
              children: [
                Expanded(
                  child: OutlinedButton(
                    onPressed: () async {
                      final amount = await _showDueAmountSheet(
                        context,
                        title: 'বাকি আদায়',
                        hint: 'আদায়ের পরিমাণ লিখুন',
                        maxAmount: totalDue,
                        confirmLabel: 'আদায় করুন',
                      );
                      if (!context.mounted || amount == null) return;
                      ref.read(dokanPosProvider.notifier).collectDuePayment(
                            customerNumber: widget.customerNumber,
                            amount: amount,
                          );
                    },
                    style: OutlinedButton.styleFrom(
                      foregroundColor: const Color(0xFF006B53),
                      side: const BorderSide(color: Color(0xFF006B53)),
                      padding: const EdgeInsets.symmetric(vertical: 14),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                    ),
                    child: const Text('বাকি আদায়', style: TextStyle(fontWeight: FontWeight.w800)),
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: ElevatedButton(
                    onPressed: () async {
                      final amount = await _showDueAmountSheet(
                        context,
                        title: 'বাকি যোগ',
                        hint: 'নতুন বাকি পরিমাণ লিখুন',
                        maxAmount: 9999999,
                        confirmLabel: 'যোগ করুন',
                      );
                      if (!context.mounted || amount == null) return;
                      ref.read(dokanPosProvider.notifier).addCustomerDueAmount(
                            customerName: customerName,
                            customerNumber: widget.customerNumber,
                            amount: amount,
                          );
                    },
                    style: ElevatedButton.styleFrom(
                      backgroundColor: const Color(0xFF0C8C67),
                      foregroundColor: Colors.white,
                      padding: const EdgeInsets.symmetric(vertical: 14),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                    ),
                    child: const Text('বাকি যোগ', style: TextStyle(fontWeight: FontWeight.w800)),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _DueCustomerCard extends StatelessWidget {
  const _DueCustomerCard({
    required this.customer,
    required this.selected,
    required this.onTap,
  });

  final _DueCustomerSummary customer;
  final bool selected;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final borderColor = selected ? const Color(0xFF0C8C67) : const Color(0xFFD6E4E0);
    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(22),
        child: Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(22),
            border: Border.all(color: borderColor, width: selected ? 1.6 : 1.0),
            boxShadow: const [
              BoxShadow(
                color: Color(0x08000000),
                blurRadius: 12,
                offset: Offset(0, 4),
              ),
            ],
          ),
          child: Row(
            children: [
              Container(
                width: 46,
                height: 46,
                decoration: BoxDecoration(
                  color: const Color(0xFFE1F0EC),
                  borderRadius: BorderRadius.circular(16),
                ),
                child: const Icon(Icons.person_outline, color: Color(0xFF0C8C67)),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      customer.customerName,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                        color: Colors.black,
                        fontSize: 16,
                        fontWeight: FontWeight.w900,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      customer.customerNumber.isEmpty ? 'নম্বর নেই' : customer.customerNumber,
                      style: const TextStyle(color: Colors.black87, fontWeight: FontWeight.w600),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      customer.lastPaymentAt == null
                          ? 'সর্বশেষ পেমেন্ট নেই'
                          : 'শেষ পেমেন্ট ${_dueDateLabel(customer.lastPaymentAt!)}',
                      style: const TextStyle(color: Colors.black54),
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 12),
              Column(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  const _DueStatusBadge(label: 'Active Due', active: true),
                  const SizedBox(height: 10),
                  Text(
                    _formatCurrency(customer.totalDue),
                    style: const TextStyle(
                      color: Color(0xFFB3261E),
                      fontSize: 18,
                      fontWeight: FontWeight.w900,
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _DueStatusBadge extends StatelessWidget {
  const _DueStatusBadge({
    required this.label,
    required this.active,
  });

  final String label;
  final bool active;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
      decoration: BoxDecoration(
        color: active ? const Color(0xFFEAF7F0) : const Color(0xFFF4F6F5),
        borderRadius: BorderRadius.circular(999),
      ),
      child: Text(
        label,
        style: TextStyle(
          color: active ? const Color(0xFF0C8C67) : const Color(0xFF5F6A66),
          fontWeight: FontWeight.w800,
          fontSize: 12,
        ),
      ),
    );
  }
}

class _DueEmptyState extends StatelessWidget {
  const _DueEmptyState();

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(top: 32),
      child: Column(
        children: const [
          Icon(Icons.check_circle_rounded, size: 72, color: Color(0xFF0C8C67)),
          SizedBox(height: 14),
          Text(
            'কোনো বাকি গ্রাহক নেই',
            style: TextStyle(color: Colors.black, fontSize: 18, fontWeight: FontWeight.w900),
          ),
          SizedBox(height: 6),
          Text(
            'সব গ্রাহকের হিসাব আপডেট আছে',
            style: TextStyle(color: Colors.black54, fontWeight: FontWeight.w600),
          ),
        ],
      ),
    );
  }
}

class _DueHistoryTile extends StatelessWidget {
  const _DueHistoryTile({required this.record});

  final DokanPosOrderRecord record;

  @override
  Widget build(BuildContext context) {
    final accent = record.status == DokanPosOrderStatus.paid
        ? const Color(0xFF0C8C67)
        : record.status == DokanPosOrderStatus.partiallyPaid
            ? const Color(0xFFF49B1A)
            : const Color(0xFFB3261E);

    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: Container(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(18),
          border: Border.all(color: accent.withValues(alpha: 0.22)),
        ),
        child: Row(
          children: [
            Container(
              width: 42,
              height: 42,
              decoration: BoxDecoration(
                color: accent.withValues(alpha: 0.12),
                borderRadius: BorderRadius.circular(14),
              ),
              child: Icon(
                record.status == DokanPosOrderStatus.paid
                    ? Icons.check_rounded
                    : record.status == DokanPosOrderStatus.partiallyPaid
                        ? Icons.timelapse_outlined
                        : Icons.error_outline,
                color: accent,
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    record.summary,
                    style: const TextStyle(color: Colors.black, fontWeight: FontWeight.w800),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    _dueDateLabel(record.createdAt),
                    style: const TextStyle(color: Colors.black54),
                  ),
                ],
              ),
            ),
            const SizedBox(width: 10),
            Column(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                Text(
                  _formatCurrency(record.dueAmount),
                  style: TextStyle(color: accent, fontWeight: FontWeight.w900),
                ),
                const SizedBox(height: 4),
                Text(
                  record.status == DokanPosOrderStatus.paid
                      ? 'পরিশোধিত'
                      : record.status == DokanPosOrderStatus.partiallyPaid
                          ? 'আংশিক'
                          : 'বাকি',
                  style: TextStyle(color: accent, fontWeight: FontWeight.w700),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class _Category {
  const _Category({required this.label, required this.key});

  final String label;
  final String key;
}

class _Product {
  const _Product({
    required this.id,
    required this.name,
    required this.price,
    required this.stock,
    required this.categoryKey,
    required this.icon,
    required this.searchTerms,
  });

  final String id;
  final String name;
  final int price;
  final int stock;
  final String categoryKey;
  final IconData icon;
  final List<String> searchTerms;
}




