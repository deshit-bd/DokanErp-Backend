import 'dart:math' as math;

import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:dokan_erp/app/dokan_app_providers.dart';


const Map<String, int> dokanPosPriceBook = <String, int>{
  'rice-5kg': 630,
  'rice-1kg': 130,
  'lentil-1kg': 190,
  'lentil-5kg': 880,
  'soap-100g': 250,
  'detergent': 285,
  'tea-250': 100,
  'tea-500': 120,
  'oil-1l': 185,
  'oil-500': 220,
  'salt-1kg': 40,
  'sugar-1kg': 135,
  'biscuit': 80,
};

enum DokanPosPaymentMethod { cash, bkash, nagad, card, rocket, bank }

enum DokanPosOrderStatus { paid, due, partiallyPaid, cancelled }

class DokanPosDueRecord {
  const DokanPosDueRecord({
    required this.name,
    required this.number,
    required this.amount,
  });

  final String name;
  final String number;
  final int amount;
}

class DokanCustomerProfileRecord {
  const DokanCustomerProfileRecord({
    required this.key,
    required this.name,
    required this.phone,
    required this.address,
    required this.openingDue,
    required this.createdAt,
    required this.updatedAt,
  });

  final String key;
  final String name;
  final String phone;
  final String address;
  final int openingDue;
  final DateTime createdAt;
  final DateTime updatedAt;

  DokanCustomerProfileRecord copyWith({
    String? key,
    String? name,
    String? phone,
    String? address,
    int? openingDue,
    DateTime? createdAt,
    DateTime? updatedAt,
  }) {
    return DokanCustomerProfileRecord(
      key: key ?? this.key,
      name: name ?? this.name,
      phone: phone ?? this.phone,
      address: address ?? this.address,
      openingDue: openingDue ?? this.openingDue,
      createdAt: createdAt ?? this.createdAt,
      updatedAt: updatedAt ?? this.updatedAt,
    );
  }
}

String dokanSupplierRecordKey(String name, String phone) {
  final normalizedPhone = phone.trim();
  if (normalizedPhone.isNotEmpty) {
    return normalizedPhone;
  }
  return name.trim().toLowerCase();
}

enum DokanSupplierLedgerKind { purchase, payment }

class DokanSupplierProfileRecord {
  const DokanSupplierProfileRecord({
    required this.key,
    required this.name,
    required this.phone,
    required this.address,
    required this.productType,
    required this.creditLimit,
    required this.createdAt,
    required this.updatedAt,
  });

  final String key;
  final String name;
  final String phone;
  final String address;
  final String productType;
  final int creditLimit;
  final DateTime createdAt;
  final DateTime updatedAt;

  DokanSupplierProfileRecord copyWith({
    String? key,
    String? name,
    String? phone,
    String? address,
    String? productType,
    int? creditLimit,
    DateTime? createdAt,
    DateTime? updatedAt,
  }) {
    return DokanSupplierProfileRecord(
      key: key ?? this.key,
      name: name ?? this.name,
      phone: phone ?? this.phone,
      address: address ?? this.address,
      productType: productType ?? this.productType,
      creditLimit: creditLimit ?? this.creditLimit,
      createdAt: createdAt ?? this.createdAt,
      updatedAt: updatedAt ?? this.updatedAt,
    );
  }
}

class DokanSupplierLedgerRecord {
  const DokanSupplierLedgerRecord({
    required this.id,
    required this.supplierKey,
    required this.supplierName,
    required this.amount,
    required this.kind,
    required this.createdAt,
    required this.note,
    required this.paymentMethod,
  });

  final String id;
  final String supplierKey;
  final String supplierName;
  final int amount;
  final DokanSupplierLedgerKind kind;
  final DateTime createdAt;
  final String note;
  final DokanPosPaymentMethod? paymentMethod;

  DokanSupplierLedgerRecord copyWith({
    String? id,
    String? supplierKey,
    String? supplierName,
    int? amount,
    DokanSupplierLedgerKind? kind,
    DateTime? createdAt,
    String? note,
    DokanPosPaymentMethod? paymentMethod,
  }) {
    return DokanSupplierLedgerRecord(
      id: id ?? this.id,
      supplierKey: supplierKey ?? this.supplierKey,
      supplierName: supplierName ?? this.supplierName,
      amount: amount ?? this.amount,
      kind: kind ?? this.kind,
      createdAt: createdAt ?? this.createdAt,
      note: note ?? this.note,
      paymentMethod: paymentMethod ?? this.paymentMethod,
    );
  }
}

class DokanStaffProfileRecord {
  const DokanStaffProfileRecord({
    required this.key,
    required this.name,
    required this.phone,
    required this.role,
    required this.address,
    required this.note,
    required this.active,
    required this.joinedAt,
    required this.lastActiveAt,
    required this.lastLoginAt,
    required this.recentSalesCount,
    required this.permissions,
    required this.pinCode,
    required this.createdAt,
    required this.updatedAt,
  });

  final String key;
  final String name;
  final String phone;
  final String role;
  final String address;
  final String note;
  final bool active;
  final DateTime joinedAt;
  final DateTime lastActiveAt;
  final DateTime lastLoginAt;
  final int recentSalesCount;
  final List<String> permissions;
  final String? pinCode;
  final DateTime createdAt;
  final DateTime updatedAt;

  DokanStaffProfileRecord copyWith({
    String? key,
    String? name,
    String? phone,
    String? role,
    String? address,
    String? note,
    bool? active,
    DateTime? joinedAt,
    DateTime? lastActiveAt,
    DateTime? lastLoginAt,
    int? recentSalesCount,
    List<String>? permissions,
    String? pinCode,
    DateTime? createdAt,
    DateTime? updatedAt,
  }) {
    return DokanStaffProfileRecord(
      key: key ?? this.key,
      name: name ?? this.name,
      phone: phone ?? this.phone,
      role: role ?? this.role,
      address: address ?? this.address,
      note: note ?? this.note,
      active: active ?? this.active,
      joinedAt: joinedAt ?? this.joinedAt,
      lastActiveAt: lastActiveAt ?? this.lastActiveAt,
      lastLoginAt: lastLoginAt ?? this.lastLoginAt,
      recentSalesCount: recentSalesCount ?? this.recentSalesCount,
      permissions: permissions ?? this.permissions,
      pinCode: pinCode ?? this.pinCode,
      createdAt: createdAt ?? this.createdAt,
      updatedAt: updatedAt ?? this.updatedAt,
    );
  }
}

class DokanPosOrderRecord {
  const DokanPosOrderRecord({
    required this.id,
    required this.customerName,
    required this.customerNumber,
    required this.totalAmount,
    required this.paidAmount,
    required this.dueAmount,
    required this.paymentMethod,
    required this.status,
    required this.summary,
    required this.createdAt,
    this.salesmanPhone,
  });

  final String id;
  final String customerName;
  final String customerNumber;
  final int totalAmount;
  final int paidAmount;
  final int dueAmount;
  final DokanPosPaymentMethod paymentMethod;
  final DokanPosOrderStatus status;
  final String summary;
  final DateTime createdAt;
  final String? salesmanPhone;

  DokanPosOrderRecord copyWith({
    String? id,
    String? customerName,
    String? customerNumber,
    int? totalAmount,
    int? paidAmount,
    int? dueAmount,
    DokanPosPaymentMethod? paymentMethod,
    DokanPosOrderStatus? status,
    String? summary,
    DateTime? createdAt,
    String? salesmanPhone,
  }) {
    return DokanPosOrderRecord(
      id: id ?? this.id,
      customerName: customerName ?? this.customerName,
      customerNumber: customerNumber ?? this.customerNumber,
      totalAmount: totalAmount ?? this.totalAmount,
      paidAmount: paidAmount ?? this.paidAmount,
      dueAmount: dueAmount ?? this.dueAmount,
      paymentMethod: paymentMethod ?? this.paymentMethod,
      status: status ?? this.status,
      summary: summary ?? this.summary,
      createdAt: createdAt ?? this.createdAt,
      salesmanPhone: salesmanPhone ?? this.salesmanPhone,
    );
  }
}

String dokanPosPaymentMethodLabel(DokanPosPaymentMethod method) {
  switch (method) {
    case DokanPosPaymentMethod.cash:
      return 'নগদ';
    case DokanPosPaymentMethod.bkash:
      return 'বিকাশ';
    case DokanPosPaymentMethod.nagad:
      return 'নগদ';
    case DokanPosPaymentMethod.card:
      return 'কার্ড';
    case DokanPosPaymentMethod.rocket:
      return 'রকেট';
    case DokanPosPaymentMethod.bank:
      return 'ব্যাংক';
  }
}

class DokanPosState {
  const DokanPosState({
    this.cartQuantities = const <String, int>{},
    this.discount = 0,
    this.taxPercent = 0,
    this.paymentMethod = DokanPosPaymentMethod.cash,
    this.customerName = '',
    this.customerNumber = '',
    this.transactionId = '',
    this.cashReceived = 0,
    this.orders = const <DokanPosOrderRecord>[],
    this.customerProfiles = const <DokanCustomerProfileRecord>[],
    this.hiddenCustomerKeys = const <String>{},
    this.supplierProfiles = const <DokanSupplierProfileRecord>[],
    this.supplierLedger = const <DokanSupplierLedgerRecord>[],
    this.hiddenSupplierKeys = const <String>{},
    this.staffProfiles = const <DokanStaffProfileRecord>[],
    this.hiddenStaffKeys = const <String>{},
    this.paymentConfirmed = false,
    this.confirmationMessage,
  });

  final Map<String, int> cartQuantities;
  final int discount;
  final int taxPercent;
  final DokanPosPaymentMethod paymentMethod;
  final String customerName;
  final String customerNumber;
  final String transactionId;
  final int cashReceived;
  final List<DokanPosOrderRecord> orders;
  final List<DokanCustomerProfileRecord> customerProfiles;
  final Set<String> hiddenCustomerKeys;
  final List<DokanSupplierProfileRecord> supplierProfiles;
  final List<DokanSupplierLedgerRecord> supplierLedger;
  final Set<String> hiddenSupplierKeys;
  final List<DokanStaffProfileRecord> staffProfiles;
  final Set<String> hiddenStaffKeys;
  final bool paymentConfirmed;
  final String? confirmationMessage;

  DokanPosState copyWith({
    Map<String, int>? cartQuantities,
    int? discount,
    int? taxPercent,
    DokanPosPaymentMethod? paymentMethod,
    String? customerName,
    String? customerNumber,
    String? transactionId,
    int? cashReceived,
    List<DokanPosOrderRecord>? orders,
    List<DokanCustomerProfileRecord>? customerProfiles,
    Set<String>? hiddenCustomerKeys,
    List<DokanSupplierProfileRecord>? supplierProfiles,
    List<DokanSupplierLedgerRecord>? supplierLedger,
    Set<String>? hiddenSupplierKeys,
    List<DokanStaffProfileRecord>? staffProfiles,
    Set<String>? hiddenStaffKeys,
    bool? paymentConfirmed,
    String? confirmationMessage,
  }) {
    return DokanPosState(
      cartQuantities: cartQuantities ?? this.cartQuantities,
      discount: discount ?? this.discount,
      taxPercent: taxPercent ?? this.taxPercent,
      paymentMethod: paymentMethod ?? this.paymentMethod,
      customerName: customerName ?? this.customerName,
      customerNumber: customerNumber ?? this.customerNumber,
      transactionId: transactionId ?? this.transactionId,
      cashReceived: cashReceived ?? this.cashReceived,
      orders: orders ?? this.orders,
      customerProfiles: customerProfiles ?? this.customerProfiles,
      hiddenCustomerKeys: hiddenCustomerKeys ?? this.hiddenCustomerKeys,
      supplierProfiles: supplierProfiles ?? this.supplierProfiles,
      supplierLedger: supplierLedger ?? this.supplierLedger,
      hiddenSupplierKeys: hiddenSupplierKeys ?? this.hiddenSupplierKeys,
      staffProfiles: staffProfiles ?? this.staffProfiles,
      hiddenStaffKeys: hiddenStaffKeys ?? this.hiddenStaffKeys,
      paymentConfirmed: paymentConfirmed ?? this.paymentConfirmed,
      confirmationMessage: confirmationMessage ?? this.confirmationMessage,
    );
  }

  int get cartCount => cartQuantities.values.fold<int>(0, (sum, item) => sum + item);

  int get subtotal {
    var total = 0;
    for (final entry in cartQuantities.entries) {
      total += (dokanPosPriceBook[entry.key] ?? 0) * entry.value;
    }
    return total;
  }

  int get discountAmount => math.max(0, math.min(discount, subtotal));

  int get taxableAmount => math.max(0, subtotal - discountAmount);

  int get taxAmount {
    if (taxPercent <= 0) {
      return 0;
    }
    return ((taxableAmount * taxPercent) / 100).round();
  }

  int get total => taxableAmount + taxAmount;

  int get dueAmount {
    if (paymentMethod == DokanPosPaymentMethod.cash) {
      return math.max(0, total - cashReceived);
    }
    return 0;
  }

  List<DokanPosOrderRecord> get paidOrders =>
      orders.where((order) => order.status == DokanPosOrderStatus.paid).toList(growable: false);

  List<DokanPosOrderRecord> get dueOrders => orders
      .where((order) =>
          order.status == DokanPosOrderStatus.due ||
          order.status == DokanPosOrderStatus.partiallyPaid)
      .toList(growable: false);

  int get totalOutstandingDueAmount =>
      dueOrders.fold<int>(0, (sum, order) => sum + order.dueAmount);

  int get totalSupplierOutstandingDueAmount {
    final dueBySupplier = <String, int>{};
    for (final record in supplierLedger) {
      if (hiddenSupplierKeys.contains(record.supplierKey)) {
        continue;
      }
      final current = dueBySupplier[record.supplierKey] ?? 0;
      if (record.kind == DokanSupplierLedgerKind.purchase) {
        dueBySupplier[record.supplierKey] = current + record.amount;
      } else {
        dueBySupplier[record.supplierKey] = current - record.amount;
      }
    }
    return dueBySupplier.values.fold<int>(0, (sum, item) => sum + math.max(0, item));
  }
}

class DokanPosNotifier extends Notifier<DokanPosState> {
  static List<DokanPosOrderRecord> _seedOrders() {
    final now = DateTime.now();
    final todayMorning = DateTime(now.year, now.month, now.day, 9, 44);
    final yesterdayEvening = DateTime(now.year, now.month, now.day)
        .subtract(const Duration(days: 1))
        .add(const Duration(hours: 18, minutes: 20));

    return <DokanPosOrderRecord>[
      DokanPosOrderRecord(
        id: 'seed-paid-1',
        customerName: 'করিম সাহেব',
        customerNumber: '01912334455',
        totalAmount: 8421,
        paidAmount: 8421,
        dueAmount: 0,
        paymentMethod: DokanPosPaymentMethod.cash,
        status: DokanPosOrderStatus.paid,
        summary: 'নমুনা সম্পূর্ণ পরিশোধ অর্ডার',
        createdAt: todayMorning,
        salesmanPhone: '01711223344',
      ),
      DokanPosOrderRecord(
        id: 'seed-partial-1',
        customerName: 'সালমা বেগম',
        customerNumber: '01700000000',
        totalAmount: 1230,
        paidAmount: 845,
        dueAmount: 385,
        paymentMethod: DokanPosPaymentMethod.cash,
        status: DokanPosOrderStatus.partiallyPaid,
        summary: 'নমুনা আংশিক পরিশোধ অর্ডার',
        createdAt: todayMorning.subtract(const Duration(hours: 1, minutes: 5)),
        salesmanPhone: '01711223344',
      ),
      DokanPosOrderRecord(
        id: 'seed-due-1',
        customerName: 'রহিম আপা',
        customerNumber: '01800000000',
        totalAmount: 675,
        paidAmount: 0,
        dueAmount: 675,
        paymentMethod: DokanPosPaymentMethod.cash,
        status: DokanPosOrderStatus.due,
        summary: 'নমুনা বাকি অর্ডার',
        createdAt: yesterdayEvening,
      ),
    ];
  }

  static List<DokanSupplierProfileRecord> _seedSuppliers() {
    final now = DateTime.now();
    final key = dokanSupplierRecordKey('আলম ট্রেডার্স', '');
    return <DokanSupplierProfileRecord>[
      DokanSupplierProfileRecord(
        key: key,
        name: 'আলম ট্রেডার্স',
        phone: '',
        address: '',
        productType: 'চাল',
        creditLimit: 0,
        createdAt: now.subtract(const Duration(days: 1)),
        updatedAt: now.subtract(const Duration(days: 1)),
      ),
    ];
  }

  static List<DokanSupplierLedgerRecord> _seedSupplierLedger() {
    final now = DateTime.now();
    final key = dokanSupplierRecordKey('আলম ট্রেডার্স', '');
    return <DokanSupplierLedgerRecord>[
      DokanSupplierLedgerRecord(
        id: 'supplier-ledger-001',
        supplierKey: key,
        supplierName: 'আলম ট্রেডার্স',
        amount: 7800,
        kind: DokanSupplierLedgerKind.purchase,
        createdAt: now.subtract(const Duration(days: 1, hours: 3)),
        note: 'নতুন পণ্য ক্রয়',
        paymentMethod: DokanPosPaymentMethod.cash,
      ),
    ];
  }

  static List<DokanStaffProfileRecord> _seedStaffProfiles() {
    final now = DateTime.now();
    return <DokanStaffProfileRecord>[
      DokanStaffProfileRecord(
        key: 'staff-sohel',
        name: 'সোহেল রানা',
        phone: '01711223344',
        role: 'Salesman',
        address: 'ঢাকা',
        note: 'দৈনিক বিক্রয় ও কাস্টমার হ্যান্ডেল',
        active: true,
        joinedAt: now.subtract(const Duration(days: 120)),
        lastActiveAt: now.subtract(const Duration(minutes: 12)),
        lastLoginAt: now.subtract(const Duration(hours: 2)),
        recentSalesCount: 18,
        permissions: <String>[
          'sales.create',
          'sales.view',
          'customer.view',
        ],
        pinCode: '1234',
        createdAt: now.subtract(const Duration(days: 120)),
        updatedAt: now.subtract(const Duration(hours: 2)),
      ),
      DokanStaffProfileRecord(
        key: 'staff-ripon',
        name: 'রিপন হোসেন',
        phone: '01833445566',
        role: 'Cashier',
        address: 'নারায়ণগঞ্জ',
        note: 'নগদ ও টাকা জমা দেখাশোনা',
        active: true,
        joinedAt: now.subtract(const Duration(days: 90)),
        lastActiveAt: now.subtract(const Duration(minutes: 48)),
        lastLoginAt: now.subtract(const Duration(days: 1, hours: 3)),
        recentSalesCount: 9,
        permissions: <String>[
          'sales.view',
          'accounts.view',
          'reports.view',
        ],
        pinCode: '2468',
        createdAt: now.subtract(const Duration(days: 90)),
        updatedAt: now.subtract(const Duration(days: 1, hours: 3)),
      ),
      DokanStaffProfileRecord(
        key: 'staff-nadia',
        name: 'নাদিয়া সুলতানা',
        phone: '01999887766',
        role: 'Manager',
        address: 'চট্টগ্রাম',
        note: 'স্টোর অপারেশন এবং অনুমতি',
        active: false,
        joinedAt: now.subtract(const Duration(days: 210)),
        lastActiveAt: now.subtract(const Duration(days: 7)),
        lastLoginAt: now.subtract(const Duration(days: 3, hours: 5)),
        recentSalesCount: 0,
        permissions: <String>[
          'staff.manage',
          'supplier.view',
          'reports.view',
          'accounts.view',
        ],
        pinCode: '1357',
        createdAt: now.subtract(const Duration(days: 210)),
        updatedAt: now.subtract(const Duration(days: 3, hours: 5)),
      ),
    ];
  }

  @override
  DokanPosState build() => DokanPosState(
        orders: _seedOrders(),
        supplierProfiles: _seedSuppliers(),
        supplierLedger: _seedSupplierLedger(),
        staffProfiles: _seedStaffProfiles(),
      );

  void addItem(String productId, {int stockLimit = 9999}) {
    final current = state.cartQuantities[productId] ?? 0;
    if (current >= stockLimit) {
      return;
    }

    final next = Map<String, int>.from(state.cartQuantities);
    next[productId] = current + 1;
    state = state.copyWith(cartQuantities: next);
  }

  void removeItem(String productId) {
    final current = state.cartQuantities[productId] ?? 0;
    if (current <= 1) {
      final next = Map<String, int>.from(state.cartQuantities)..remove(productId);
      state = state.copyWith(cartQuantities: next);
      return;
    }

    final next = Map<String, int>.from(state.cartQuantities);
    next[productId] = current - 1;
    state = state.copyWith(cartQuantities: next);
  }

  void setDiscount(String value) {
    final parsed = int.tryParse(value.trim()) ?? 0;
    state = state.copyWith(discount: math.max(0, parsed));
  }

  void setTaxPercent(String value) {
    final parsed = int.tryParse(value.trim()) ?? 0;
    state = state.copyWith(taxPercent: math.max(0, parsed));
  }

  void setPaymentMethod(DokanPosPaymentMethod method) {
    final keepIdentityFields =
        method == DokanPosPaymentMethod.cash ||
        method == DokanPosPaymentMethod.bkash ||
        method == DokanPosPaymentMethod.nagad ||
        method == DokanPosPaymentMethod.rocket;

    state = state.copyWith(
      paymentMethod: method,
      customerName: keepIdentityFields ? state.customerName : '',
      customerNumber: keepIdentityFields ? state.customerNumber : '',
      transactionId:
          method == DokanPosPaymentMethod.cash || !keepIdentityFields
              ? ''
              : state.transactionId,
      cashReceived: method == DokanPosPaymentMethod.cash ? state.cashReceived : 0,
    );
  }

  void setCustomerName(String value) {
    state = state.copyWith(customerName: value);
  }

  void setCustomerNumber(String value) {
    state = state.copyWith(customerNumber: value);
  }

  void setTransactionId(String value) {
    state = state.copyWith(transactionId: value);
  }

  void setCashReceived(String value) {
    final trimmed = value.trim();
    final parsed = trimmed.isEmpty ? 0 : int.tryParse(trimmed) ?? -1;
    state = state.copyWith(cashReceived: math.max(0, parsed));
  }

  void addDueRecord(DokanPosDueRecord record) {
    addOrder(
      DokanPosOrderRecord(
        id: 'manual-${DateTime.now().microsecondsSinceEpoch}',
        customerName: record.name,
        customerNumber: record.number,
        totalAmount: record.amount,
        paidAmount: 0,
        dueAmount: record.amount,
        paymentMethod: DokanPosPaymentMethod.cash,
        status: DokanPosOrderStatus.due,
        summary: 'ম্যানুয়াল বাকি রেকর্ড',
        createdAt: DateTime.now(),
      ),
    );
  }

  void collectDuePayment({
    required String customerNumber,
    required int amount,
  }) {
    if (amount <= 0) {
      return;
    }

    var remaining = amount;
    final updatedOrders = state.orders.map((order) {
      if (remaining <= 0 || order.customerNumber != customerNumber || order.dueAmount <= 0) {
        return order;
      }

      final payNow = math.min(remaining, order.dueAmount);
      remaining -= payNow;
      final nextDue = order.dueAmount - payNow;
      final nextPaid = order.paidAmount + payNow;
      return order.copyWith(
        paidAmount: nextPaid,
        dueAmount: nextDue,
        status: nextDue <= 0
            ? DokanPosOrderStatus.paid
            : nextPaid > 0
                ? DokanPosOrderStatus.partiallyPaid
                : DokanPosOrderStatus.due,
        summary: nextDue <= 0
            ? '${order.summary} | বাকি আদায় সম্পন্ন'
            : '${order.summary} | আংশিক বাকি আদায়',
      );
    }).toList(growable: false);

    state = state.copyWith(orders: updatedOrders);
  }

  void addCustomerDueAmount({
    required String customerName,
    required String customerNumber,
    required int amount,
  }) {
    if (amount <= 0) {
      return;
    }
    addDueRecord(
      DokanPosDueRecord(
        name: customerName,
        number: customerNumber,
        amount: amount,
      ),
    );
  }

  void addCustomer({
    required String name,
    required String phone,
    String address = '',
    int openingDue = 0,
  }) {
    final normalizedName = name.trim();
    final normalizedPhone = phone.trim();
    final normalizedAddress = address.trim();
    final normalizedKey = normalizedPhone.isNotEmpty ? normalizedPhone : normalizedName.toLowerCase();
    final now = DateTime.now();
    final nextProfiles = state.customerProfiles.toList(growable: true);
    final index = nextProfiles.indexWhere((item) => item.key == normalizedKey);
    final existingCreatedAt = index >= 0 ? nextProfiles[index].createdAt : now;
    final nextRecord = DokanCustomerProfileRecord(
      key: normalizedKey,
      name: normalizedName,
      phone: normalizedPhone,
      address: normalizedAddress,
      openingDue: math.max(0, openingDue),
      createdAt: existingCreatedAt,
      updatedAt: now,
    );

    if (index >= 0) {
      nextProfiles[index] = nextRecord;
    } else {
      nextProfiles.insert(0, nextRecord);
    }

    final nextHiddenKeys = Set<String>.from(state.hiddenCustomerKeys)..remove(normalizedKey);
    state = state.copyWith(
      customerProfiles: List<DokanCustomerProfileRecord>.unmodifiable(nextProfiles),
      hiddenCustomerKeys: nextHiddenKeys,
    );
  }

  void deleteCustomer(String customerKey) {
    final normalizedKey = customerKey.trim();
    if (normalizedKey.isEmpty) {
      return;
    }

    final nextProfiles = state.customerProfiles
        .where((item) => item.key != normalizedKey)
        .toList(growable: false);
    final nextHiddenKeys = Set<String>.from(state.hiddenCustomerKeys)..add(normalizedKey);

    state = state.copyWith(
      customerProfiles: nextProfiles,
      hiddenCustomerKeys: nextHiddenKeys,
    );
  }

  void addSupplier({
    required String name,
    String phone = '',
    String address = '',
    String productType = '',
    int creditLimit = 0,
  }) {
    final normalizedName = name.trim();
    final normalizedPhone = phone.trim();
    final normalizedAddress = address.trim();
    final normalizedProductType = productType.trim();
    final normalizedKey = dokanSupplierRecordKey(normalizedName, normalizedPhone);
    final now = DateTime.now();
    final nextProfiles = state.supplierProfiles.toList(growable: true);
    final index = nextProfiles.indexWhere((item) => item.key == normalizedKey);
    final existingCreatedAt = index >= 0 ? nextProfiles[index].createdAt : now;
    final nextRecord = DokanSupplierProfileRecord(
      key: normalizedKey,
      name: normalizedName,
      phone: normalizedPhone,
      address: normalizedAddress,
      productType: normalizedProductType,
      creditLimit: math.max(0, creditLimit),
      createdAt: existingCreatedAt,
      updatedAt: now,
    );

    if (index >= 0) {
      nextProfiles[index] = nextRecord;
    } else {
      nextProfiles.insert(0, nextRecord);
    }

    final nextHiddenKeys = Set<String>.from(state.hiddenSupplierKeys)..remove(normalizedKey);
    state = state.copyWith(
      supplierProfiles: List<DokanSupplierProfileRecord>.unmodifiable(nextProfiles),
      hiddenSupplierKeys: nextHiddenKeys,
    );
  }

  void deleteSupplier(String supplierKey) {
    final normalizedKey = supplierKey.trim();
    if (normalizedKey.isEmpty) {
      return;
    }

    final nextProfiles = state.supplierProfiles
        .where((item) => item.key != normalizedKey)
        .toList(growable: false);
    final nextLedger = state.supplierLedger
        .where((item) => item.supplierKey != normalizedKey)
        .toList(growable: false);
    final nextHiddenKeys = Set<String>.from(state.hiddenSupplierKeys)..add(normalizedKey);

    state = state.copyWith(
      supplierProfiles: nextProfiles,
      supplierLedger: nextLedger,
      hiddenSupplierKeys: nextHiddenKeys,
    );
  }

  void addSupplierPurchase({
    required String supplierKey,
    required String supplierName,
    required int amount,
    String note = '',
  }) {
    if (amount <= 0) {
      return;
    }

    final normalizedKey = supplierKey.trim();
    final nextLedger = <DokanSupplierLedgerRecord>[
      DokanSupplierLedgerRecord(
        id: 'supplier-purchase-${DateTime.now().microsecondsSinceEpoch}',
        supplierKey: normalizedKey,
        supplierName: supplierName.trim(),
        amount: amount,
        kind: DokanSupplierLedgerKind.purchase,
        createdAt: DateTime.now(),
        note: note.trim().isEmpty ? 'ক্রয় যোগ' : note.trim(),
        paymentMethod: DokanPosPaymentMethod.cash,
      ),
      ...state.supplierLedger,
    ];

    state = state.copyWith(supplierLedger: nextLedger);
  }

  void addSupplierPayment({
    required String supplierKey,
    required String supplierName,
    required int amount,
    required DokanPosPaymentMethod paymentMethod,
    String note = '',
  }) {
    if (amount <= 0) {
      return;
    }

    final normalizedKey = supplierKey.trim();
    final nextLedger = <DokanSupplierLedgerRecord>[
      DokanSupplierLedgerRecord(
        id: 'supplier-payment-${DateTime.now().microsecondsSinceEpoch}',
        supplierKey: normalizedKey,
        supplierName: supplierName.trim(),
        amount: amount,
        kind: DokanSupplierLedgerKind.payment,
        createdAt: DateTime.now(),
        note: note.trim().isEmpty ? 'পেমেন্ট সম্পন্ন' : note.trim(),
        paymentMethod: paymentMethod,
      ),
      ...state.supplierLedger,
    ];

    state = state.copyWith(supplierLedger: nextLedger);
  }

  void addStaff({
    required String name,
    required String phone,
    required String role,
    String address = '',
    String note = '',
    List<String> permissions = const <String>[],
    String? pinCode,
  }) {
    final normalizedName = name.trim();
    final normalizedPhone = phone.trim();
    final normalizedRole = role.trim();
    final normalizedAddress = address.trim();
    final normalizedNote = note.trim();
    final normalizedKey = normalizedPhone.isNotEmpty ? normalizedPhone : normalizedName.toLowerCase();
    final now = DateTime.now();
    final nextProfiles = state.staffProfiles.toList(growable: true);
    final index = nextProfiles.indexWhere((item) => item.key == normalizedKey);
    final existingCreatedAt = index >= 0 ? nextProfiles[index].createdAt : now;
    final nextRecord = DokanStaffProfileRecord(
      key: normalizedKey,
      name: normalizedName,
      phone: normalizedPhone,
      role: normalizedRole,
      address: normalizedAddress,
      note: normalizedNote,
      active: true,
      joinedAt: index >= 0 ? nextProfiles[index].joinedAt : now,
      lastActiveAt: now,
      lastLoginAt: now,
      recentSalesCount: index >= 0 ? nextProfiles[index].recentSalesCount : 0,
      permissions: List<String>.unmodifiable(permissions),
      pinCode: pinCode?.trim().isEmpty == true ? null : pinCode?.trim(),
      createdAt: existingCreatedAt,
      updatedAt: now,
    );

    if (index >= 0) {
      nextProfiles[index] = nextRecord;
    } else {
      nextProfiles.insert(0, nextRecord);
    }

    final nextHiddenKeys = Set<String>.from(state.hiddenStaffKeys)..remove(normalizedKey);
    state = state.copyWith(
      staffProfiles: List<DokanStaffProfileRecord>.unmodifiable(nextProfiles),
      hiddenStaffKeys: nextHiddenKeys,
    );
  }

  void deleteStaff(String staffKey) {
    final normalizedKey = staffKey.trim();
    if (normalizedKey.isEmpty) {
      return;
    }

    final nextProfiles = state.staffProfiles
        .where((item) => item.key != normalizedKey)
        .toList(growable: false);
    final nextHiddenKeys = Set<String>.from(state.hiddenStaffKeys)..add(normalizedKey);

    state = state.copyWith(
      staffProfiles: nextProfiles,
      hiddenStaffKeys: nextHiddenKeys,
    );
  }

  void toggleStaffStatus(String staffKey) {
    final normalizedKey = staffKey.trim();
    final nextProfiles = state.staffProfiles.map((item) {
      if (item.key != normalizedKey) {
        return item;
      }
      return item.copyWith(
        active: !item.active,
        lastActiveAt: DateTime.now(),
        updatedAt: DateTime.now(),
      );
    }).toList(growable: false);
    state = state.copyWith(staffProfiles: nextProfiles);
  }

  void updateStaffPermissions(String staffKey, List<String> permissions) {
    final normalizedKey = staffKey.trim();
    final normalizedPermissions = List<String>.unmodifiable(
      permissions.map((item) => item.trim()).where((item) => item.isNotEmpty).toSet().toList(growable: false),
    );
    final now = DateTime.now();
    final nextProfiles = state.staffProfiles.map((item) {
      if (item.key != normalizedKey) {
        return item;
      }
      return item.copyWith(
        permissions: normalizedPermissions,
        updatedAt: now,
      );
    }).toList(growable: false);
    state = state.copyWith(staffProfiles: nextProfiles);
  }

  void setStaffPin({
    required String staffKey,
    required String pinCode,
  }) {
    final normalizedKey = staffKey.trim();
    final pin = pinCode.trim();
    final now = DateTime.now();
    final nextProfiles = state.staffProfiles.map((item) {
      if (item.key != normalizedKey) {
        return item;
      }
      return item.copyWith(
        pinCode: pin,
        updatedAt: now,
      );
    }).toList(growable: false);
    state = state.copyWith(staffProfiles: nextProfiles);
  }

  void recordStaffLogin(String staffKey) {
    final normalizedKey = staffKey.trim();
    final now = DateTime.now();
    final nextProfiles = state.staffProfiles.map((item) {
      if (item.key != normalizedKey) {
        return item;
      }
      return item.copyWith(
        lastLoginAt: now,
        lastActiveAt: now,
        updatedAt: now,
      );
    }).toList(growable: false);
    state = state.copyWith(staffProfiles: nextProfiles);
  }

  void addOrder(DokanPosOrderRecord record) {
    state = state.copyWith(orders: <DokanPosOrderRecord>[record, ...state.orders]);
  }

  DokanPosOrderStatus currentCheckoutStatus() {
    if (state.paymentMethod == DokanPosPaymentMethod.cash) {
      if (state.cashReceived >= state.total) {
        return DokanPosOrderStatus.paid;
      }
      if (state.cashReceived > 0 && state.cashReceived < state.total) {
        return DokanPosOrderStatus.partiallyPaid;
      }
      return DokanPosOrderStatus.due;
    }

    return DokanPosOrderStatus.paid;
  }

  String? validateCheckout() {
    if (state.total <= 0) {
      return 'মোট টাকার পরিমাণ সঠিক নয়';
    }

    if (state.paymentMethod == DokanPosPaymentMethod.cash) {
      if (state.cashReceived <= 0) {
        return 'প্রাপ্ত নগদ শূন্য হতে পারে না';
      }
      if (state.cashReceived > state.total) {
        return 'প্রাপ্ত নগদ মোট টাকার চেয়ে বেশি হতে পারে না';
      }
      return null;
    }

    if (state.transactionId.trim().length < 6 || state.transactionId.trim().length > 20) {
      return 'লেনদেন আইডি সঠিক নয়';
    }

    if (!RegExp(r'^[0-9]{11}$').hasMatch(state.customerNumber.trim())) {
      return 'নম্বর সঠিক নয়';
    }

    return null;
  }

  String confirmCheckout() {
    final status = currentCheckoutStatus();
    final paidAmount = state.paymentMethod == DokanPosPaymentMethod.cash ? math.min(state.cashReceived, state.total) : state.total;
    final dueAmount = math.max(0, state.total - paidAmount);
    final customerName = state.customerName.trim();
    final customerNumber = state.customerNumber.trim();
    
    final flow = ref.read(dokanAppFlowProvider);
    final currentSalesmanPhone = flow.currentUserRole == 1 ? flow.currentSalesmanPhone : null;

    final order = DokanPosOrderRecord(
      id: 'order-${DateTime.now().microsecondsSinceEpoch}',
      customerName: customerName.isEmpty ? 'সরাসরি ক্রেতা' : customerName,
      customerNumber: customerNumber,
      totalAmount: state.total,
      paidAmount: paidAmount,
      dueAmount: dueAmount,
      paymentMethod: state.paymentMethod,
      status: status,
      summary:
          'সাবটোটাল ${state.subtotal}, ডিসকাউন্ট ${state.discountAmount}, ট্যাক্স ${state.taxAmount}',
      createdAt: DateTime.now(),
      salesmanPhone: currentSalesmanPhone,
    );

    state = state.copyWith(
      orders: <DokanPosOrderRecord>[order, ...state.orders],
      paymentConfirmed: true,
      confirmationMessage: 'পেমেন্ট সম্পন্ন',
    );
    return 'পেমেন্ট সম্পন্ন';
  }

  void cancelCheckout() {
    state = state.copyWith(
      paymentConfirmed: false,
      confirmationMessage: 'চেকআউট বাতিল',
    );
  }

  void resetAfterCheckout() {
    state = state.copyWith(
      cartQuantities: const <String, int>{},
      discount: 0,
      taxPercent: 0,
      paymentMethod: DokanPosPaymentMethod.cash,
      customerName: '',
      customerNumber: '',
      transactionId: '',
      cashReceived: 0,
      paymentConfirmed: false,
      confirmationMessage: null,
    );
  }
}

final dokanPosProvider =
    NotifierProvider<DokanPosNotifier, DokanPosState>(DokanPosNotifier.new);
