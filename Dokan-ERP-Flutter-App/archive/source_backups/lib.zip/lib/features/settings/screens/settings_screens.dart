import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../app/dokan_app_providers.dart';

import '../../babsha/screens/babsha_screens.dart';
import '../../notifications/screens/notification_center_screen.dart';
import '../../pos/screens/pos_screens.dart';
import '../../products/screens/product_screens.dart';
import '../../reports/screens/reports_screens.dart';
import '../../../shared/widgets/dokan_placeholder_screen.dart';

class DokanHelpSupportScreen extends StatefulWidget {
  const DokanHelpSupportScreen({super.key});

  @override
  State<DokanHelpSupportScreen> createState() =>
      _DokanHelpSupportScreenState();
}

class _DokanHelpSupportScreenState
    extends State<DokanHelpSupportScreen> {
  int? _expandedFaq;

  @override
Widget build(BuildContext context) {
  final faqs = [
    (
      'কিভাবে পণ্য যোগ করবো?',
      'পণ্য মেনুতে গিয়ে নতুন পণ্য যোগ করুন এবং তথ্য পূরণ করুন।'
    ),
    (
      'কিভাবে বিক্রয় করবো?',
      'বিক্রয় সেকশনে গিয়ে পণ্য নির্বাচন করে বিক্রয় সম্পন্ন করুন।'
    ),
    (
      'স্টক কম হলে কি হবে?',
      'কম স্টক লিমিট অনুযায়ী ড্যাশবোর্ডে সতর্কতা দেখাবে।'
    ),
    (
      'ট্যাক্স কিভাবে কাজ করে?',
      'ট্যাক্স সেটিংস অনুযায়ী স্বয়ংক্রিয়ভাবে বিক্রয়ে প্রয়োগ হবে।'
    ),
  ];

  return Scaffold(
    backgroundColor: Colors.white,
    appBar: AppBar(
      backgroundColor: Colors.white,
      elevation: 0,
      iconTheme: const IconThemeData(color: Colors.black),
      title: const Text(
        'গাইড ও সাপোর্ট',
        style: TextStyle(
          color: Colors.black,
          fontWeight: FontWeight.w800,
        ),
      ),
    ),
    body: SafeArea(
      child: ListView(
        padding: const EdgeInsets.all(16),
        children: [

          const Text(
            'অ্যাপ ব্যবহার নির্দেশিকা ও সহায়তা নিন',
            style: TextStyle(
              color: Colors.black54,
              fontSize: 14,
            ),
          ),

          const SizedBox(height: 20),

          _guideCard(
            Icons.menu_book_outlined,
            'অ্যাপ ব্যবহার নির্দেশিকা',
            'How to use inventory system',
          ),

          _guideCard(
            Icons.point_of_sale_outlined,
            'বিক্রয় শুরু করুন',
            'Sales flow guide',
          ),

          _guideCard(
            Icons.inventory_2_outlined,
            'পণ্য যোগ করুন',
            'Product management guide',
          ),

          _guideCard(
            Icons.bar_chart_outlined,
            'রিপোর্ট দেখুন',
            'Reports explanation',
          ),

          const SizedBox(height: 24),

          const Text(
            'সাধারণ প্রশ্ন',
            style: TextStyle(
              color: Colors.black,
              fontSize: 18,
              fontWeight: FontWeight.w800,
            ),
          ),

          const SizedBox(height: 12),

          ...List.generate(faqs.length, (index) {
            final item = faqs[index];
            final expanded = _expandedFaq == index;

            return Container(
              margin: const EdgeInsets.only(bottom: 10),
              decoration: BoxDecoration(
                color: Colors.white,
                border: Border.all(
                  color: const Color(0xFFE5E7EB),
                ),
                borderRadius: BorderRadius.circular(12),
              ),
              child: Column(
                children: [
                  InkWell(
                    borderRadius: BorderRadius.circular(12),
                    onTap: () {
                      setState(() {
                        _expandedFaq =
                            expanded ? null : index;
                      });
                    },
                    child: Padding(
                      padding: const EdgeInsets.all(14),
                      child: Row(
                        children: [
                          Expanded(
                            child: Text(
                              item.$1,
                              style: const TextStyle(
                                color: Colors.black,
                                fontWeight: FontWeight.w700,
                              ),
                            ),
                          ),
                          AnimatedRotation(
                            duration: const Duration(
                                milliseconds: 250),
                            turns: expanded ? 0.5 : 0,
                            child: const Icon(
                              Icons.keyboard_arrow_down,
                              color: Colors.black,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),

                  AnimatedCrossFade(
                    duration: const Duration(
                        milliseconds: 250),
                    crossFadeState: expanded
                        ? CrossFadeState.showFirst
                        : CrossFadeState.showSecond,
                    firstChild: Container(
                      width: double.infinity,
                      padding: const EdgeInsets.fromLTRB(
                          14, 0, 14, 14),
                      child: Text(
                        item.$2,
                        style: const TextStyle(
                          color: Colors.black,
                          height: 1.5,
                        ),
                      ),
                    ),
                    secondChild:
                        const SizedBox.shrink(),
                  ),
                ],
              ),
            );
          }),

          const SizedBox(height: 24),

          const Text(
            'সাপোর্টের সাথে যোগাযোগ করুন',
            style: TextStyle(
              color: Colors.black,
              fontSize: 18,
              fontWeight: FontWeight.w800,
            ),
          ),

          const SizedBox(height: 12),

          _supportButton(
            'WhatsApp Support',
            Icons.chat_outlined,
          ),

          const SizedBox(height: 10),

          _supportButton(
            'Email Support',
            Icons.email_outlined,
          ),

          const SizedBox(height: 10),

          _supportButton(
            'Call Support',
            Icons.call_outlined,
          ),

          const SizedBox(height: 24),

          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              border: Border.all(
                color: const Color(0xFFE5E7EB),
              ),
              borderRadius: BorderRadius.circular(12),
            ),
            child: const Column(
              crossAxisAlignment:
                  CrossAxisAlignment.start,
              children: [
                Text(
                  'System Info',
                  style: TextStyle(
                    color: Colors.black,
                    fontWeight: FontWeight.w800,
                  ),
                ),
                SizedBox(height: 8),
                Text(
                  'App Version: 1.0.0',
                  style: TextStyle(color: Colors.black),
                ),
                Text(
                  'Build Number: 100',
                  style: TextStyle(color: Colors.black),
                ),
                Text(
                  'Last Update: June 2026',
                  style: TextStyle(color: Colors.black),
                ),
              ],
            ),
          ),
        ],
      ),
    ),
  );
}

Widget _guideCard(
  IconData icon,
  String title,
  String subtitle,
) {
  return Container(
    margin: const EdgeInsets.only(bottom: 10),
    decoration: BoxDecoration(
      color: Colors.white,
      border: Border.all(
        color: const Color(0xFFE5E7EB),
      ),
      borderRadius: BorderRadius.circular(12),
    ),
    child: ListTile(
      leading: Icon(icon, color: Colors.black),
      title: Text(
        title,
        style: const TextStyle(
          color: Colors.black,
          fontWeight: FontWeight.w700,
        ),
      ),
      subtitle: Text(
        subtitle,
        style: const TextStyle(
          color: Colors.black54,
        ),
      ),
      onTap: () {},
    ),
  );
}

Widget _supportButton(
  String title,
  IconData icon,
) {
  return SizedBox(
    width: double.infinity,
    child: OutlinedButton.icon(
      onPressed: () {},
      icon: Icon(icon, color: Colors.black),
      label: Text(
        title,
        style: const TextStyle(
          color: Colors.black,
          fontWeight: FontWeight.w700,
        ),
      ),
      style: OutlinedButton.styleFrom(
        backgroundColor: Colors.white,
        side: const BorderSide(
          color: Color(0xFFE5E7EB),
        ),
        minimumSize: const Size.fromHeight(52),
      ),
    ),
  );
}

}
class DokanNotificationSubscriptionSettingsScreen extends StatelessWidget {
  const DokanNotificationSubscriptionSettingsScreen({super.key});

  static const Color _bg = Color(0xFFF4F7FB);
  static const Color _text = Color(0xFF16302E);
  static const Color _muted = Color(0xFF6F8280);
  static const Color _border = Color(0xFFE3EBE8);
  static const Color _accent = Color(0xFF0E8F5F);
  static const Color _accentDeep = Color(0xFF0A7A52);
  static const Color _warning = Color(0xFFD9822B);
  static const Color _danger = Color(0xFFE15241);

  @override
  Widget build(BuildContext context) {
    final plans = <_SubscriptionPlanData>[
      _SubscriptionPlanData(
        name: 'ফ্রি',
        price: '৳০',
        monthlyPrice: 0,
        subtitle: 'নতুন দোকানের জন্য শুরু করুন',
        badge: 'বর্তমান প্ল্যান',
        badgeColor: Color(0xFFEAF5F1),
        badgeTextColor: _accent,
        icon: Icons.storefront_rounded,
        iconBackground: Color(0xFFEAF5F1),
        iconColor: _accent,
        current: true,
        popular: false,
        upgradeLabel: 'এখনই দেখুন',
        features: <String>[
          '১টি দোকান',
          '২৫০ পণ্য সীমা',
          '১ জন ইউজার',
          'বেসিক রিপোর্ট',
        ],
      ),
      _SubscriptionPlanData(
        name: 'বেসিক',
        price: '৳৪৯৯',
        monthlyPrice: 499,
        subtitle: 'দৈনন্দিন ব্যবসার জন্য স্মার্ট সমাধান',
        badge: 'জনপ্রিয়',
        badgeColor: Color(0xFFFFF4E5),
        badgeTextColor: _warning,
        icon: Icons.workspace_premium_rounded,
        iconBackground: Color(0xFFFFF4E5),
        iconColor: _warning,
        current: false,
        popular: true,
        upgradeLabel: 'এখনই নিন',
        features: <String>[
          '৫০০ পণ্য সীমা',
          '৩ জন ইউজার',
          'আয়-ব্যয়ের রিপোর্ট',
          'দ্রুত সাপোর্ট',
        ],
      ),
      _SubscriptionPlanData(
        name: 'প্রিমিয়াম',
        price: '৳৯৯৯',
        monthlyPrice: 999,
        subtitle: 'বড় ব্যবসার জন্য সম্পূর্ণ কন্ট্রোল',
        badge: 'সর্বোচ্চ সুবিধা',
        badgeColor: Color(0xFFEAF0FF),
        badgeTextColor: Color(0xFF4A6CF7),
        icon: Icons.diamond_rounded,
        iconBackground: Color(0xFFEAF0FF),
        iconColor: Color(0xFF4A6CF7),
        current: false,
        popular: false,
        upgradeLabel: 'আপগ্রেড করুন',
        features: <String>[
          'অসীম পণ্য',
          'অসীম ইউজার',
          'অ্যাডভান্সড রিপোর্ট',
          'প্রাধান্যভিত্তিক সাপোর্ট',
        ],
      ),
    ];

      const paymentHistory = <_SubscriptionHistoryData>[
      _SubscriptionHistoryData(
        planName: 'ফ্রি',
        amount: '৳০',
        date: '১২ জুন ২০২৬',
        status: 'সক্রিয়',
        statusColor: Color(0xFFEAF5F1),
        statusTextColor: _accent,
        icon: Icons.verified_rounded,
      ),
      _SubscriptionHistoryData(
        planName: 'বেসিক',
        amount: '৳৪৯৯',
        date: '১২ মে ২০২৬',
        status: 'মেয়াদ শেষ',
        statusColor: Color(0xFFFDECEC),
        statusTextColor: _danger,
        icon: Icons.schedule_rounded,
      ),
      _SubscriptionHistoryData(
        planName: 'ফ্রি',
        amount: '৳০',
        date: '১২ এপ্রিল ২০২৬',
        status: 'সক্রিয়',
        statusColor: Color(0xFFEAF5F1),
        statusTextColor: _accent,
        icon: Icons.verified_rounded,
      ),
    ];

    return Scaffold(
      backgroundColor: _bg,
      appBar: AppBar(
        backgroundColor: _bg,
        surfaceTintColor: _bg,
        elevation: 0,
        centerTitle: false,
        leading: Padding(
          padding: const EdgeInsets.only(left: 16),
          child: IconButton(
            onPressed: () => Navigator.of(context).maybePop(),
            icon: const Icon(Icons.arrow_back_rounded),
            style: IconButton.styleFrom(
              backgroundColor: Colors.white,
              foregroundColor: _text,
            ),
          ),
        ),
        leadingWidth: 72,
        title: const Text(
          'প্ল্যান ও পেমেন্ট',
          style: TextStyle(
            color: _text,
            fontSize: 19,
            fontWeight: FontWeight.w800,
          ),
        ),
      ),
      body: SafeArea(
        child: LayoutBuilder(
          builder: (context, constraints) {
            final contentWidth = constraints.maxWidth > 760 ? 760.0 : constraints.maxWidth;
            final bottomPadding = MediaQuery.viewInsetsOf(context).bottom + 24;
            return CustomScrollView(
              physics: const AlwaysScrollableScrollPhysics(parent: BouncingScrollPhysics()),
              keyboardDismissBehavior: ScrollViewKeyboardDismissBehavior.onDrag,
              slivers: [
                SliverPadding(
                  padding: EdgeInsets.fromLTRB(16, 8, 16, bottomPadding),
                  sliver: SliverToBoxAdapter(
                    child: Center(
                      child: ConstrainedBox(
                        constraints: BoxConstraints(maxWidth: contentWidth),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.stretch,
                          children: [
                            _CurrentPlanSummaryCard(
                              accent: _accent,
                              accentDeep: _accentDeep,
                              borderColor: _border,
                              textColor: _text,
                              mutedColor: _muted,
                              onPrimaryAction: () => _openPlanDetails(context, plans.first),
                              onUpgrade: () => _openCheckout(context, plans[1]),
                            ),
                            const SizedBox(height: 18),
                            const _SubscriptionSectionLabel(title: 'উপলব্ধ প্ল্যান'),
                            const SizedBox(height: 10),
                            LayoutBuilder(
                              builder: (context, planConstraints) {
                                final cardWidth = planConstraints.maxWidth > 620
                                    ? (planConstraints.maxWidth - 12) / 2
                                    : planConstraints.maxWidth;
                                return Wrap(
                                  spacing: 12,
                                  runSpacing: 12,
                                  children: plans
                                      .map(
                                        (plan) => SizedBox(
                                          width: cardWidth,
                                          child: _SubscriptionPlanCard(
                                            data: plan,
                                            accent: _accent,
                                            borderColor: _border,
                                            textColor: _text,
                                            mutedColor: _muted,
                                            onViewPlan: () => _openPlanDetails(context, plan),
                                            onUpgrade: () => _openCheckout(context, plan),
                                          ),
                                        ),
                                      )
                                      .toList(growable: false),
                                );
                              },
                            ),
                            const SizedBox(height: 18),
                            const _SubscriptionSectionLabel(title: 'পেমেন্ট ইতিহাস'),
                            const SizedBox(height: 10),
                            ...paymentHistory.map(
                              (item) => Padding(
                                padding: const EdgeInsets.only(bottom: 12),
                                child: _SubscriptionHistoryCard(
                                  data: item,
                                  textColor: _text,
                                  mutedColor: _muted,
                                  borderColor: _border,
                                ),
                              ),
                            ),
                            const SizedBox(height: 6),
                            const _SubscriptionSectionLabel(title: 'সাহায্য ও সাপোর্ট'),
                            const SizedBox(height: 10),
                            _SubscriptionSupportCard(
                              accent: _accent,
                              accentDeep: _accentDeep,
                              borderColor: _border,
                              textColor: _text,
                              mutedColor: _muted,
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            );
          },
        ),
      ),
    );
  }

  void _openPlanDetails(BuildContext context, _SubscriptionPlanData plan) {
    showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (sheetContext) => _PlanDetailsSheet(plan: plan),
    );
  }

  void _openCheckout(BuildContext context, _SubscriptionPlanData plan) {
    Navigator.of(context).push(
      MaterialPageRoute(
        builder: (_) => _SubscriptionCheckoutScreen(plan: plan),
      ),
    );
  }
}

class _SubscriptionSectionLabel extends StatelessWidget {
  const _SubscriptionSectionLabel({required this.title});

  final String title;

  @override
  Widget build(BuildContext context) {
    return Text(
      title,
      style: const TextStyle(
        color: Color(0xFF5A6B69),
        fontSize: 13.5,
        fontWeight: FontWeight.w800,
        letterSpacing: 0.2,
      ),
    );
  }
}

class _CurrentPlanSummaryCard extends StatelessWidget {
  const _CurrentPlanSummaryCard({
    required this.accent,
    required this.accentDeep,
    required this.borderColor,
    required this.textColor,
    required this.mutedColor,
    required this.onPrimaryAction,
    required this.onUpgrade,
  });

  final Color accent;
  final Color accentDeep;
  final Color borderColor;
  final Color textColor;
  final Color mutedColor;
  final VoidCallback onPrimaryAction;
  final VoidCallback onUpgrade;

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: <Color>[accent, accentDeep],
        ),
        borderRadius: BorderRadius.circular(20),
        boxShadow: const [
          BoxShadow(
            color: Color(0x220B5B40),
            blurRadius: 24,
            offset: Offset(0, 12),
          ),
        ],
      ),
      child: Padding(
        padding: const EdgeInsets.all(18),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Container(
                  width: 54,
                  height: 54,
                  decoration: BoxDecoration(
                    color: Colors.white.withValues(alpha: 0.16),
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(color: Colors.white.withValues(alpha: 0.15)),
                  ),
                  child: const Icon(
                    Icons.workspace_premium_rounded,
                    color: Colors.white,
                    size: 28,
                  ),
                ),
                const SizedBox(width: 14),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text(
                        'বর্তমান প্ল্যান',
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 13,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                      const SizedBox(height: 6),
                      const Text(
                        'ফ্রি প্ল্যান',
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 24,
                          fontWeight: FontWeight.w900,
                          height: 1.05,
                        ),
                      ),
                      const SizedBox(height: 8),
                      Text(
                        'ছোট ব্যবসার জন্য স্মার্ট শুরু',
                        style: TextStyle(
                          color: Colors.white.withValues(alpha: 0.9),
                          fontSize: 13,
                          fontWeight: FontWeight.w500,
                          height: 1.3,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
            const SizedBox(height: 18),
            Wrap(
              spacing: 10,
              runSpacing: 10,
              children: const [
                _SubscriptionMetricPill(label: 'মূল্য', value: '৳০'),
                _SubscriptionMetricPill(label: 'মেয়াদ', value: 'চলমান'),
                _SubscriptionMetricPill(label: 'পণ্য সীমা', value: '২৫০'),
                _SubscriptionMetricPill(label: 'ইউজার সীমা', value: '১'),
              ],
            ),
            const SizedBox(height: 16),
            Row(
              children: [
                Expanded(
                  child: OutlinedButton(
                    onPressed: onPrimaryAction,
                    style: OutlinedButton.styleFrom(
                      foregroundColor: Colors.white,
                      side: BorderSide(color: Colors.white.withValues(alpha: 0.36)),
                      backgroundColor: Colors.white.withValues(alpha: 0.08),
                      minimumSize: const Size.fromHeight(48),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                    ),
                    child: const Text(
                      'প্ল্যান দেখুন',
                      style: TextStyle(fontSize: 15, fontWeight: FontWeight.w700),
                    ),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: ElevatedButton(
                    onPressed: onUpgrade,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.white,
                      foregroundColor: accentDeep,
                      minimumSize: const Size.fromHeight(48),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                      elevation: 0,
                    ),
                    child: const Text(
                      'আপগ্রেড করুন',
                      style: TextStyle(fontSize: 15, fontWeight: FontWeight.w800),
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 14),
            Row(
              children: [
                Icon(Icons.verified_rounded, size: 18, color: Colors.white.withValues(alpha: 0.9)),
                const SizedBox(width: 6),
                Expanded(
                  child: Text(
                    'অ্যাকাউন্ট এখনো সক্রিয় আছে এবং পরবর্তী ধাপে আপগ্রেড করা যাবে',
                    style: TextStyle(
                      color: Colors.white.withValues(alpha: 0.88),
                      fontSize: 12.5,
                      fontWeight: FontWeight.w500,
                      height: 1.35,
                    ),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class _SubscriptionMetricPill extends StatelessWidget {
  const _SubscriptionMetricPill({
    required this.label,
    required this.value,
  });

  final String label;
  final String value;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
      decoration: BoxDecoration(
        color: Colors.white.withValues(alpha: 0.12),
        borderRadius: BorderRadius.circular(999),
        border: Border.all(color: Colors.white.withValues(alpha: 0.16)),
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            label,
            style: TextStyle(
              color: Colors.white.withValues(alpha: 0.88),
              fontSize: 11,
              fontWeight: FontWeight.w600,
            ),
          ),
          const SizedBox(height: 2),
          Text(
            value,
            style: const TextStyle(
              color: Colors.white,
              fontSize: 13.5,
              fontWeight: FontWeight.w800,
            ),
          ),
        ],
      ),
    );
  }
}

class _SubscriptionPlanCard extends StatelessWidget {
  const _SubscriptionPlanCard({
    required this.data,
    required this.accent,
    required this.borderColor,
    required this.textColor,
    required this.mutedColor,
    required this.onViewPlan,
    required this.onUpgrade,
  });

  final _SubscriptionPlanData data;
  final Color accent;
  final Color borderColor;
  final Color textColor;
  final Color mutedColor;
  final VoidCallback onViewPlan;
  final VoidCallback onUpgrade;

  @override
  Widget build(BuildContext context) {
    final isCurrent = data.current;
    final isPopular = data.popular;

    return Material(
      color: Colors.white,
      borderRadius: BorderRadius.circular(20),
      child: InkWell(
        onTap: onViewPlan,
        borderRadius: BorderRadius.circular(20),
        child: Container(
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(20),
            border: Border.all(
              color: isCurrent ? accent.withValues(alpha: 0.28) : borderColor,
              width: isCurrent ? 1.4 : 1,
            ),
            boxShadow: const [
              BoxShadow(
                color: Color(0x0E21413C),
                blurRadius: 18,
                offset: Offset(0, 8),
              ),
            ],
          ),
          child: Padding(
            padding: const EdgeInsets.all(18),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
            Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Container(
                  width: 48,
                  height: 48,
                  decoration: BoxDecoration(
                    color: data.iconBackground,
                    borderRadius: BorderRadius.circular(14),
                  ),
                  child: Icon(data.icon, color: data.iconColor, size: 26),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Expanded(
                            child: Text(
                              data.name,
                              style: TextStyle(
                                color: textColor,
                                fontSize: 18,
                                fontWeight: FontWeight.w800,
                              ),
                            ),
                          ),
                          if (isCurrent || isPopular)
                            Container(
                              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                              decoration: BoxDecoration(
                                color: isCurrent ? data.badgeColor : data.badgeColor,
                                borderRadius: BorderRadius.circular(999),
                              ),
                              child: Text(
                                data.badge,
                                style: TextStyle(
                                  color: data.badgeTextColor,
                                  fontSize: 11.5,
                                  fontWeight: FontWeight.w800,
                                ),
                              ),
                            ),
                        ],
                      ),
                      const SizedBox(height: 4),
                      Text(
                        data.subtitle,
                        style: TextStyle(
                          color: mutedColor,
                          fontSize: 12.5,
                          fontWeight: FontWeight.w500,
                          height: 1.35,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
            const SizedBox(height: 16),
            Row(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                Text(
                  data.price,
                  style: TextStyle(
                    color: isCurrent ? accent : textColor,
                    fontSize: 28,
                    fontWeight: FontWeight.w900,
                    height: 1,
                  ),
                ),
                const SizedBox(width: 6),
                Padding(
                  padding: const EdgeInsets.only(bottom: 4),
                  child: Text(
                    '/মাস',
                    style: TextStyle(
                      color: mutedColor,
                      fontSize: 12.5,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 14),
            ...data.features.map(
              (feature) => Padding(
                padding: const EdgeInsets.only(bottom: 9),
                child: _SubscriptionFeatureRow(
                  text: feature,
                  accent: accent,
                  textColor: textColor,
                  mutedColor: mutedColor,
                ),
              ),
            ),
            const SizedBox(height: 8),
            SizedBox(
              width: double.infinity,
              child: isCurrent
                  ? OutlinedButton(
                      onPressed: onViewPlan,
                      style: OutlinedButton.styleFrom(
                        foregroundColor: accent,
                        side: BorderSide(color: accent.withValues(alpha: 0.28)),
                        minimumSize: const Size.fromHeight(48),
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                      ),
                      child: const Text(
                        'বর্তমান প্ল্যান',
                        style: TextStyle(fontSize: 15, fontWeight: FontWeight.w800),
                      ),
                    )
                  : ElevatedButton(
                      onPressed: onUpgrade,
                      style: ElevatedButton.styleFrom(
                        backgroundColor: isPopular ? accent : const Color(0xFF1A8F63),
                        foregroundColor: Colors.white,
                        minimumSize: const Size.fromHeight(48),
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                        elevation: 0,
                      ),
                      child: Text(
                        data.upgradeLabel,
                        style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w800),
                      ),
                    ),
            ),
          ],
        ),
      ),
    ),
  ),
);
  }
}

class _SubscriptionFeatureRow extends StatelessWidget {
  const _SubscriptionFeatureRow({
    required this.text,
    required this.accent,
    required this.textColor,
    required this.mutedColor,
  });

  final String text;
  final Color accent;
  final Color textColor;
  final Color mutedColor;

  @override
  Widget build(BuildContext context) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Container(
          width: 18,
          height: 18,
          margin: const EdgeInsets.only(top: 1),
          decoration: BoxDecoration(
            color: accent.withValues(alpha: 0.12),
            shape: BoxShape.circle,
          ),
          child: Icon(
            Icons.check_rounded,
            color: accent,
            size: 12,
          ),
        ),
        const SizedBox(width: 10),
        Expanded(
          child: Text(
            text,
            style: TextStyle(
              color: textColor,
              fontSize: 13.5,
              fontWeight: FontWeight.w600,
              height: 1.3,
            ),
          ),
        ),
      ],
    );
  }
}

class _SubscriptionHistoryCard extends StatelessWidget {
  const _SubscriptionHistoryCard({
    required this.data,
    required this.textColor,
    required this.mutedColor,
    required this.borderColor,
  });

  final _SubscriptionHistoryData data;
  final Color textColor;
  final Color mutedColor;
  final Color borderColor;

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: borderColor),
        boxShadow: const [
          BoxShadow(
            color: Color(0x0C21413C),
            blurRadius: 14,
            offset: Offset(0, 6),
          ),
        ],
      ),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Row(
          children: [
            Container(
              width: 46,
              height: 46,
              decoration: BoxDecoration(
                color: data.statusColor,
                borderRadius: BorderRadius.circular(14),
              ),
              child: Icon(data.icon, color: data.statusTextColor, size: 24),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    data.planName,
                    style: TextStyle(
                      color: textColor,
                      fontSize: 16,
                      fontWeight: FontWeight.w800,
                    ),
                  ),
                  const SizedBox(height: 3),
                  Text(
                    data.date,
                    style: TextStyle(
                      color: mutedColor,
                      fontSize: 12.5,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(width: 12),
            Column(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                Text(
                  data.amount,
                  style: TextStyle(
                    color: textColor,
                    fontSize: 16,
                    fontWeight: FontWeight.w800,
                  ),
                ),
                const SizedBox(height: 6),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                  decoration: BoxDecoration(
                    color: data.statusColor,
                    borderRadius: BorderRadius.circular(999),
                  ),
                  child: Text(
                    data.status,
                    style: TextStyle(
                      color: data.statusTextColor,
                      fontSize: 11.5,
                      fontWeight: FontWeight.w800,
                    ),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class _SubscriptionSupportCard extends StatelessWidget {
  const _SubscriptionSupportCard({
    required this.accent,
    required this.accentDeep,
    required this.borderColor,
    required this.textColor,
    required this.mutedColor,
  });

  final Color accent;
  final Color accentDeep;
  final Color borderColor;
  final Color textColor;
  final Color mutedColor;

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: borderColor),
        boxShadow: const [
          BoxShadow(
            color: Color(0x0C21413C),
            blurRadius: 16,
            offset: Offset(0, 8),
          ),
        ],
      ),
      child: Padding(
        padding: const EdgeInsets.all(18),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Container(
                  width: 48,
                  height: 48,
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      colors: <Color>[accent.withValues(alpha: 0.16), accentDeep.withValues(alpha: 0.12)],
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                    ),
                    borderRadius: BorderRadius.circular(14),
                  ),
                  child: Icon(Icons.headset_mic_rounded, color: accent, size: 25),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'সহজে সাহায্য নিন',
                        style: TextStyle(
                          color: textColor,
                          fontSize: 17,
                          fontWeight: FontWeight.w800,
                        ),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        'প্ল্যান, বিলিং, বা আপগ্রেড সংক্রান্ত যেকোনো প্রশ্নে আমাদের টিম পাশে আছে।',
                        style: TextStyle(
                          color: mutedColor,
                          fontSize: 12.8,
                          fontWeight: FontWeight.w500,
                          height: 1.35,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
            const SizedBox(height: 16),
            Row(
              children: [
                Expanded(
                  child: OutlinedButton.icon(
                    onPressed: () {},
                    icon: const Icon(Icons.menu_book_rounded, size: 18),
                    label: const Text(
                      'গাইড দেখুন',
                      style: TextStyle(fontWeight: FontWeight.w800),
                    ),
                    style: OutlinedButton.styleFrom(
                      foregroundColor: textColor,
                      side: BorderSide(color: borderColor),
                      minimumSize: const Size.fromHeight(46),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                    ),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: ElevatedButton.icon(
                    onPressed: () {},
                    icon: const Icon(Icons.support_agent_rounded, size: 18),
                    label: const Text(
                      'সাপোর্ট',
                      style: TextStyle(fontWeight: FontWeight.w800),
                    ),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: accent,
                      foregroundColor: Colors.white,
                      minimumSize: const Size.fromHeight(46),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                      elevation: 0,
                    ),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class _PlanDetailsSheet extends StatelessWidget {
  const _PlanDetailsSheet({required this.plan});

  final _SubscriptionPlanData plan;

  @override
  Widget build(BuildContext context) {
    final premium = plan.name.contains('প্রিমিয়াম');
    final themeColor = premium ? const Color(0xFF4A6CF7) : const Color(0xFF0E8F5F);
    final bgColor = premium ? const Color(0xFFEAF0FF) : const Color(0xFFEAF5F1);

    return DraggableScrollableSheet(
      initialChildSize: 0.9,
      minChildSize: 0.72,
      maxChildSize: 0.96,
      expand: false,
      builder: (context, scrollController) {
        return Container(
          decoration: const BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.vertical(top: Radius.circular(28)),
          ),
          child: ListView(
            controller: scrollController,
            padding: EdgeInsets.fromLTRB(
              16,
              10,
              16,
              16 + MediaQuery.viewInsetsOf(context).bottom,
            ),
            children: [
              Center(
                child: Container(
                  width: 44,
                  height: 5,
                  decoration: BoxDecoration(
                    color: const Color(0xFFD9E2E0),
                    borderRadius: BorderRadius.circular(99),
                  ),
                ),
              ),
              const SizedBox(height: 14),
              Container(
                padding: const EdgeInsets.all(18),
                decoration: BoxDecoration(
                  gradient: premium
                      ? const LinearGradient(
                          begin: Alignment.topLeft,
                          end: Alignment.bottomRight,
                          colors: [Color(0xFF4A6CF7), Color(0xFF2346C7)],
                        )
                      : const LinearGradient(
                          begin: Alignment.topLeft,
                          end: Alignment.bottomRight,
                          colors: [Color(0xFF0E8F5F), Color(0xFF0A7A52)],
                        ),
                  borderRadius: BorderRadius.circular(22),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Container(
                          width: 52,
                          height: 52,
                          decoration: BoxDecoration(
                            color: Colors.white.withValues(alpha: 0.16),
                            borderRadius: BorderRadius.circular(16),
                          ),
                          child: Icon(plan.icon, color: Colors.white, size: 28),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                plan.name,
                                style: const TextStyle(
                                  color: Colors.white,
                                  fontSize: 22,
                                  fontWeight: FontWeight.w900,
                                ),
                              ),
                              const SizedBox(height: 4),
                              Text(
                                plan.subtitle,
                                style: TextStyle(
                                  color: Colors.white.withValues(alpha: 0.92),
                                  fontSize: 13,
                                  fontWeight: FontWeight.w500,
                                  height: 1.3,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 16),
                    Row(
                      children: [
                        _PlanDetailsChip(
                          label: 'মাসিক মূল্য',
                          value: plan.price,
                          dark: true,
                        ),
                        const SizedBox(width: 10),
                        _PlanDetailsChip(
                          label: 'স্ট্যাটাস',
                          value: plan.current ? 'বর্তমান' : 'আপগ্রেড',
                          dark: true,
                        ),
                      ],
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 18),
              _SectionTitle(title: 'ফিচার তুলনা'),
              const SizedBox(height: 10),
              Container(
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(color: const Color(0xFFE3EBE8)),
                ),
                child: Column(
                  children: plan.features
                      .map(
                        (feature) => Column(
                          children: [
                            Padding(
                              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
                              child: Row(
                                children: [
                                  Container(
                                    width: 24,
                                    height: 24,
                                    decoration: BoxDecoration(
                                      color: bgColor,
                                      borderRadius: BorderRadius.circular(999),
                                    ),
                                    child: Icon(Icons.check_rounded, size: 15, color: themeColor),
                                  ),
                                  const SizedBox(width: 12),
                                  Expanded(
                                    child: Text(
                                      feature,
                                      style: const TextStyle(
                                        color: Color(0xFF16302E),
                                        fontSize: 14.5,
                                        fontWeight: FontWeight.w600,
                                        height: 1.25,
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            if (feature != plan.features.last)
                              const Divider(height: 1, thickness: 1, color: Color(0xFFF1F5F4)),
                          ],
                        ),
                      )
                      .toList(growable: false),
                ),
              ),
              const SizedBox(height: 18),
              _SectionTitle(title: 'প্ল্যান সারাংশ'),
              const SizedBox(height: 10),
              Container(
                decoration: BoxDecoration(
                  color: const Color(0xFFF9FBFC),
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(color: const Color(0xFFE3EBE8)),
                ),
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    children: [
                      _PlanSummaryRow(label: 'প্ল্যান নাম', value: plan.name),
                      const SizedBox(height: 10),
                      _PlanSummaryRow(label: 'মূল্য', value: plan.price),
                      const SizedBox(height: 10),
                      _PlanSummaryRow(
                        label: 'বিবরণ',
                        value: plan.popular ? 'জনপ্রিয় প্যাকেজ' : 'মানক ব্যবসায়িক প্যাকেজ',
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 18),
              SizedBox(
                height: 52,
                child: ElevatedButton(
                  onPressed: () {
                    Navigator.of(context).pop();
                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: themeColor,
                    foregroundColor: Colors.white,
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                    elevation: 0,
                  ),
                  child: Text(
                    plan.current ? 'প্ল্যানটি ব্যবহার হচ্ছে' : 'চেকআউটে যান',
                    style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w800),
                  ),
                ),
              ),
              const SizedBox(height: 6),
            ],
          ),
        );
      },
    );
  }
}

class _SectionTitle extends StatelessWidget {
  const _SectionTitle({required this.title});

  final String title;

  @override
  Widget build(BuildContext context) {
    return Text(
      title,
      style: const TextStyle(
        color: Color(0xFF16302E),
        fontSize: 16,
        fontWeight: FontWeight.w800,
      ),
    );
  }
}

class _PlanDetailsChip extends StatelessWidget {
  const _PlanDetailsChip({
    required this.label,
    required this.value,
    required this.dark,
  });

  final String label;
  final String value;
  final bool dark;

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
        decoration: BoxDecoration(
          color: Colors.white.withValues(alpha: dark ? 0.16 : 1),
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: Colors.white.withValues(alpha: dark ? 0.16 : 0.16)),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              label,
              style: TextStyle(
                color: dark ? Colors.white.withValues(alpha: 0.84) : const Color(0xFF6F8280),
                fontSize: 11.5,
                fontWeight: FontWeight.w600,
              ),
            ),
            const SizedBox(height: 3),
            Text(
              value,
              style: TextStyle(
                color: dark ? Colors.white : const Color(0xFF16302E),
                fontSize: 14,
                fontWeight: FontWeight.w800,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _PlanSummaryRow extends StatelessWidget {
  const _PlanSummaryRow({
    required this.label,
    required this.value,
  });

  final String label;
  final String value;

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Text(
          label,
          style: const TextStyle(
            color: Color(0xFF6F8280),
            fontSize: 13,
            fontWeight: FontWeight.w600,
          ),
        ),
        const Spacer(),
        Flexible(
          child: Text(
            value,
            textAlign: TextAlign.end,
            style: const TextStyle(
              color: Color(0xFF16302E),
              fontSize: 13.5,
              fontWeight: FontWeight.w800,
            ),
          ),
        ),
      ],
    );
  }
}

class _SubscriptionCheckoutScreen extends StatefulWidget {
  const _SubscriptionCheckoutScreen({required this.plan});

  final _SubscriptionPlanData plan;

  @override
  State<_SubscriptionCheckoutScreen> createState() => _SubscriptionCheckoutScreenState();
}

class _SubscriptionCheckoutScreenState extends State<_SubscriptionCheckoutScreen> {
  final TextEditingController _bkashNumberController = TextEditingController();
  final TextEditingController _bkashTransactionController = TextEditingController();
  final TextEditingController _nagadNumberController = TextEditingController();
  final TextEditingController _nagadTransactionController = TextEditingController();
  final TextEditingController _cardHolderController = TextEditingController();
  final TextEditingController _cardNumberController = TextEditingController();
  final TextEditingController _cardExpiryController = TextEditingController();
  final TextEditingController _cardCvvController = TextEditingController();

  String _method = 'বিকাশ';
  bool _confirmed = false;
  bool _processing = false;

  String? _bkashNumberError;
  String? _bkashTransactionError;
  String? _nagadNumberError;
  String? _nagadTransactionError;
  String? _cardHolderError;
  String? _cardNumberError;
  String? _cardExpiryError;
  String? _cardCvvError;
  String? _confirmationError;

  @override
  void dispose() {
    _bkashNumberController.dispose();
    _bkashTransactionController.dispose();
    _nagadNumberController.dispose();
    _nagadTransactionController.dispose();
    _cardHolderController.dispose();
    _cardNumberController.dispose();
    _cardExpiryController.dispose();
    _cardCvvController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final amountText = widget.plan.price;
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: Colors.white,
        surfaceTintColor: Colors.white,
        elevation: 0,
        leading: Padding(
          padding: const EdgeInsets.only(left: 16),
          child: IconButton(
            onPressed: _processing ? null : () => Navigator.of(context).maybePop(),
            icon: const Icon(Icons.arrow_back_rounded),
            style: IconButton.styleFrom(
              backgroundColor: const Color(0xFFF4F7FB),
              foregroundColor: const Color(0xFF16302E),
            ),
          ),
        ),
        leadingWidth: 72,
        title: const Text(
          'চেকআউট',
          style: TextStyle(
            color: Color(0xFF16302E),
            fontSize: 19,
            fontWeight: FontWeight.w800,
          ),
        ),
      ),
      body: SafeArea(
        child: LayoutBuilder(
          builder: (context, constraints) {
            final contentWidth = constraints.maxWidth > 760 ? 760.0 : constraints.maxWidth;
            return SingleChildScrollView(
              physics: const AlwaysScrollableScrollPhysics(parent: BouncingScrollPhysics()),
              keyboardDismissBehavior: ScrollViewKeyboardDismissBehavior.onDrag,
              padding: EdgeInsets.fromLTRB(16, 8, 16, 24 + MediaQuery.viewInsetsOf(context).bottom),
              child: Center(
                child: ConstrainedBox(
                  constraints: BoxConstraints(maxWidth: contentWidth),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      _CheckoutSectionCard(
                        title: 'নির্বাচিত প্ল্যান',
                        child: _CheckoutPlanCard(plan: widget.plan),
                      ),
                      const SizedBox(height: 14),
                      _CheckoutSectionCard(
                        title: 'মূল্য সারাংশ',
                        child: Column(
                          children: [
                            _PlanSummaryRow(label: 'প্ল্যান', value: widget.plan.name),
                            const SizedBox(height: 10),
                            _PlanSummaryRow(label: 'মূল্য', value: amountText),
                            const SizedBox(height: 10),
                            _PlanSummaryRow(
                              label: 'পরবর্তী বিল',
                              value: '${widget.plan.price} / মাস',
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(height: 14),
                      _CheckoutSectionCard(
                        title: 'পেমেন্ট পদ্ধতি',
                        child: Column(
                          children: [
                            _PaymentMethodChoice(
                              label: 'বিকাশ',
                              selected: _method == 'বিকাশ',
                              icon: Icons.phone_android_rounded,
                              onTap: () => setState(() => _method = 'বিকাশ'),
                            ),
                            const SizedBox(height: 10),
                            _PaymentMethodChoice(
                              label: 'নগদ',
                              selected: _method == 'নগদ',
                              icon: Icons.account_balance_wallet_rounded,
                              onTap: () => setState(() => _method = 'নগদ'),
                            ),
                            const SizedBox(height: 10),
                            _PaymentMethodChoice(
                              label: 'ডেবিট / ক্রেডিট কার্ড',
                              selected: _method == 'ডেবিট / ক্রেডিট কার্ড',
                              icon: Icons.credit_card_rounded,
                              onTap: () => setState(() => _method = 'ডেবিট / ক্রেডিট কার্ড'),
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(height: 14),
                      if (_method == 'বিকাশ') ...[
                        _CheckoutSectionCard(
                          title: 'বিকাশ তথ্য',
                          child: Column(
                            children: [
                              _CheckoutField(
                                label: 'বিকাশ নম্বর *',
                                controller: _bkashNumberController,
                                keyboardType: TextInputType.phone,
                                errorText: _bkashNumberError,
                                hintText: '01XXXXXXXXX',
                                onChanged: (_) => _clearError(() => _bkashNumberError = null),
                              ),
                              const SizedBox(height: 12),
                              _CheckoutField(
                                label: 'ট্রানজেকশন আইডি *',
                                controller: _bkashTransactionController,
                                errorText: _bkashTransactionError,
                                hintText: 'ট্রানজেকশন আইডি দিন',
                                onChanged: (_) => _clearError(() => _bkashTransactionError = null),
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(height: 14),
                      ],
                      if (_method == 'নগদ') ...[
                        _CheckoutSectionCard(
                          title: 'নগদ তথ্য',
                          child: Column(
                            children: [
                              _CheckoutField(
                                label: 'নগদ নম্বর *',
                                controller: _nagadNumberController,
                                keyboardType: TextInputType.phone,
                                errorText: _nagadNumberError,
                                hintText: '01XXXXXXXXX',
                                onChanged: (_) => _clearError(() => _nagadNumberError = null),
                              ),
                              const SizedBox(height: 12),
                              _CheckoutField(
                                label: 'ট্রানজেকশন আইডি *',
                                controller: _nagadTransactionController,
                                errorText: _nagadTransactionError,
                                hintText: 'ট্রানজেকশন আইডি দিন',
                                onChanged: (_) => _clearError(() => _nagadTransactionError = null),
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(height: 14),
                      ],
                      if (_method == 'ডেবিট / ক্রেডিট কার্ড') ...[
                        _CheckoutSectionCard(
                          title: 'কার্ড তথ্য',
                          child: Column(
                            children: [
                              _CheckoutField(
                                label: 'কার্ডধারীর নাম *',
                                controller: _cardHolderController,
                                errorText: _cardHolderError,
                                hintText: 'নাম লিখুন',
                                onChanged: (_) => _clearError(() => _cardHolderError = null),
                              ),
                              const SizedBox(height: 12),
                              _CheckoutField(
                                label: 'কার্ড নম্বর *',
                                controller: _cardNumberController,
                                keyboardType: TextInputType.number,
                                errorText: _cardNumberError,
                                hintText: '১৬ ডিজিট কার্ড নম্বর',
                                onChanged: (_) => _clearError(() => _cardNumberError = null),
                              ),
                              const SizedBox(height: 12),
                              Row(
                                children: [
                                  Expanded(
                                    child: _CheckoutField(
                                      label: 'মেয়াদ শেষের তারিখ *',
                                      controller: _cardExpiryController,
                                      errorText: _cardExpiryError,
                                      hintText: 'MM/YY',
                                      onChanged: (_) => _clearError(() => _cardExpiryError = null),
                                    ),
                                  ),
                                  const SizedBox(width: 12),
                                  Expanded(
                                    child: _CheckoutField(
                                      label: 'CVV *',
                                      controller: _cardCvvController,
                                      keyboardType: TextInputType.number,
                                      obscureText: true,
                                      errorText: _cardCvvError,
                                      hintText: '৩ বা ৪ সংখ্যা',
                                      onChanged: (_) => _clearError(() => _cardCvvError = null),
                                    ),
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(height: 14),
                      ],
                      _CheckoutSectionCard(
                        title: 'নিশ্চিতকরণ',
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            _PlanSummaryRow(label: 'প্ল্যান', value: widget.plan.name),
                            const SizedBox(height: 10),
                            _PlanSummaryRow(label: 'মূল্য', value: widget.plan.price),
                            const SizedBox(height: 10),
                            _PlanSummaryRow(label: 'পেমেন্ট পদ্ধতি', value: _method),
                            if (_confirmationError != null) ...[
                              const SizedBox(height: 12),
                              Text(
                                _confirmationError!,
                                style: const TextStyle(
                                  color: Color(0xFFE15241),
                                  fontSize: 12.5,
                                  fontWeight: FontWeight.w600,
                                ),
                              ),
                            ],
                            const SizedBox(height: 12),
                            InkWell(
                              onTap: _processing
                                  ? null
                                  : () => setState(() {
                                        _confirmed = !_confirmed;
                                        _confirmationError = null;
                                      }),
                              borderRadius: BorderRadius.circular(12),
                              child: Row(
                                children: [
                                  Checkbox(
                                    value: _confirmed,
                                    onChanged: _processing
                                        ? null
                                        : (value) => setState(() {
                                              _confirmed = value ?? false;
                                              _confirmationError = null;
                                            }),
                                    activeColor: const Color(0xFF0E8F5F),
                                  ),
                                  const Expanded(
                                    child: Text(
                                      'আমি প্রদত্ত তথ্য সঠিক বলে নিশ্চিত করছি',
                                      style: TextStyle(
                                        color: Color(0xFF16302E),
                                        fontSize: 13.5,
                                        fontWeight: FontWeight.w600,
                                        height: 1.25,
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(height: 18),
                      SizedBox(
                        height: 52,
                        child: ElevatedButton(
                          onPressed: _processing ? null : _submitPayment,
                          style: ElevatedButton.styleFrom(
                            backgroundColor: const Color(0xFF0E8F5F),
                            foregroundColor: Colors.white,
                            disabledBackgroundColor: const Color(0xFFB9C7C5),
                            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                            elevation: 0,
                          ),
                          child: Text(
                            _processing ? 'পেমেন্ট যাচাই করা হচ্ছে...' : 'পেমেন্ট সম্পন্ন করুন',
                            style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w800),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            );
          },
        ),
      ),
    );
  }

  void _clearError(VoidCallback clearAction) {
    setState(clearAction);
  }

  bool _isBangladeshPhone(String value) {
    final digits = value.replaceAll(RegExp(r'\D'), '');
    return digits.length == 11 && digits.startsWith('01');
  }

  bool _isExpiryValid(String value) {
    final regex = RegExp(r'^(0[1-9]|1[0-2])\/\d{2}$');
    return regex.hasMatch(value.trim());
  }

  bool _isCardValidNumber(String value) {
    final digits = value.replaceAll(RegExp(r'\D'), '');
    return digits.length == 16;
  }

  bool _isCvvValid(String value) {
    final digits = value.replaceAll(RegExp(r'\D'), '');
    return digits.length == 3 || digits.length == 4;
  }

  bool _validateForm() {
    var valid = true;
    setState(() {
      _bkashNumberError = null;
      _bkashTransactionError = null;
      _nagadNumberError = null;
      _nagadTransactionError = null;
      _cardHolderError = null;
      _cardNumberError = null;
      _cardExpiryError = null;
      _cardCvvError = null;
      _confirmationError = null;

      if (!_confirmed) {
        _confirmationError = 'এই ঘরটি পূরণ করা আবশ্যক';
        valid = false;
      }

      if (_method == 'বিকাশ') {
        if (_bkashNumberController.text.trim().isEmpty) {
          _bkashNumberError = 'এই ঘরটি পূরণ করা আবশ্যক';
          valid = false;
        } else if (!_isBangladeshPhone(_bkashNumberController.text)) {
          _bkashNumberError = 'সঠিক মোবাইল নম্বর দিন';
          valid = false;
        }

        if (_bkashTransactionController.text.trim().isEmpty) {
          _bkashTransactionError = 'এই ঘরটি পূরণ করা আবশ্যক';
          valid = false;
        } else if (_bkashTransactionController.text.trim().length < 4) {
          _bkashTransactionError = 'সঠিক ট্রানজেকশন আইডি দিন';
          valid = false;
        }
      } else if (_method == 'নগদ') {
        if (_nagadNumberController.text.trim().isEmpty) {
          _nagadNumberError = 'এই ঘরটি পূরণ করা আবশ্যক';
          valid = false;
        } else if (!_isBangladeshPhone(_nagadNumberController.text)) {
          _nagadNumberError = 'সঠিক মোবাইল নম্বর দিন';
          valid = false;
        }

        if (_nagadTransactionController.text.trim().isEmpty) {
          _nagadTransactionError = 'এই ঘরটি পূরণ করা আবশ্যক';
          valid = false;
        } else if (_nagadTransactionController.text.trim().length < 4) {
          _nagadTransactionError = 'সঠিক ট্রানজেকশন আইডি দিন';
          valid = false;
        }
      } else {
        if (_cardHolderController.text.trim().isEmpty) {
          _cardHolderError = 'এই ঘরটি পূরণ করা আবশ্যক';
          valid = false;
        }
        if (_cardNumberController.text.trim().isEmpty) {
          _cardNumberError = 'এই ঘরটি পূরণ করা আবশ্যক';
          valid = false;
        } else if (!_isCardValidNumber(_cardNumberController.text)) {
          _cardNumberError = 'সঠিক কার্ড নম্বর দিন';
          valid = false;
        }
        if (_cardExpiryController.text.trim().isEmpty) {
          _cardExpiryError = 'এই ঘরটি পূরণ করা আবশ্যক';
          valid = false;
        } else if (!_isExpiryValid(_cardExpiryController.text)) {
          _cardExpiryError = 'সঠিক মেয়াদ শেষের তারিখ দিন';
          valid = false;
        }
        if (_cardCvvController.text.trim().isEmpty) {
          _cardCvvError = 'এই ঘরটি পূরণ করা আবশ্যক';
          valid = false;
        } else if (!_isCvvValid(_cardCvvController.text)) {
          _cardCvvError = 'সঠিক CVV দিন';
          valid = false;
        }
      }
    });
    return valid;
  }

  Future<void> _submitPayment() async {
    if (!_validateForm()) {
      return;
    }
    setState(() => _processing = true);
    await Future<void>.delayed(const Duration(seconds: 1));
    if (!mounted) {
      return;
    }
    setState(() => _processing = false);
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('${widget.plan.name} পেমেন্ট সফল হয়েছে'),
        backgroundColor: const Color(0xFF0E8F5F),
      ),
    );
    Navigator.of(context).pop();
  }
}

class _CheckoutSectionCard extends StatelessWidget {
  const _CheckoutSectionCard({
    required this.title,
    required this.child,
  });

  final String title;
  final Widget child;

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: const Color(0xFFE3EBE8)),
        boxShadow: const [
          BoxShadow(
            color: Color(0x0B21413C),
            blurRadius: 18,
            offset: Offset(0, 8),
          ),
        ],
      ),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              title,
              style: const TextStyle(
                color: Color(0xFF16302E),
                fontSize: 16,
                fontWeight: FontWeight.w800,
              ),
            ),
            const SizedBox(height: 14),
            child,
          ],
        ),
      ),
    );
  }
}

class _CheckoutPlanCard extends StatelessWidget {
  const _CheckoutPlanCard({required this.plan});

  final _SubscriptionPlanData plan;

  @override
  Widget build(BuildContext context) {
    final premium = plan.name.contains('প্রিমিয়াম');
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        gradient: premium
            ? const LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [Color(0xFF4A6CF7), Color(0xFF2346C7)],
              )
            : const LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [Color(0xFF0E8F5F), Color(0xFF0A7A52)],
              ),
        borderRadius: BorderRadius.circular(18),
      ),
      child: Row(
        children: [
          Container(
            width: 50,
            height: 50,
            decoration: BoxDecoration(
              color: Colors.white.withValues(alpha: 0.16),
              borderRadius: BorderRadius.circular(14),
            ),
            child: Icon(plan.icon, color: Colors.white, size: 27),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  plan.name,
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 18,
                    fontWeight: FontWeight.w800,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  plan.price,
                  style: TextStyle(
                    color: Colors.white.withValues(alpha: 0.92),
                    fontSize: 13,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _PaymentMethodChoice extends StatelessWidget {
  const _PaymentMethodChoice({
    required this.label,
    required this.selected,
    required this.icon,
    required this.onTap,
  });

  final String label;
  final bool selected;
  final IconData icon;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final borderColor = selected ? const Color(0xFF0E8F5F) : const Color(0xFFE3EBE8);
    final backgroundColor = selected ? const Color(0xFFEAF5F1) : Colors.white;
    return Material(
      color: backgroundColor,
      borderRadius: BorderRadius.circular(16),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(16),
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: borderColor, width: selected ? 1.4 : 1),
          ),
          child: Row(
            children: [
              Icon(icon, color: selected ? const Color(0xFF0E8F5F) : const Color(0xFF6F8280)),
              const SizedBox(width: 12),
              Expanded(
                child: Text(
                  label,
                  style: const TextStyle(
                    color: Color(0xFF16302E),
                    fontSize: 14.5,
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ),
              Icon(
                selected ? Icons.radio_button_checked_rounded : Icons.radio_button_unchecked_rounded,
                color: selected ? const Color(0xFF0E8F5F) : const Color(0xFFB3BFBC),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _CheckoutField extends StatelessWidget {
  const _CheckoutField({
    required this.label,
    required this.controller,
    required this.errorText,
    required this.hintText,
    required this.onChanged,
    this.keyboardType,
    this.obscureText = false,
  });

  final String label;
  final TextEditingController controller;
  final String? errorText;
  final String hintText;
  final ValueChanged<String> onChanged;
  final TextInputType? keyboardType;
  final bool obscureText;

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label,
          style: const TextStyle(
            color: Color(0xFF16302E),
            fontSize: 13,
            fontWeight: FontWeight.w700,
          ),
        ),
        const SizedBox(height: 8),
        TextField(
          controller: controller,
          keyboardType: keyboardType,
          obscureText: obscureText,
          onChanged: onChanged,
          decoration: InputDecoration(
            hintText: hintText,
            hintStyle: const TextStyle(color: Color(0xFF99A8A5)),
            filled: true,
            fillColor: Colors.white,
            errorText: errorText,
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(14),
              borderSide: const BorderSide(color: Color(0xFFE3EBE8)),
            ),
            enabledBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(14),
              borderSide: const BorderSide(color: Color(0xFFE3EBE8)),
            ),
            focusedBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(14),
              borderSide: const BorderSide(color: Color(0xFF0E8F5F), width: 1.4),
            ),
            errorBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(14),
              borderSide: const BorderSide(color: Color(0xFFE15241)),
            ),
            focusedErrorBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(14),
              borderSide: const BorderSide(color: Color(0xFFE15241), width: 1.4),
            ),
            contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 15),
          ),
          style: const TextStyle(
            color: Color(0xFF16302E),
            fontSize: 14.5,
            fontWeight: FontWeight.w600,
          ),
        ),
      ],
    );
  }
}

class _SubscriptionPlanData {
  const _SubscriptionPlanData({
    required this.name,
    required this.price,
    required this.monthlyPrice,
    required this.subtitle,
    required this.badge,
    required this.badgeColor,
    required this.badgeTextColor,
    required this.icon,
    required this.iconBackground,
    required this.iconColor,
    required this.current,
    required this.popular,
    required this.upgradeLabel,
    required this.features,
  });

  final String name;
  final String price;
  final int monthlyPrice;
  final String subtitle;
  final String badge;
  final Color badgeColor;
  final Color badgeTextColor;
  final IconData icon;
  final Color iconBackground;
  final Color iconColor;
  final bool current;
  final bool popular;
  final String upgradeLabel;
  final List<String> features;
}

class _SubscriptionHistoryData {
  const _SubscriptionHistoryData({
    required this.planName,
    required this.amount,
    required this.date,
    required this.status,
    required this.statusColor,
    required this.statusTextColor,
    required this.icon,
  });

  final String planName;
  final String amount;
  final String date;
  final String status;
  final Color statusColor;
  final Color statusTextColor;
  final IconData icon;
}

class DokanShopSettingsScreen extends StatefulWidget {
  const DokanShopSettingsScreen({super.key});

  @override
  State<DokanShopSettingsScreen> createState() => _DokanShopSettingsScreenState();
}

class _DokanShopSettingsScreenState extends State<DokanShopSettingsScreen> {
  bool _receiptShopName = true;
  bool _receiptMobile = true;
  bool _receiptAddress = true;
  bool _receiptLogo = false;
  String _language = 'বাংলা';
  String _theme = 'লাইট মোড';
  String _currency = '৳ বাংলাদেশি টাকা';

  static const Color _bg = Color(0xFFF4F7FB);
  static const Color _text = Color(0xFF16302E);
  static const Color _muted = Color(0xFF6F8280);
  static const Color _border = Color(0xFFE3EBE8);
  static const Color _accent = Color(0xFF0E8F5F);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _bg,
      appBar: AppBar(
        backgroundColor: _bg,
        surfaceTintColor: _bg,
        elevation: 0,
        centerTitle: false,
        leading: Padding(
          padding: const EdgeInsets.only(left: 16),
          child: IconButton(
            onPressed: () => Navigator.of(context).maybePop(),
            icon: const Icon(Icons.arrow_back_rounded),
            style: IconButton.styleFrom(
              backgroundColor: Colors.white,
              foregroundColor: _text,
            ),
          ),
        ),
        leadingWidth: 72,
        title: const Text(
          'দোকানের তথ্য',
          style: TextStyle(
            color: _text,
            fontSize: 19,
            fontWeight: FontWeight.w800,
          ),
        ),
      ),
      body: SafeArea(
        child: LayoutBuilder(
          builder: (context, constraints) {
            final contentWidth = constraints.maxWidth > 760 ? 760.0 : constraints.maxWidth;
            final bottomPadding = MediaQuery.viewInsetsOf(context).bottom + 24;
            return CustomScrollView(
              physics: const AlwaysScrollableScrollPhysics(parent: BouncingScrollPhysics()),
              keyboardDismissBehavior: ScrollViewKeyboardDismissBehavior.onDrag,
              slivers: [
                SliverPadding(
                  padding: EdgeInsets.fromLTRB(16, 8, 16, bottomPadding),
                  sliver: SliverToBoxAdapter(
                    child: Center(
                      child: ConstrainedBox(
                        constraints: BoxConstraints(maxWidth: contentWidth),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.stretch,
                          children: [
                            _StoreInfoSummaryCard(
                              borderColor: _border,
                              accent: _accent,
                              textColor: _text,
                              mutedColor: _muted,
                              onViewDetails: () {
                                Navigator.of(context).push(
                                  MaterialPageRoute(
                                    builder: (_) => const DokanStoreDetailsScreen(),
                                  ),
                                );
                              },
                            ),
                            const SizedBox(height: 14),
                            _StoreSettingsCard(
                              title: 'রিসিট সেটিংস',
                              child: Column(
                                children: [
                                  _StoreToggleTile(
                                    label: 'রিসিটে দোকানের নাম',
                                    value: _receiptShopName,
                                    onChanged: (value) => setState(() => _receiptShopName = value),
                                  ),
                                  _StoreToggleTile(
                                    label: 'রিসিটে মোবাইল নম্বর',
                                    value: _receiptMobile,
                                    onChanged: (value) => setState(() => _receiptMobile = value),
                                  ),
                                  _StoreToggleTile(
                                    label: 'রিসিটে ঠিকানা',
                                    value: _receiptAddress,
                                    onChanged: (value) => setState(() => _receiptAddress = value),
                                  ),
                                  _StoreToggleTile(
                                    label: 'রিসিটে লোগো',
                                    value: _receiptLogo,
                                    onChanged: (value) => setState(() => _receiptLogo = value),
                                  ),
                                ],
                              ),
                            ),
                            const SizedBox(height: 14),
                            _StoreSettingsCard(
                              title: 'অ্যাপ সেটিংস',
                              child: Column(
                                children: [
                                  _SelectableStoreInfoRow(
                                    label: 'ভাষা',
                                    value: _language,
                                    icon: Icons.language_rounded,
                                    onTap: () => _showOptionSheet(
                                      context: context,
                                      title: 'ভাষা নির্বাচন করুন',
                                      options: const ['বাংলা', 'English'],
                                      selected: _language,
                                      onSelected: (value) => setState(() => _language = value),
                                    ),
                                  ),
                                  const SizedBox(height: 14),
                                  _SelectableStoreInfoRow(
                                    label: 'থিম',
                                    value: _theme,
                                    icon: Icons.light_mode_rounded,
                                    onTap: () => _showOptionSheet(
                                      context: context,
                                      title: 'থিম নির্বাচন করুন',
                                      options: const ['লাইট মোড', 'ডার্ক মোড'],
                                      selected: _theme,
                                      onSelected: (value) => setState(() => _theme = value),
                                    ),
                                  ),
                                  const SizedBox(height: 14),
                                  _SelectableStoreInfoRow(
                                    label: 'কারেন্সি',
                                    value: _currency,
                                    icon: Icons.payments_rounded,
                                    onTap: () => _showOptionSheet(
                                      context: context,
                                      title: 'কারেন্সি নির্বাচন করুন',
                                      options: const ['৳ বাংলাদেশি টাকা', '\$ মার্কিন ডলার'],
                                      selected: _currency,
                                      onSelected: (value) => setState(() => _currency = value),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            const SizedBox(height: 14),
                            _StoreSettingsCard(
                              title: 'ডেটা ম্যানেজমেন্ট',
                              child: Column(
                                children: [
                                  _StoreActionButton(
                                    label: 'ডেটা ব্যাকআপ করুন',
                                    icon: Icons.cloud_upload_outlined,
                                    onPressed: () => _showInfoSnack(context, 'ডেটা ব্যাকআপ শুরু করা হয়েছে'),
                                  ),
                                  const SizedBox(height: 12),
                                  _StoreActionButton(
                                    label: 'ডেটা রিস্টোর করুন',
                                    icon: Icons.cloud_download_outlined,
                                    onPressed: () => _showInfoSnack(context, 'ডেটা রিস্টোর প্রস্তুত'),
                                    outlined: true,
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            );
          },
        ),
      ),
    );
  }

  void _showInfoSnack(BuildContext context, String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(message)),
    );
  }

  void _showOptionSheet({
    required BuildContext context,
    required String title,
    required List<String> options,
    required String selected,
    required ValueChanged<String> onSelected,
  }) {
    showModalBottomSheet<void>(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: false,
      builder: (sheetContext) {
        return SafeArea(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(12, 0, 12, 12),
            child: Container(
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(20),
                boxShadow: const [
                  BoxShadow(
                    color: Color(0x22000000),
                    blurRadius: 20,
                    offset: Offset(0, 10),
                  ),
                ],
              ),
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      title,
                      style: const TextStyle(
                        color: Color(0xFF16302E),
                        fontSize: 16,
                        fontWeight: FontWeight.w800,
                      ),
                    ),
                    const SizedBox(height: 12),
                    ...options.map(
                      (option) => Padding(
                        padding: const EdgeInsets.only(bottom: 10),
                        child: _SelectableOptionBox(
                          label: option,
                          selected: option == selected,
                          onTap: () {
                            onSelected(option);
                            Navigator.of(sheetContext).pop();
                          },
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        );
      },
    );
  }
}

class DokanStoreDetailsScreen extends StatefulWidget {
  const DokanStoreDetailsScreen({super.key});

  @override
  State<DokanStoreDetailsScreen> createState() => _DokanStoreDetailsScreenState();
}

class _DokanStoreDetailsScreenState extends State<DokanStoreDetailsScreen> {
  final _formKey = GlobalKey<FormState>();
  final _storeNameController = TextEditingController(text: 'রহিম মুদি ভান্ডার');
  final _ownerNameController = TextEditingController(text: 'আবদুর রহিম');
  final _mobileController = TextEditingController(text: '01712-XXXXXX');
  final _addressController = TextEditingController(text: 'মিরপুর, ঢাকা');
  String _storeType = 'মুদি দোকান';
  bool _saving = false;
  String? _storeNameError;
  String? _ownerNameError;
  String? _mobileError;
  String? _addressError;

  static const List<String> _storeTypes = <String>[
    'মুদি দোকান',
    'সুপার শপ',
    'ফার্মেসি',
    'স্টেশনারি',
    'অন্যান্য',
  ];

  @override
  void dispose() {
    _storeNameController.dispose();
    _ownerNameController.dispose();
    _mobileController.dispose();
    _addressController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF4F7FB),
      appBar: AppBar(
        backgroundColor: const Color(0xFFF4F7FB),
        surfaceTintColor: const Color(0xFFF4F7FB),
        elevation: 0,
        centerTitle: false,
        leading: Padding(
          padding: const EdgeInsets.only(left: 16),
          child: IconButton(
            onPressed: _saving ? null : () => Navigator.of(context).maybePop(),
            icon: const Icon(Icons.arrow_back_rounded),
            style: IconButton.styleFrom(
              backgroundColor: Colors.white,
              foregroundColor: const Color(0xFF16302E),
            ),
          ),
        ),
        leadingWidth: 72,
        title: const Text(
          'দোকানের বিস্তারিত তথ্য',
          style: TextStyle(
            color: Color(0xFF16302E),
            fontSize: 19,
            fontWeight: FontWeight.w800,
          ),
        ),
      ),
      body: SafeArea(
        child: LayoutBuilder(
          builder: (context, constraints) {
            final contentWidth = constraints.maxWidth > 760 ? 760.0 : constraints.maxWidth;
            final bottomPadding = MediaQuery.viewInsetsOf(context).bottom + 24;
            return Form(
              key: _formKey,
              child: CustomScrollView(
                physics: const AlwaysScrollableScrollPhysics(parent: BouncingScrollPhysics()),
                keyboardDismissBehavior: ScrollViewKeyboardDismissBehavior.onDrag,
                slivers: [
                  SliverPadding(
                    padding: EdgeInsets.fromLTRB(16, 8, 16, bottomPadding),
                    sliver: SliverToBoxAdapter(
                      child: Center(
                        child: ConstrainedBox(
                          constraints: BoxConstraints(maxWidth: contentWidth),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.stretch,
                            children: [
                              _StoreLogoCard(
                                onTap: () => _showInfoSnack(context, 'লোগো পরিবর্তনের UI প্রস্তুত'),
                              ),
                              const SizedBox(height: 14),
                              _StoreSettingsCard(
                                title: 'দোকানের তথ্য',
                                child: Column(
                                  children: [
                                    _StoreTextField(
                                      label: 'দোকানের নাম',
                                      controller: _storeNameController,
                                      errorText: _storeNameError,
                                      onChanged: (_) => setState(() => _storeNameError = null),
                                    ),
                                    const SizedBox(height: 12),
                                    _StoreDropdownField(
                                      label: 'দোকানের ধরন',
                                      value: _storeType,
                                      items: _storeTypes,
                                      onChanged: (value) => setState(() => _storeType = value ?? _storeType),
                                    ),
                                    const SizedBox(height: 12),
                                    _StoreTextField(
                                      label: 'মালিকের নাম',
                                      controller: _ownerNameController,
                                      errorText: _ownerNameError,
                                      onChanged: (_) => setState(() => _ownerNameError = null),
                                    ),
                                    const SizedBox(height: 12),
                                    _StoreTextField(
                                      label: 'মোবাইল নম্বর',
                                      controller: _mobileController,
                                      keyboardType: TextInputType.phone,
                                      errorText: _mobileError,
                                      onChanged: (_) => setState(() => _mobileError = null),
                                    ),
                                    const SizedBox(height: 12),
                                    _StoreTextField(
                                      label: 'ঠিকানা',
                                      controller: _addressController,
                                      maxLines: 3,
                                      errorText: _addressError,
                                      onChanged: (_) => setState(() => _addressError = null),
                                    ),
                                  ],
                                ),
                              ),
                              const SizedBox(height: 18),
                              SizedBox(
                                height: 52,
                                child: ElevatedButton(
                                  onPressed: _saving ? null : _saveStoreDetails,
                                  style: ElevatedButton.styleFrom(
                                    backgroundColor: const Color(0xFF0E8F5F),
                                    foregroundColor: Colors.white,
                                    disabledBackgroundColor: const Color(0xFFB9C7C5),
                                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                                    elevation: 0,
                                  ),
                                  child: Text(
                                    _saving ? 'সংরক্ষণ করা হচ্ছে...' : 'সংরক্ষণ',
                                    style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w800),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            );
          },
        ),
      ),
    );
  }

  void _showInfoSnack(BuildContext context, String message) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(message)));
  }

  bool _isBangladeshPhone(String value) {
    final digits = value.replaceAll(RegExp(r'\D'), '');
    return digits.length == 11 && digits.startsWith('01');
  }

  bool _validate() {
    var valid = true;
    setState(() {
      _storeNameError = null;
      _ownerNameError = null;
      _mobileError = null;
      _addressError = null;

      if (_storeNameController.text.trim().isEmpty) {
        _storeNameError = 'এই ঘরটি পূরণ করা আবশ্যক';
        valid = false;
      }
      if (_ownerNameController.text.trim().isEmpty) {
        _ownerNameError = 'এই ঘরটি পূরণ করা আবশ্যক';
        valid = false;
      }
      if (_mobileController.text.trim().isEmpty) {
        _mobileError = 'এই ঘরটি পূরণ করা আবশ্যক';
        valid = false;
      } else if (!_isBangladeshPhone(_mobileController.text)) {
        _mobileError = 'সঠিক মোবাইল নম্বর দিন';
        valid = false;
      }
      if (_addressController.text.trim().isEmpty) {
        _addressError = 'এই ঘরটি পূরণ করা আবশ্যক';
        valid = false;
      }
    });
    return valid;
  }

  Future<void> _saveStoreDetails() async {
    if (!_validate()) {
      return;
    }
    setState(() => _saving = true);
    await Future<void>.delayed(const Duration(milliseconds: 700));
    if (!mounted) {
      return;
    }
    setState(() => _saving = false);
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('দোকানের তথ্য সংরক্ষণ করা হয়েছে')),
    );
  }
}

class _StoreSettingsCard extends StatelessWidget {
  const _StoreSettingsCard({
    required this.title,
    required this.child,
  });

  final String title;
  final Widget child;

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: const Color(0xFFE3EBE8)),
        boxShadow: const [
          BoxShadow(
            color: Color(0x0C21413C),
            blurRadius: 18,
            offset: Offset(0, 8),
          ),
        ],
      ),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              title,
              style: const TextStyle(
                color: Color(0xFF16302E),
                fontSize: 16,
                fontWeight: FontWeight.w800,
              ),
            ),
            const SizedBox(height: 14),
            child,
          ],
        ),
      ),
    );
  }
}

class _StoreInfoSummaryCard extends StatelessWidget {
  const _StoreInfoSummaryCard({
    required this.borderColor,
    required this.accent,
    required this.textColor,
    required this.mutedColor,
    required this.onViewDetails,
  });

  final Color borderColor;
  final Color accent;
  final Color textColor;
  final Color mutedColor;
  final VoidCallback onViewDetails;

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: borderColor),
        boxShadow: const [
          BoxShadow(
            color: Color(0x0C21413C),
            blurRadius: 18,
            offset: Offset(0, 8),
          ),
        ],
      ),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              width: 56,
              height: 56,
              decoration: BoxDecoration(
                color: accent.withValues(alpha: 0.12),
                borderRadius: BorderRadius.circular(16),
              ),
              child: const Icon(Icons.storefront_rounded, color: Color(0xFF0E8F5F), size: 28),
            ),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'রহিম মুদি ভান্ডার',
                    style: TextStyle(
                      color: textColor,
                      fontSize: 18,
                      fontWeight: FontWeight.w800,
                    ),
                  ),
                  const SizedBox(height: 5),
                  Text(
                    'মুদি দোকান',
                    style: TextStyle(
                      color: mutedColor,
                      fontSize: 13.5,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                  const SizedBox(height: 12),
                  Row(
                    children: [
                      Expanded(
                        child: TextButton(
                          onPressed: onViewDetails,
                          style: TextButton.styleFrom(
                            foregroundColor: accent,
                            backgroundColor: accent.withValues(alpha: 0.08),
                            padding: const EdgeInsets.symmetric(vertical: 12),
                            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                          ),
                          child: const Text(
                            'দেখুন / পরিবর্তন করুন',
                            style: TextStyle(fontWeight: FontWeight.w800),
                          ),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _StoreToggleTile extends StatelessWidget {
  const _StoreToggleTile({
    required this.label,
    required this.value,
    required this.onChanged,
  });

  final String label;
  final bool value;
  final ValueChanged<bool> onChanged;

  @override
  Widget build(BuildContext context) {
    return SwitchListTile.adaptive(
      value: value,
      onChanged: onChanged,
      contentPadding: EdgeInsets.zero,
      dense: true,
      activeThumbColor: const Color(0xFF0E8F5F),
      title: Text(
        label,
        style: const TextStyle(
          color: Color(0xFF16302E),
          fontSize: 14,
          fontWeight: FontWeight.w600,
        ),
      ),
    );
  }
}

class _SelectableStoreInfoRow extends StatelessWidget {
  const _SelectableStoreInfoRow({
    required this.label,
    required this.value,
    required this.icon,
    required this.onTap,
  });

  final String label;
  final String value;
  final IconData icon;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(16),
        child: Padding(
          padding: const EdgeInsets.symmetric(vertical: 2),
          child: Row(
            children: [
              Container(
                width: 38,
                height: 38,
                decoration: BoxDecoration(
                  color: const Color(0xFFEAF5F1),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Icon(icon, color: const Color(0xFF0E8F5F), size: 20),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      label,
                      style: const TextStyle(
                        color: Color(0xFF6F8280),
                        fontSize: 12.5,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      value,
                      style: const TextStyle(
                        color: Color(0xFF16302E),
                        fontSize: 14.5,
                        fontWeight: FontWeight.w800,
                      ),
                    ),
                  ],
                ),
              ),
              const Icon(Icons.keyboard_arrow_down_rounded, color: Color(0xFF8A9896)),
            ],
          ),
        ),
      ),
    );
  }
}

class _SelectableOptionBox extends StatelessWidget {
  const _SelectableOptionBox({
    required this.label,
    required this.selected,
    required this.onTap,
  });

  final String label;
  final bool selected;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: selected ? const Color(0xFFEAF5F1) : Colors.white,
      borderRadius: BorderRadius.circular(14),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(14),
        child: Container(
          width: double.infinity,
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(14),
            border: Border.all(
              color: selected ? const Color(0xFF0E8F5F) : const Color(0xFFE3EBE8),
            ),
          ),
          child: Text(
            label,
            style: const TextStyle(
              color: Color(0xFF16302E),
              fontSize: 14.5,
              fontWeight: FontWeight.w700,
            ),
          ),
        ),
      ),
    );
  }
}

class _StoreActionButton extends StatelessWidget {
  const _StoreActionButton({
    required this.label,
    required this.icon,
    required this.onPressed,
    this.outlined = false,
  });

  final String label;
  final IconData icon;
  final VoidCallback onPressed;
  final bool outlined;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: double.infinity,
      height: 50,
      child: outlined
          ? OutlinedButton.icon(
              onPressed: onPressed,
              icon: Icon(icon, size: 18),
              label: Text(label, style: const TextStyle(fontWeight: FontWeight.w800)),
              style: OutlinedButton.styleFrom(
                foregroundColor: const Color(0xFF16302E),
                side: const BorderSide(color: Color(0xFFE3EBE8)),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
              ),
            )
          : ElevatedButton.icon(
              onPressed: onPressed,
              icon: Icon(icon, size: 18),
              label: Text(label, style: const TextStyle(fontWeight: FontWeight.w800)),
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFF0E8F5F),
                foregroundColor: Colors.white,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                elevation: 0,
              ),
            ),
    );
  }
}

class _StoreLogoCard extends StatelessWidget {
  const _StoreLogoCard({required this.onTap});

  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: const Color(0xFFE3EBE8)),
        boxShadow: const [
          BoxShadow(
            color: Color(0x0C21413C),
            blurRadius: 18,
            offset: Offset(0, 8),
          ),
        ],
      ),
      child: Padding(
        padding: const EdgeInsets.all(18),
        child: Column(
          children: [
            Container(
              width: 76,
              height: 76,
              decoration: BoxDecoration(
                color: const Color(0xFFEAF5F1),
                borderRadius: BorderRadius.circular(24),
              ),
              child: const Icon(Icons.storefront_rounded, color: Color(0xFF0E8F5F), size: 36),
            ),
            const SizedBox(height: 14),
            const Text(
              'লোগো পরিবর্তন',
              style: TextStyle(
                color: Color(0xFF16302E),
                fontSize: 16,
                fontWeight: FontWeight.w800,
              ),
            ),
            const SizedBox(height: 8),
            Text(
              'দোকানের ব্র্যান্ডিং আরও সুন্দর করুন',
              textAlign: TextAlign.center,
              style: TextStyle(
                color: const Color(0xFF6F8280),
                fontSize: 12.8,
                fontWeight: FontWeight.w500,
              ),
            ),
            const SizedBox(height: 14),
            OutlinedButton(
              onPressed: onTap,
              style: OutlinedButton.styleFrom(
                foregroundColor: const Color(0xFF0E8F5F),
                side: const BorderSide(color: Color(0xFF0E8F5F)),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
              ),
              child: const Text(
                'লোগো নির্বাচন করুন',
                style: TextStyle(fontWeight: FontWeight.w800),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _StoreTextField extends StatelessWidget {
  const _StoreTextField({
    required this.label,
    required this.controller,
    required this.onChanged,
    this.errorText,
    this.keyboardType,
    this.maxLines = 1,
  });

  final String label;
  final TextEditingController controller;
  final ValueChanged<String> onChanged;
  final String? errorText;
  final TextInputType? keyboardType;
  final int maxLines;

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label,
          style: const TextStyle(
            color: Color(0xFF16302E),
            fontSize: 13,
            fontWeight: FontWeight.w700,
          ),
        ),
        const SizedBox(height: 8),
        TextField(
          controller: controller,
          keyboardType: keyboardType,
          maxLines: maxLines,
          onChanged: onChanged,
          decoration: InputDecoration(
            filled: true,
            fillColor: Colors.white,
            errorText: errorText,
            hintStyle: const TextStyle(color: Color(0xFF99A8A5)),
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(14),
              borderSide: const BorderSide(color: Color(0xFFE3EBE8)),
            ),
            enabledBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(14),
              borderSide: const BorderSide(color: Color(0xFFE3EBE8)),
            ),
            focusedBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(14),
              borderSide: const BorderSide(color: Color(0xFF0E8F5F), width: 1.4),
            ),
            errorBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(14),
              borderSide: const BorderSide(color: Color(0xFFE15241)),
            ),
            focusedErrorBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(14),
              borderSide: const BorderSide(color: Color(0xFFE15241), width: 1.4),
            ),
            contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 15),
          ),
          style: const TextStyle(
            color: Color(0xFF16302E),
            fontSize: 14.5,
            fontWeight: FontWeight.w600,
          ),
        ),
      ],
    );
  }
}

class _StoreDropdownField extends StatelessWidget {
  const _StoreDropdownField({
    required this.label,
    required this.value,
    required this.items,
    required this.onChanged,
  });

  final String label;
  final String value;
  final List<String> items;
  final ValueChanged<String?> onChanged;

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label,
          style: const TextStyle(
            color: Color(0xFF16302E),
            fontSize: 13,
            fontWeight: FontWeight.w700,
          ),
        ),
        const SizedBox(height: 8),
        DropdownButtonFormField<String>(
          dropdownColor: Colors.white,
          initialValue: value,
          onChanged: onChanged,
          decoration: InputDecoration(
            filled: true,
            fillColor: Colors.white,
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(14),
              borderSide: const BorderSide(color: Color(0xFFE3EBE8)),
            ),
            enabledBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(14),
              borderSide: const BorderSide(color: Color(0xFFE3EBE8)),
            ),
            focusedBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(14),
              borderSide: const BorderSide(color: Color(0xFF0E8F5F), width: 1.4),
            ),
            contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 15),
          ),
          items: items
              .map(
                (item) => DropdownMenuItem<String>(
                  value: item,
                  child: Text(
                    item,
                    style: const TextStyle(
                      color: Color(0xFF16302E),
                      fontSize: 14.5,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ),
              )
              .toList(growable: false),
        ),
      ],
    );
  }
}

class DokanAroOptionScreen extends ConsumerWidget {
  const DokanAroOptionScreen({super.key});

  static const Color _accent = Color(0xFF0E8F5F);
  static const Color _primaryText = Color(0xFF16302E);
  static const Color _secondaryText = Color(0xFF71827F);
  static const Color _cardBorder = Color(0xFFE2EBE8);

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final sections = <_MoreSection>[
      _MoreSection(
        title: 'ব্যবসা পরিচালনা',
        items: [
          _MoreItem(
            icon: Icons.person_outline_rounded,
            iconBackground: const Color(0xFFE5F4EF),
            iconColor: _accent,
            title: 'গ্রাহক',
            subtitle: 'গ্রাহকের তথ্য ও বাকি',
            onTap: () => Navigator.of(context).push(
              MaterialPageRoute(builder: (_) => const DokanCustomerListScreen()),
            ),
          ),
          _MoreItem(
            icon: Icons.local_shipping_outlined,
            iconBackground: const Color(0xFFFFF4E5),
            iconColor: const Color(0xFFDF8B1D),
            title: 'সরবরাহকারী',
            subtitle: 'সরবরাহকারীর তথ্য',
            onTap: () => Navigator.of(context).push(
              MaterialPageRoute(builder: (_) => const DokanSupplierListScreen()),
            ),
          ),
          _MoreItem(
            icon: Icons.badge_outlined,
            iconBackground: const Color(0xFFEAF0FF),
            iconColor: const Color(0xFF4A6CF7),
            title: 'কর্মচারী',
            subtitle: 'স্টাফ পরিচালনা',
            onTap: () => Navigator.of(context).push(
              MaterialPageRoute(builder: (_) => const DokanStaffListScreen()),
            ),
          ),
          _MoreItem(
            icon: Icons.payments_outlined,
            iconBackground: const Color(0xFFFDECEC),
            iconColor: const Color(0xFFE15241),
            title: 'খরচ',
            subtitle: 'দৈনিক খরচ',
            onTap: () => Navigator.of(context).push(
              MaterialPageRoute(builder: (_) => const DokanExpenseReportScreen()),
            ),
          ),
          _MoreItem(
            icon: Icons.account_balance_wallet_outlined,
            iconBackground: const Color(0xFFEAF5F1),
            iconColor: _accent,
            title: 'হিসাব',
            subtitle: 'আয়-ব্যয়ের হিসাব',
            onTap: () => Navigator.of(context).push(
              MaterialPageRoute(builder: (_) => const DokanReportsHomeScreen()),
            ),
          ),
          _MoreItem(
            icon: Icons.bar_chart_outlined,
            iconBackground: const Color(0xFFF2EDFF),
            iconColor: const Color(0xFF7B4DF2),
            title: 'রিপোর্ট',
            subtitle: 'লাভ-ক্ষতির রিপোর্ট',
            onTap: () => Navigator.of(context).push(
              MaterialPageRoute(builder: (_) => const DokanStockValueReportScreen()),
            ),
          ),
        ],
      ),
      _MoreSection(
        title: 'সাবস্ক্রিপশন',
        items: [
          _MoreItem(
            icon: Icons.workspace_premium_outlined,
            iconBackground: const Color(0xFFEAF5F1),
            iconColor: _accent,
            title: 'প্ল্যান ও পেমেন্ট',
            subtitle: 'সাবস্ক্রিপশন প্ল্যান দেখুন',
            onTap: () => Navigator.of(context).push(
              MaterialPageRoute(
                builder: (_) => const DokanNotificationSubscriptionSettingsScreen(),
              ),
            ),
          ),
        ],
      ),
      _MoreSection(
        title: 'দোকান',
        items: [
          _MoreItem(
            icon: Icons.storefront_outlined,
            iconBackground: const Color(0xFFEAF5F1),
            iconColor: _accent,
            title: 'দোকানের তথ্য',
            subtitle: 'দোকানের প্রোফাইল দেখুন',
            onTap: () => Navigator.of(context).push(
              MaterialPageRoute(builder: (_) => const DokanShopSettingsScreen()),
            ),
          ),
          _MoreItem(
            icon: Icons.edit_outlined,
            iconBackground: const Color(0xFFEAF0FF),
            iconColor: const Color(0xFF4A6CF7),
            title: 'দোকান সম্পাদনা',
            subtitle: 'দোকানের তথ্য আপডেট করুন',
            onTap: () => Navigator.of(context).push(
              MaterialPageRoute(builder: (_) => const DokanStoreDetailsScreen()),
            ),
          ),
        ],
      ),
      _MoreSection(
        title: 'নোটিফিকেশন',
        items: [
          _MoreItem(
            icon: Icons.notifications_none_rounded,
            iconBackground: const Color(0xFFFFF4E5),
            iconColor: const Color(0xFFDF8B1D),
            title: 'নোটিফিকেশন সেটিংস',
            subtitle: 'সতর্কবার্তা নিয়ন্ত্রণ করুন',
            onTap: () => Navigator.of(context).push(
              MaterialPageRoute(
                builder: (_) => const DokanNotificationCenterScreen(),
              ),
            ),
          ),
        ],
      ),
      _MoreSection(
        title: 'অ্যাপ সেটিংস',
        items: [
          _MoreItem(
            icon: Icons.tune_rounded,
            iconBackground: const Color(0xFFEAF5F1),
            iconColor: _accent,
            title: 'অ্যাপ কনফিগারেশন',
            subtitle: 'অ্যাপের সেটআপ কাস্টমাইজ করুন',
            onTap: () => Navigator.of(context).push(
              MaterialPageRoute(builder: (_) => const DokanAppConfigurationScreen()),
            ),
          ),
        ],
      ),
      _MoreSection(
        title: 'সাহায্য',
        items: [
          _MoreItem(
            icon: Icons.help_outline_rounded,
            iconBackground: const Color(0xFFEAF0FF),
            iconColor: const Color(0xFF4A6CF7),
            title: 'গাইড ও সাপোর্ট',
            subtitle: 'সহায়তা ও ব্যবহার নির্দেশনা',
            onTap: () => Navigator.of(context).push(
              MaterialPageRoute(builder: (_) => const DokanHelpSupportScreen()),
            ),
          ),
        ],
      ),
      _MoreSection(
        title: 'অ্যাকাউন্ট',
        items: [
          _MoreItem(
            icon: Icons.logout_rounded,
            iconBackground: const Color(0xFFFDECEC),
            iconColor: const Color(0xFFE15241),
            title: 'লগ আউট',
            subtitle: 'অ্যাকাউন্ট থেকে বের হয়ে যান',
            titleColor: const Color(0xFFE15241),
            onTap: () => _showLogoutDialog(context, ref),
          ),
        ],
      ),
    ];

    return Scaffold(
      backgroundColor: const Color(0xFFF4F7FB),
      body: SafeArea(
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 12, 16, 0),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  _HeaderButton(
                    icon: Icons.arrow_back_rounded,
                    onTap: () => Navigator.of(context).popUntil((r) => r.isFirst),
                  ),
                  const SizedBox(width: 14),
                  const Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'আরও অপশন',
                          style: TextStyle(
                            color: _primaryText,
                            fontSize: 22,
                            fontWeight: FontWeight.w800,
                          ),
                        ),
                        SizedBox(height: 4),
                        Text(
                          'দোকান, হিসাব, কর্মচারী ও সেটিংস এক জায়গায়',
                          style: TextStyle(
                            color: _secondaryText,
                            fontSize: 13,
                            fontWeight: FontWeight.w500,
                            height: 1.3,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            Expanded(
              child: ListView(
                physics: const BouncingScrollPhysics(),
                padding: const EdgeInsets.fromLTRB(16, 16, 16, 20),
                children: [
                  _ProfileCard(
                    shopName: 'রহিম মুদি ভান্ডার',
                    ownerName: 'আবদুর রহিম',
                    badgeText: 'ফ্রি প্ল্যান',
                    accent: _accent,
                  ),
                  const SizedBox(height: 18),
                  ...sections.map(
                    (section) => Padding(
                      padding: const EdgeInsets.only(bottom: 18),
                      child: _MoreSectionView(
                        title: section.title,
                        items: section.items,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
      bottomNavigationBar: _MoreBottomNav(
        selectedIndex: 4,
        onHomeTap: () => Navigator.of(context).popUntil((r) => r.isFirst),
        onSalesTap: () => Navigator.of(context).pushReplacement(
          MaterialPageRoute(builder: (_) => const DokanPosMainScreen()),
        ),
        onProductsTap: () => Navigator.of(context).pushReplacement(
          MaterialPageRoute(builder: (_) => const DokanProductListScreen()),
        ),
        onReportsTap: () => Navigator.of(context).pushReplacement(
          MaterialPageRoute(builder: (_) => const DokanReportsHomeScreen()),
        ),
      ),
    );
  }

  void _showLogoutDialog(BuildContext context, WidgetRef ref) {
    showDialog(
      context: context,
      builder: (dialogContext) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
        title: const Text('লগ আউট'),
        content: const Text('আপনি কি সত্যিই এই অ্যাকাউন্ট থেকে লগ আউট করতে চান?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(dialogContext).pop(),
            child: const Text('বাতিল'),
          ),
          ElevatedButton(
  onPressed: () {
    Navigator.of(dialogContext).pop();

    ref.read(dokanAppFlowProvider.notifier).goToLogin();

    Navigator.of(context, rootNavigator: true).popUntil(
      (route) => route.isFirst,
    );
  },
  style: ElevatedButton.styleFrom(backgroundColor: Colors.red),
  child: const Text(
    'লগ আউট',
    style: TextStyle(color: Colors.white),
  ),
),
        ],
      ),
    );
  }
}

class _ProfileCard extends StatelessWidget {
  const _ProfileCard({
    required this.shopName,
    required this.ownerName,
    required this.badgeText,
    required this.accent,
  });

  final String shopName;
  final String ownerName;
  final String badgeText;
  final Color accent;

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            accent,
            const Color(0xFF0E7E57),
          ],
        ),
        borderRadius: BorderRadius.circular(16),
        boxShadow: const [
          BoxShadow(
            color: Color(0x220B5B40),
            blurRadius: 20,
            offset: Offset(0, 10),
          ),
        ],
      ),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              width: 44,
              height: 44,
              decoration: BoxDecoration(
                color: Colors.white.withValues(alpha: 0.92),
                borderRadius: BorderRadius.circular(12),
              ),
              child: const Icon(
                Icons.storefront_rounded,
                color: Color(0xFF0E7E57),
                size: 24,
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    shopName,
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 20,
                      fontWeight: FontWeight.w800,
                      height: 1.1,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    'মালিক: $ownerName',
                    style: TextStyle(
                      color: Colors.white.withValues(alpha: 0.86),
                      fontSize: 13,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                  const SizedBox(height: 12),
                  Row(
                    children: [
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
                        decoration: BoxDecoration(
                          color: Colors.white.withValues(alpha: 0.18),
                          borderRadius: BorderRadius.circular(999),
                          border: Border.all(color: Colors.white.withValues(alpha: 0.18)),
                        ),
                        child: Text(
                          badgeText,
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 12,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                      ),
                      const SizedBox(width: 8),
                      _MiniActionButton(
                        icon: Icons.refresh_rounded,
                        onTap: () {},
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class DokanAppConfigurationScreen extends StatefulWidget {
  const DokanAppConfigurationScreen({super.key});

  @override
  State<DokanAppConfigurationScreen> createState() => _DokanAppConfigurationScreenState();
}

class _DokanAppConfigurationScreenState extends State<DokanAppConfigurationScreen> {
  static const Color _bg = Color(0xFFF4F7FB);
  static const Color _text = Color(0xFF16302E);
  static const Color _muted = Color(0xFF6F8280);
  static const Color _accent = Color(0xFF0E8F5F);

  String _taxCharge = 'ভ্যাট ১৫%';
  String _generalSetting = 'বাংলা, কমপ্যাক্ট ভিউ';
  bool _lowStockAlert = true;
  bool _barcodeRequired = true;
  bool _offlineCache = true;
  bool _sound = true;
  bool _vibration = false;

  @override
  Widget build(BuildContext context) {
    final bottomPadding = MediaQuery.viewInsetsOf(context).bottom + 24;

    return Scaffold(
      backgroundColor: _bg,
      appBar: AppBar(
        backgroundColor: _bg,
        surfaceTintColor: _bg,
        elevation: 0,
        centerTitle: false,
        leading: Padding(
          padding: const EdgeInsets.only(left: 16),
          child: IconButton(
            onPressed: () => Navigator.of(context).maybePop(),
            icon: const Icon(Icons.arrow_back_rounded),
            style: IconButton.styleFrom(
              backgroundColor: Colors.white,
              foregroundColor: _text,
            ),
          ),
        ),
        leadingWidth: 72,
        title: const Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'অ্যাপ কনফিগারেশন',
              style: TextStyle(
                color: _text,
                fontSize: 19,
                fontWeight: FontWeight.w800,
              ),
            ),
            SizedBox(height: 4),
            Text(
              'আপনার দোকান ও ইনভেন্টরি সম্পর্কিত সেটিংস পরিচালনা করুন',
              style: TextStyle(
                color: _muted,
                fontSize: 12.5,
                fontWeight: FontWeight.w500,
                height: 1.25,
              ),
            ),
          ],
        ),
      ),
      body: SafeArea(
        child: LayoutBuilder(
          builder: (context, constraints) {
            final contentWidth = constraints.maxWidth > 760 ? 760.0 : constraints.maxWidth;

            return CustomScrollView(
              physics: const AlwaysScrollableScrollPhysics(parent: BouncingScrollPhysics()),
              keyboardDismissBehavior: ScrollViewKeyboardDismissBehavior.onDrag,
              slivers: [
                SliverPadding(
                  padding: EdgeInsets.fromLTRB(16, 8, 16, bottomPadding),
                  sliver: SliverToBoxAdapter(
                    child: Center(
                      child: ConstrainedBox(
                        constraints: BoxConstraints(maxWidth: contentWidth),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.stretch,
                          children: [
                            Container(
                              padding: const EdgeInsets.all(18),
                              decoration: BoxDecoration(
                                gradient: const LinearGradient(
                                  begin: Alignment.topLeft,
                                  end: Alignment.bottomRight,
                                  colors: [Color(0xFF0E8F5F), Color(0xFF0A6F4A)],
                                ),
                                borderRadius: BorderRadius.circular(24),
                                boxShadow: const [
                                  BoxShadow(
                                    color: Color(0x220B5B40),
                                    blurRadius: 22,
                                    offset: Offset(0, 10),
                                  ),
                                ],
                              ),
                              child: Row(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Container(
                                    width: 54,
                                    height: 54,
                                    decoration: BoxDecoration(
                                      color: Colors.white.withValues(alpha: 0.16),
                                      borderRadius: BorderRadius.circular(16),
                                    ),
                                    child: const Icon(
                                      Icons.tune_rounded,
                                      color: Colors.white,
                                      size: 28,
                                    ),
                                  ),
                                  const SizedBox(width: 14),
                                  Expanded(
                                    child: Column(
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        const Text(
                                          'ব্যবসা-উপযোগী সেটআপ',
                                          style: TextStyle(
                                            color: Colors.white,
                                            fontSize: 20,
                                            fontWeight: FontWeight.w800,
                                            height: 1.1,
                                          ),
                                        ),
                                        const SizedBox(height: 6),
                                        Text(
                                          'স্টোর, ইনভেন্টরি, ট্যাক্স এবং অ্যাপ আচরণ এক জায়গা থেকে নিয়ন্ত্রণ করুন।',
                                          style: TextStyle(
                                            color: Colors.white.withValues(alpha: 0.88),
                                            fontSize: 13.5,
                                            fontWeight: FontWeight.w500,
                                            height: 1.4,
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                  const SizedBox(width: 12),
                                  Container(
                                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 7),
                                    decoration: BoxDecoration(
                                      color: Colors.white.withValues(alpha: 0.14),
                                      borderRadius: BorderRadius.circular(999),
                                      border: Border.all(color: Colors.white.withValues(alpha: 0.16)),
                                    ),
                                    child: const Text(
                                      'প্রোডাকশন রেডি',
                                      style: TextStyle(
                                        color: Colors.white,
                                        fontSize: 11.5,
                                        fontWeight: FontWeight.w700,
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            const SizedBox(height: 14),
                            _StoreSettingsCard(
                              title: 'স্টোর ম্যানেজমেন্ট',
                              child: _StoreActionButton(
                                label: 'স্টোর ম্যানেজমেন্ট',
                                icon: Icons.warehouse_rounded,
                                onPressed: () => _showStoreManagementSheet(context),
                              ),
                            ),
                            const SizedBox(height: 14),
                            _StoreSettingsCard(
                              title: 'ইনভেন্টরি ম্যানেজমেন্ট',
                              child: Column(
                                children: [
                                  _SelectableStoreInfoRow(
                                    label: "\u0987\u09a8\u09ad\u09c7\u09a8\u09cd\u099f\u09b0\u09bf \u09b8\u09c7\u099f\u09bf\u0982\u09b8",
                                    value: "\u09b8\u09cd\u099f\u0995 \u09b0\u09c1\u09b2\u09b8 \u0993 \u09a5\u09cd\u09b0\u09c7\u09b6\u09b9\u09cb\u09b2\u09cd\u09a1",
                                    icon: Icons.inventory_2_rounded,
                                    onTap: () => Navigator.of(context).push(
                                      MaterialPageRoute(
                                        builder: (_) => const DokanInventorySettingsScreen(),
                                      ),
                                    ),
                                  ),
                                  const SizedBox(height: 12),
                                  _SelectableStoreInfoRow(
                                    label: "\u0987\u09a8\u09ad\u09c7\u09a8\u09cd\u099f\u09b0\u09bf \u09ac\u09cd\u09af\u09ac\u09b8\u09cd\u09a5\u09be\u09aa\u09a8\u09be",
                                    value: "\u0987\u0989\u09a8\u09bf\u099f \u0993 \u0995\u09cd\u09af\u09be\u099f\u09c7\u0997\u09b0\u09bf",
                                    icon: Icons.category_outlined,
                                    onTap: () => Navigator.of(context).push(
                                      MaterialPageRoute(
                                        builder: (_) => const DokanUnitCategoryScreen(),
                                      ),
                                    ),
                                  ),
                                  const SizedBox(height: 12),
                                  _SelectableStoreInfoRow(
                                    label: 'ট্যাক্স ও চার্জ',
                                    value: _taxCharge,
                                    icon: Icons.receipt_long_rounded,
                                    onTap: () {
  Navigator.of(context).push(
    MaterialPageRoute(
      builder: (_) => const DokanTaxChargesManagementScreen(),
    ),
  );
},
                                  ),
                                ],
                              ),
                            ),
                            const SizedBox(height: 14),
                            _StoreSettingsCard(
                              title: 'অ্যাপ পছন্দসমূহ',
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  _SelectableStoreInfoRow(
                                    label: 'সাধারণ সেটিংস',
                                    value: _generalSetting,
                                    icon: Icons.settings_suggest_rounded,
                                    onTap: () => _showChoiceSheet(
                                      context: context,
                                      title: 'সাধারণ সেটিংস',
                                      description: 'অ্যাপের সাধারণ আচরণ ও উপস্থাপন নির্বাচন করুন।',
                                      selected: _generalSetting,
                                      options: const ['বাংলা, কমপ্যাক্ট ভিউ', 'বাংলা, স্ট্যান্ডার্ড ভিউ', 'English, Standard View'],
                                      onSelected: (value) => setState(() => _generalSetting = value),
                                    ),
                                  ),
                                  const SizedBox(height: 8),
                                  const Text(
                                    'ব্যবহারিক আচরণ',
                                    style: TextStyle(
                                      color: _muted,
                                      fontSize: 12.5,
                                      fontWeight: FontWeight.w700,
                                    ),
                                  ),
                                  const SizedBox(height: 8),
                                  _StoreToggleTile(
                                    label: 'লো-স্টক সতর্কতা',
                                    value: _lowStockAlert,
                                    onChanged: (value) => setState(() => _lowStockAlert = value),
                                  ),
                                  _StoreToggleTile(
                                    label: 'বারকোড বাধ্যতামূলক',
                                    value: _barcodeRequired,
                                    onChanged: (value) => setState(() => _barcodeRequired = value),
                                  ),
                                  _StoreToggleTile(
                                    label: 'অফলাইন ক্যাশ',
                                    value: _offlineCache,
                                    onChanged: (value) => setState(() => _offlineCache = value),
                                  ),
                                  _StoreToggleTile(
                                    label: 'সাউন্ড নোটিফিকেশন',
                                    value: _sound,
                                    onChanged: (value) => setState(() => _sound = value),
                                  ),
                                  _StoreToggleTile(
                                    label: 'ভাইব্রেশন',
                                    value: _vibration,
                                    onChanged: (value) => setState(() => _vibration = value),
                                  ),
                                ],
                              ),
                            ),
                            const SizedBox(height: 14),
                            Container(
                              decoration: BoxDecoration(
                                color: Colors.white,
                                borderRadius: BorderRadius.circular(20),
                                border: Border.all(color: const Color(0xFFE3EBE8)),
                                boxShadow: const [
                                  BoxShadow(
                                    color: Color(0x0C21413C),
                                    blurRadius: 18,
                                    offset: Offset(0, 8),
                                  ),
                                ],
                              ),
                              child: Padding(
                                padding: const EdgeInsets.all(16),
                                child: Row(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Container(
                                      width: 52,
                                      height: 52,
                                      decoration: BoxDecoration(
                                        color: const Color(0xFFEAF5F1),
                                        borderRadius: BorderRadius.circular(16),
                                      ),
                                      child: const Icon(
                                        Icons.storefront_rounded,
                                        color: _accent,
                                        size: 28,
                                      ),
                                    ),
                                    const SizedBox(width: 14),
                                    Expanded(
                                      child: Column(
                                        crossAxisAlignment: CrossAxisAlignment.start,
                                        children: [
                                          const Text(
                                            'DokanERP',
                                            style: TextStyle(
                                              color: _text,
                                              fontSize: 18,
                                              fontWeight: FontWeight.w800,
                                            ),
                                          ),
                                          const SizedBox(height: 4),
                                          const Text(
                                            'দোকান ব্যবসা ERP সিস্টেম',
                                            style: TextStyle(
                                              color: _muted,
                                              fontSize: 13,
                                              fontWeight: FontWeight.w500,
                                            ),
                                          ),
                                          const SizedBox(height: 10),
                                          Wrap(
                                            spacing: 8,
                                            runSpacing: 8,
                                            children: [
                                              _AppConfigFooterChip(
                                                label: 'ভার্সন 1.0.0',
                                                icon: Icons.verified_rounded,
                                              ),
                                              _AppConfigFooterChip(
                                                label: '© 2026 DokanERP',
                                                icon: Icons.copyright_rounded,
                                              ),
                                            ],
                                          ),
                                        ],
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            );
          },
        ),
      ),
    );
  }

  void _showChoiceSheet({
    required BuildContext context,
    required String title,
    required String description,
    required String selected,
    required List<String> options,
    required ValueChanged<String> onSelected,
  }) {
    showModalBottomSheet<void>(
      context: context,
      backgroundColor: Colors.transparent,
      builder: (sheetContext) {
        return SafeArea(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(12, 0, 12, 12),
            child: Container(
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(20),
                boxShadow: const [
                  BoxShadow(
                    color: Color(0x22000000),
                    blurRadius: 20,
                    offset: Offset(0, 10),
                  ),
                ],
              ),
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      title,
                      style: const TextStyle(
                        color: _text,
                        fontSize: 16,
                        fontWeight: FontWeight.w800,
                      ),
                    ),
                    const SizedBox(height: 6),
                    Text(
                      description,
                      style: const TextStyle(
                        color: _muted,
                        fontSize: 12.5,
                        height: 1.35,
                      ),
                    ),
                    const SizedBox(height: 12),
                    ...options.map(
                      (option) => Padding(
                        padding: const EdgeInsets.only(bottom: 10),
                        child: _SelectableOptionBox(
                          label: option,
                          selected: option == selected,
                          onTap: () {
                            onSelected(option);
                            Navigator.of(sheetContext).pop();
                          },
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        );
      },
    );
  }

  void _showStoreManagementSheet(BuildContext context) {
    Navigator.of(context).push(
      MaterialPageRoute(
        builder: (_) => const DokanInventoryModeSelectionScreen(),
      ),
    );
  }
}


class DokanInventorySettingsScreen extends StatefulWidget {
  const DokanInventorySettingsScreen({super.key});

  @override
  State<DokanInventorySettingsScreen> createState() => _DokanInventorySettingsScreenState();
}

class _DokanInventorySettingsScreenState extends State<DokanInventorySettingsScreen> {
  static const Color _bg = Color(0xFFF4F7FB);
  static const Color _text = Color(0xFF16302E);
  static const Color _muted = Color(0xFF6F8280);
  static const Color _accent = Color(0xFF0E8F5F);
  static const Color _border = Color(0xFFE3EBE8);
  static const Color _warning = Color(0xFFD9822B);

  late final TextEditingController _lowStockLimitCtrl;
  late final TextEditingController _criticalStockLimitCtrl;
  bool _autoLowStockAlert = true;

  bool _autoDeductOnSale = true;
  bool _allowNegativeStock = false;
  bool _binAssignmentRequired = true;
  bool _showBinOnSale = true;
  bool _trackExpiry = false;

  String _costingMethod = 'FIFO';

  @override
  void initState() {
    super.initState();
    _lowStockLimitCtrl = TextEditingController(text: '10');
    _criticalStockLimitCtrl = TextEditingController(text: '5');
  }

  @override
  void dispose() {
    _lowStockLimitCtrl.dispose();
    _criticalStockLimitCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _bg,
      appBar: AppBar(
        backgroundColor: _bg,
        surfaceTintColor: _bg,
        elevation: 0,
        centerTitle: false,
        leading: Padding(
          padding: const EdgeInsets.only(left: 16),
          child: IconButton(
            onPressed: () => Navigator.of(context).maybePop(),
            icon: const Icon(Icons.arrow_back_rounded),
            style: IconButton.styleFrom(
              backgroundColor: Colors.white,
              foregroundColor: _text,
            ),
          ),
        ),
        leadingWidth: 72,
        title: const Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'ইনভেন্টরি সেটিংস',
              style: TextStyle(
                color: _text,
                fontSize: 19,
                fontWeight: FontWeight.w800,
              ),
            ),
            SizedBox(height: 4),
            Text(
              'স্টক রুলস এবং থ্রেশহোল্ড সেট করুন',
              style: TextStyle(
                color: _muted,
                fontSize: 12.5,
                fontWeight: FontWeight.w500,
                height: 1.25,
              ),
            ),
          ],
        ),
      ),
      body: SafeArea(
        child: CustomScrollView(
          physics: const AlwaysScrollableScrollPhysics(parent: BouncingScrollPhysics()),
          slivers: [
            SliverPadding(
              padding: const EdgeInsets.fromLTRB(16, 12, 16, 120),
              sliver: SliverToBoxAdapter(
                child: Center(
                  child: ConstrainedBox(
                    constraints: const BoxConstraints(maxWidth: 760),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        // ─── Section 1: কম স্টক সতর্কতা ───
                        _buildSectionCard(
                          title: 'কম স্টক সতর্কতা',
                          icon: Icons.notifications_active_rounded,
                          children: [
                            _StoreTextField(
                              label: 'কম স্টক সীমা',
                              controller: _lowStockLimitCtrl,
                              onChanged: (_) {},
                              keyboardType: TextInputType.number,
                            ),
                            const SizedBox(height: 6),
                            const Padding(
                              padding: EdgeInsets.only(left: 2, bottom: 10),
                              child: Text(
                                'এর নিচে হলে সতর্কবার্তা',
                                style: TextStyle(color: _muted, fontSize: 11.5, fontWeight: FontWeight.w500),
                              ),
                            ),
                            _StoreTextField(
                              label: 'জরুরি স্টক সীমা',
                              controller: _criticalStockLimitCtrl,
                              onChanged: (_) {},
                              keyboardType: TextInputType.number,
                            ),
                            const SizedBox(height: 6),
                            const Padding(
                              padding: EdgeInsets.only(left: 2, bottom: 4),
                              child: Text(
                                'লাল সতর্কতা দেখাবে',
                                style: TextStyle(color: _muted, fontSize: 11.5, fontWeight: FontWeight.w500),
                              ),
                            ),
                            _buildSwitchTile(
                              label: 'স্বয়ংক্রিয় কম স্টক সতর্কতা',
                              description: 'ড্যাশবোর্ডে সতর্কতা দেখাবে',
                              value: _autoLowStockAlert,
                              onChanged: (v) => setState(() => _autoLowStockAlert = v),
                            ),
                          ],
                        ),
                        const SizedBox(height: 14),
                        // ─── Section 2: স্টক নিয়মাবলী ───
                        _buildSectionCard(
                          title: 'স্টক নিয়মাবলী',
                          icon: Icons.rule_rounded,
                          children: [
                            _buildSwitchTile(
                              label: 'বিক্রয়ে স্বয়ংক্রিয় স্টক কমানো',
                              description: 'বিক্রির সময় স্টক কমবে',
                              value: _autoDeductOnSale,
                              onChanged: (v) => setState(() => _autoDeductOnSale = v),
                            ),
                            _buildDivider(),
                            _buildSwitchTile(
                              label: 'নেগেটিভ স্টক অনুমোদন',
                              description: 'স্টক শূন্যের নিচে যেতে দেবে',
                              value: _allowNegativeStock,
                              onChanged: (v) => setState(() => _allowNegativeStock = v),
                            ),
                            _buildDivider(),
                            _buildSwitchTile(
                              label: 'বিন অ্যাসাইনমেন্ট আবশ্যক',
                              description: 'পণ্য যোগে বিন না দিলে সতর্কতা',
                              value: _binAssignmentRequired,
                              onChanged: (v) => setState(() => _binAssignmentRequired = v),
                            ),
                            _buildDivider(),
                            _buildSwitchTile(
                              label: 'বিক্রয়ে বিন লোকেশন দেখান',
                              description: 'কোথা থেকে নিতে হবে দেখাবে',
                              value: _showBinOnSale,
                              onChanged: (v) => setState(() => _showBinOnSale = v),
                            ),
                            _buildDivider(),
                            _buildSwitchTile(
                              label: 'মেয়াদ ট্র্যাক করুন',
                              description: 'পণ্যের মেয়াদ উত্তীর্ণের তারিখ রাখুন',
                              value: _trackExpiry,
                              onChanged: (v) => setState(() => _trackExpiry = v),
                            ),
                          ],
                        ),
                        const SizedBox(height: 14),
                        // ─── Section 3: স্টক গণনা পদ্ধতি ───
                        _buildSectionCard(
                          title: 'স্টক গণনা পদ্ধতি',
                          icon: Icons.calculate_rounded,
                          children: [
                            _buildRadioTile(
                              label: 'FIFO',
                              description: 'আগে আসলে আগে যাবে',
                              value: 'FIFO',
                            ),
                            _buildDivider(),
                            _buildRadioTile(
                              label: 'LIFO',
                              description: 'পরে আসলে আগে যাবে',
                              value: 'LIFO',
                            ),
                          ],
                        ),
                        const SizedBox(height: 14),
                        // ─── Section 4: সতর্কতা নোটিশ ───
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
                          decoration: BoxDecoration(
                            color: _warning.withValues(alpha: 0.08),
                            borderRadius: BorderRadius.circular(16),
                            border: Border.all(color: _warning.withValues(alpha: 0.25)),
                          ),
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              const Icon(Icons.info_outline_rounded, color: _warning, size: 20),
                              const SizedBox(width: 10),
                              const Expanded(
                                child: Text(
                                  'পরিবর্তন সংরক্ষণ করলে বিদ্যমান স্টক ডেটা প্রভাবিত হতে পারে।',
                                  style: TextStyle(
                                    color: Color(0xFF7A4500),
                                    fontSize: 13,
                                    fontWeight: FontWeight.w500,
                                    height: 1.4,
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
      bottomNavigationBar: SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(16, 10, 16, 16),
          child: SizedBox(
            width: double.infinity,
            height: 52,
            child: ElevatedButton(
              onPressed: _save,
              style: ElevatedButton.styleFrom(
                backgroundColor: _accent,
                foregroundColor: Colors.white,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                elevation: 0,
              ),
              child: const Text(
                'সংরক্ষণ করুন',
                style: TextStyle(fontSize: 16, fontWeight: FontWeight.w800),
              ),
            ),
          ),
        ),
      ),
    );
  }

  void _save() {
    final lowStock = int.tryParse(_lowStockLimitCtrl.text.trim());
    final criticalStock = int.tryParse(_criticalStockLimitCtrl.text.trim());
    if (lowStock == null || criticalStock == null || lowStock < 0 || criticalStock < 0) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('সঠিক স্টক সীমা দিন'),
          backgroundColor: Color(0xFFE15241),
        ),
      );
      return;
    }
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: const Text('সেটিংস সংরক্ষিত হয়েছে'),
        backgroundColor: _accent,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        margin: const EdgeInsets.all(16),
      ),
    );
    Navigator.of(context).maybePop();
  }

  Widget _buildSectionCard({
    required String title,
    required IconData icon,
    required List<Widget> children,
  }) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: _border),
        boxShadow: const [
          BoxShadow(color: Color(0x0C21413C), blurRadius: 18, offset: Offset(0, 8)),
        ],
      ),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Container(
                  width: 34,
                  height: 34,
                  decoration: BoxDecoration(
                    color: _accent.withValues(alpha: 0.10),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: Icon(icon, color: _accent, size: 18),
                ),
                const SizedBox(width: 10),
                Text(
                  title,
                  style: const TextStyle(
                    color: _text,
                    fontSize: 15,
                    fontWeight: FontWeight.w800,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 16),
            ...children,
          ],
        ),
      ),
    );
  }

  Widget _buildSwitchTile({
    required String label,
    required String description,
    required bool value,
    required ValueChanged<bool> onChanged,
  }) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Row(
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(label, style: const TextStyle(color: _text, fontSize: 14, fontWeight: FontWeight.w700)),
                const SizedBox(height: 2),
                Text(description, style: const TextStyle(color: _muted, fontSize: 12, fontWeight: FontWeight.w500)),
              ],
            ),
          ),
          const SizedBox(width: 8),
          Switch.adaptive(value: value, onChanged: onChanged, activeThumbColor: _accent),
        ],
      ),
    );
  }

  Widget _buildRadioTile({
    required String label,
    required String description,
    required String value,
  }) {
    final selected = _costingMethod == value;
    return InkWell(
      onTap: () => setState(() => _costingMethod = value),
      borderRadius: BorderRadius.circular(12),
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 6),
        child: Row(
          children: [
            AnimatedContainer(
              duration: const Duration(milliseconds: 150),
              width: 20,
              height: 20,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                border: Border.all(
                  color: selected ? _accent : const Color(0xFFB0BEC5),
                  width: selected ? 5.5 : 2,
                ),
                color: Colors.white,
              ),
            ),
            const SizedBox(width: 8),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    label,
                    style: TextStyle(
                      color: selected ? _accent : _text,
                      fontSize: 14,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                  Text(description, style: const TextStyle(color: _muted, fontSize: 12, fontWeight: FontWeight.w500)),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildDivider() => const Divider(height: 1, thickness: 1, color: Color(0xFFF0F4F3));
}


// ─── Data Store (module-level, shared across tabs) ────────────────────────────

final _unitCategoryData = _UnitCategoryStore();

class _UnitCategoryStore {
  final categories = <_CategoryData>[
    _CategoryData(bangla: 'মুদি', english: 'Grocery'),
    _CategoryData(bangla: 'পানীয়', english: 'Drinks'),
    _CategoryData(bangla: 'স্ন্যাকস', english: 'Snacks'),
    _CategoryData(bangla: 'ডেইরি', english: 'Dairy'),
    _CategoryData(bangla: 'বেকারি', english: 'Bakery'),
    _CategoryData(bangla: 'পার্সোনাল কেয়ার', english: 'Personal Care'),
    _CategoryData(bangla: 'গৃহস্থালি', english: 'Household'),
  ];

  final units = <_UnitData>[
    _UnitData(bangla: 'পিস', english: 'Piece'),
    _UnitData(bangla: 'কেজি', english: 'KG'),
    _UnitData(bangla: 'গ্রাম', english: 'Gram'),
    _UnitData(bangla: 'লিটার', english: 'Liter'),
    _UnitData(bangla: 'মিলি', english: 'ML'),
    _UnitData(bangla: 'ডজন', english: 'Dozen'),
    _UnitData(bangla: 'বান্ডিল', english: 'Bundle'),
    _UnitData(bangla: 'বাক্স', english: 'Box'),
  ];
}

class _CategoryData {
  String bangla;
  String english;
  _CategoryData({required this.bangla, required this.english});
}

class _UnitData {
  String bangla;
  String english;
  _UnitData({required this.bangla, required this.english});
}

// ─── Main Screen ──────────────────────────────────────────────────────────────

class DokanUnitCategoryScreen extends StatefulWidget {
  const DokanUnitCategoryScreen({super.key});

  @override
  State<DokanUnitCategoryScreen> createState() => _DokanUnitCategoryScreenState();
}

class _DokanUnitCategoryScreenState extends State<DokanUnitCategoryScreen>
    with SingleTickerProviderStateMixin {
  static const Color _bg = Color(0xFFF4F7FB);
  static const Color _text = Color(0xFF16302E);
  static const Color _muted = Color(0xFF6F8280);
  static const Color _accent = Color(0xFF0E8F5F);
  static const Color _border = Color(0xFFE3EBE8);

  late final TabController _tabController;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this);
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _bg,
      appBar: AppBar(
        backgroundColor: _bg,
        surfaceTintColor: _bg,
        elevation: 0,
        centerTitle: false,
        leading: Padding(
          padding: const EdgeInsets.only(left: 16),
          child: IconButton(
            onPressed: () => Navigator.of(context).maybePop(),
            icon: const Icon(Icons.arrow_back_rounded),
            style: IconButton.styleFrom(
              backgroundColor: Colors.white,
              foregroundColor: _text,
            ),
          ),
        ),
        leadingWidth: 72,
        title: const Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'ইউনিট ও ক্যাটেগরি',
              style: TextStyle(color: _text, fontSize: 19, fontWeight: FontWeight.w800),
            ),
            SizedBox(height: 3),
            Text(
              'ইউনিট এবং ক্যাটেগরি ম্যানেজ করুন',
              style: TextStyle(color: _muted, fontSize: 12.5, fontWeight: FontWeight.w500, height: 1.25),
            ),
          ],
        ),
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(54),
          child: Padding(
            padding: const EdgeInsets.fromLTRB(16, 0, 16, 10),
            child: Container(
              height: 42,
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: _border),
              ),
              child: TabBar(
                controller: _tabController,
                dividerColor: Colors.transparent,
                indicator: BoxDecoration(
                  color: _accent,
                  borderRadius: BorderRadius.circular(10),
                ),
                indicatorSize: TabBarIndicatorSize.tab,
                labelColor: Colors.white,
                unselectedLabelColor: _muted,
                labelStyle: const TextStyle(fontSize: 14, fontWeight: FontWeight.w700),
                unselectedLabelStyle: const TextStyle(fontSize: 14, fontWeight: FontWeight.w600),
                padding: const EdgeInsets.all(3),
                tabs: const [
                  Tab(text: 'ক্যাটেগরি'),
                  Tab(text: 'ইউনিট'),
                ],
              ),
            ),
          ),
        ),
      ),
      body: TabBarView(
        controller: _tabController,
        children: [
          _CategoryListTab(onRefresh: () => setState(() {})),
          _UnitListTab(onRefresh: () => setState(() {})),
        ],
      ),
    );
  }
}

// ─── Category Tab ─────────────────────────────────────────────────────────────

class _CategoryListTab extends StatefulWidget {
  const _CategoryListTab({required this.onRefresh});
  final VoidCallback onRefresh;

  @override
  State<_CategoryListTab> createState() => _CategoryListTabState();
}

class _CategoryListTabState extends State<_CategoryListTab> {
  void _refresh() => setState(() {});

  void _showAddEdit([_CategoryData? existing]) {
    showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (_) => _AddEditCategorySheet(existing: existing, onSaved: _refresh),
    );
  }

  Future<void> _confirmDelete(_CategoryData item) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        backgroundColor: Colors.white,
        title: const Text('মুছে ফেলবেন?',
            style: TextStyle(color: Color(0xFF16302E), fontWeight: FontWeight.w800)),
        content: Text('"${item.bangla}" ক্যাটেগরিটি মুছে দেওয়া হবে।',
            style: const TextStyle(color: Color(0xFF6F8280))),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(ctx).pop(false),
            child: const Text('বাতিল', style: TextStyle(color: Color(0xFF6F8280))),
          ),
          TextButton(
            onPressed: () => Navigator.of(ctx).pop(true),
            child: const Text('মুছুন',
                style: TextStyle(color: Color(0xFFE15241), fontWeight: FontWeight.w700)),
          ),
        ],
      ),
    );
    if (confirmed == true && mounted) {
      _unitCategoryData.categories.remove(item);
      _refresh();
    }
  }

  @override
  Widget build(BuildContext context) {
    final cats = _unitCategoryData.categories;
    return CustomScrollView(
      physics: const AlwaysScrollableScrollPhysics(parent: BouncingScrollPhysics()),
      slivers: [
        SliverSafeArea(
          sliver: SliverPadding(
            padding: const EdgeInsets.fromLTRB(16, 16, 16, 32),
            sliver: SliverToBoxAdapter(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  _UCHeaderCard(
                    count: cats.length,
                    countSuffix: 'টি ক্যাটেগরি',
                    icon: Icons.category_rounded,
                    onAdd: () => _showAddEdit(),
                  ),
                  const SizedBox(height: 14),
                  if (cats.isEmpty)
                    const _UCEmptyState(
                      icon: Icons.category_outlined,
                      message: 'কোনো ক্যাটেগরি নেই। নতুন যোগ করুন।',
                    )
                  else
                    _UCList(
                      items: cats,
                      iconColor: const Color(0xFF0E8F5F),
                      icon: Icons.label_rounded,
                      onEdit: _showAddEdit,
                      onDelete: _confirmDelete,
                    ),
                ],
              ),
            ),
          ),
        ),
      ],
    );
  }
}

// ─── Unit Tab ─────────────────────────────────────────────────────────────────

class _UnitListTab extends StatefulWidget {
  const _UnitListTab({required this.onRefresh});
  final VoidCallback onRefresh;

  @override
  State<_UnitListTab> createState() => _UnitListTabState();
}

class _UnitListTabState extends State<_UnitListTab> {
  void _refresh() => setState(() {});

  void _showAddEdit([_UnitData? existing]) {
    showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (_) => _AddEditUnitSheet(existing: existing, onSaved: _refresh),
    );
  }

  Future<void> _confirmDelete(_UnitData item) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        backgroundColor: Colors.white,
        title: const Text('মুছে ফেলবেন?',
            style: TextStyle(color: Color(0xFF16302E), fontWeight: FontWeight.w800)),
        content: Text('"${item.bangla}" ইউনিটটি মুছে দেওয়া হবে।',
            style: const TextStyle(color: Color(0xFF6F8280))),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(ctx).pop(false),
            child: const Text('বাতিল', style: TextStyle(color: Color(0xFF6F8280))),
          ),
          TextButton(
            onPressed: () => Navigator.of(ctx).pop(true),
            child: const Text('মুছুন',
                style: TextStyle(color: Color(0xFFE15241), fontWeight: FontWeight.w700)),
          ),
        ],
      ),
    );
    if (confirmed == true && mounted) {
      _unitCategoryData.units.remove(item);
      _refresh();
    }
  }

  @override
  Widget build(BuildContext context) {
    final units = _unitCategoryData.units;
    return CustomScrollView(
      physics: const AlwaysScrollableScrollPhysics(parent: BouncingScrollPhysics()),
      slivers: [
        SliverSafeArea(
          sliver: SliverPadding(
            padding: const EdgeInsets.fromLTRB(16, 16, 16, 32),
            sliver: SliverToBoxAdapter(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  _UCHeaderCard(
                    count: units.length,
                    countSuffix: 'টি ইউনিট',
                    icon: Icons.straighten_rounded,
                    onAdd: () => _showAddEdit(),
                  ),
                  const SizedBox(height: 14),
                  if (units.isEmpty)
                    const _UCEmptyState(
                      icon: Icons.straighten_outlined,
                      message: 'কোনো ইউনিট নেই। নতুন যোগ করুন।',
                    )
                  else
                    _UCList(
                      items: units,
                      iconColor: Colors.blue,
                      icon: Icons.scale_rounded,
                      onEdit: _showAddEdit,
                      onDelete: _confirmDelete,
                    ),
                ],
              ),
            ),
          ),
        ),
      ],
    );
  }
}

// ─── Shared Widgets ───────────────────────────────────────────────────────────

class _UCHeaderCard extends StatelessWidget {
  const _UCHeaderCard({
    required this.count,
    required this.countSuffix,
    required this.icon,
    required this.onAdd,
  });

  final int count;
  final String countSuffix;
  final IconData icon;
  final VoidCallback onAdd;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [Color(0xFF0E8F5F), Color(0xFF0A6F4A)],
        ),
        borderRadius: BorderRadius.circular(20),
        boxShadow: const [
          BoxShadow(color: Color(0x220B5B40), blurRadius: 16, offset: Offset(0, 8)),
        ],
      ),
      child: Row(
        children: [
          Container(
            width: 48,
            height: 48,
            decoration: BoxDecoration(
              color: Colors.white.withValues(alpha: 0.15),
              borderRadius: BorderRadius.circular(14),
            ),
            child: Icon(icon, color: Colors.white, size: 24),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Text(
              '$count$countSuffix',
              style: const TextStyle(color: Colors.white, fontSize: 22, fontWeight: FontWeight.w800),
            ),
          ),
          ElevatedButton.icon(
            onPressed: onAdd,
            icon: const Icon(Icons.add_rounded, size: 17),
            label: const Text('নতুন যোগ করুন',
                style: TextStyle(fontWeight: FontWeight.w700, fontSize: 13)),
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.white,
              foregroundColor: const Color(0xFF0E8F5F),
              elevation: 0,
              padding: const EdgeInsets.symmetric(horizontal: 13, vertical: 10),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
            ),
          ),
        ],
      ),
    );
  }
}

class _UCList<T> extends StatelessWidget {
  const _UCList({
    required this.items,
    required this.iconColor,
    required this.icon,
    required this.onEdit,
    required this.onDelete,
  });

  final List<T> items;
  final Color iconColor;
  final IconData icon;
  final void Function(T) onEdit;
  final void Function(T) onDelete;

  String _getBangla(T item) =>
      item is _CategoryData ? item.bangla : (item as _UnitData).bangla;
  String _getEnglish(T item) =>
      item is _CategoryData ? item.english : (item as _UnitData).english;

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: const Color(0xFFE3EBE8)),
        boxShadow: const [
          BoxShadow(color: Color(0x0C21413C), blurRadius: 18, offset: Offset(0, 8)),
        ],
      ),
      child: Column(
        children: [
          for (int i = 0; i < items.length; i++) ...[
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 11),
              child: Row(
                children: [
                  Container(
                    width: 40,
                    height: 40,
                    decoration: BoxDecoration(
                      color: iconColor.withValues(alpha: 0.10),
                      borderRadius: BorderRadius.circular(11),
                    ),
                    child: Icon(icon, color: iconColor, size: 19),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(_getBangla(items[i]),
                            style: const TextStyle(
                                color: Color(0xFF16302E),
                                fontSize: 15,
                                fontWeight: FontWeight.w700)),
                        if (_getEnglish(items[i]).isNotEmpty)
                          Text(_getEnglish(items[i]),
                              style: const TextStyle(
                                  color: Color(0xFF6F8280),
                                  fontSize: 12.5,
                                  fontWeight: FontWeight.w500)),
                      ],
                    ),
                  ),
                  IconButton(
                    onPressed: () => onEdit(items[i]),
                    icon: const Icon(Icons.edit_rounded, size: 17),
                    style: IconButton.styleFrom(
                      foregroundColor: const Color(0xFF0E8F5F),
                      backgroundColor: const Color(0xFFEAF5F1),
                      padding: const EdgeInsets.all(7),
                      minimumSize: const Size(32, 32),
                    ),
                  ),
                  const SizedBox(width: 6),
                  IconButton(
                    onPressed: () => onDelete(items[i]),
                    icon: const Icon(Icons.delete_outline_rounded, size: 17),
                    style: IconButton.styleFrom(
                      foregroundColor: const Color(0xFFE15241),
                      backgroundColor: const Color(0xFFFEF0EF),
                      padding: const EdgeInsets.all(7),
                      minimumSize: const Size(32, 32),
                    ),
                  ),
                ],
              ),
            ),
            if (i < items.length - 1)
              const Divider(height: 1, indent: 16, endIndent: 16, color: Color(0xFFF0F4F3)),
          ],
        ],
      ),
    );
  }
}

class _UCEmptyState extends StatelessWidget {
  const _UCEmptyState({required this.icon, required this.message});
  final IconData icon;
  final String message;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 44),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: const Color(0xFFE3EBE8)),
      ),
      child: Column(
        children: [
          Icon(icon, size: 48, color: const Color(0xFFB0C4BE)),
          const SizedBox(height: 12),
          Text(message,
              style: const TextStyle(
                  color: Color(0xFF8A9896),
                  fontSize: 14,
                  fontWeight: FontWeight.w500),
              textAlign: TextAlign.center),
        ],
      ),
    );
  }
}

// ─── Add / Edit Sheets ────────────────────────────────────────────────────────

class _AddEditCategorySheet extends StatefulWidget {
  const _AddEditCategorySheet({this.existing, required this.onSaved});
  final _CategoryData? existing;
  final VoidCallback onSaved;

  @override
  State<_AddEditCategorySheet> createState() => _AddEditCategorySheetState();
}

class _AddEditCategorySheetState extends State<_AddEditCategorySheet> {
  static const Color _text = Color(0xFF16302E);
  static const Color _muted = Color(0xFF6F8280);

  late final TextEditingController _banglaCtrl;
  late final TextEditingController _englishCtrl;
  String? _banglaError;

  @override
  void initState() {
    super.initState();
    _banglaCtrl = TextEditingController(text: widget.existing?.bangla ?? '');
    _englishCtrl = TextEditingController(text: widget.existing?.english ?? '');
  }

  @override
  void dispose() {
    _banglaCtrl.dispose();
    _englishCtrl.dispose();
    super.dispose();
  }

  void _save() {
    final bangla = _banglaCtrl.text.trim();
    if (bangla.isEmpty) {
      setState(() => _banglaError = 'বাংলা নাম আবশ্যক');
      return;
    }
    final isDup = _unitCategoryData.categories
        .any((c) => c != widget.existing && c.bangla.trim() == bangla);
    if (isDup) {
      setState(() => _banglaError = 'এই নামে ক্যাটেগরি আগে থেকেই আছে');
      return;
    }
    final english = _englishCtrl.text.trim();
    if (widget.existing != null) {
      widget.existing!
        ..bangla = bangla
        ..english = english;
    } else {
      _unitCategoryData.categories.add(_CategoryData(bangla: bangla, english: english));
    }
    widget.onSaved();
    Navigator.of(context).pop();
  }

  @override
  Widget build(BuildContext context) {
    final isEdit = widget.existing != null;
    return SafeArea(
      child: Padding(
        padding: EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom),
        child: Container(
          margin: const EdgeInsets.fromLTRB(12, 0, 12, 12),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(24),
            boxShadow: const [
              BoxShadow(color: Color(0x22000000), blurRadius: 24, offset: Offset(0, -4)),
            ],
          ),
          child: SingleChildScrollView(
            padding: const EdgeInsets.fromLTRB(20, 16, 20, 24),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Center(
                  child: Container(
                    width: 40, height: 4,
                    margin: const EdgeInsets.only(bottom: 16),
                    decoration: BoxDecoration(
                        color: const Color(0xFFE0E0E0),
                        borderRadius: BorderRadius.circular(2)),
                  ),
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      isEdit ? 'ক্যাটেগরি সম্পাদনা' : 'নতুন ক্যাটেগরি যোগ করুন',
                      style: const TextStyle(
                          color: _text, fontSize: 17, fontWeight: FontWeight.w800),
                    ),
                    IconButton(
                      onPressed: () => Navigator.of(context).pop(),
                      icon: const Icon(Icons.close_rounded),
                      style: IconButton.styleFrom(foregroundColor: _muted),
                    ),
                  ],
                ),
                const SizedBox(height: 16),
                _StoreTextField(
                  label: 'বাংলা নাম *',
                  controller: _banglaCtrl,
                  onChanged: (_) => setState(() => _banglaError = null),
                  errorText: _banglaError,
                ),
                const SizedBox(height: 4),
                Padding(
                  padding: const EdgeInsets.only(left: 2, bottom: 14),
                  child: Text('যেমন: মুদি',
                      style: const TextStyle(color: _muted, fontSize: 11.5)),
                ),
                _StoreTextField(
                  label: 'ইংরেজি নাম',
                  controller: _englishCtrl,
                  onChanged: (_) {},
                ),
                const SizedBox(height: 4),
                const Padding(
                  padding: EdgeInsets.only(left: 2, bottom: 20),
                  child: Text('e.g. Grocery',
                      style: TextStyle(color: _muted, fontSize: 11.5)),
                ),
                _StoreActionButton(
                  label: isEdit ? 'পরিবর্তন সংরক্ষণ করুন' : 'ক্যাটেগরি যোগ করুন',
                  icon: isEdit ? Icons.save_rounded : Icons.add_rounded,
                  onPressed: _save,
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _AddEditUnitSheet extends StatefulWidget {
  const _AddEditUnitSheet({this.existing, required this.onSaved});
  final _UnitData? existing;
  final VoidCallback onSaved;

  @override
  State<_AddEditUnitSheet> createState() => _AddEditUnitSheetState();
}

class _AddEditUnitSheetState extends State<_AddEditUnitSheet> {
  static const Color _text = Color(0xFF16302E);
  static const Color _muted = Color(0xFF6F8280);

  late final TextEditingController _banglaCtrl;
  late final TextEditingController _englishCtrl;
  String? _banglaError;

  @override
  void initState() {
    super.initState();
    _banglaCtrl = TextEditingController(text: widget.existing?.bangla ?? '');
    _englishCtrl = TextEditingController(text: widget.existing?.english ?? '');
  }

  @override
  void dispose() {
    _banglaCtrl.dispose();
    _englishCtrl.dispose();
    super.dispose();
  }

  void _save() {
    final bangla = _banglaCtrl.text.trim();
    if (bangla.isEmpty) {
      setState(() => _banglaError = 'বাংলা নাম আবশ্যক');
      return;
    }
    final isDup = _unitCategoryData.units
        .any((u) => u != widget.existing && u.bangla.trim() == bangla);
    if (isDup) {
      setState(() => _banglaError = 'এই নামে ইউনিট আগে থেকেই আছে');
      return;
    }
    final english = _englishCtrl.text.trim();
    if (widget.existing != null) {
      widget.existing!
        ..bangla = bangla
        ..english = english;
    } else {
      _unitCategoryData.units.add(_UnitData(bangla: bangla, english: english));
    }
    widget.onSaved();
    Navigator.of(context).pop();
  }

  @override
  Widget build(BuildContext context) {
    final isEdit = widget.existing != null;
    return SafeArea(
      child: Padding(
        padding: EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom),
        child: Container(
          margin: const EdgeInsets.fromLTRB(12, 0, 12, 12),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(24),
            boxShadow: const [
              BoxShadow(color: Color(0x22000000), blurRadius: 24, offset: Offset(0, -4)),
            ],
          ),
          child: SingleChildScrollView(
            padding: const EdgeInsets.fromLTRB(20, 16, 20, 24),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Center(
                  child: Container(
                    width: 40, height: 4,
                    margin: const EdgeInsets.only(bottom: 16),
                    decoration: BoxDecoration(
                        color: const Color(0xFFE0E0E0),
                        borderRadius: BorderRadius.circular(2)),
                  ),
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      isEdit ? 'ইউনিট সম্পাদনা' : 'নতুন ইউনিট যোগ করুন',
                      style: const TextStyle(
                          color: _text, fontSize: 17, fontWeight: FontWeight.w800),
                    ),
                    IconButton(
                      onPressed: () => Navigator.of(context).pop(),
                      icon: const Icon(Icons.close_rounded),
                      style: IconButton.styleFrom(foregroundColor: _muted),
                    ),
                  ],
                ),
                const SizedBox(height: 16),
                _StoreTextField(
                  label: 'বাংলা নাম *',
                  controller: _banglaCtrl,
                  onChanged: (_) => setState(() => _banglaError = null),
                  errorText: _banglaError,
                ),
                const SizedBox(height: 4),
                Padding(
                  padding: const EdgeInsets.only(left: 2, bottom: 14),
                  child: Text('যেমন: পিস',
                      style: const TextStyle(color: _muted, fontSize: 11.5)),
                ),
                _StoreTextField(
                  label: 'ইংরেজি নাম',
                  controller: _englishCtrl,
                  onChanged: (_) {},
                ),
                const SizedBox(height: 4),
                const Padding(
                  padding: EdgeInsets.only(left: 2, bottom: 20),
                  child: Text('e.g. Piece',
                      style: TextStyle(color: _muted, fontSize: 11.5)),
                ),
                _StoreActionButton(
                  label: isEdit ? 'পরিবর্তন সংরক্ষণ করুন' : 'ইউনিট যোগ করুন',
                  icon: isEdit ? Icons.save_rounded : Icons.add_rounded,
                  onPressed: _save,
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}



enum _InventoryModeType {
  basic,
  advanced;

  String get title => switch (this) {
        _InventoryModeType.basic => 'সাধারণ ইনভেন্টরি মোড',
        _InventoryModeType.advanced => 'অ্যাডভান্সড র‍্যাক ইনভেন্টরি মোড',
      };

  String get description => switch (this) {
        _InventoryModeType.basic => 'র‍্যাক বা বিন ব্যবহার করা হয় না',
        _InventoryModeType.advanced => 'জোন, র‍্যাক, শেলফ এবং বিন ব্যবহার করা হয়',
      };

  String get summary => switch (this) {
        _InventoryModeType.basic => 'সব স্টক মেইন স্টোরে রাখা হবে',
        _InventoryModeType.advanced => 'লোকেশন অনুযায়ী স্টক ট্র‍্যাক করা হবে',
      };

  IconData get icon => switch (this) {
        _InventoryModeType.basic => Icons.inventory_2_outlined,
        _InventoryModeType.advanced => Icons.dashboard_customize_rounded,
      };

  List<String> get benefits => switch (this) {
        _InventoryModeType.basic => const [
          'সরল, দ্রুত সেটআপ',
          'ছোট ব্যবসার জন্য উপযোগী',
          'অতিরিক্ত লোকেশন কনফিগারেশন লাগে না',
        ],
        _InventoryModeType.advanced => const [
          'জোন, র‍্যাক, শেলফ এবং বিন যোগ করা যাবে',
          'নির্দিষ্ট লোকেশনে স্টক অ্যাসাইন করা যাবে',
          'প্রতি শেলফ/বিন অনুযায়ী লো স্টক অ্যালার্ট পাওয়া যাবে',
        ],
      };
}

class DokanInventoryModeSelectionScreen extends StatefulWidget {
  const DokanInventoryModeSelectionScreen({super.key});

  @override
  State<DokanInventoryModeSelectionScreen> createState() => _DokanInventoryModeSelectionScreenState();
}

class _DokanInventoryModeSelectionScreenState extends State<DokanInventoryModeSelectionScreen> {
  static const Color _bg = Color(0xFFF4F7FB);
  static const Color _text = Color(0xFF16302E);
  static const Color _muted = Color(0xFF6F8280);
  static const Color _accent = Color(0xFF0E8F5F);

  _InventoryModeType? _selectedMode;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _bg,
      appBar: AppBar(
        backgroundColor: _bg,
        surfaceTintColor: _bg,
        elevation: 0,
        centerTitle: false,
        leading: Padding(
          padding: const EdgeInsets.only(left: 16),
          child: IconButton(
            onPressed: () => Navigator.of(context).maybePop(),
            icon: const Icon(Icons.arrow_back_rounded),
            style: IconButton.styleFrom(
              backgroundColor: Colors.white,
              foregroundColor: _text,
            ),
          ),
        ),
        leadingWidth: 72,
        title: const Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'ইনভেন্টরি মোড',
              style: TextStyle(
                color: _text,
                fontSize: 19,
                fontWeight: FontWeight.w800,
              ),
            ),
            SizedBox(height: 4),
            Text(
              'আপনার ইনভেন্টরি কীভাবে পরিচালনা করবেন তা নির্বাচন করুন',
              style: TextStyle(
                color: _muted,
                fontSize: 12.5,
                fontWeight: FontWeight.w500,
                height: 1.25,
              ),
            ),
          ],
        ),
      ),
      bottomNavigationBar: SafeArea(
        top: false,
        child: Padding(
          padding: const EdgeInsets.fromLTRB(16, 8, 16, 16),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              const Padding(
                padding: EdgeInsets.only(bottom: 10),
                child: Text(
                  'দ্রষ্টব্য: আপনি পরবর্তীতে সেটিংস থেকে এই মোড পরিবর্তন করতে পারবেন',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    color: _muted,
                    fontSize: 11.5,
                    height: 1.35,
                  ),
                ),
              ),
              SizedBox(
                height: 50,
                child: ElevatedButton(
                  onPressed: _selectedMode == null ? null : _saveSelection,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: _accent,
                    foregroundColor: Colors.white,
                    disabledBackgroundColor: const Color(0xFFB9C8C2),
                    disabledForegroundColor: Colors.white70,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(14),
                    ),
                    elevation: 0,
                  ),
                  child: const Text(
                    'পছন্দ সংরক্ষণ করুন',
                    style: TextStyle(
                      fontSize: 15,
                      fontWeight: FontWeight.w800,
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
      body: SafeArea(
        child: LayoutBuilder(
          builder: (context, constraints) {
            final contentWidth = constraints.maxWidth > 760 ? 760.0 : constraints.maxWidth;

            return CustomScrollView(
              physics: const AlwaysScrollableScrollPhysics(parent: BouncingScrollPhysics()),
              slivers: [
                SliverPadding(
                  padding: const EdgeInsets.fromLTRB(16, 12, 16, 20),
                  sliver: SliverToBoxAdapter(
                    child: Center(
                      child: ConstrainedBox(
                        constraints: BoxConstraints(maxWidth: contentWidth),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.stretch,
                          children: [
                            Container(
                              padding: const EdgeInsets.all(18),
                              decoration: BoxDecoration(
                                gradient: const LinearGradient(
                                  begin: Alignment.topLeft,
                                  end: Alignment.bottomRight,
                                  colors: [Color(0xFF0E8F5F), Color(0xFF0A6F4A)],
                                ),
                                borderRadius: BorderRadius.circular(24),
                                boxShadow: const [
                                  BoxShadow(
                                    color: Color(0x220B5B40),
                                    blurRadius: 24,
                                    offset: Offset(0, 12),
                                  ),
                                ],
                              ),
                              child: Row(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Container(
                                    width: 56,
                                    height: 56,
                                    decoration: BoxDecoration(
                                      color: Colors.white.withValues(alpha: 0.16),
                                      borderRadius: BorderRadius.circular(16),
                                    ),
                                    child: const Icon(
                                      Icons.precision_manufacturing_rounded,
                                      color: Colors.white,
                                      size: 30,
                                    ),
                                  ),
                                  const SizedBox(width: 14),
                                  Expanded(
                                    child: Column(
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        const Text(
                                          'দ্রুত, পরিষ্কার সিদ্ধান্ত নিন',
                                          style: TextStyle(
                                            color: Colors.white,
                                            fontSize: 20,
                                            fontWeight: FontWeight.w800,
                                            height: 1.1,
                                          ),
                                        ),
                                        const SizedBox(height: 6),
                                        Text(
                                          'ছোট দোকানের জন্য সরল সেটআপ, আর বড় অপারেশনের জন্য বিস্তারিত লোকেশন কন্ট্রোল।',
                                          style: TextStyle(
                                            color: Colors.white.withValues(alpha: 0.88),
                                            fontSize: 13.5,
                                            fontWeight: FontWeight.w500,
                                            height: 1.4,
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            const SizedBox(height: 16),
                            _InventoryModeOptionCard(
                              mode: _InventoryModeType.basic,
                              selected: _selectedMode == _InventoryModeType.basic,
                              onTap: () => setState(() => _selectedMode = _InventoryModeType.basic),
                            ),
                            const SizedBox(height: 14),
                            _InventoryModeOptionCard(
                              mode: _InventoryModeType.advanced,
                              selected: _selectedMode == _InventoryModeType.advanced,
                              onTap: () {
                                setState(() => _selectedMode = _InventoryModeType.advanced);
                                Navigator.of(context).push(
                                  MaterialPageRoute(
                                    builder: (_) => const DokanStoreLayoutManagementScreen(),
                                  ),
                                );
                              },
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            );
          },
        ),
      ),
    );
  }

  void _saveSelection() {
    final selected = _selectedMode;
    if (selected == null) {
      return;
    }

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('${selected.title} সংরক্ষণ করা হয়েছে'),
        behavior: SnackBarBehavior.floating,
      ),
    );
    Navigator.of(context).pop();
  }
}

class _InventoryModeOptionCard extends StatelessWidget {
  const _InventoryModeOptionCard({
    required this.mode,
    required this.selected,
    required this.onTap,
  });

  final _InventoryModeType mode;
  final bool selected;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final accent = selected ? const Color(0xFF0E8F5F) : const Color(0xFFE3EBE8);
    final background = selected ? const Color(0xFFF1FBF6) : Colors.white;
    final shadowColor = selected ? const Color(0x200B5B40) : const Color(0x0C21413C);

    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(24),
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 180),
          curve: Curves.easeOut,
          padding: const EdgeInsets.all(18),
          decoration: BoxDecoration(
            color: background,
            borderRadius: BorderRadius.circular(24),
            border: Border.all(color: accent, width: selected ? 1.8 : 1),
            boxShadow: [
              BoxShadow(
                color: shadowColor,
                blurRadius: selected ? 22 : 18,
                offset: const Offset(0, 8),
              ),
            ],
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    width: 52,
                    height: 52,
                    decoration: BoxDecoration(
                      color: selected ? const Color(0xFF0E8F5F) : const Color(0xFFEAF5F1),
                      borderRadius: BorderRadius.circular(16),
                    ),
                    child: Icon(
                      mode.icon,
                      color: selected ? Colors.white : const Color(0xFF0E8F5F),
                      size: 28,
                    ),
                  ),
                  const SizedBox(width: 14),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            Expanded(
                              child: Text(
                                mode.title,
                                style: const TextStyle(
                                  color: Color(0xFF16302E),
                                  fontSize: 17,
                                  fontWeight: FontWeight.w800,
                                  height: 1.2,
                                ),
                              ),
                            ),
                            AnimatedContainer(
                              duration: const Duration(milliseconds: 180),
                              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                              decoration: BoxDecoration(
                                color: selected ? const Color(0xFF0E8F5F) : const Color(0xFFEAF5F1),
                                borderRadius: BorderRadius.circular(999),
                              ),
                              child: Text(
                                selected ? 'নির্বাচিত' : 'নির্বাচন করুন',
                                style: TextStyle(
                                  color: selected ? Colors.white : const Color(0xFF0E8F5F),
                                  fontSize: 11.5,
                                  fontWeight: FontWeight.w700,
                                ),
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 6),
                        Text(
                          mode.description,
                          style: const TextStyle(
                            color: Color(0xFF516462),
                            fontSize: 13.5,
                            fontWeight: FontWeight.w500,
                            height: 1.35,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 16),
              Text(
                mode.summary,
                style: const TextStyle(
                  color: Color(0xFF16302E),
                  fontSize: 15,
                  fontWeight: FontWeight.w700,
                ),
              ),
              const SizedBox(height: 14),
              ...mode.benefits.map(
                (benefit) => Padding(
                  padding: const EdgeInsets.only(bottom: 10),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Icon(Icons.check_circle_rounded, size: 18, color: Color(0xFF0E8F5F)),
                      const SizedBox(width: 8),
                      Expanded(
                        child: Text(
                          benefit,
                          style: const TextStyle(
                            color: Color(0xFF516462),
                            fontSize: 13,
                            height: 1.35,
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class DokanStoreLayoutManagementScreen extends StatefulWidget {
  const DokanStoreLayoutManagementScreen({super.key});

  static const Color _bg = Color(0xFFF3F7FA);
  static const Color _text = Color(0xFF142D2A);
  static const Color _muted = Color(0xFF6B7D78);
  static const Color _accent = Color(0xFF0E8F5F);
  static const Color _danger = Color(0xFFC2410C);
  static const Color _warning = Color(0xFFB45309);
  static const Color _cardBorder = Color(0xFFE1E9E7);

  @override
  State<DokanStoreLayoutManagementScreen> createState() => _DokanStoreLayoutManagementScreenState();
}

class _DokanStoreLayoutManagementScreenState extends State<DokanStoreLayoutManagementScreen> {
  _StoreZoneData? _selectedZone;
  void _refresh() => setState(() {});

  @override
  Widget build(BuildContext context) {
    final zones = _storeZones;
    final lowStockBins = _lowStockBins;
    final contentWidth = MediaQuery.of(context).size.width > 980 ? 980.0 : MediaQuery.of(context).size.width;

    return Scaffold(
      backgroundColor: DokanStoreLayoutManagementScreen._bg,
      appBar: AppBar(
        backgroundColor: DokanStoreLayoutManagementScreen._bg,
        surfaceTintColor: DokanStoreLayoutManagementScreen._bg,
        elevation: 0,
        centerTitle: false,
        leading: Padding(
          padding: const EdgeInsets.only(left: 16),
          child: IconButton(
            onPressed: () => Navigator.of(context).maybePop(),
            icon: const Icon(Icons.arrow_back_rounded),
            style: IconButton.styleFrom(
              backgroundColor: Colors.white,
              foregroundColor: DokanStoreLayoutManagementScreen._text,
            ),
          ),
        ),
        leadingWidth: 72,
        title: const Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'স্টোর লেআউট',
              style: TextStyle(
                color: DokanStoreLayoutManagementScreen._text,
                fontSize: 19,
                fontWeight: FontWeight.w800,
              ),
            ),
            SizedBox(height: 4),
            Text(
              'জোন, র‍্যাক, শেলফ এবং বিন ম্যানেজ করুন',
              style: TextStyle(
                color: DokanStoreLayoutManagementScreen._muted,
                fontSize: 12.5,
                fontWeight: FontWeight.w500,
                height: 1.25,
              ),
            ),
          ],
        ),
      ),
      body: SafeArea(
        child: CustomScrollView(
          physics: const AlwaysScrollableScrollPhysics(parent: BouncingScrollPhysics()),
          slivers: [
            SliverPadding(
              padding: const EdgeInsets.fromLTRB(16, 12, 16, 24),
              sliver: SliverToBoxAdapter(
                child: Center(
                  child: ConstrainedBox(
                    constraints: BoxConstraints(maxWidth: contentWidth),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        const _StoreLayoutHeroCard(
                          accent: DokanStoreLayoutManagementScreen._accent,
                          textColor: DokanStoreLayoutManagementScreen._text,
                          mutedColor: DokanStoreLayoutManagementScreen._muted,
                        ),
                        const SizedBox(height: 14),
                        const _StoreLayoutBreadcrumb(
                          steps: ['হোম', 'স্টোর লেআউট', 'জোন'],
                        ),
                        const SizedBox(height: 14),
                        if (lowStockBins.isNotEmpty) ...[
                          _StoreLayoutSectionCard(
                            title: 'কম স্টক সতর্কতা',
                            subtitle: '${lowStockBins.length}টি বিনে স্টক কম (১০ এর নিচে)',
                            accent: DokanStoreLayoutManagementScreen._danger,
                            child: Column(
                              children: [
                                for (final bin in lowStockBins) ...[
                                  _StoreLayoutAlertRow(
                                    binCode: bin.code,
                                    location: bin.locationPath,
                                    quantity: bin.quantity,
                                    onTap: () => _showContextMenu(
                                      context,
                                      type: 'Bin',
                                      item: bin,
                                      onChanged: _refresh,
                                    ),
                                  ),
                                  if (bin != lowStockBins.last) const SizedBox(height: 10),
                                ],
                              ],
                            ),
                          ),
                          const SizedBox(height: 14),
                        ],
                        _StoreLayoutSectionCard(
                          title: 'জোন লিস্ট',
                          subtitle: 'দোকানের প্রধান জোনসমূহ',
                          accent: DokanStoreLayoutManagementScreen._accent,
                          child: Column(
                            children: [
                              if (zones.isEmpty)
                                const Padding(
                                  padding: EdgeInsets.symmetric(vertical: 24),
                                  child: Text('কোনো জোন পাওয়া যায়নি। একটি নতুন জোন যোগ করুন।'),
                                )
                              else
                                for (final zone in zones) ...[
                                  _buildZoneCard(context, zone),
                                  if (zone != zones.last) const SizedBox(height: 12),
                                ],
                            ],
                          ),
                        ),
                        const SizedBox(height: 14),
                        _StoreLayoutSectionCard(
                          title: 'কুইক অ্যাকশন',
                          subtitle: 'দ্রুত CRUD এন্ট্রি পয়েন্ট',
                          accent: DokanStoreLayoutManagementScreen._accent,
                          child: Column(
                            children: [
                              _StoreLayoutActionCard(
                                icon: Icons.add_location_alt_rounded,
                                title: 'জোন ম্যানেজ করুন',
                                subtitle: 'নতুন জোন তৈরি বা আপডেট করুন',
                                onTap: () => _showAddEditBottomSheet(
                                  context,
                                  type: 'Zone',
                                  onSaved: _refresh,
                                ),
                              ),
                              const SizedBox(height: 10),
                              _StoreLayoutActionCard(
                                icon: Icons.view_module_rounded,
                                title: 'র‍্যাক ম্যানেজ করুন',
                                subtitle: 'জোনের অধীনে র‍্যাক কনফিগার করুন',
                                onTap: () => _showAddEditBottomSheet(
                                  context,
                                  type: 'Rack',
                                  onSaved: _refresh,
                                ),
                              ),
                              const SizedBox(height: 10),
                              _StoreLayoutActionCard(
                                icon: Icons.layers_rounded,
                                title: 'শেলফ ম্যানেজ করুন',
                                subtitle: 'র‍্যাকের ভিতরে শেলফ সেট করুন',
                                onTap: () => _showAddEditBottomSheet(
                                  context,
                                  type: 'Shelf',
                                  onSaved: _refresh,
                                ),
                              ),
                              const SizedBox(height: 10),
                              _StoreLayoutActionCard(
                                icon: Icons.archive_rounded,
                                title: 'বিন ম্যানেজ করুন',
                                subtitle: 'বিন কোড ও স্টক লোকেশন নিয়ন্ত্রণ করুন',
                                onTap: () => _showAddEditBottomSheet(
                                  context,
                                  type: 'Bin',
                                  onSaved: _refresh,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => _showAddEditBottomSheet(
          context,
          type: 'Zone',
          onSaved: _refresh,
        ),
        backgroundColor: DokanStoreLayoutManagementScreen._accent,
        foregroundColor: Colors.white,
        icon: const Icon(Icons.add_location_alt_rounded),
        label: const Text('জোন যোগ করুন', style: TextStyle(fontWeight: FontWeight.bold)),
      ),
    );
  }

    Widget _buildZoneCard(BuildContext context, _StoreZoneData zone) {
    return _StoreLayoutItemCard(
      title: Text(
        zone.name,
        style: const TextStyle(
          color: DokanStoreLayoutManagementScreen._text,
          fontSize: 16,
          fontWeight: FontWeight.w800,
        ),
      ),
      subtitle: Text(
        '${zone.racks.length}টি র‍্যাক · ${zone.totalStock} পিস স্টক',
        style: const TextStyle(
          color: DokanStoreLayoutManagementScreen._muted,
          fontSize: 13,
          fontWeight: FontWeight.w600,
        ),
      ),
      icon: Icons.my_location_rounded,
      iconColor: DokanStoreLayoutManagementScreen._accent,
      iconBgColor: DokanStoreLayoutManagementScreen._accent.withValues(alpha: 0.12),
      isSelected: _selectedZone == zone,
            onTap: () async {
        setState(() {
          _selectedZone = zone;
        });
        await Future.delayed(const Duration(milliseconds: 250));
        if (!context.mounted) return;
        await Navigator.of(context).push(
          MaterialPageRoute(
            builder: (_) => _DokanStoreRackListScreen(zone: zone),
          ),
        ).then((_) => _refresh());
        setState(() {
          _selectedZone = null;
        });
      },
      onMorePressed: () => _showContextMenu(
        context,
        type: 'Zone',
        item: zone,
        onChanged: _refresh,
      ),
    );
  }
}

class _DokanStoreRackListScreen extends StatefulWidget {
  const _DokanStoreRackListScreen({required this.zone});
  final _StoreZoneData zone;

  @override
  State<_DokanStoreRackListScreen> createState() => _DokanStoreRackListScreenState();
}

class _DokanStoreRackListScreenState extends State<_DokanStoreRackListScreen> {
  _StoreRackData? _selectedRack;
  void _refresh() => setState(() {});

  @override
  Widget build(BuildContext context) {
    final zone = widget.zone;
    final contentWidth = MediaQuery.of(context).size.width > 980 ? 980.0 : MediaQuery.of(context).size.width;

    return Scaffold(
      backgroundColor: DokanStoreLayoutManagementScreen._bg,
      appBar: AppBar(
        backgroundColor: DokanStoreLayoutManagementScreen._bg,
        surfaceTintColor: DokanStoreLayoutManagementScreen._bg,
        elevation: 0,
        centerTitle: false,
        leading: Padding(
          padding: const EdgeInsets.only(left: 16),
          child: IconButton(
            onPressed: () => Navigator.of(context).pop(),
            icon: const Icon(Icons.arrow_back_rounded),
            style: IconButton.styleFrom(
              backgroundColor: Colors.white,
              foregroundColor: DokanStoreLayoutManagementScreen._text,
            ),
          ),
        ),
        leadingWidth: 72,
        title: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              zone.name,
              style: const TextStyle(
                color: DokanStoreLayoutManagementScreen._text,
                fontSize: 19,
                fontWeight: FontWeight.w800,
              ),
            ),
            const SizedBox(height: 4),
            const Text(
              'র‍্যাক লিস্ট',
              style: TextStyle(
                color: DokanStoreLayoutManagementScreen._muted,
                fontSize: 12.5,
                fontWeight: FontWeight.w500,
                height: 1.25,
              ),
            ),
          ],
        ),
      ),
      body: SafeArea(
        child: CustomScrollView(
          physics: const AlwaysScrollableScrollPhysics(parent: BouncingScrollPhysics()),
          slivers: [
            SliverPadding(
              padding: const EdgeInsets.fromLTRB(16, 12, 16, 24),
              sliver: SliverToBoxAdapter(
                child: Center(
                  child: ConstrainedBox(
                    constraints: BoxConstraints(maxWidth: contentWidth),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        _StoreLayoutBreadcrumb(
                          steps: ['হোম', 'স্টোর লেআউট', zone.name, 'র‍্যাক'],
                        ),
                        const SizedBox(height: 14),
                        _StoreLayoutSectionCard(
                          title: 'র‍্যাক লিস্ট',
                          subtitle: '${zone.racks.length}টি র‍্যাক নিবন্ধিত আছে',
                          accent: DokanStoreLayoutManagementScreen._accent,
                          child: Column(
                            children: [
                              if (zone.racks.isEmpty)
                                const Padding(
                                  padding: EdgeInsets.symmetric(vertical: 24),
                                  child: Text('কোনো র‍্যাক পাওয়া যায়নি। একটি নতুন র‍্যাক যোগ করুন।'),
                                )
                              else
                                for (final rack in zone.racks) ...[
                                  _buildRackCard(context, rack),
                                  if (rack != zone.racks.last) const SizedBox(height: 12),
                                ],
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => _showAddEditBottomSheet(
          context,
          type: 'Rack',
          parent: zone,
          onSaved: _refresh,
        ),
        backgroundColor: DokanStoreLayoutManagementScreen._accent,
        foregroundColor: Colors.white,
        icon: const Icon(Icons.add_rounded),
        label: const Text('র‍্যাক যোগ করুন', style: TextStyle(fontWeight: FontWeight.bold)),
      ),
    );
  }

    Widget _buildRackCard(BuildContext context, _StoreRackData rack) {
    return _StoreLayoutItemCard(
      title: Text(
        rack.name,
        style: const TextStyle(
          color: DokanStoreLayoutManagementScreen._text,
          fontSize: 16,
          fontWeight: FontWeight.w800,
        ),
      ),
      subtitle: Text(
        '${rack.shelves.length}টি শেলফ · ${rack.binCount}টি বিন · ${rack.totalStock} পিস স্টক',
        style: const TextStyle(
          color: DokanStoreLayoutManagementScreen._muted,
          fontSize: 13,
          fontWeight: FontWeight.w600,
        ),
      ),
      icon: Icons.view_module_rounded,
      iconColor: DokanStoreLayoutManagementScreen._accent,
      iconBgColor: DokanStoreLayoutManagementScreen._accent.withValues(alpha: 0.12),
      isSelected: _selectedRack == rack,
            onTap: () async {
        setState(() {
          _selectedRack = rack;
        });
        await Future.delayed(const Duration(milliseconds: 250));
        if (!context.mounted) return;
        await Navigator.of(context).push(
          MaterialPageRoute(
            builder: (_) => _DokanStoreShelfListScreen(zone: widget.zone, rack: rack),
          ),
        ).then((_) => _refresh());
        setState(() {
          _selectedRack = null;
        });
      },
      onMorePressed: () => _showContextMenu(
        context,
        type: 'Rack',
        item: rack,
        parent: widget.zone,
        onChanged: _refresh,
      ),
    );
  }
}

class _DokanStoreShelfListScreen extends StatefulWidget {
  const _DokanStoreShelfListScreen({required this.zone, required this.rack});
  final _StoreZoneData zone;
  final _StoreRackData rack;

  @override
  State<_DokanStoreShelfListScreen> createState() => _DokanStoreShelfListScreenState();
}

class _DokanStoreShelfListScreenState extends State<_DokanStoreShelfListScreen> {
  _StoreShelfData? _selectedShelf;
  void _refresh() => setState(() {});

  @override
  Widget build(BuildContext context) {
    final zone = widget.zone;
    final rack = widget.rack;
    final contentWidth = MediaQuery.of(context).size.width > 980 ? 980.0 : MediaQuery.of(context).size.width;

    return Scaffold(
      backgroundColor: DokanStoreLayoutManagementScreen._bg,
      appBar: AppBar(
        backgroundColor: DokanStoreLayoutManagementScreen._bg,
        surfaceTintColor: DokanStoreLayoutManagementScreen._bg,
        elevation: 0,
        centerTitle: false,
        leading: Padding(
          padding: const EdgeInsets.only(left: 16),
          child: IconButton(
            onPressed: () => Navigator.of(context).pop(),
            icon: const Icon(Icons.arrow_back_rounded),
            style: IconButton.styleFrom(
              backgroundColor: Colors.white,
              foregroundColor: DokanStoreLayoutManagementScreen._text,
            ),
          ),
        ),
        leadingWidth: 72,
        title: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              rack.name,
              style: const TextStyle(
                color: DokanStoreLayoutManagementScreen._text,
                fontSize: 19,
                fontWeight: FontWeight.w800,
              ),
            ),
            const SizedBox(height: 4),
            Text(
              'জোন: ${zone.name}',
              style: const TextStyle(
                color: DokanStoreLayoutManagementScreen._muted,
                fontSize: 12.5,
                fontWeight: FontWeight.w500,
                height: 1.25,
              ),
            ),
          ],
        ),
      ),
      body: SafeArea(
        child: CustomScrollView(
          physics: const AlwaysScrollableScrollPhysics(parent: BouncingScrollPhysics()),
          slivers: [
            SliverPadding(
              padding: const EdgeInsets.fromLTRB(16, 12, 16, 24),
              sliver: SliverToBoxAdapter(
                child: Center(
                  child: ConstrainedBox(
                    constraints: BoxConstraints(maxWidth: contentWidth),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        _StoreLayoutBreadcrumb(
                          steps: ['হোম', zone.name, rack.name, 'শেলফ'],
                        ),
                        const SizedBox(height: 14),
                        _StoreLayoutSectionCard(
                          title: 'শেলফ লিস্ট',
                          subtitle: '${rack.shelves.length}টি শেলফ নিবন্ধিত আছে',
                          accent: DokanStoreLayoutManagementScreen._accent,
                          child: Column(
                            children: [
                              if (rack.shelves.isEmpty)
                                const Padding(
                                  padding: EdgeInsets.symmetric(vertical: 24),
                                  child: Text('কোনো শেলফ পাওয়া যায়নি। একটি নতুন শেলফ যোগ করুন।'),
                                )
                              else
                                for (final shelf in rack.shelves) ...[
                                  _buildShelfCard(context, shelf),
                                  if (shelf != rack.shelves.last) const SizedBox(height: 12),
                                ],
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => _showAddEditBottomSheet(
          context,
          type: 'Shelf',
          parent: rack,
          onSaved: _refresh,
        ),
        backgroundColor: DokanStoreLayoutManagementScreen._accent,
        foregroundColor: Colors.white,
        icon: const Icon(Icons.add_rounded),
        label: const Text('শেলফ যোগ করুন', style: TextStyle(fontWeight: FontWeight.bold)),
      ),
    );
  }

    Widget _buildShelfCard(BuildContext context, _StoreShelfData shelf) {
    return _StoreLayoutItemCard(
      title: Text(
        shelf.name,
        style: const TextStyle(
          color: DokanStoreLayoutManagementScreen._text,
          fontSize: 16,
          fontWeight: FontWeight.w800,
        ),
      ),
      subtitle: Text(
        'দিক: ${shelf.direction} · ${shelf.bins.length}টি বিন · ${shelf.totalStock} পিস স্টক',
        style: const TextStyle(
          color: DokanStoreLayoutManagementScreen._muted,
          fontSize: 13,
          fontWeight: FontWeight.w600,
        ),
      ),
      icon: Icons.layers_rounded,
      iconColor: Colors.orange,
      iconBgColor: Colors.orange.withValues(alpha: 0.12),
      isSelected: _selectedShelf == shelf,
            onTap: () async {
        setState(() {
          _selectedShelf = shelf;
        });
        await Future.delayed(const Duration(milliseconds: 250));
        if (!context.mounted) return;
        await Navigator.of(context).push(
          MaterialPageRoute(
            builder: (_) => _DokanStoreBinListScreen(zone: widget.zone, rack: widget.rack, shelf: shelf),
          ),
        ).then((_) => _refresh());
        setState(() {
          _selectedShelf = null;
        });
      },
      onMorePressed: () => _showContextMenu(
        context,
        type: 'Shelf',
        item: shelf,
        parent: widget.rack,
        onChanged: _refresh,
      ),
    );
  }
}

class _DokanStoreBinListScreen extends StatefulWidget {
  const _DokanStoreBinListScreen({required this.zone, required this.rack, required this.shelf});
  final _StoreZoneData zone;
  final _StoreRackData rack;
  final _StoreShelfData shelf;

  @override
  State<_DokanStoreBinListScreen> createState() => _DokanStoreBinListScreenState();
}

class _DokanStoreBinListScreenState extends State<_DokanStoreBinListScreen> {
  _StoreBinData? _selectedBin;
  void _refresh() => setState(() {});

  @override
  Widget build(BuildContext context) {
    final zone = widget.zone;
    final rack = widget.rack;
    final shelf = widget.shelf;
    final contentWidth = MediaQuery.of(context).size.width > 980 ? 980.0 : MediaQuery.of(context).size.width;

    return Scaffold(
      backgroundColor: DokanStoreLayoutManagementScreen._bg,
      appBar: AppBar(
        backgroundColor: DokanStoreLayoutManagementScreen._bg,
        surfaceTintColor: DokanStoreLayoutManagementScreen._bg,
        elevation: 0,
        centerTitle: false,
        leading: Padding(
          padding: const EdgeInsets.only(left: 16),
          child: IconButton(
            onPressed: () => Navigator.of(context).pop(),
            icon: const Icon(Icons.arrow_back_rounded),
            style: IconButton.styleFrom(
              backgroundColor: Colors.white,
              foregroundColor: DokanStoreLayoutManagementScreen._text,
            ),
          ),
        ),
        leadingWidth: 72,
        title: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              shelf.name,
              style: const TextStyle(
                color: DokanStoreLayoutManagementScreen._text,
                fontSize: 19,
                fontWeight: FontWeight.w800,
              ),
            ),
            const SizedBox(height: 4),
            Text(
              'র‍্যাক: ${rack.name} · জোন: ${zone.name}',
              style: const TextStyle(
                color: DokanStoreLayoutManagementScreen._muted,
                fontSize: 12.5,
                fontWeight: FontWeight.w500,
                height: 1.25,
              ),
            ),
          ],
        ),
      ),
      body: SafeArea(
        child: CustomScrollView(
          physics: const AlwaysScrollableScrollPhysics(parent: BouncingScrollPhysics()),
          slivers: [
            SliverPadding(
              padding: const EdgeInsets.fromLTRB(16, 12, 16, 24),
              sliver: SliverToBoxAdapter(
                child: Center(
                  child: ConstrainedBox(
                    constraints: BoxConstraints(maxWidth: contentWidth),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        _StoreLayoutBreadcrumb(
                          steps: ['হোম', zone.name, rack.name, shelf.name, 'বিন'],
                        ),
                        const SizedBox(height: 14),
                        _StoreLayoutSectionCard(
                          title: 'বিন লিস্ট',
                          subtitle: '${shelf.bins.length}টি বিন নিবন্ধিত আছে',
                          accent: DokanStoreLayoutManagementScreen._accent,
                          child: Column(
                            children: [
                              if (shelf.bins.isEmpty)
                                const Padding(
                                  padding: EdgeInsets.symmetric(vertical: 24),
                                  child: Text('কোনো বিন পাওয়া যায়নি। একটি নতুন বিন যোগ করুন।'),
                                )
                              else
                                for (final bin in shelf.bins) ...[
                                  _buildBinCard(context, bin),
                                  if (bin != shelf.bins.last) const SizedBox(height: 12),
                                ],
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => _showAddEditBottomSheet(
          context,
          type: 'Bin',
          parent: shelf,
          onSaved: _refresh,
        ),
        backgroundColor: DokanStoreLayoutManagementScreen._accent,
        foregroundColor: Colors.white,
        icon: const Icon(Icons.add_rounded),
        label: const Text('বিন যোগ করুন', style: TextStyle(fontWeight: FontWeight.bold)),
      ),
    );
  }

    Widget _buildBinCard(BuildContext context, _StoreBinData bin) {
    Color badgeColor;
    String badgeText;

    if (bin.quantity == 0) {
      badgeColor = Colors.red;
      badgeText = 'স্টক আউট';
    } else if (bin.isLowStock) {
      badgeColor = Colors.orange;
      badgeText = 'লো স্টক';
    } else {
      badgeColor = Colors.green;
      badgeText = 'স্টক ওকে';
    }

    return _StoreLayoutItemCard(
            title: Wrap(
        spacing: 8,
        runSpacing: 4,
        crossAxisAlignment: WrapCrossAlignment.center,
        children: [
          Text(
            bin.code,
            style: const TextStyle(
              color: DokanStoreLayoutManagementScreen._text,
              fontSize: 16,
              fontWeight: FontWeight.w800,
            ),
          ),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
            decoration: BoxDecoration(
              color: badgeColor.withValues(alpha: 0.12),
              borderRadius: BorderRadius.circular(99),
            ),
            child: Text(
              badgeText,
              style: TextStyle(
                color: badgeColor,
                fontSize: 10,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
        ],
      ),
      subtitle: Text(
        'স্টক: ${bin.quantity} পিস',
        style: const TextStyle(
          color: DokanStoreLayoutManagementScreen._muted,
          fontSize: 13,
          fontWeight: FontWeight.w600,
        ),
      ),
      icon: Icons.archive_rounded,
      iconColor: Colors.blue,
      iconBgColor: Colors.blue.withValues(alpha: 0.12),
      isSelected: _selectedBin == bin,
            onTap: () async {
        setState(() {
          _selectedBin = bin;
        });
        await Future.delayed(const Duration(milliseconds: 250));
        if (!context.mounted) return;
        _showContextMenu(
          context,
          type: 'Bin',
          item: bin,
          parent: widget.shelf,
          onChanged: _refresh,
        );
        setState(() {
          _selectedBin = null;
        });
      },
      onMorePressed: () => _showContextMenu(
        context,
        type: 'Bin',
        item: bin,
        parent: widget.shelf,
        onChanged: _refresh,
      ),
            trailing: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          SizedBox(
            width: 28,
            height: 28,
            child: IconButton(
              padding: EdgeInsets.zero,
              constraints: const BoxConstraints(minWidth: 28, minHeight: 28),
              onPressed: () {
                if (bin.quantity > 0) {
                  setState(() {
                    bin.quantity--;
                  });
                  _refresh();
                }
              },
              icon: const Icon(Icons.remove_circle_outline_rounded, color: Colors.red, size: 18),
            ),
          ),
          const SizedBox(width: 4),
          SizedBox(
            width: 28,
            child: Text(
              '${bin.quantity}',
              textAlign: TextAlign.center,
              style: const TextStyle(
                color: DokanStoreLayoutManagementScreen._text,
                fontWeight: FontWeight.w800,
                fontSize: 13,
              ),
            ),
          ),
          const SizedBox(width: 4),
          SizedBox(
            width: 28,
            height: 28,
            child: IconButton(
              padding: EdgeInsets.zero,
              constraints: const BoxConstraints(minWidth: 28, minHeight: 28),
              onPressed: () {
                setState(() {
                  bin.quantity++;
                });
                _refresh();
              },
              icon: const Icon(Icons.add_circle_outline_rounded, color: DokanStoreLayoutManagementScreen._accent, size: 18),
            ),
          ),
        ],
      ),
    );
  }
}

class _AddEditBottomSheetContent extends StatefulWidget {
  const _AddEditBottomSheetContent({
    required this.type,
    this.item,
    this.parent,
    required this.onSaved,
  });

  final String type;
  final Object? item;
  final Object? parent;
  final VoidCallback onSaved;

  @override
  State<_AddEditBottomSheetContent> createState() => _AddEditBottomSheetContentState();
}

class _AddEditBottomSheetContentState extends State<_AddEditBottomSheetContent> {
  final _formKey = GlobalKey<FormState>();
  late TextEditingController _nameController;
  late TextEditingController _quantityController;
  String? _selectedDirection;
  _StoreZoneData? _selectedZone;
  _StoreRackData? _selectedRack;
  _StoreShelfData? _selectedShelf;

  final List<String> _directions = ['উপরের সারি', 'ডান দিকে', 'বাম দিক', 'নিচের সারি'];

  @override
  void initState() {
    super.initState();
    _nameController = TextEditingController();
    _quantityController = TextEditingController(text: '0');

    if (widget.item != null) {
      if (widget.item is _StoreZoneData) {
        _nameController.text = (widget.item as _StoreZoneData).name;
      } else if (widget.item is _StoreRackData) {
        _nameController.text = (widget.item as _StoreRackData).name;
        for (final z in _storeZones) {
          if (z.racks.contains(widget.item)) {
            _selectedZone = z;
            break;
          }
        }
      } else if (widget.item is _StoreShelfData) {
        final shelf = widget.item as _StoreShelfData;
        _nameController.text = shelf.name;
        _selectedDirection = shelf.direction;
        for (final z in _storeZones) {
          for (final r in z.racks) {
            if (r.shelves.contains(shelf)) {
              _selectedRack = r;
              break;
            }
          }
        }
      } else if (widget.item is _StoreBinData) {
        final bin = widget.item as _StoreBinData;
        _nameController.text = bin.code;
        _quantityController.text = bin.quantity.toString();
        for (final z in _storeZones) {
          for (final r in z.racks) {
            for (final s in r.shelves) {
              if (s.bins.contains(bin)) {
                _selectedShelf = s;
                break;
              }
            }
          }
        }
      }
    } else {
      if (widget.parent != null) {
        if (widget.parent is _StoreZoneData) {
          _selectedZone = widget.parent as _StoreZoneData;
        } else if (widget.parent is _StoreRackData) {
          _selectedRack = widget.parent as _StoreRackData;
        } else if (widget.parent is _StoreShelfData) {
          _selectedShelf = widget.parent as _StoreShelfData;
        }
      }
    }
  }

  @override
  void dispose() {
    _nameController.dispose();
    _quantityController.dispose();
    super.dispose();
  }

  void _save() {
    if (!_formKey.currentState!.validate()) return;

    final name = _nameController.text.trim();
    final qty = int.tryParse(_quantityController.text.trim()) ?? 0;

    if (widget.item != null) {
      if (widget.item is _StoreZoneData) {
        (widget.item as _StoreZoneData).name = name;
      } else if (widget.item is _StoreRackData) {
        (widget.item as _StoreRackData).name = name;
      } else if (widget.item is _StoreShelfData) {
        final shelf = widget.item as _StoreShelfData;
        shelf.name = name;
        if (_selectedDirection != null) {
          shelf.direction = _selectedDirection!;
        }
      } else if (widget.item is _StoreBinData) {
        final bin = widget.item as _StoreBinData;
        bin.code = name;
        bin.quantity = qty;
      }
    } else {
      if (widget.type == 'Zone') {
        _storeZones.add(_StoreZoneData(name: name, racks: []));
      } else if (widget.type == 'Rack') {
        if (_selectedZone == null) return;
        _selectedZone!.racks.add(_StoreRackData(name: name, shelves: []));
      } else if (widget.type == 'Shelf') {
        if (_selectedRack == null) return;
        _selectedRack!.shelves.add(_StoreShelfData(
          name: name,
          direction: _selectedDirection ?? 'উপরের সারি',
          bins: [],
        ));
      } else if (widget.type == 'Bin') {
        if (_selectedShelf == null) return;
        String rackName = '';
        String shelfName = _selectedShelf!.name;
        for (final z in _storeZones) {
          for (final r in z.racks) {
            if (r.shelves.contains(_selectedShelf)) {
              rackName = r.name;
              break;
            }
          }
        }
        _selectedShelf!.bins.add(_StoreBinData(
          code: name,
          quantity: qty,
          rackName: rackName,
          shelfName: shelfName,
        ));
      }
    }

    widget.onSaved();
    Navigator.of(context).pop();
  }

  @override
  Widget build(BuildContext context) {
    final titleText = widget.item != null ? '${widget.type} সম্পাদনা' : 'নতুন ${widget.type} যোগ করুন';
    final allRacks = _storeZones.expand((z) => z.racks).toList();
    final allShelves = _storeZones.expand((z) => z.racks.expand((r) => r.shelves)).toList();

    return SafeArea(
      child: Padding(
        padding: EdgeInsets.only(
          bottom: MediaQuery.of(context).viewInsets.bottom + 48,
          left: 20,
          right: 20,
          top: 24,
        ),
        child: Form(
          key: _formKey,
          child: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                                    Text(
                    titleText,
                    style: const TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                      color: Colors.black,
                    ),
                  ),
                                    IconButton(
                    onPressed: () => Navigator.of(context).pop(),
                    icon: const Icon(Icons.close_rounded, color: Colors.black),
                  ),
                ],
              ),
              const SizedBox(height: 16),
              if (widget.type == 'Rack' && widget.item == null) ...[
                                DropdownButtonFormField<_StoreZoneData>(
                  initialValue: _selectedZone,
                  style: const TextStyle(color: Colors.black, fontSize: 15),
                  decoration: const InputDecoration(
                    labelText: 'জোন নির্বাচন করুন',
                    labelStyle: TextStyle(color: Colors.black54),
                    border: OutlineInputBorder(borderRadius: BorderRadius.all(Radius.circular(12))),
                  ),
                  items: _storeZones.map((z) {
                    return DropdownMenuItem(
                      value: z,
                      child: Text(z.name, style: const TextStyle(color: Colors.black)),
                    );
                  }).toList(),
                  onChanged: widget.parent != null ? null : (val) {
                    setState(() {
                      _selectedZone = val;
                    });
                  },
                  validator: (val) => val == null ? 'দয়া করে একটি জোন নির্বাচন করুন' : null,
                ),
                const SizedBox(height: 14),
              ],
              if (widget.type == 'Shelf' && widget.item == null) ...[
                                DropdownButtonFormField<_StoreRackData>(
                  initialValue: _selectedRack,
                  style: const TextStyle(color: Colors.black, fontSize: 15),
                  decoration: const InputDecoration(
                    labelText: 'র‍্যাক নির্বাচন করুন',
                    labelStyle: TextStyle(color: Colors.black54),
                    border: OutlineInputBorder(borderRadius: BorderRadius.all(Radius.circular(12))),
                  ),
                  items: allRacks.map((r) {
                    return DropdownMenuItem(
                      value: r,
                      child: Text(r.name, style: const TextStyle(color: Colors.black)),
                    );
                  }).toList(),
                  onChanged: widget.parent != null ? null : (val) {
                    setState(() {
                      _selectedRack = val;
                    });
                  },
                  validator: (val) => val == null ? 'দয়া করে একটি র‍্যাক নির্বাচন করুন' : null,
                ),
                const SizedBox(height: 14),
              ],
              if (widget.type == 'Bin' && widget.item == null) ...[
                                DropdownButtonFormField<_StoreShelfData>(
                  initialValue: _selectedShelf,
                  style: const TextStyle(color: Colors.black, fontSize: 15),
                  decoration: const InputDecoration(
                    labelText: 'শেলফ নির্বাচন করুন',
                    labelStyle: TextStyle(color: Colors.black54),
                    border: OutlineInputBorder(borderRadius: BorderRadius.all(Radius.circular(12))),
                  ),
                  items: allShelves.map((s) {
                    return DropdownMenuItem(
                      value: s,
                      child: Text(s.name, style: const TextStyle(color: Colors.black)),
                    );
                  }).toList(),
                  onChanged: widget.parent != null ? null : (val) {
                    setState(() {
                      _selectedShelf = val;
                    });
                  },
                  validator: (val) => val == null ? 'দয়া করে একটি শেলফ নির্বাচন করুন' : null,
                ),
                const SizedBox(height: 14),
              ],
                            TextFormField(
                controller: _nameController,
                style: const TextStyle(color: Colors.black, fontSize: 15),
                decoration: InputDecoration(
                  labelText: widget.type == 'Bin' ? 'বিন কোড (যেমন: A-A-S1-B3)' : '${widget.type} নাম',
                  labelStyle: const TextStyle(color: Colors.black54),
                  border: const OutlineInputBorder(borderRadius: BorderRadius.all(Radius.circular(12))),
                ),
                validator: (val) => val == null || val.trim().isEmpty ? 'দয়া করে সঠিক নাম লিখুন' : null,
              ),
              const SizedBox(height: 14),
              if (widget.type == 'Shelf') ...[
                                DropdownButtonFormField<String>(
                  initialValue: _selectedDirection,
                  style: const TextStyle(color: Colors.black, fontSize: 15),
                  decoration: const InputDecoration(
                    labelText: 'শেলফের দিক',
                    labelStyle: TextStyle(color: Colors.black54),
                    border: OutlineInputBorder(borderRadius: BorderRadius.all(Radius.circular(12))),
                  ),
                  items: _directions.map((d) {
                    return DropdownMenuItem(
                      value: d,
                      child: Text(d, style: const TextStyle(color: Colors.black)),
                    );
                  }).toList(),
                  onChanged: (val) {
                    setState(() {
                      _selectedDirection = val;
                    });
                  },
                  validator: (val) => val == null ? 'দয়া করে দিক সিলেক্ট করুন' : null,
                ),
                const SizedBox(height: 14),
              ],
              if (widget.type == 'Bin') ...[
                                TextFormField(
                  controller: _quantityController,
                  style: const TextStyle(color: Colors.black, fontSize: 15),
                  keyboardType: TextInputType.number,
                  decoration: const InputDecoration(
                    labelText: 'স্টক পরিমাণ (পিস)',
                    labelStyle: TextStyle(color: Colors.black54),
                    border: OutlineInputBorder(borderRadius: BorderRadius.all(Radius.circular(12))),
                  ),
                  validator: (val) {
                    if (val == null || val.trim().isEmpty) return 'দয়া করে স্টক সংখ্যা লিখুন';
                    if (int.tryParse(val) == null) return 'দয়া করে সঠিক সংখ্যা লিখুন';
                    return null;
                  },
                ),
                const SizedBox(height: 14),
              ],
              ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor: DokanStoreLayoutManagementScreen._accent,
                  foregroundColor: Colors.white,
                  padding: const EdgeInsets.symmetric(vertical: 14),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                ),
                onPressed: _save,
                child: const Text('সংরক্ষণ করুন', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
              ),
              const SizedBox(height: 10),
            ],
          ),
        ),
      ),
    ));
  }
}

void _showAddEditBottomSheet(
  BuildContext context, {
  required String type,
  Object? item,
  Object? parent,
  required VoidCallback onSaved,
}) {
  showModalBottomSheet(
    context: context,
    isScrollControlled: true,
    showDragHandle: true,
    useSafeArea: true,
    backgroundColor: Colors.white,
    shape: const RoundedRectangleBorder(
      borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
    ),
    builder: (context) {
      return _AddEditBottomSheetContent(
        type: type,
        item: item,
        parent: parent,
        onSaved: onSaved,
      );
    },
  );
}

void _showContextMenu(
  BuildContext context, {
  required String type,
  required Object item,
  Object? parent,
  required VoidCallback onChanged,
}) {
  showModalBottomSheet(
    context: context,
    isScrollControlled: true,
    showDragHandle: true,
    useSafeArea: true,
    backgroundColor: Colors.white,
    shape: const RoundedRectangleBorder(
      borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
    ),
    builder: (context) {
      return SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const SizedBox(height: 4),
            if (type != 'Bin')
              ListTile(
                leading: const Icon(Icons.add_circle_outline_rounded, color: Color(0xFF0E8F5F)),
                title: Text(
                  type == 'Zone' ? 'র‍্যাক যোগ করুন' : (type == 'Rack' ? 'শেলফ যোগ করুন' : 'বিন যোগ করুন'),
                  style: const TextStyle(fontWeight: FontWeight.bold, color: Colors.black),
                ),
                onTap: () {
                  Navigator.of(context).pop();
                  _showAddEditBottomSheet(
                    context,
                    type: type == 'Zone' ? 'Rack' : (type == 'Rack' ? 'Shelf' : 'Bin'),
                    parent: item,
                    onSaved: onChanged,
                  );
                },
              ),
            ListTile(
              leading: const Icon(Icons.edit_rounded, color: Colors.blue),
              title: const Text('সম্পাদনা', style: TextStyle(fontWeight: FontWeight.bold, color: Colors.black)),
              onTap: () {
                Navigator.of(context).pop();
                _showAddEditBottomSheet(
                  context,
                  type: type,
                  item: item,
                  onSaved: onChanged,
                );
              },
            ),
            ListTile(
              leading: const Icon(Icons.delete_forever_rounded, color: Colors.red),
              title: const Text('মুছে ফেলুন', style: TextStyle(fontWeight: FontWeight.bold, color: Colors.black)),
              onTap: () {
                Navigator.of(context).pop();
                _deleteItem(context, item, onChanged);
              },
            ),
            const SizedBox(height: 12),
          ],
        ),
      );
    },
  );
}

void _deleteItem(BuildContext context, Object item, VoidCallback onDeleted) {
  String warningText = '';
  if (item is _StoreZoneData) {
    warningText = 'এই জোনটি ডিলিট করলে এর অধীনে থাকা সব র‍্যাক, শেলফ এবং বিন ডিলিট হয়ে যাবে। আপনি কি নিশ্চিত?';
  } else if (item is _StoreRackData) {
    warningText = 'এই র‍্যাকটি ডিলিট করলে এর অধীনে থাকা সব শেলফ এবং বিন ডিলিট হয়ে যাবে। আপনি কি নিশ্চিত?';
  } else if (item is _StoreShelfData) {
    warningText = 'এই শেলফটি ডিলিট করলে এর অধীনে থাকা সব বিন ডিলিট হয়ে যাবে। আপনি কি নিশ্চিত?';
  } else if (item is _StoreBinData) {
    warningText = 'এই বিনটি ডিলিট করতে চান?';
  }

  showDialog(
    context: context,
    builder: (context) {
      return AlertDialog(
        title: const Row(
          children: [
            Icon(Icons.warning_amber_rounded, color: Colors.red),
            SizedBox(width: 8),
            Text('সতর্কতা', style: TextStyle(fontWeight: FontWeight.bold)),
          ],
        ),
        content: Text(warningText),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: const Text('বাতিল', style: TextStyle(color: Colors.grey)),
          ),
          ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: Colors.red),
            onPressed: () {
              if (item is _StoreZoneData) {
                _storeZones.remove(item);
              } else if (item is _StoreRackData) {
                for (final z in _storeZones) {
                  if (z.racks.contains(item)) {
                    z.racks.remove(item);
                    break;
                  }
                }
              } else if (item is _StoreShelfData) {
                for (final z in _storeZones) {
                  for (final r in z.racks) {
                    if (r.shelves.contains(item)) {
                      r.shelves.remove(item);
                      break;
                    }
                  }
                }
              } else if (item is _StoreBinData) {
                for (final z in _storeZones) {
                  for (final r in z.racks) {
                    for (final s in r.shelves) {
                      if (s.bins.contains(item)) {
                        s.bins.remove(item);
                        break;
                      }
                    }
                  }
                }
              }
              Navigator.of(context).pop();
              onDeleted();
            },
            child: const Text('মুছে ফেলুন', style: TextStyle(color: Colors.white)),
          ),
        ],
      );
    },
  );
}

class _StoreZoneData {
  _StoreZoneData({
    required this.name,
    required this.racks,
  });

  String name;
  List<_StoreRackData> racks;

  int get totalStock => racks.fold<int>(0, (sum, r) => sum + r.totalStock);
  int get lowStockCount => racks.fold<int>(0, (sum, r) => sum + r.lowStockCount);
}

class _StoreRackData {
  _StoreRackData({
    required this.name,
    required this.shelves,
  });

  String name;
  List<_StoreShelfData> shelves;

  int get totalStock => shelves.fold<int>(0, (sum, s) => sum + s.totalStock);
  int get lowStockCount => shelves.fold<int>(0, (sum, s) => sum + s.lowStockCount);
  int get binCount => shelves.fold<int>(0, (sum, s) => sum + s.bins.length);
}

class _StoreShelfData {
  _StoreShelfData({
    required this.name,
    required this.direction,
    required this.bins,
  });

  String name;
  String direction;
  List<_StoreBinData> bins;

  int get totalStock => bins.fold<int>(0, (sum, b) => sum + b.quantity);
  int get lowStockCount => bins.where((b) => b.isLowStock).length;
}

class _StoreBinData {
  _StoreBinData({
    required this.code,
    required this.quantity,
    required this.rackName,
    required this.shelfName,
  });

  String code;
  int quantity;
  String rackName;
  String shelfName;

  bool get isLowStock => quantity < 10;

  String get locationPath {
    String zoneName = 'গ্রোসারি জোন';
    for (final zone in _storeZones) {
      for (final rack in zone.racks) {
        if (rack.name == rackName) {
          zoneName = zone.name;
          break;
        }
      }
    }
    return '$zoneName · $rackName · $shelfName';
  }
}

List<_StoreZoneData> _storeZones = <_StoreZoneData>[
  _StoreZoneData(
    name: 'গ্রোসারি জোন',
    racks: [
      _StoreRackData(
        name: 'র‍্যাক A',
        shelves: [
          _StoreShelfData(
            name: 'শেলফ ১',
            direction: 'উপরের সারি',
            bins: [
              _StoreBinData(code: 'A-A-S1-B1', quantity: 24, rackName: 'র‍্যাক A', shelfName: 'শেলফ ১'),
              _StoreBinData(code: 'A-A-S1-B2', quantity: 8, rackName: 'র‍্যাক A', shelfName: 'শেলফ ১'),
            ],
          ),
          _StoreShelfData(
            name: 'শেলফ ২',
            direction: 'ডান দিকে',
            bins: [
              _StoreBinData(code: 'A-A-S2-B1', quantity: 14, rackName: 'র‍্যাক A', shelfName: 'শেলফ ২'),
              _StoreBinData(code: 'A-A-S2-B2', quantity: 6, rackName: 'র‍্যাক A', shelfName: 'শেলফ ২'),
            ],
          ),
        ],
      ),
      _StoreRackData(
        name: 'র‍্যাক B',
        shelves: [
          _StoreShelfData(
            name: 'শেলফ ১',
            direction: 'বাম দিক',
            bins: [
              _StoreBinData(code: 'A-B-S1-B1', quantity: 32, rackName: 'র‍্যাক B', shelfName: 'শেলফ ১'),
              _StoreBinData(code: 'A-B-S1-B2', quantity: 18, rackName: 'র‍্যাক B', shelfName: 'শেলফ ১'),
            ],
          ),
          _StoreShelfData(
            name: 'শেলফ ২',
            direction: 'নিচের সারি',
            bins: [
              _StoreBinData(code: 'A-B-S2-B1', quantity: 5, rackName: 'র‍্যাক B', shelfName: 'শেলফ ২'),
              _StoreBinData(code: 'A-B-S2-B2', quantity: 22, rackName: 'র‍্যাক B', shelfName: 'শেলফ ২'),
            ],
          ),
        ],
      ),
    ],
  ),
  _StoreZoneData(
    name: 'ফ্রেশ প্রোডাক্ট জোন',
    racks: [
      _StoreRackData(
        name: 'র‍্যাক C',
        shelves: [
          _StoreShelfData(
            name: 'শেলফ ১',
            direction: 'উপরের সারি',
            bins: [
              _StoreBinData(code: 'B-C-S1-B1', quantity: 12, rackName: 'র‍্যাক C', shelfName: 'শেলফ ১'),
              _StoreBinData(code: 'B-C-S1-B2', quantity: 9, rackName: 'র‍্যাক C', shelfName: 'শেলফ ১'),
            ],
          ),
        ],
      ),
    ],
  ),
  _StoreZoneData(
    name: 'নন-ফুড জোন',
    racks: [
      _StoreRackData(
        name: 'র‍্যাক D',
        shelves: [
          _StoreShelfData(
            name: 'শেলফ ১',
            direction: 'উপরের সারি',
            bins: [
              _StoreBinData(code: 'C-D-S1-B1', quantity: 40, rackName: 'র‍্যাক D', shelfName: 'শেলফ ১'),
              _StoreBinData(code: 'C-D-S1-B2', quantity: 27, rackName: 'র‍্যাক D', shelfName: 'শেলফ ১'),
            ],
          ),
        ],
      ),
    ],
  ),
];

List<_StoreBinData> get _lowStockBins {
  final List<_StoreBinData> result = [];
  for (final zone in _storeZones) {
    for (final rack in zone.racks) {
      for (final shelf in rack.shelves) {
        for (final bin in shelf.bins) {
          if (bin.isLowStock) {
            result.add(bin);
          }
        }
      }
    }
  }
  return result;
}

class DokanStoreLayoutDetailScreen extends StatelessWidget {
  const DokanStoreLayoutDetailScreen({
    super.key,
    required this.level,
    required this.title,
    required this.subtitle,
    required this.details,
    required this.breadcrumbs,
  });

  final String level;
  final String title;
  final String subtitle;
  final String details;
  final List<String> breadcrumbs;

  @override
  Widget build(BuildContext context) {
    final themeAccent = DokanStoreLayoutManagementScreen._accent;
    final themeBg = DokanStoreLayoutManagementScreen._bg;
    final themeText = DokanStoreLayoutManagementScreen._text;
    final themeMuted = DokanStoreLayoutManagementScreen._muted;

    return Scaffold(
      backgroundColor: themeBg,
      appBar: AppBar(
        backgroundColor: themeBg,
        surfaceTintColor: themeBg,
        elevation: 0,
        leading: Padding(
          padding: const EdgeInsets.only(left: 16),
          child: IconButton(
            onPressed: () => Navigator.of(context).maybePop(),
            icon: const Icon(Icons.arrow_back_rounded),
            style: IconButton.styleFrom(
              backgroundColor: Colors.white,
              foregroundColor: themeText,
            ),
          ),
        ),
        leadingWidth: 72,
        title: Text(
          title,
          style: const TextStyle(
            color: DokanStoreLayoutManagementScreen._text,
            fontSize: 19,
            fontWeight: FontWeight.w800,
          ),
        ),
      ),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.fromLTRB(16, 10, 16, 24),
          children: [
            Container(
              padding: const EdgeInsets.all(18),
              decoration: BoxDecoration(
                gradient: const LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [Color(0xFF0E8F5F), Color(0xFF0A6F4A)],
                ),
                borderRadius: BorderRadius.circular(24),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Wrap(
                    spacing: 8,
                    runSpacing: 8,
                    children: breadcrumbs
                        .map(
                          (crumb) => Container(
                            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                            decoration: BoxDecoration(
                              color: Colors.white.withValues(alpha: 0.16),
                              borderRadius: BorderRadius.circular(999),
                              border: Border.all(color: Colors.white.withValues(alpha: 0.16)),
                            ),
                            child: Text(
                              crumb,
                              style: const TextStyle(
                                color: Colors.white,
                                fontSize: 11.5,
                                fontWeight: FontWeight.w700,
                              ),
                            ),
                          ),
                        )
                        .toList(growable: false),
                  ),
                  const SizedBox(height: 14),
                  Text(
                    '$level details',
                    style: TextStyle(
                      color: Colors.white.withValues(alpha: 0.84),
                      fontSize: 12.5,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                  const SizedBox(height: 6),
                  Text(
                    title,
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 22,
                      fontWeight: FontWeight.w800,
                    ),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    subtitle,
                    style: TextStyle(
                      color: Colors.white.withValues(alpha: 0.9),
                      fontSize: 13.5,
                      height: 1.4,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 14),
            _StoreLayoutSectionCard(
              title: 'স্ট্যাটাস',
              subtitle: 'দ্রুত সারাংশ',
              accent: themeAccent,
              child: Wrap(
                spacing: 10,
                runSpacing: 10,
                children: [
                  _StoreLayoutMiniChip(label: 'অ্যাক্টিভ', icon: Icons.circle_rounded, color: themeAccent),
                  _StoreLayoutMiniChip(label: 'রিয়েল-টাইম', icon: Icons.bolt_rounded, color: themeAccent),
                  _StoreLayoutMiniChip(label: details, icon: Icons.inventory_2_rounded, color: themeMuted),
                ],
              ),
            ),
            const SizedBox(height: 14),
            _StoreLayoutSectionCard(
              title: 'দ্রুত পদক্ষেপ',
              subtitle: 'নতুন এন্ট্রি বা আপডেট',
              accent: themeAccent,
              child: Column(
                children: [
                  _StoreLayoutActionCard(
                    icon: Icons.edit_rounded,
                    title: 'সম্পাদনা',
                    subtitle: 'এই আইটেম কনফিগার করুন',
                    onTap: () => Navigator.of(context).maybePop(),
                  ),
                  const SizedBox(height: 10),
                  _StoreLayoutActionCard(
                    icon: Icons.add_rounded,
                    title: 'নতুন যোগ করুন',
                    subtitle: 'এই লেভেলের অধীনে নতুন আইটেম তৈরি করুন',
                    onTap: () => Navigator.of(context).maybePop(),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _StoreLayoutHeroCard extends StatelessWidget {
  const _StoreLayoutHeroCard({
    required this.accent,
    required this.textColor,
    required this.mutedColor,
  });

  final Color accent;
  final Color textColor;
  final Color mutedColor;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [Color(0xFF0E8F5F), Color(0xFF0A6F4A)],
        ),
        borderRadius: BorderRadius.circular(24),
        boxShadow: const [
          BoxShadow(
            color: Color(0x220B5B40),
            blurRadius: 24,
            offset: Offset(0, 12),
          ),
        ],
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: 56,
            height: 56,
            decoration: BoxDecoration(
              color: Colors.white.withValues(alpha: 0.16),
              borderRadius: BorderRadius.circular(16),
            ),
            child: const Icon(Icons.dashboard_customize_rounded, color: Colors.white, size: 30),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'দোকানের ইনভেন্টরি হায়ারার্কি',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 20,
                    fontWeight: FontWeight.w800,
                    height: 1.1,
                  ),
                ),
                const SizedBox(height: 6),
                Text(
                  'Zone থেকে Bin পর্যন্ত সমস্ত লোকেশন এক নজরে দেখুন এবং drill-down করুন।',
                  style: TextStyle(
                    color: Colors.white.withValues(alpha: 0.88),
                    fontSize: 13.5,
                    fontWeight: FontWeight.w500,
                    height: 1.4,
                  ),
                ),
                const SizedBox(height: 10),
                Wrap(
                  spacing: 8,
                  runSpacing: 8,
                  children: [
                                                            Container(
                      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 7),
                      decoration: BoxDecoration(
                        color: Colors.black.withValues(alpha: 0.35),
                        borderRadius: BorderRadius.circular(999),
                        border: Border.all(color: Colors.white.withValues(alpha: 0.2)),
                      ),
                      child: const Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(Icons.verified_rounded, size: 14, color: Colors.white),
                          SizedBox(width: 6),
                          Text(
                                                        'Advanced Inventory Mode',
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: 11.5,
                              fontWeight: FontWeight.w700,
                            ),
                          ),
                        ],
                      ),
                    ),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 7),
                      decoration: BoxDecoration(
                        color: Colors.black.withValues(alpha: 0.35),
                        borderRadius: BorderRadius.circular(999),
                        border: Border.all(color: Colors.white.withValues(alpha: 0.2)),
                      ),
                      child: const Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(Icons.bolt_rounded, size: 14, color: Colors.white),
                          SizedBox(width: 6),
                          Text(
                            'Real-time tracking',
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: 11.5,
                              fontWeight: FontWeight.w700,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _StoreLayoutItemCard extends StatelessWidget {
  const _StoreLayoutItemCard({
    required this.title,
    required this.subtitle,
    required this.icon,
    required this.iconColor,
    required this.iconBgColor,
    required this.onTap,
    required this.onMorePressed,
    this.isSelected = false,
    this.trailing,
  });

  final Widget title;
  final Widget subtitle;
  final IconData icon;
  final Color iconColor;
  final Color iconBgColor;
  final VoidCallback onTap;
  final VoidCallback onMorePressed;
  final bool isSelected;
  final Widget? trailing;

  @override
  Widget build(BuildContext context) {
    const activeColor = DokanStoreLayoutManagementScreen._accent;
    const cardBorderColor = DokanStoreLayoutManagementScreen._cardBorder;
    final trailingWidget = trailing;

    return AnimatedContainer(
      duration: const Duration(milliseconds: 200),
      curve: Curves.easeInOut,
      transform: isSelected
          ? Matrix4.translationValues(8, 0, 0)
          : Matrix4.identity(),
      decoration: BoxDecoration(
        color: isSelected ? const Color(0xFFF0FDF4) : const Color(0xFFFDFEFE),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: isSelected ? activeColor : cardBorderColor,
          width: isSelected ? 2 : 1,
        ),
        boxShadow: isSelected
            ? const [
                BoxShadow(
                  color: Color(0x1A0E8F5F),
                  blurRadius: 12,
                  offset: Offset(0, 4),
                )
              ]
            : const [
                BoxShadow(
                  color: Color(0x05000000),
                  blurRadius: 4,
                  offset: Offset(0, 2),
                )
              ],
      ),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: onTap,
          borderRadius: BorderRadius.circular(16),
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
            child: Row(
              children: [
                Container(
                  width: 48,
                  height: 48,
                  decoration: BoxDecoration(
                    color: isSelected ? activeColor.withValues(alpha: 0.15) : iconBgColor,
                    borderRadius: BorderRadius.circular(14),
                  ),
                  child: Icon(icon, color: isSelected ? activeColor : iconColor),
                ),
                const SizedBox(width: 14),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      title,
                      const SizedBox(height: 6),
                      subtitle,
                    ],
                  ),
                ),
                                if (trailingWidget != null)
                  GestureDetector(
                    behavior: HitTestBehavior.translucent,
                    onTap: () {},
                    child: Padding(
                      padding: const EdgeInsets.only(left: 4),
                      child: IntrinsicWidth(
                        child: trailingWidget,
                      ),
                    ),
                  ),
                GestureDetector(
                  onTap: () {},
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 4),
                    child: IconButton(
                      padding: EdgeInsets.zero,
                      constraints: const BoxConstraints(),
                      icon: const Icon(Icons.more_vert_rounded, color: DokanStoreLayoutManagementScreen._muted),
                      onPressed: onMorePressed,
                    ),
                  ),
                ),
                if (trailingWidget == null)
                  const Icon(Icons.chevron_right_rounded, color: Color(0xFF8A9896)),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _StoreLayoutBreadcrumb extends StatelessWidget {
  const _StoreLayoutBreadcrumb({required this.steps});

  final List<String> steps;

  @override
  Widget build(BuildContext context) {
    return Wrap(
      crossAxisAlignment: WrapCrossAlignment.center,
      spacing: 8,
      runSpacing: 8,
      children: [
        for (var i = 0; i < steps.length; i++) ...[
          _StoreLayoutMiniChip(
            label: steps[i],
            icon: i == 0 ? Icons.home_rounded : Icons.chevron_right_rounded,
            color: i == 0 ? DokanStoreLayoutManagementScreen._accent : DokanStoreLayoutManagementScreen._muted,
          ),
        ],
      ],
    );
  }
}

class _StoreLayoutSectionCard extends StatelessWidget {
  const _StoreLayoutSectionCard({
    required this.title,
    required this.subtitle,
    required this.accent,
    required this.child,
  });

  final String title;
  final String subtitle;
  final Color accent;
  final Widget child;

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(22),
        border: Border.all(color: DokanStoreLayoutManagementScreen._cardBorder),
        boxShadow: const [
          BoxShadow(
            color: Color(0x0C21413C),
            blurRadius: 18,
            offset: Offset(0, 8),
          ),
        ],
      ),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Container(width: 10, height: 10, decoration: BoxDecoration(color: accent, shape: BoxShape.circle)),
                const SizedBox(width: 8),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        title,
                        style: const TextStyle(
                          color: Color(0xFF142D2A),
                          fontSize: 16,
                          fontWeight: FontWeight.w800,
                        ),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        subtitle,
                        style: const TextStyle(
                          color: Color(0xFF6B7D78),
                          fontSize: 12.5,
                          height: 1.35,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
            const SizedBox(height: 14),
            child,
          ],
        ),
      ),
    );
  }
}

class _StoreLayoutAlertRow extends StatelessWidget {
  const _StoreLayoutAlertRow({
    required this.binCode,
    required this.location,
    required this.quantity,
    required this.onTap,
  });

  final String binCode;
  final String location;
  final int quantity;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(16),
        child: Container(
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(
            color: const Color(0xFFFFF4EC),
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: const Color(0xFFF3C6A4)),
          ),
          child: Row(
            children: [
              Container(
                width: 42,
                height: 42,
                decoration: BoxDecoration(
                  color: const Color(0xFFFFE3D0),
                  borderRadius: BorderRadius.circular(14),
                ),
                child: const Icon(Icons.warning_amber_rounded, color: DokanStoreLayoutManagementScreen._warning),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      binCode,
                      style: const TextStyle(
                        color: Color(0xFF8A3B0C),
                        fontSize: 14.5,
                        fontWeight: FontWeight.w800,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      location,
                      style: const TextStyle(
                        color: Color(0xFF7E4A2B),
                        fontSize: 12.5,
                        height: 1.3,
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 8),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 7),
                decoration: BoxDecoration(
                  color: const Color(0xFFFFE4D6),
                  borderRadius: BorderRadius.circular(999),
                ),
                child: Text(
                  '$quantity',
                  style: const TextStyle(
                    color: DokanStoreLayoutManagementScreen._danger,
                    fontWeight: FontWeight.w800,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _StoreLayoutActionCard extends StatelessWidget {
  const _StoreLayoutActionCard({
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.onTap,
  });

  final IconData icon;
  final String title;
  final String subtitle;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(16),
        child: Container(
          width: double.infinity,
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(
            color: const Color(0xFFF7FBFA),
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: const Color(0xFFE3EBE8)),
          ),
          child: Row(
            children: [
              Container(
                width: 44,
                height: 44,
                decoration: BoxDecoration(
                  color: const Color(0xFFEAF5F1),
                  borderRadius: BorderRadius.circular(14),
                ),
                child: Icon(icon, color: const Color(0xFF0E8F5F)),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      title,
                      style: const TextStyle(
                        color: Color(0xFF142D2A),
                        fontSize: 14.5,
                        fontWeight: FontWeight.w800,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      subtitle,
                      style: const TextStyle(
                        color: Color(0xFF6B7D78),
                        fontSize: 12.5,
                        height: 1.35,
                      ),
                    ),
                  ],
                ),
              ),
              const Icon(Icons.chevron_right_rounded, color: Color(0xFF8A9896)),
            ],
          ),
        ),
      ),
    );
  }
}

class _StoreLayoutMiniChip extends StatelessWidget {
  const _StoreLayoutMiniChip({
    required this.label,
    required this.icon,
    required this.color,
  });

  final String label;
  final IconData icon;
  final Color color;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 7),
      decoration: BoxDecoration(
        color: color.withValues(alpha: 0.12),
        borderRadius: BorderRadius.circular(999),
        border: Border.all(color: color.withValues(alpha: 0.2)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 14, color: color),
          const SizedBox(width: 6),
          Text(
            label,
            style: TextStyle(
              color: color,
              fontSize: 11.5,
              fontWeight: FontWeight.w700,
            ),
          ),
        ],
      ),
    );
  }
}

class _AppConfigFooterChip extends StatelessWidget {
  const _AppConfigFooterChip({
    required this.label,
    required this.icon,
  });

  final String label;
  final IconData icon;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 7),
      decoration: BoxDecoration(
        color: const Color(0xFFEAF5F1),
        borderRadius: BorderRadius.circular(999),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 14, color: DokanAroOptionScreen._accent),
          const SizedBox(width: 6),
          Text(
            label,
            style: const TextStyle(
              color: DokanAroOptionScreen._primaryText,
              fontSize: 11.5,
              fontWeight: FontWeight.w700,
            ),
          ),
        ],
      ),
    );
  }
}

class _MoreSectionView extends StatelessWidget {
  const _MoreSectionView({
    required this.title,
    required this.items,
  });

  final String title;
  final List<_MoreItem> items;

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.only(left: 2, bottom: 8),
          child: Text(
            title,
            style: const TextStyle(
              color: Color(0xFF516462),
              fontSize: 14,
              fontWeight: FontWeight.w700,
            ),
          ),
        ),
        Container(
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: DokanAroOptionScreen._cardBorder),
            boxShadow: const [
              BoxShadow(
                color: Color(0x0F21413C),
                blurRadius: 18,
                offset: Offset(0, 8),
              ),
            ],
          ),
          child: ClipRRect(
            borderRadius: BorderRadius.circular(16),
            child: Column(
              children: [
                for (var index = 0; index < items.length; index++) ...[
                  _MoreMenuTile(item: items[index]),
                  if (index != items.length - 1)
                    const Divider(height: 1, thickness: 1, color: Color(0xFFF0F4F5)),
                ],
              ],
            ),
          ),
        ),
      ],
    );
  }
}

class _MoreMenuTile extends StatelessWidget {
  const _MoreMenuTile({required this.item});

  final _MoreItem item;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: item.onTap,
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 13),
          child: Row(
            children: [
              Container(
                width: 40,
                height: 40,
                decoration: BoxDecoration(
                  color: item.iconBackground,
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Icon(
                  item.icon,
                  color: item.iconColor,
                  size: 22,
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      item.title,
                      style: TextStyle(
                        color: item.titleColor ?? DokanAroOptionScreen._primaryText,
                        fontSize: 15,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                    const SizedBox(height: 3),
                    Text(
                      item.subtitle,
                      style: const TextStyle(
                        color: DokanAroOptionScreen._secondaryText,
                        fontSize: 12.5,
                        fontWeight: FontWeight.w500,
                        height: 1.25,
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 10),
              const Icon(
                Icons.chevron_right_rounded,
                color: Color(0xFF8A9896),
                size: 22,
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _HeaderButton extends StatelessWidget {
  const _HeaderButton({
    required this.icon,
    required this.onTap,
  });

  final IconData icon;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.white,
      borderRadius: BorderRadius.circular(14),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(14),
        child: SizedBox(
          width: 40,
          height: 40,
          child: Icon(
            icon,
            color: DokanAroOptionScreen._primaryText,
            size: 22,
          ),
        ),
      ),
    );
  }
}

class _MiniActionButton extends StatelessWidget {
  const _MiniActionButton({
    required this.icon,
    required this.onTap,
  });

  final IconData icon;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.white.withValues(alpha: 0.18),
      shape: const CircleBorder(),
      child: InkWell(
        onTap: onTap,
        customBorder: const CircleBorder(),
        child: SizedBox(
          width: 28,
          height: 28,
          child: Icon(
            icon,
            color: Colors.white,
            size: 17,
          ),
        ),
      ),
    );
  }
}

class _MoreBottomNav extends StatelessWidget {
  const _MoreBottomNav({
    required this.selectedIndex,
    required this.onHomeTap,
    required this.onSalesTap,
    required this.onProductsTap,
    required this.onReportsTap,
  });

  final int selectedIndex;
  final VoidCallback onHomeTap;
  final VoidCallback onSalesTap;
  final VoidCallback onProductsTap;
  final VoidCallback onReportsTap;

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      top: false,
      child: Container(
        decoration: BoxDecoration(
          color: Colors.white.withValues(alpha: 0.97),
          border: const Border(top: BorderSide(color: Color(0xFFE4ECEE))),
          boxShadow: const [
            BoxShadow(
              color: Color(0x14000000),
              blurRadius: 18,
              offset: Offset(0, -4),
            ),
          ],
        ),
        padding: const EdgeInsets.fromLTRB(8, 8, 8, 10),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceAround,
          children: [
            _MoreNavItem(
              icon: Icons.home_rounded,
              label: 'হোম',
              selected: selectedIndex == 0,
              onTap: onHomeTap,
            ),
            _MoreNavItem(
              icon: Icons.shopping_bag_rounded,
              label: 'বিক্রয়',
              selected: selectedIndex == 1,
              onTap: onSalesTap,
            ),
            _MoreNavItem(
              icon: Icons.inventory_2_rounded,
              label: 'পণ্য',
              selected: selectedIndex == 2,
              onTap: onProductsTap,
            ),
            _MoreNavItem(
              icon: Icons.bar_chart_rounded,
              label: 'রিপোর্ট',
              selected: selectedIndex == 3,
              onTap: onReportsTap,
            ),
            _MoreNavItem(
              icon: Icons.more_horiz_rounded,
              label: 'আরও',
              selected: selectedIndex == 4,
              onTap: () {},
            ),
          ],
        ),
      ),
    );
  }
}

class _MoreNavItem extends StatelessWidget {
  const _MoreNavItem({
    required this.icon,
    required this.label,
    required this.selected,
    required this.onTap,
  });

  final IconData icon;
  final String label;
  final bool selected;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final color = selected ? DokanAroOptionScreen._accent : const Color(0xFF83929A);
    return Expanded(
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: onTap,
          borderRadius: BorderRadius.circular(16),
          child: Padding(
            padding: const EdgeInsets.symmetric(vertical: 4),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(icon, color: color, size: 24),
                const SizedBox(height: 4),
                Text(
                  label,
                  style: TextStyle(
                    color: color,
                    fontSize: 11.5,
                    fontWeight: selected ? FontWeight.w700 : FontWeight.w500,
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _MoreSection {
  const _MoreSection({
    required this.title,
    required this.items,
  });

  final String title;
  final List<_MoreItem> items;
}

class _MoreItem {
  const _MoreItem({
    required this.icon,
    required this.iconBackground,
    required this.iconColor,
    required this.title,
    required this.subtitle,
    required this.onTap,
    this.titleColor,
  });

  final IconData icon;
  final Color iconBackground;
  final Color iconColor;
  final String title;
  final String subtitle;
  final VoidCallback onTap;
  final Color? titleColor;
}

enum _TaxChargeValueType {
  percent,
  fixed;

  String get label {
    switch (this) {
      case _TaxChargeValueType.percent:
        return 'শতাংশ (%)';
      case _TaxChargeValueType.fixed:
        return 'নির্দিষ্ট (৳)';
    }
  }

  String format(double value) {
    final clean = value % 1 == 0 ? value.toInt().toString() : value.toStringAsFixed(2);
    switch (this) {
      case _TaxChargeValueType.percent:
        return '$clean%';
      case _TaxChargeValueType.fixed:
        return '৳$clean';
    }
  }
}

class _TaxChargeItem {
  const _TaxChargeItem({
    required this.name,
    required this.value,
    required this.type,
  });

  final String name;
  final double value;
  final _TaxChargeValueType type;
}

class DokanTaxChargesManagementScreen extends StatefulWidget {
  const DokanTaxChargesManagementScreen({super.key});

  @override
  State<DokanTaxChargesManagementScreen> createState() => _DokanTaxChargesManagementScreenState();
}

class _DokanTaxChargesManagementScreenState extends State<DokanTaxChargesManagementScreen> {
  final List<_TaxChargeItem> _taxes = [
    const _TaxChargeItem(name: 'ভ্যাট', value: 15, type: _TaxChargeValueType.percent),
    const _TaxChargeItem(name: 'সম্পূরক শুল্ক (SD)', value: 5, type: _TaxChargeValueType.percent),
  ];

  final List<_TaxChargeItem> _charges = [
    const _TaxChargeItem(name: 'ডেলিভারি চার্জ', value: 60, type: _TaxChargeValueType.fixed),
    const _TaxChargeItem(name: 'প্যাকেজিং চার্জ', value: 10, type: _TaxChargeValueType.fixed),
    const _TaxChargeItem(name: 'সার্ভিস চার্জ', value: 2, type: _TaxChargeValueType.percent),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        leading: IconButton(
          onPressed: () => Navigator.of(context).maybePop(),
          icon: const Icon(Icons.arrow_back_rounded, color: Colors.black),
        ),
        title: const Text(
          'Tax & Charges Management',
          style: TextStyle(color: Colors.black, fontSize: 18, fontWeight: FontWeight.w800),
        ),
      ),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            _section('কর (Tax)', _taxes, true),
            const SizedBox(height: 28),
            _section('অতিরিক্ত চার্জ', _charges, false),
          ],
        ),
      ),
    );
  }

  Widget _section(String title, List<_TaxChargeItem> items, bool isTax) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Row(
          children: [
            Expanded(
              child: Text(
                title,
                style: const TextStyle(color: Colors.black, fontSize: 20, fontWeight: FontWeight.w800),
              ),
            ),
            FilledButton(
              onPressed: () => _openSheet(isTax: isTax),
              style: FilledButton.styleFrom(backgroundColor: Colors.black, foregroundColor: Colors.white),
              child: const Text('যোগ করুন'),
            ),
          ],
        ),
        const SizedBox(height: 12),
        ...List.generate(items.length, (index) {
          final item = items[index];
          return Card(
            color: Colors.white,
            elevation: 0,
            margin: const EdgeInsets.only(bottom: 10),
            shape: RoundedRectangleBorder(
              side: const BorderSide(color: Color(0xFFE5E7EB)),
              borderRadius: BorderRadius.circular(12),
            ),
            child: ListTile(
              title: Text(item.name, style: const TextStyle(color: Colors.black, fontWeight: FontWeight.w700)),
              trailing: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(item.type.format(item.value), style: const TextStyle(color: Colors.black, fontWeight: FontWeight.w800)),
                PopupMenuButton<String>(
  icon: const Icon(
    Icons.more_vert,
    color: Colors.black,
  ),
  color: Colors.white,
  onSelected: (value) {
                      if (value == 'edit') _openSheet(isTax: isTax, index: index);
                      if (value == 'delete') _deleteItem(isTax: isTax, index: index);
                    },
                    itemBuilder: (_) => const [
                      PopupMenuItem(value: 'edit', child: Text('Edit')),
                      PopupMenuItem(value: 'delete', child: Text('Delete')),
                    ],
                  ),
                ],
              ),
            ),
          );
        }),
      ],
    );
  }

  void _deleteItem({required bool isTax, required int index}) {
    setState(() {
      if (isTax) {
        _taxes.removeAt(index);
      } else {
        _charges.removeAt(index);
      }
    });
  }

  Future<void> _openSheet({required bool isTax, int? index}) async {
    final list = isTax ? _taxes : _charges;
    final old = index == null ? null : list[index];

    final result = await showModalBottomSheet<_TaxChargeItem>(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.white,
      builder: (_) => _TaxChargeSheet(
        oldItem: old,
        existingNames: list
            .asMap()
            .entries
            .where((e) => e.key != index)
            .map((e) => e.value.name.trim().toLowerCase())
            .toSet(),
      ),
    );

    if (result == null) return;

    setState(() {
      if (index == null) {
        list.add(result);
      } else {
        list[index] = result;
      }
    });
  }
}

class _TaxChargeSheet extends StatefulWidget {
  const _TaxChargeSheet({
    required this.existingNames,
    this.oldItem,
  });

  final _TaxChargeItem? oldItem;
  final Set<String> existingNames;

  @override
  State<_TaxChargeSheet> createState() => _TaxChargeSheetState();
}

class _TaxChargeSheetState extends State<_TaxChargeSheet> {
  final _formKey = GlobalKey<FormState>();
  late final TextEditingController _name;
  late final TextEditingController _value;
  late _TaxChargeValueType _type;

  @override
  void initState() {
    super.initState();
    _name = TextEditingController(text: widget.oldItem?.name ?? '');
    _value = TextEditingController(text: widget.oldItem?.value.toString() ?? '');
    _type = widget.oldItem?.type ?? _TaxChargeValueType.percent;
  }

  @override
  void dispose() {
    _name.dispose();
    _value.dispose();
    super.dispose();
  }

  @override
 @override
Widget build(BuildContext context) {
  final keyboard = MediaQuery.viewInsetsOf(context).bottom;

  return Padding(
    padding: EdgeInsets.only(bottom: keyboard),
    child: SafeArea(
      child: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Form(
          key: _formKey,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextFormField(
                controller: _name,
                style: const TextStyle(color: Colors.black, fontSize: 15, fontWeight: FontWeight.w600),
                decoration: InputDecoration(
                  labelText: 'নাম',
                  labelStyle: const TextStyle(color: Colors.black, fontWeight: FontWeight.w600),
                  hintText: 'যেমন VAT / ডেলিভারি চার্জ',
                  hintStyle: const TextStyle(color: Color(0xFF6B7280)),
                  border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
                ),
                validator: (v) {
                  final name = v?.trim() ?? '';
                  if (name.isEmpty) return 'নাম লিখুন';
                  if (widget.existingNames.contains(name.toLowerCase())) return 'এই নামটি আগে থেকেই আছে';
                  return null;
                },
              ),
              const SizedBox(height: 12),
              DropdownButtonFormField<_TaxChargeValueType>(
                value: _type,
                dropdownColor: Colors.white,
                style: const TextStyle(color: Colors.black, fontSize: 15, fontWeight: FontWeight.w600),
                decoration: InputDecoration(
                  labelText: 'ধরন',
                  labelStyle: const TextStyle(color: Colors.black, fontWeight: FontWeight.w600),
                  border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
                ),
                items: _TaxChargeValueType.values
                    .map((e) => DropdownMenuItem(
                          value: e,
                          child: Text(e.label, style: const TextStyle(color: Colors.black)),
                        ))
                    .toList(),
                onChanged: (v) => setState(() => _type = v ?? _type),
              ),
              const SizedBox(height: 12),
              TextFormField(
                controller: _value,
                style: const TextStyle(color: Colors.black, fontSize: 15, fontWeight: FontWeight.w600),
                keyboardType: const TextInputType.numberWithOptions(decimal: true),
                decoration: InputDecoration(
                  labelText: 'মান',
                  labelStyle: const TextStyle(color: Colors.black, fontWeight: FontWeight.w600),
                  border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
                ),
                validator: (v) {
                  final raw = v?.trim() ?? '';
                  final num = double.tryParse(raw);
                  if (raw.isEmpty) return 'মান লিখুন';
                  if (num == null) return 'সঠিক সংখ্যা লিখুন';
                  return null;
                },
              ),
              const SizedBox(height: 18),
              SizedBox(
                width: double.infinity,
                child: FilledButton(
                  onPressed: _save,
                  style: FilledButton.styleFrom(backgroundColor: Colors.black, foregroundColor: Colors.white),
                  child: const Text('সংরক্ষণ করুন'),
                ),
              ),
              TextButton(
                onPressed: () => Navigator.of(context).pop(),
                child: const Text('বাতিল', style: TextStyle(color: Colors.black)),
              ),
            ],
          ),
        ),
      ),
    ),
  );
}
  void _save() {
    if (!_formKey.currentState!.validate()) return;

    Navigator.of(context).pop(
      _TaxChargeItem(
        name: _name.text.trim(),
        value: double.parse(_value.text.trim()),
        type: _type,
      ),
    );
  }
}