import 'dart:math' as math;

// ignore_for_file: deprecated_member_use, invalid_use_of_visible_for_testing_member, invalid_use_of_protected_member, argument_type_not_assignable, unused_element, non_exhaustive_switch_expression
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../pos/screens/pos_screens.dart';
import '../../products/screens/product_screens.dart';
import '../../settings/screens/settings_screens.dart';
import '../screens/expense_entry_screen.dart';
import '../state/expense_report_provider.dart';

enum DokanReportTimeFilter { today, thisWeek, thisMonth, thisYear }

class _ReportFilterNotifier extends Notifier<DokanReportTimeFilter> {
  @override
  DokanReportTimeFilter build() => DokanReportTimeFilter.thisMonth;

  void setFilter(DokanReportTimeFilter value) {
    state = value;
  }
}

final reportFilterProvider =
    NotifierProvider<_ReportFilterNotifier, DokanReportTimeFilter>(_ReportFilterNotifier.new);

class _ReportBreakdownTabNotifier extends Notifier<int> {
  @override
  int build() => 0;

  void setTab(int value) {
    state = value;
  }
}

final reportBreakdownTabProvider =
    NotifierProvider<_ReportBreakdownTabNotifier, int>(_ReportBreakdownTabNotifier.new);

class _ReportRecord {
  const _ReportRecord({
    required this.timestamp,
    required this.kind,
    required this.title,
    required this.category,
    required this.paymentMethod,
    required this.quantity,
    required this.salesAmount,
    required this.profitAmount,
    required this.purchaseAmount,
    required this.expenseAmount,
    required this.note,
    required this.icon,
    required this.color,
  });

  final DateTime timestamp;
  final _ReportRecordKind kind;
  final String title;
  final String category;
  final String paymentMethod;
  final int quantity;
  final int salesAmount;
  final int profitAmount;
  final int purchaseAmount;
  final int expenseAmount;
  final String note;
  final IconData icon;
  final Color color;
}

enum _ReportRecordKind { sale, purchase, expense, returnItem, manual }

class _ReportSummary {
  const _ReportSummary({
    required this.sales,
    required this.profit,
    required this.purchase,
    required this.expense,
  });

  final int sales;
  final int profit;
  final int purchase;
  final int expense;
}

class _TrendPoint {
  const _TrendPoint({
    required this.label,
    required this.value,
  });

  final String label;
  final int value;
}

class _PaymentSlice {
  const _PaymentSlice({
    required this.label,
    required this.amount,
    required this.color,
    required this.icon,
  });

  final String label;
  final int amount;
  final Color color;
  final IconData icon;
}

class _TopProductStat {
  const _TopProductStat({
    required this.rank,
    required this.name,
    required this.salesCount,
    required this.revenue,
    required this.category,
    required this.icon,
    required this.color,
  });

  final int rank;
  final String name;
  final int salesCount;
  final int revenue;
  final String category;
  final IconData icon;
  final Color color;
}

class _ActivityEntry {
  const _ActivityEntry({
    required this.timestamp,
    required this.title,
    required this.subtitle,
    required this.trailing,
    required this.color,
    required this.icon,
  });

  final DateTime timestamp;
  final String title;
  final String subtitle;
  final String trailing;
  final Color color;
  final IconData icon;
}

String _bnDigits(String input) {
  const map = <String, String>{
    '0': '০',
    '1': '১',
    '2': '২',
    '3': '৩',
    '4': '৪',
    '5': '৫',
    '6': '৬',
    '7': '৭',
    '8': '৮',
    '9': '৯',
  };
  return input.split('').map((char) => map[char] ?? char).join();
}

String _currency(int value) => '৳${_bnDigits(value.toString())}';

String _monthName(int month) {
  const names = <String>[
    'জানুয়ারি',
    'ফেব্রুয়ারি',
    'মার্চ',
    'এপ্রিল',
    'মে',
    'জুন',
    'জুলাই',
    'আগস্ট',
    'সেপ্টেম্বর',
    'অক্টোবর',
    'নভেম্বর',
    'ডিসেম্বর',
  ];
  return names[month - 1];
}


String _formatTime(DateTime dateTime) {
  final hour12 = dateTime.hour % 12 == 0 ? 12 : dateTime.hour % 12;
  final suffix = dateTime.hour >= 12 ? 'PM' : 'AM';
  return '${_bnDigits(hour12.toString())}:${dateTime.minute.toString().padLeft(2, '0')} $suffix';
}

DateTime _startOfWeek(DateTime date) {
  final day = DateUtils.dateOnly(date);
  return day.subtract(Duration(days: day.weekday - 1));
}

bool _matchesFilter(DateTime dateTime, DokanReportTimeFilter filter) {
  final now = DateTime.now();
  final today = DateUtils.dateOnly(now);
  final day = DateUtils.dateOnly(dateTime);
  switch (filter) {
    case DokanReportTimeFilter.today:
      return day == today;
    case DokanReportTimeFilter.thisWeek:
      return !day.isBefore(_startOfWeek(now));
    case DokanReportTimeFilter.thisMonth:
      return day.year == now.year && day.month == now.month;
    case DokanReportTimeFilter.thisYear:
      return day.year == now.year;
  }
}

List<_ReportRecord> _seedReportRecords() {
  final now = DateTime.now();
  final yesterday = now.subtract(const Duration(days: 1));
  final threeDaysAgo = now.subtract(const Duration(days: 3));
  final fiveDaysAgo = now.subtract(const Duration(days: 5));
  final sixDaysAgo = now.subtract(const Duration(days: 6));
  final eightDaysAgo = now.subtract(const Duration(days: 8));
  final tenDaysAgo = now.subtract(const Duration(days: 10));
  final fourteenDaysAgo = now.subtract(const Duration(days: 14));
  return <_ReportRecord>[
    _ReportRecord(
      timestamp: DateTime(now.year, now.month, now.day, 9, 40),
      kind: _ReportRecordKind.sale,
      title: 'মিনিকেট চাল ১কেজি বিক্রি',
      category: 'চাল-ডাল',
      paymentMethod: 'নগদ',
      quantity: 12,
      salesAmount: 9600,
      profitAmount: 2040,
      purchaseAmount: 7560,
      expenseAmount: 0,
      note: 'গ্রাহক: করিম সাহেব',
      icon: Icons.shopping_cart_outlined,
      color: const Color(0xFFD43B3B),
    ),
    _ReportRecord(
      timestamp: DateTime(now.year, now.month, now.day, 11, 20),
      kind: _ReportRecordKind.sale,
      title: 'কোকা কোলা ২৫০মি বিক্রি',
      category: 'পানীয়',
      paymentMethod: 'bKash',
      quantity: 18,
      salesAmount: 630,
      profitAmount: 144,
      purchaseAmount: 486,
      expenseAmount: 0,
      note: 'অনলাইন অর্ডার',
      icon: Icons.local_drink_outlined,
      color: const Color(0xFF2F6BFF),
    ),
    _ReportRecord(
      timestamp: DateTime(now.year, now.month, now.day, 14, 5),
      kind: _ReportRecordKind.expense,
      title: 'দোকান খরচ',
      category: 'খরচ',
      paymentMethod: 'নগদ',
      quantity: 0,
      salesAmount: 0,
      profitAmount: 0,
      purchaseAmount: 0,
      expenseAmount: 1240,
      note: 'বিদ্যুৎ ও ভাড়া',
      icon: Icons.receipt_long_outlined,
      color: const Color(0xFF8A8A8A),
    ),
    _ReportRecord(
      timestamp: DateTime(yesterday.year, yesterday.month, yesterday.day, 10, 10),
      kind: _ReportRecordKind.sale,
      title: 'সয়াবিন তেল ১লি বিক্রি',
      category: 'তেল-মসলা',
      paymentMethod: 'নগদ',
      quantity: 24,
      salesAmount: 3960,
      profitAmount: 840,
      purchaseAmount: 3120,
      expenseAmount: 0,
      note: 'দোকান ক্রেতা',
      icon: Icons.shopping_bag_outlined,
      color: const Color(0xFF0C8C67),
    ),
    _ReportRecord(
      timestamp: DateTime(yesterday.year, yesterday.month, yesterday.day, 13, 45),
      kind: _ReportRecordKind.purchase,
      title: 'নতুন পণ্য ক্রয়',
      category: 'ক্রয়',
      paymentMethod: 'নগদ',
      quantity: 0,
      salesAmount: 0,
      profitAmount: 0,
      purchaseAmount: 7800,
      expenseAmount: 0,
      note: 'সরবরাহকারী: আলম ট্রেডার্স',
      icon: Icons.inventory_2_outlined,
      color: const Color(0xFF0C8C67),
    ),
    _ReportRecord(
      timestamp: now.subtract(const Duration(days: 2, hours: 3)),
      kind: _ReportRecordKind.sale,
      title: 'লাক্স সাবান ১০০গ্রা বিক্রি',
      category: 'সাবান',
      paymentMethod: 'বাকি',
      quantity: 10,
      salesAmount: 580,
      profitAmount: 160,
      purchaseAmount: 420,
      expenseAmount: 0,
      note: 'বাকি হিসেবে যোগ',
      icon: Icons.water_drop_outlined,
      color: const Color(0xFFF49B1A),
    ),
    _ReportRecord(
      timestamp: threeDaysAgo.subtract(const Duration(hours: 5)),
      kind: _ReportRecordKind.returnItem,
      title: 'ফেরত গ্রহণ',
      category: 'রিটার্ন',
      paymentMethod: 'নগদ',
      quantity: 2,
      salesAmount: -190,
      profitAmount: -45,
      purchaseAmount: 0,
      expenseAmount: 0,
      note: 'গ্রাহক ফেরত দিয়েছেন',
      icon: Icons.assignment_return_outlined,
      color: const Color(0xFF2F6BFF),
    ),
    _ReportRecord(
      timestamp: fiveDaysAgo.subtract(const Duration(hours: 2)),
      kind: _ReportRecordKind.sale,
      title: 'চিনি ১কেজি বিক্রি',
      category: 'চাল-ডাল',
      paymentMethod: 'নগদ',
      quantity: 14,
      salesAmount: 1680,
      profitAmount: 210,
      purchaseAmount: 1470,
      expenseAmount: 0,
      note: 'রেগুলার বিক্রয়',
      icon: Icons.shopping_basket_outlined,
      color: const Color(0xFFD43B3B),
    ),
    _ReportRecord(
      timestamp: sixDaysAgo.subtract(const Duration(hours: 1)),
      kind: _ReportRecordKind.manual,
      title: 'স্টক সমন্বয়',
      category: 'ম্যানুয়াল',
      paymentMethod: 'ম্যানুয়াল',
      quantity: 0,
      salesAmount: 0,
      profitAmount: 0,
      purchaseAmount: 0,
      expenseAmount: 0,
      note: 'ভুল এন্ট্রি সংশোধন',
      icon: Icons.edit_outlined,
      color: const Color(0xFF8A8A8A),
    ),
    _ReportRecord(
      timestamp: eightDaysAgo.subtract(const Duration(hours: 3)),
      kind: _ReportRecordKind.sale,
      title: 'বিস্কুট ১ প্যাকেট বিক্রি',
      category: 'বিস্কুট',
      paymentMethod: 'bKash',
      quantity: 20,
      salesAmount: 1200,
      profitAmount: 260,
      purchaseAmount: 940,
      expenseAmount: 0,
      note: 'রেস্টক দরকার',
      icon: Icons.cookie_outlined,
      color: const Color(0xFF0C8C67),
    ),
    _ReportRecord(
      timestamp: tenDaysAgo.subtract(const Duration(hours: 6)),
      kind: _ReportRecordKind.purchase,
      title: 'মিনিকেট চাল ক্রয়',
      category: 'ক্রয়',
      paymentMethod: 'নগদ',
      quantity: 0,
      salesAmount: 0,
      profitAmount: 0,
      purchaseAmount: 12400,
      expenseAmount: 0,
      note: 'নতুন চালান এসেছে',
      icon: Icons.local_shipping_outlined,
      color: const Color(0xFF0C8C67),
    ),
    _ReportRecord(
      timestamp: fourteenDaysAgo.subtract(const Duration(hours: 4)),
      kind: _ReportRecordKind.sale,
      title: 'ডিটারজেন্ট ৫০০গ্রা বিক্রি',
      category: 'সাবান',
      paymentMethod: 'নগদ',
      quantity: 8,
      salesAmount: 680,
      profitAmount: 135,
      purchaseAmount: 545,
      expenseAmount: 0,
      note: 'পুনরায় অর্ডারযোগ্য',
      icon: Icons.cleaning_services_outlined,
      color: const Color(0xFF2F6BFF),
    ),
  ];
}

List<_ReportRecord> _filteredRecords(DokanReportTimeFilter filter) {
  return _seedReportRecords().where((record) => _matchesFilter(record.timestamp, filter)).toList(growable: false);
}

final reportSummaryProvider = Provider<_ReportSummary>((ref) {
  final filter = ref.watch(reportFilterProvider);
  final records = _filteredRecords(filter);
  final sales = records.fold<int>(0, (sum, record) => sum + record.salesAmount).clamp(-999999, 999999);
  final profit = records.fold<int>(0, (sum, record) => sum + record.profitAmount).clamp(-999999, 999999);
  final purchase = records.fold<int>(0, (sum, record) => sum + record.purchaseAmount).clamp(-999999, 999999);
  final expense = records.fold<int>(0, (sum, record) => sum + record.expenseAmount).clamp(-999999, 999999);
  return _ReportSummary(sales: sales, profit: profit, purchase: purchase, expense: expense);
});

final salesTrendProvider = Provider<List<_TrendPoint>>((ref) {
  final filter = ref.watch(reportFilterProvider);
  final records = _filteredRecords(filter).where((record) => record.kind == _ReportRecordKind.sale);
  final now = DateTime.now();

  if (filter == DokanReportTimeFilter.today) {
    final byHour = <int, int>{};
    for (final record in records) {
      byHour.update(record.timestamp.hour, (value) => value + record.salesAmount, ifAbsent: () => record.salesAmount);
    }
    return List<_TrendPoint>.generate(6, (index) {
      final hour = now.hour - (5 - index);
      final hourValue = hour % 24;
      final label = '${_bnDigits(hourValue.toString())}h';
      return _TrendPoint(label: label, value: byHour[hourValue] ?? 0);
    });
  }

  if (filter == DokanReportTimeFilter.thisWeek) {
    final start = _startOfWeek(now);
    return List<_TrendPoint>.generate(7, (index) {
      final day = start.add(Duration(days: index));
      final value = records
          .where((record) => DateUtils.dateOnly(record.timestamp) == DateUtils.dateOnly(day))
          .fold<int>(0, (sum, record) => sum + record.salesAmount);
      const labels = <String>['সো', 'ম', 'ম', 'বু', 'বৃহ', 'শু', 'শনি'];
      return _TrendPoint(label: labels[index], value: value);
    });
  }

  const monthAbbreviations = <String>[
    'জানু',
    'ফেব',
    'মার্চ',
    'এপ্রি',
    'মে',
    'জুন',
    'জুল',
    'আগ',
    'সেপ্ট',
    'অক্টো',
    'নভে',
    'ডিসে',
  ];
  final monthData = <String, int>{};
  for (var i = 5; i >= 0; i--) {
    final month = DateTime(now.year, now.month - i, 1);
    monthData[monthAbbreviations[month.month - 1]] = 0;
  }
  for (final record in records) {
    final key = monthAbbreviations[record.timestamp.month - 1];
    if (monthData.containsKey(key)) {
      monthData[key] = monthData[key]! + record.salesAmount;
    }
  }
  return monthData.entries
      .map((entry) => _TrendPoint(label: entry.key, value: entry.value))
      .toList(growable: false);
});

final paymentMethodProvider = Provider<List<_PaymentSlice>>((ref) {
  final filter = ref.watch(reportFilterProvider);
  final records = _filteredRecords(filter).where((record) => record.kind == _ReportRecordKind.sale);
  final cash = records
      .where((record) => record.paymentMethod == 'নগদ')
      .fold<int>(0, (sum, record) => sum + record.salesAmount);
  final bkash = records
      .where((record) => record.paymentMethod == 'bKash')
      .fold<int>(0, (sum, record) => sum + record.salesAmount);
  final due = records
      .where((record) => record.paymentMethod == 'বাকি')
      .fold<int>(0, (sum, record) => sum + record.salesAmount);
  return <_PaymentSlice>[
    _PaymentSlice(
      label: 'নগদ',
      amount: cash,
      color: const Color(0xFF0C8C67),
      icon: Icons.payments_outlined,
    ),
    _PaymentSlice(
      label: 'bKash',
      amount: bkash,
      color: const Color(0xFF2F6BFF),
      icon: Icons.account_balance_wallet_outlined,
    ),
    _PaymentSlice(
      label: 'বাকি',
      amount: due,
      color: const Color(0xFFD43B3B),
      icon: Icons.pending_actions_outlined,
    ),
  ].map((slice) => _PaymentSlice(
        label: slice.label,
        amount: slice.amount,
        color: slice.color,
        icon: slice.icon,
      )).toList(growable: false);
});

final topProductsProvider = Provider<List<_TopProductStat>>((ref) {
  final filter = ref.watch(reportFilterProvider);
  final records = _filteredRecords(filter).where((record) => record.kind == _ReportRecordKind.sale);
  final grouped = <String, _TopProductStat>{};

  for (final record in records) {
    final existing = grouped[record.title];
    if (existing == null) {
      grouped[record.title] = _TopProductStat(
        rank: 0,
        name: record.title,
        salesCount: record.quantity,
        revenue: record.salesAmount,
        category: record.category,
        icon: record.icon,
        color: record.color,
      );
    } else {
      grouped[record.title] = _TopProductStat(
        rank: 0,
        name: record.title,
        salesCount: existing.salesCount + record.quantity,
        revenue: existing.revenue + record.salesAmount,
        category: record.category,
        icon: record.icon,
        color: record.color,
      );
    }
  }

  final sorted = grouped.values.toList()
    ..sort((a, b) => b.revenue.compareTo(a.revenue));

  return [
    for (var i = 0; i < math.min(5, sorted.length); i++)
      _TopProductStat(
        rank: i + 1,
        name: sorted[i].name,
        salesCount: sorted[i].salesCount,
        revenue: sorted[i].revenue,
        category: sorted[i].category,
        icon: sorted[i].icon,
        color: sorted[i].color,
      ),
  ];
});

final activityLogProvider = Provider<List<_ActivityEntry>>((ref) {
  final filter = ref.watch(reportFilterProvider);
  final records = _filteredRecords(filter).toList(growable: false)
    ..sort((a, b) => b.timestamp.compareTo(a.timestamp));
  return records
      .map(
        (record) => _ActivityEntry(
          timestamp: record.timestamp,
          title: record.title,
          subtitle: '${record.category} • ${record.note}',
          trailing: record.kind == _ReportRecordKind.expense
              ? _currency(record.expenseAmount)
              : record.kind == _ReportRecordKind.purchase
                  ? _currency(record.purchaseAmount)
                  : _currency(record.salesAmount.abs()),
          color: record.color,
          icon: record.icon,
        ),
      )
      .toList(growable: false);
});

class DokanReportsHomeScreen extends StatelessWidget {
  const DokanReportsHomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return const DokanReportsDashboardScreen();
  }
}

class DokanStockValueReportScreen extends StatelessWidget {
  const DokanStockValueReportScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return const _DokanStockValueReportPage();
  }
}

class DokanProfitLossReportScreen extends StatelessWidget {
  const DokanProfitLossReportScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return const DokanReportsDashboardScreen(
      initialFilter: DokanReportTimeFilter.thisMonth,
      initialBreakdownTab: 2,
    );
  }
}

class DokanDailySalesReportScreen extends StatelessWidget {
  const DokanDailySalesReportScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return const _DokanDailySalesReportPage();
  }
}

class DokanReportsDashboardScreen extends ConsumerStatefulWidget {
  const DokanReportsDashboardScreen({
    super.key,
    this.initialFilter,
    this.initialBreakdownTab,
  });

  final DokanReportTimeFilter? initialFilter;
  final int? initialBreakdownTab;

  @override
  ConsumerState<DokanReportsDashboardScreen> createState() => _DokanReportsDashboardScreenState();
}

class _DokanReportsDashboardScreenState extends ConsumerState<DokanReportsDashboardScreen> {
  @override
  void initState() {
    super.initState();
    if (widget.initialFilter != null || widget.initialBreakdownTab != null) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (!mounted) return;
        if (widget.initialFilter != null) {
          ref.read(reportFilterProvider.notifier).setFilter(widget.initialFilter!);
        }
        if (widget.initialBreakdownTab != null) {
          ref.read(reportBreakdownTabProvider.notifier).setTab(widget.initialBreakdownTab!);
        }
      });
    }
  }


  Widget _buildTimeFilterRow(DokanReportTimeFilter selected, WidgetRef ref) {
    return SingleChildScrollView(
      scrollDirection: Axis.horizontal,
      child: Row(
        children: [
          _ReportChip(
            label: 'আজকে',
            selected: selected == DokanReportTimeFilter.today,
            onTap: () => ref.read(reportFilterProvider.notifier).setFilter(DokanReportTimeFilter.today),
          ),
          const SizedBox(width: 10),
          _ReportChip(
            label: 'এই সপ্তাহ',
            selected: selected == DokanReportTimeFilter.thisWeek,
            onTap: () => ref.read(reportFilterProvider.notifier).setFilter(DokanReportTimeFilter.thisWeek),
          ),
          const SizedBox(width: 10),
          _ReportChip(
            label: 'এই মাস',
            selected: selected == DokanReportTimeFilter.thisMonth,
            onTap: () => ref.read(reportFilterProvider.notifier).setFilter(DokanReportTimeFilter.thisMonth),
          ),
          const SizedBox(width: 10),
          _ReportChip(
            label: 'এই বছর',
            selected: selected == DokanReportTimeFilter.thisYear,
            onTap: () => ref.read(reportFilterProvider.notifier).setFilter(DokanReportTimeFilter.thisYear),
          ),
        ],
      ),
    );
  }

  Widget _buildKpiCardGrid(_ReportSummary summary, String monthLabel) {
    return LayoutBuilder(
      builder: (context, constraints) {
        final width = constraints.maxWidth;
        final cardWidth = width < 340 ? width : (width - 12) / 2;
        return Wrap(
          spacing: 12,
          runSpacing: 12,
          children: [
            SizedBox(
              width: cardWidth,
              child: _KpiCard(
                label: 'মোট বিক্রয়',
                value: _currency(summary.sales.abs()),
                accent: const Color(0xFF0C8C67),
                icon: Icons.payments_outlined,
                subtitle: monthLabel,
              ),
            ),
            SizedBox(
              width: cardWidth,
              child: _KpiCard(
                label: 'লাভ',
                value: _currency(summary.profit.abs()),
                accent: const Color(0xFF0C8C67),
                icon: Icons.trending_up_rounded,
                subtitle: 'নিট মুনাফা',
              ),
            ),
            SizedBox(
              width: cardWidth,
              child: _KpiCard(
                label: 'ক্রয়',
                value: _currency(summary.purchase.abs()),
                accent: const Color(0xFF2F6BFF),
                icon: Icons.shopping_bag_outlined,
                subtitle: 'পণ্য ক্রয়',
              ),
            ),
            SizedBox(
              width: cardWidth,
              child: _KpiCard(
                label: 'খরচ',
                value: _currency(summary.expense.abs()),
                accent: const Color(0xFFD43B3B),
                icon: Icons.receipt_long_outlined,
                subtitle: 'চলমান ব্যয়',
              ),
            ),
          ],
        );
      },
    );
  }

  Widget _buildHeroSummaryCard(_ReportSummary summary, String monthLabel, double growth) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [Color(0xFF1FA47A), Color(0xFF0B7557)],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(24),
        boxShadow: const [
          BoxShadow(
            color: Color(0x250B7557),
            blurRadius: 24,
            offset: Offset(0, 12),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Expanded(
                child: Text(
                  'এই মাসের সারসংক্ষেপ',
                  style: Theme.of(context).textTheme.titleMedium?.copyWith(
                        color: Colors.white,
                        fontWeight: FontWeight.w900,
                      ),
                ),
              ),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                decoration: BoxDecoration(
                  color: Colors.white.withValues(alpha: 0.16),
                  borderRadius: BorderRadius.circular(999),
                ),
                child: Text(
                  monthLabel,
                  style: const TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 18),
          Row(
            children: [
              Expanded(
                child: _HeroMetric(
                  label: 'বিক্রয়',
                  value: _currency(summary.sales.abs()),
                ),
              ),
              Container(width: 1, height: 54, color: Colors.white.withValues(alpha: 0.18)),
              Expanded(
                child: _HeroMetric(
                  label: 'লাভ',
                  value: _currency(summary.profit.abs()),
                ),
              ),
              Container(width: 1, height: 54, color: Colors.white.withValues(alpha: 0.18)),
              Expanded(
                child: _HeroMetric(
                  label: 'ক্রয়',
                  value: _currency(summary.purchase.abs()),
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          Container(
            height: 1,
            color: Colors.white.withValues(alpha: 0.20),
          ),
          const SizedBox(height: 12),
          Row(
            children: [
              Expanded(
                child: Text(
                  'বৃদ্ধি',
                  style: const TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ),
              Text(
                '${_growthTextValue(growth)} ↑',
                style: const TextStyle(
                  color: Colors.white,
                  fontWeight: FontWeight.w900,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildBreakdownTabs(int index, WidgetRef ref) {
    final items = <({String label, String amount, String subtitle, IconData icon, Color color})>[
      (
        label: 'বিক্রয় রিপোর্ট',
        amount: _currency(85000),
        subtitle: 'এই মাস ৳৮৫,০০০',
        icon: Icons.payments_outlined,
        color: const Color(0xFF0C8C67),
      ),
      (
        label: 'ক্রয় রিপোর্ট',
        amount: _currency(45000),
        subtitle: 'এই মাস ৳৪৫,০০০',
        icon: Icons.shopping_bag_outlined,
        color: const Color(0xFF2F6BFF),
      ),
      (
        label: 'লাভ-ক্ষতি',
        amount: _currency(12500),
        subtitle: 'বৃদ্ধি +১২%',
        icon: Icons.show_chart_rounded,
        color: const Color(0xFF9C4DFF),
      ),
      (
        label: 'বাকির রিপোর্ট',
        amount: _currency(8500),
        subtitle: '১০টি ভাউচার',
        icon: Icons.pending_actions_outlined,
        color: const Color(0xFFF49B1A),
      ),
      (
        label: 'খরচ রিপোর্ট',
        amount: _currency(15500),
        subtitle: 'এই মাস ৳১৫,৫০০',
        icon: Icons.receipt_long_outlined,
        color: const Color(0xFFE25A4E),
      ),
      (
        label: 'স্টক রিপোর্ট',
        amount: _currency(240000),
        subtitle: 'মোট মূল্য ৳২,৪০,০০০',
        icon: Icons.inventory_2_outlined,
        color: const Color(0xFF18A999),
      ),
    ];
    return GridView.builder(
      itemCount: items.length,
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      padding: EdgeInsets.zero,
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 2,
        mainAxisSpacing: 12,
        crossAxisSpacing: 12,
        childAspectRatio: 1.08,
      ),
      itemBuilder: (context, i) {
        return _ReportActionCard(
          label: items[i].label,
          subtitle: items[i].subtitle,
          amount: items[i].amount,
          icon: items[i].icon,
          color: items[i].color,
          selected: index == i,
          onTap: () {
            ref.read(reportBreakdownTabProvider.notifier).setTab(i);
            if (i == 0) {
              Navigator.of(context).push(
                MaterialPageRoute(
                  builder: (_) => const DokanDailySalesReportScreen(),
                ),
              );
            } else if (i == 1) {
              Navigator.of(context).push(
                MaterialPageRoute(
                  builder: (_) => const DokanDailyPurchaseReportScreen(),
                ),
              );
            } else if (i == 2) {
              Navigator.of(context).push(
                MaterialPageRoute(
                  builder: (_) => const DokanStockValueReportScreen(),
                ),
              );
            } else if (i == 3) {
              Navigator.of(context).push(
                MaterialPageRoute(
                  builder: (_) => const DokanDueManagementScreen(),
                ),
              );
            } else if (i == 4) {
              Navigator.of(context).push(
                MaterialPageRoute(
                  builder: (_) => const DokanExpenseReportScreen(),
                ),
              );
            } else if (i == 5) {
              Navigator.of(context).push(
                MaterialPageRoute(
                  builder: (_) => const DokanStockReportScreen(),
                ),
              );
            }
          },
        );
      },
    );
  }



  String _growthText(List<_TrendPoint> trend) {
    if (trend.length < 2) return '০%';
    final first = trend.first.value;
    final last = trend.last.value;
    if (first <= 0) return '+১২%';
    final growth = (((last - first) / first) * 100).round();
    final sign = growth >= 0 ? '+' : '';
    return '$sign${_bnDigits(growth.abs().toString())}%';
  }

  String _growthTextValue(double growth) {
    final rounded = growth.round();
    final sign = rounded >= 0 ? '+' : '-';
    return '$sign${_bnDigits(rounded.abs().toString())}%';
  }

  double _trendGrowthValue(List<_TrendPoint> trend) {
    if (trend.length < 2) return 0;
    final first = trend.first.value;
    final last = trend.last.value;
    if (first <= 0) return 12;
    return ((last - first) / first) * 100;
  }

  @override
  Widget build(BuildContext context) {
    final selectedFilter = ref.watch(reportFilterProvider);
    final summary = ref.watch(reportSummaryProvider);
    final trend = ref.watch(salesTrendProvider);
    final paymentSlices = ref.watch(paymentMethodProvider);
    final topProducts = ref.watch(topProductsProvider);
    final activities = ref.watch(activityLogProvider);
    final selectedBreakdownIndex = ref.watch(reportBreakdownTabProvider);
    final monthLabel = 'এই মাস: ${_monthName(DateTime.now().month)} ${_bnDigits(DateTime.now().year.toString())}';
    final bottomPadding = MediaQuery.of(context).padding.bottom + 8;
    final trendLabel = selectedFilter == DokanReportTimeFilter.today
        ? 'আজকের ট্রেন্ড'
        : selectedFilter == DokanReportTimeFilter.thisWeek
            ? 'সাপ্তাহিক ট্রেন্ড'
            : selectedFilter == DokanReportTimeFilter.thisYear
                ? 'বছরভিত্তিক ট্রেন্ড'
                : 'মাসভিত্তিক ট্রেন্ড';

    return Scaffold(
      backgroundColor: const Color(0xFFF3F8F7),
      appBar: AppBar(
        backgroundColor: const Color(0xFFF3FAFB),
        elevation: 0,
        foregroundColor: const Color(0xFF111111),
        leading: IconButton(
          onPressed: () => Navigator.of(context).maybePop(),
          icon: const Icon(Icons.arrow_back_rounded),
        ),
        title: const Text(
          'রিপোর্ট ও বিশ্লেষণ',
          style: TextStyle(
            color: Color(0xFF00694C),
            fontWeight: FontWeight.w900,
          ),
        ),
      ),
      body: CustomScrollView(
        physics: const ClampingScrollPhysics(),
        slivers: [
          SliverPadding(
            padding: EdgeInsets.fromLTRB(16, 16, 16, bottomPadding),
            sliver: SliverList(
              delegate: SliverChildListDelegate(
                [
                  _SectionCard(
                    title: 'টাইম ফিল্টার',
                    child: _buildTimeFilterRow(selectedFilter, ref),
                  ),
                  const SizedBox(height: 14),
                  _SectionCard(
                    title: 'মাসিক সারসংক্ষেপ',
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        _buildHeroSummaryCard(summary, monthLabel, _trendGrowthValue(trend)),
                        const SizedBox(height: 14),
                        _buildKpiCardGrid(summary, monthLabel),
                      ],
                    ),
                  ),
                  const SizedBox(height: 14),
                  _SectionCard(
                    title: 'বিক্রয় ট্রেন্ড',
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            Text(
                              trendLabel,
                              style: Theme.of(context).textTheme.titleMedium?.copyWith(
                                    fontWeight: FontWeight.w800,
                                    color: const Color(0xFF111111),
                                  ),
                            ),
                            const Spacer(),
                            Text(
                              '${_growthText(trend)} ↑',
                              style: const TextStyle(
                                color: Color(0xFF0C8C67),
                                fontWeight: FontWeight.w900,
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 12),
                        SizedBox(
                          height: 190,
                          child: _TrendChart(points: trend),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 14),
                  _buildBreakdownTabs(selectedBreakdownIndex, ref),
                  const SizedBox(height: 14),
                  _SectionCard(
                    title: 'পেমেন্ট মেথড বিশ্লেষণ',
                    child: Column(
                      children: [
                        for (final slice in paymentSlices) ...[
                          _PaymentAnalysisRow(
                            label: slice.label,
                            amount: _currency(slice.amount.abs()),
                            percent: _paymentPercent(slice.amount, paymentSlices),
                            color: slice.color,
                            icon: slice.icon,
                          ),
                          if (slice != paymentSlices.last) const SizedBox(height: 12),
                        ],
                      ],
                    ),
                  ),
                  const SizedBox(height: 14),
                  _SectionCard(
                    title: 'সেরা বিক্রয় পণ্য',
                    child: Column(
                      children: [
                        for (final product in topProducts)
                          Padding(
                            padding: const EdgeInsets.only(bottom: 10),
                            child: _RankedProductCard(product: product),
                          ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 14),
                  _SectionCard(
                    title: 'সাম্প্রতিক অ্যাক্টিভিটি',
                    child: activities.isEmpty
                        ? const Padding(
                            padding: EdgeInsets.symmetric(vertical: 20),
                            child: Center(
                              child: Text(
                                'কোনো সাম্প্রতিক অ্যাক্টিভিটি পাওয়া যায়নি',
                                style: TextStyle(
                                  color: Color(0xFF3D4943),
                                  fontWeight: FontWeight.w700,
                                ),
                              ),
                            ),
                          )
                        : ListView.separated(
                            itemCount: activities.length,
                            shrinkWrap: true,
                            physics: const NeverScrollableScrollPhysics(),
                            separatorBuilder: (context, index) => const SizedBox(height: 10),
                            itemBuilder: (context, index) {
                              final item = activities[index];
                              return _ActivityTile(entry: item);
                            },
                          ),
                  ),
                  const SizedBox(height: 4),
                ],
              ),
            ),
          ),
        ],
      ),
      bottomNavigationBar: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          _ReportsExportBar(
            onPdf: () => _showReportSnackBar(context, 'PDF রিপোর্ট তৈরি হয়েছে'),
            onExcel: () => _showReportSnackBar(context, 'Excel রপ্তানি প্রস্তুত'),
            onWhatsApp: () => _showReportSnackBar(context, 'WhatsApp শেয়ার প্রস্তুত'),
          ),
          _ReportsBottomNav(selectedIndex: 3),
        ],
      ),
    );
  }

  double _paymentPercent(int amount, List<_PaymentSlice> slices) {
    final total = slices.fold<int>(0, (sum, slice) => sum + slice.amount.abs());
    if (total <= 0) return 0;
    return amount.abs() / total;
  }
}

void _showReportSnackBar(BuildContext context, String message) {
  if (!context.mounted) return;
  ScaffoldMessenger.of(context).showSnackBar(
    SnackBar(
      content: Text(message),
      backgroundColor: const Color(0xFF0C8C67),
      behavior: SnackBarBehavior.floating,
    ),
  );
}

class _SectionCard extends StatelessWidget {
  const _SectionCard({
    required this.title,
    required this.child,
  });

  final String title;
  final Widget child;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: const Color(0xFFD9E6E2)),
        boxShadow: const [
          BoxShadow(
            color: Color(0x09000000),
            blurRadius: 14,
            offset: Offset(0, 4),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            title,
            style: const TextStyle(
              color: Color(0xFF111111),
              fontSize: 16,
              fontWeight: FontWeight.w900,
            ),
          ),
          const SizedBox(height: 14),
          child,
        ],
      ),
    );
  }
}



class _HeroMetric extends StatelessWidget {
  const _HeroMetric({
    required this.label,
    required this.value,
  });

  final String label;
  final String value;

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.center,
      children: [
        Text(
          label,
          textAlign: TextAlign.center,
          maxLines: 1,
          overflow: TextOverflow.ellipsis,
          style: const TextStyle(
            color: Colors.white,
            fontWeight: FontWeight.w700,
          ),
        ),
        const SizedBox(height: 4),
        FittedBox(
          fit: BoxFit.scaleDown,
          child: Text(
            value,
            style: const TextStyle(
              color: Colors.white,
              fontSize: 18,
              fontWeight: FontWeight.w900,
            ),
          ),
        ),
      ],
    );
  }
}
class _ReportActionCard extends StatelessWidget {
  const _ReportActionCard({
    required this.label,
    required this.subtitle,
    required this.amount,
    required this.icon,
    required this.color,
    required this.selected,
    required this.onTap,
  });

  final String label;
  final String subtitle;
  final String amount;
  final IconData icon;
  final Color color;
  final bool selected;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final borderColor = selected ? color : const Color(0xFFD9E8E3);
    final background = selected ? color.withValues(alpha: 0.13) : Colors.white;
    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(18),
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 180),
          transform: Matrix4.translationValues(0, selected ? -2 : 0, 0),
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(
            color: background,
            borderRadius: BorderRadius.circular(18),
            border: Border.all(color: borderColor, width: selected ? 2.4 : 1.0),
            boxShadow: [
              BoxShadow(
                color: selected ? color.withValues(alpha: 0.18) : const Color(0x0C0B7557),
                blurRadius: selected ? 20 : 16,
                offset: const Offset(0, 6),
              ),
            ],
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisSize: MainAxisSize.min,
            children: [
              Row(
                children: [
                  Container(
                    width: 36,
                    height: 36,
                    decoration: BoxDecoration(
                      color: selected ? color : color.withValues(alpha: 0.12),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Icon(icon, color: selected ? Colors.white : color, size: 20),
                  ),
                  const Spacer(),
                  if (selected)
                    Container(
                      width: 22,
                      height: 22,
                      decoration: BoxDecoration(
                        color: color,
                        shape: BoxShape.circle,
                      ),
                      child: const Icon(Icons.check_rounded, color: Colors.white, size: 14),
                    ),
                ],
              ),
              const SizedBox(height: 12),
              Text(
                label,
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
                softWrap: true,
                style: Theme.of(context).textTheme.titleSmall?.copyWith(
                  fontWeight: FontWeight.w800,
                  color: selected ? color : const Color(0xFF14211D),
                ),
              ),
              const SizedBox(height: 6),
              Text(
                amount,
                style: TextStyle(
                  color: selected ? color : const Color(0xFF111111),
                  fontWeight: FontWeight.w900,
                ),
              ),
              const SizedBox(height: 4),
              Text(
                subtitle,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: Theme.of(context).textTheme.bodySmall?.copyWith(
                  color: selected ? color.withValues(alpha: 0.85) : const Color(0xFF66736F),
                  fontWeight: FontWeight.w600,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _ReportChip extends StatelessWidget {
  const _ReportChip({
    required this.label,
    required this.selected,
    required this.onTap,
  });

  final String label;
  final bool selected;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(999),
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 180),
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
          decoration: BoxDecoration(
            color: selected ? const Color(0xFF0C8C67) : const Color(0xFFF2F6F5),
            borderRadius: BorderRadius.circular(999),
            border: Border.all(
              color: selected ? const Color(0xFF0C8C67) : const Color(0xFFD9E6E2),
            ),
          ),
          child: Text(
            label,
            style: TextStyle(
              color: selected ? Colors.white : const Color(0xFF111111),
              fontWeight: FontWeight.w800,
            ),
          ),
        ),
      ),
    );
  }
}

class _KpiCard extends StatelessWidget {
  const _KpiCard({
    required this.label,
    required this.value,
    required this.accent,
    required this.icon,
    required this.subtitle,
  });

  final String label;
  final String value;
  final Color accent;
  final IconData icon;
  final String subtitle;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: accent.withValues(alpha: 0.06),
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: accent.withValues(alpha: 0.15)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                width: 36,
                height: 36,
                decoration: BoxDecoration(
                  color: accent.withValues(alpha: 0.12),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Icon(icon, color: accent, size: 20),
              ),
              const Spacer(),
            ],
          ),
          const SizedBox(height: 14),
          Text(
            label,
            style: const TextStyle(
              color: Color(0xFF3D4943),
              fontWeight: FontWeight.w700,
            ),
          ),
          const SizedBox(height: 6),
          FittedBox(
            fit: BoxFit.scaleDown,
            alignment: Alignment.centerLeft,
            child: Text(
              value,
              style: TextStyle(
                color: accent,
                fontSize: 22,
                fontWeight: FontWeight.w900,
              ),
            ),
          ),
          const SizedBox(height: 4),
          Text(
            subtitle,
            style: const TextStyle(
              color: Color(0xFF5F6A66),
              fontWeight: FontWeight.w600,
            ),
          ),
        ],
      ),
    );
  }
}

class _PaymentAnalysisRow extends StatelessWidget {
  const _PaymentAnalysisRow({
    required this.label,
    required this.amount,
    required this.percent,
    required this.color,
    required this.icon,
  });

  final String label;
  final String amount;
  final double percent;
  final Color color;
  final IconData icon;

  @override
  Widget build(BuildContext context) {
    final percentText = '${_bnDigits((percent * 100).round().toString())}%';
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Container(
              width: 38,
              height: 38,
              decoration: BoxDecoration(
                color: color.withValues(alpha: 0.12),
                borderRadius: BorderRadius.circular(12),
              ),
              child: Icon(icon, color: color, size: 20),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Text(
                label,
                style: const TextStyle(
                  color: Color(0xFF111111),
                  fontWeight: FontWeight.w800,
                ),
              ),
            ),
            const SizedBox(width: 12),
            Text(
              amount,
              style: const TextStyle(
                color: Color(0xFF111111),
                fontWeight: FontWeight.w900,
              ),
            ),
          ],
        ),
        const SizedBox(height: 8),
        ClipRRect(
          borderRadius: BorderRadius.circular(999),
          child: LinearProgressIndicator(
            minHeight: 10,
            value: percent.clamp(0, 1),
            color: color,
            backgroundColor: const Color(0xFFE2ECE8),
          ),
        ),
        const SizedBox(height: 6),
        Text(
          percentText,
          style: TextStyle(
            color: color,
            fontWeight: FontWeight.w800,
          ),
        ),
      ],
    );
  }
}

class _RankedProductCard extends StatelessWidget {
  const _RankedProductCard({required this.product});

  final _TopProductStat product;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: const Color(0xFFD9E6E2)),
      ),
      child: Row(
        children: [
          Container(
            width: 42,
            height: 42,
            decoration: BoxDecoration(
              color: const Color(0xFFEAF7F0),
              borderRadius: BorderRadius.circular(14),
            ),
            child: Center(
              child: Text(
                _bnDigits(product.rank.toString()),
                style: const TextStyle(
                  color: Color(0xFF0C8C67),
                  fontWeight: FontWeight.w900,
                ),
              ),
            ),
          ),
          const SizedBox(width: 12),
          Container(
            width: 42,
            height: 42,
            decoration: BoxDecoration(
              color: product.color.withValues(alpha: 0.12),
              borderRadius: BorderRadius.circular(14),
            ),
            child: Icon(product.icon, color: product.color, size: 20),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  product.name,
                  style: const TextStyle(
                    color: Color(0xFF111111),
                    fontWeight: FontWeight.w900,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  product.category,
                  style: const TextStyle(
                    color: Color(0xFF5F6A66),
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(width: 12),
          Column(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Text(
                '${_bnDigits(product.salesCount.toString())}টি',
                style: const TextStyle(
                  color: Color(0xFF111111),
                  fontWeight: FontWeight.w900,
                ),
              ),
              const SizedBox(height: 4),
              Text(
                _currency(product.revenue),
                style: const TextStyle(
                  color: Color(0xFF0C8C67),
                  fontWeight: FontWeight.w900,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class _ActivityTile extends StatelessWidget {
  const _ActivityTile({required this.entry});

  final _ActivityEntry entry;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: const Color(0xFFD9E6E2)),
      ),
      child: Row(
        children: [
          Container(
            width: 44,
            height: 44,
            decoration: BoxDecoration(
              color: entry.color.withValues(alpha: 0.12),
              borderRadius: BorderRadius.circular(14),
            ),
            child: Icon(entry.icon, color: entry.color, size: 22),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  entry.title,
                  style: const TextStyle(
                    color: Color(0xFF111111),
                    fontWeight: FontWeight.w900,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  entry.subtitle,
                  style: const TextStyle(
                    color: Color(0xFF5F6A66),
                    fontWeight: FontWeight.w600,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  _formatTime(entry.timestamp),
                  style: const TextStyle(
                    color: Color(0xFF3D4943),
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(width: 12),
          Text(
            entry.trailing,
            style: TextStyle(
              color: entry.color,
              fontWeight: FontWeight.w900,
            ),
          ),
        ],
      ),
    );
  }
}

class _TrendChart extends StatelessWidget {
  const _TrendChart({required this.points});

  final List<_TrendPoint> points;

  @override
  Widget build(BuildContext context) {
    if (points.isEmpty) {
      return const Center(
        child: Text(
          'কোনো ট্রেন্ড ডেটা নেই',
          style: TextStyle(
            color: Color(0xFF3D4943),
            fontWeight: FontWeight.w700,
          ),
        ),
      );
    }
    return LayoutBuilder(
      builder: (context, constraints) {
        return Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Expanded(
              child: CustomPaint(
                size: Size(constraints.maxWidth, constraints.maxHeight - 26),
                painter: _TrendChartPainter(points),
              ),
            ),
            const SizedBox(height: 6),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                for (final point in points)
                  Flexible(
                    child: Text(
                      point.label,
                      textAlign: TextAlign.center,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                        color: Color(0xFF5F6A66),
                        fontSize: 12,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                  ),
              ],
            ),
          ],
        );
      },
    );
  }
}

class _TrendChartPainter extends CustomPainter {
  _TrendChartPainter(this.points);

  final List<_TrendPoint> points;

  @override
  void paint(Canvas canvas, Size size) {
    if (points.isEmpty) return;
    final padding = 14.0;
    final chartWidth = size.width - (padding * 2);
    final chartHeight = size.height - (padding * 2);
    final maxValue = points.fold<int>(0, (max, point) => math.max(max, point.value));
    final safeMax = maxValue <= 0 ? 1 : maxValue.toDouble();
    final stepX = points.length <= 1 ? chartWidth : chartWidth / (points.length - 1);

    final axisPaint = Paint()
      ..color = const Color(0xFFD9E6E2)
      ..strokeWidth = 1;
    canvas.drawLine(
      Offset(padding, size.height - padding),
      Offset(size.width - padding, size.height - padding),
      axisPaint,
    );

    final gridPaint = Paint()
      ..color = const Color(0xFFF0F5F3)
      ..strokeWidth = 1;
    for (var i = 1; i <= 3; i++) {
      final y = padding + chartHeight * (i / 4);
      canvas.drawLine(Offset(padding, y), Offset(size.width - padding, y), gridPaint);
    }

    final fillPath = Path();
    final linePath = Path();
    for (var i = 0; i < points.length; i++) {
      final x = padding + (stepX * i);
      final normalized = points[i].value / safeMax;
      final y = padding + chartHeight - (chartHeight * normalized);
      if (i == 0) {
        linePath.moveTo(x, y);
        fillPath.moveTo(x, size.height - padding);
        fillPath.lineTo(x, y);
      } else {
        linePath.lineTo(x, y);
        fillPath.lineTo(x, y);
      }
    }
    fillPath.lineTo(padding + chartWidth, size.height - padding);
    fillPath.close();

    final gradientPaint = Paint()
      ..shader = const LinearGradient(
        colors: [
          Color(0x330C8C67),
          Color(0x110C8C67),
        ],
        begin: Alignment.topCenter,
        end: Alignment.bottomCenter,
      ).createShader(Rect.fromLTWH(0, 0, size.width, size.height));
    canvas.drawPath(fillPath, gradientPaint);

    final linePaint = Paint()
      ..color = const Color(0xFF0C8C67)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 3
      ..strokeCap = StrokeCap.round
      ..strokeJoin = StrokeJoin.round;
    canvas.drawPath(linePath, linePaint);

    final dotPaint = Paint()..color = const Color(0xFF0C8C67);
    for (var i = 0; i < points.length; i++) {
      final x = padding + (stepX * i);
      final normalized = points[i].value / safeMax;
      final y = padding + chartHeight - (chartHeight * normalized);
      canvas.drawCircle(Offset(x, y), 4.5, dotPaint);
      final valuePainter = TextPainter(
        text: TextSpan(
          text: _currency(points[i].value),
          style: const TextStyle(
            color: Color(0xFF0C8C67),
            fontSize: 10,
            fontWeight: FontWeight.w800,
          ),
        ),
        textDirection: TextDirection.ltr,
      )..layout();
      valuePainter.paint(canvas, Offset(x - valuePainter.width / 2, y - 22));
    }
  }

  @override
  bool shouldRepaint(covariant _TrendChartPainter oldDelegate) => oldDelegate.points != points;
}

class _ReportsExportBar extends StatelessWidget {
  const _ReportsExportBar({
    required this.onPdf,
    required this.onExcel,
    required this.onWhatsApp,
  });

  final VoidCallback onPdf;
  final VoidCallback onExcel;
  final VoidCallback onWhatsApp;

  @override
  Widget build(BuildContext context) {
    final border = BorderSide(color: const Color(0xFFD7E5E0));
    return SizedBox(
      height: 74,
      child: Container(
        width: double.infinity,
        padding: const EdgeInsets.fromLTRB(16, 2, 16, 4),
        decoration: BoxDecoration(
          color: const Color(0xFFEAF2F0),
          border: Border(top: border),
        ),
        child: Align(
          alignment: Alignment.bottomCenter,
          child: Row(
            children: [
              Expanded(
                child: _ReportExportActionButton(
                  label: 'PDF রিপোর্ট',
                  icon: Icons.picture_as_pdf_outlined,
                  onTap: onPdf,
                  filled: true,
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: _ReportExportActionButton(
                  label: 'Excel',
                  icon: Icons.grid_on_outlined,
                  onTap: onExcel,
                  filled: true,
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: _ReportExportActionButton(
                  label: 'WhatsApp',
                  icon: Icons.chat_bubble_outline_rounded,
                  onTap: onWhatsApp,
                  filled: true,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _DokanDailySalesReportPage extends StatefulWidget {
  const _DokanDailySalesReportPage();

  @override
  State<_DokanDailySalesReportPage> createState() => _DokanDailySalesReportPageState();
}

class _DokanDailySalesReportPageState extends State<_DokanDailySalesReportPage> {
  DateTime _selectedDate = DateTime(2026, 5, 23);

  final List<_TrendPoint> _hourlyTrend = const [
    _TrendPoint(label: '8am', value: 18),
    _TrendPoint(label: '10am', value: 24),
    _TrendPoint(label: '12pm', value: 22),
    _TrendPoint(label: '2pm', value: 35),
    _TrendPoint(label: '4pm', value: 30),
    _TrendPoint(label: '6pm', value: 33),
    _TrendPoint(label: '8pm', value: 28),
  ];

  final List<_TopProductStat> _topProducts = const [
    _TopProductStat(
      rank: 1,
      name: 'মিনিকেট চাল',
      salesCount: 48,
      revenue: 3600,
      category: 'চাল-ডাল',
      icon: Icons.grain_rounded,
      color: Color(0xFF0C8C67),
    ),
    _TopProductStat(
      rank: 2,
      name: 'কোকা কোলা',
      salesCount: 36,
      revenue: 1260,
      category: 'পানীয়',
      icon: Icons.local_drink_outlined,
      color: Color(0xFF2F6BFF),
    ),
    _TopProductStat(
      rank: 3,
      name: 'সয়াবিন তেল',
      salesCount: 24,
      revenue: 3960,
      category: 'তেল-মসলা',
      icon: Icons.opacity_outlined,
      color: Color(0xFFF49B1A),
    ),
    _TopProductStat(
      rank: 4,
      name: 'লাক্স সাবান',
      salesCount: 20,
      revenue: 1160,
      category: 'সাবান',
      icon: Icons.soap_outlined,
      color: Color(0xFFE25A4E),
    ),
    _TopProductStat(
      rank: 5,
      name: 'চিনি',
      salesCount: 18,
      revenue: 2160,
      category: 'চাল-ডাল',
      icon: Icons.kitchen_outlined,
      color: Color(0xFF18A999),
    ),
  ];

  final List<_PaymentSlice> _paymentSlices = const [
    _PaymentSlice(
      label: 'নগদ',
      amount: 60350,
      color: Color(0xFF0C8C67),
      icon: Icons.payments_outlined,
    ),
    _PaymentSlice(
      label: 'bKash',
      amount: 12750,
      color: Color(0xFFF49B1A),
      icon: Icons.phone_android_outlined,
    ),
    _PaymentSlice(
      label: 'বাকি',
      amount: 11900,
      color: Color(0xFFE25A4E),
      icon: Icons.pending_actions_outlined,
    ),
  ];

  String get _dateLabel =>
      '${_bnDigits(_selectedDate.day.toString())} ${_monthName(_selectedDate.month)} ${_bnDigits(_selectedDate.year.toString())}';

  void _shiftDate(int delta) {
    setState(() {
      _selectedDate = _selectedDate.add(Duration(days: delta));
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF3F8F7),
      appBar: AppBar(
        backgroundColor: const Color(0xFFF3FAFB),
        elevation: 0,
        foregroundColor: const Color(0xFF111111),
        leading: IconButton(
          onPressed: () => Navigator.of(context).maybePop(),
          icon: const Icon(Icons.arrow_back_rounded),
        ),
        centerTitle: true,
        title: const Text(
          'দৈনিক বিক্রয় রিপোর্ট',
          style: TextStyle(
            color: Color(0xFF00694C),
            fontWeight: FontWeight.w900,
          ),
        ),
        actions: [
          IconButton(
            onPressed: () => _showReportSnackBar(context, 'শেয়ার প্রস্তুত'),
            icon: const Icon(Icons.share_outlined),
          ),
          IconButton(
            onPressed: () => _showReportSnackBar(context, 'ক্যালেন্ডার খোলা হয়েছে'),
            icon: const Icon(Icons.calendar_month_outlined),
          ),
          const SizedBox(width: 4),
        ],
      ),
      body: CustomScrollView(
        physics: const ClampingScrollPhysics(),
        slivers: [
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.fromLTRB(16, 14, 16, 12),
              child: Row(
                children: [
                  _RoundDateNavButton(
                    icon: Icons.chevron_left_rounded,
                    onTap: () => _shiftDate(-1),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Container(
                      height: 44,
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(999),
                        border: Border.all(color: const Color(0xFFD9E6E2)),
                      ),
                      child: Center(
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            const Icon(Icons.calendar_month_outlined, size: 18, color: Color(0xFF0C8C67)),
                            const SizedBox(width: 8),
                            Text(
                              _dateLabel,
                              style: const TextStyle(
                                color: Color(0xFF111111),
                                fontWeight: FontWeight.w800,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(width: 10),
                  _RoundDateNavButton(
                    icon: Icons.chevron_right_rounded,
                    onTap: () => _shiftDate(1),
                  ),
                ],
              ),
            ),
          ),
          SliverPadding(
            padding: const EdgeInsets.fromLTRB(16, 0, 16, 150),
            sliver: SliverList(
              delegate: SliverChildListDelegate(
                [
                  Container(
                    width: double.infinity,
                    padding: const EdgeInsets.all(18),
                    decoration: BoxDecoration(
                      gradient: const LinearGradient(
                        colors: [Color(0xFF1FA47A), Color(0xFF0B7557)],
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                      ),
                      borderRadius: BorderRadius.circular(24),
                      boxShadow: const [
                        BoxShadow(
                          color: Color(0x250B7557),
                          blurRadius: 24,
                          offset: Offset(0, 12),
                        ),
                      ],
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text(
                          'মোট বিক্রয়',
                          style: TextStyle(
                            color: Colors.white,
                            fontWeight: FontWeight.w800,
                            fontSize: 16,
                          ),
                        ),
                        const SizedBox(height: 8),
                        const Text(
                          '৳৪,৮৫০',
                          style: TextStyle(
                            color: Colors.white,
                            fontWeight: FontWeight.w900,
                            fontSize: 30,
                          ),
                        ),
                        const SizedBox(height: 18),
                        Container(
                          height: 1,
                          color: Colors.white.withValues(alpha: 0.20),
                        ),
                        const SizedBox(height: 12),
                        Row(
                          children: [
                            Expanded(
                              child: _DailyHeroMetric(
                                label: 'লাভ',
                                value: '৳১,২৪০',
                              ),
                            ),
                            Container(width: 1, height: 44, color: Colors.white.withValues(alpha: 0.18)),
                            Expanded(
                              child: _DailyHeroMetric(
                                label: 'বিক্রয় সংখ্যা',
                                value: '৩২টি',
                              ),
                            ),
                            Container(width: 1, height: 44, color: Colors.white.withValues(alpha: 0.18)),
                            Expanded(
                              child: _DailyHeroMetric(
                                label: 'গড় বিক্রয়',
                                value: '৳১৫২',
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 14),
                  _SectionCard(
                    title: 'ঘণ্টাভিত্তিক বিক্রয়',
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            const Text(
                              'LIVE',
                              style: TextStyle(
                                color: Color(0xFF0C8C67),
                                fontWeight: FontWeight.w900,
                              ),
                            ),
                            const Spacer(),
                            const Text(
                              'গত মাসের তুলনায় +১২% ↑',
                              style: TextStyle(
                                color: Color(0xFF0C8C67),
                                fontWeight: FontWeight.w800,
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 12),
                        SizedBox(
                          height: 182,
                          child: _TrendChart(points: _hourlyTrend),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 14),
                  _SectionCard(
                    title: 'শীর্ষ ৫টি পণ্য',
                    child: Column(
                      children: [
                        for (var i = 0; i < _topProducts.length; i++) ...[
                          _DailyTopProductRow(product: _topProducts[i]),
                          if (i != _topProducts.length - 1) const SizedBox(height: 10),
                        ],
                      ],
                    ),
                  ),
                  const SizedBox(height: 14),
                  _SectionCard(
                    title: 'পেমেন্ট ব্রেকডাউন',
                    child: Column(
                      children: [
                        for (final slice in _paymentSlices) ...[
                          _PaymentAnalysisRow(
                            label: slice.label,
                            amount: _currency(slice.amount),
                            percent: _paymentPercent(slice.amount),
                            color: slice.color,
                            icon: slice.icon,
                          ),
                          if (slice != _paymentSlices.last) const SizedBox(height: 12),
                        ],
                      ],
                    ),
                  ),
                  const SizedBox(height: 14),
                ],
              ),
            ),
          ),
        ],
      ),
      bottomNavigationBar: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          _ReportsExportBar(
            onPdf: () => _showReportSnackBar(context, 'PDF রিপোর্ট তৈরি হয়েছে'),
            onExcel: () => _showReportSnackBar(context, 'Excel রপ্তানি প্রস্তুত'),
            onWhatsApp: () => _showReportSnackBar(context, 'WhatsApp শেয়ার প্রস্তুত'),
          ),
          _ReportsBottomNav(selectedIndex: 3),
        ],
      ),
    );
  }

  double _paymentPercent(int amount) {
    final total = _paymentSlices.fold<int>(0, (sum, slice) => sum + slice.amount.abs());
    if (total <= 0) return 0;
    return amount.abs() / total;
  }
}

class DokanDailyPurchaseReportScreen extends StatelessWidget {
  const DokanDailyPurchaseReportScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return const _DokanDailyPurchaseReportPage();
  }
}

class _DokanDailyPurchaseReportPage extends StatefulWidget {
  const _DokanDailyPurchaseReportPage();

  @override
  State<_DokanDailyPurchaseReportPage> createState() => _DokanDailyPurchaseReportPageState();
}

class _DokanDailyPurchaseReportPageState extends State<_DokanDailyPurchaseReportPage> {
  DateTime _selectedDate = DateTime(2026, 5, 23);

  final List<_TrendPoint> _hourlyTrend = const [
    _TrendPoint(label: '8am', value: 12),
    _TrendPoint(label: '10am', value: 18),
    _TrendPoint(label: '12pm', value: 22),
    _TrendPoint(label: '2pm', value: 28),
    _TrendPoint(label: '4pm', value: 24),
    _TrendPoint(label: '6pm', value: 31),
    _TrendPoint(label: '8pm', value: 27),
  ];

  final List<_PurchaseRankStat> _topItems = const [
    _PurchaseRankStat(
      rank: 1,
      name: 'মিনিকেট চাল',
      units: 48,
      amount: 3600,
      category: 'চাল-ডাল',
      icon: Icons.grain_rounded,
      color: Color(0xFF0C8C67),
    ),
    _PurchaseRankStat(
      rank: 2,
      name: 'সয়াবিন তেল',
      units: 36,
      amount: 5850,
      category: 'তেল-মসলা',
      icon: Icons.opacity_outlined,
      color: Color(0xFF2F6BFF),
    ),
    _PurchaseRankStat(
      rank: 3,
      name: 'কোকা কোলা',
      units: 30,
      amount: 1050,
      category: 'পানীয়',
      icon: Icons.local_drink_outlined,
      color: Color(0xFFF49B1A),
    ),
    _PurchaseRankStat(
      rank: 4,
      name: 'লাক্স সাবান',
      units: 24,
      amount: 1392,
      category: 'সাবান',
      icon: Icons.soap_outlined,
      color: Color(0xFFE25A4E),
    ),
    _PurchaseRankStat(
      rank: 5,
      name: 'চিনি',
      units: 18,
      amount: 2160,
      category: 'চাল-ডাল',
      icon: Icons.kitchen_outlined,
      color: Color(0xFF18A999),
    ),
  ];

  final List<_PaymentSlice> _paymentSlices = const [
    _PaymentSlice(
      label: 'নগদ',
      amount: 42350,
      color: Color(0xFF0C8C67),
      icon: Icons.payments_outlined,
    ),
    _PaymentSlice(
      label: 'bKash',
      amount: 18750,
      color: Color(0xFFF49B1A),
      icon: Icons.phone_android_outlined,
    ),
    _PaymentSlice(
      label: 'বাকি',
      amount: 11900,
      color: Color(0xFFE25A4E),
      icon: Icons.pending_actions_outlined,
    ),
  ];

  String get _dateLabel =>
      '${_bnDigits(_selectedDate.day.toString())} ${_monthName(_selectedDate.month)} ${_bnDigits(_selectedDate.year.toString())}';

  void _shiftDate(int delta) {
    setState(() {
      _selectedDate = _selectedDate.add(Duration(days: delta));
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF3F8F7),
      appBar: AppBar(
        backgroundColor: const Color(0xFFF3FAFB),
        elevation: 0,
        foregroundColor: const Color(0xFF111111),
        leading: IconButton(
          onPressed: () => Navigator.of(context).maybePop(),
          icon: const Icon(Icons.arrow_back_rounded),
        ),
        centerTitle: true,
        title: const Text(
          'দৈনিক ক্রয় রিপোর্ট',
          style: TextStyle(
            color: Color(0xFF00694C),
            fontWeight: FontWeight.w900,
          ),
        ),
        actions: [
          IconButton(
            onPressed: () => _showReportSnackBar(context, 'শেয়ার প্রস্তুত'),
            icon: const Icon(Icons.share_outlined),
          ),
          IconButton(
            onPressed: () => _showReportSnackBar(context, 'ক্যালেন্ডার খোলা হয়েছে'),
            icon: const Icon(Icons.calendar_month_outlined),
          ),
          const SizedBox(width: 4),
        ],
      ),
      body: CustomScrollView(
        physics: const ClampingScrollPhysics(),
        slivers: [
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.fromLTRB(16, 14, 16, 12),
              child: Row(
                children: [
                  _RoundDateNavButton(
                    icon: Icons.chevron_left_rounded,
                    onTap: () => _shiftDate(-1),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Container(
                      height: 44,
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(999),
                        border: Border.all(color: const Color(0xFFD9E6E2)),
                      ),
                      child: Center(
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            const Icon(Icons.calendar_month_outlined, size: 18, color: Color(0xFF0C8C67)),
                            const SizedBox(width: 8),
                            Text(
                              _dateLabel,
                              style: const TextStyle(
                                color: Color(0xFF111111),
                                fontWeight: FontWeight.w800,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(width: 10),
                  _RoundDateNavButton(
                    icon: Icons.chevron_right_rounded,
                    onTap: () => _shiftDate(1),
                  ),
                ],
              ),
            ),
          ),
          SliverPadding(
            padding: const EdgeInsets.fromLTRB(16, 0, 16, 150),
            sliver: SliverList(
              delegate: SliverChildListDelegate(
                [
                  Container(
                    width: double.infinity,
                    padding: const EdgeInsets.all(18),
                    decoration: BoxDecoration(
                      gradient: const LinearGradient(
                        colors: [Color(0xFF1FA47A), Color(0xFF0B7557)],
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                      ),
                      borderRadius: BorderRadius.circular(24),
                      boxShadow: const [
                        BoxShadow(
                          color: Color(0x250B7557),
                          blurRadius: 24,
                          offset: Offset(0, 12),
                        ),
                      ],
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text(
                          'মোট ক্রয়',
                          style: TextStyle(
                            color: Colors.white,
                            fontWeight: FontWeight.w800,
                            fontSize: 16,
                          ),
                        ),
                        const SizedBox(height: 8),
                        const Text(
                          '৳৪৫,০০০',
                          style: TextStyle(
                            color: Colors.white,
                            fontWeight: FontWeight.w900,
                            fontSize: 30,
                          ),
                        ),
                        const SizedBox(height: 18),
                        Container(
                          height: 1,
                          color: Colors.white.withValues(alpha: 0.20),
                        ),
                        const SizedBox(height: 12),
                        Row(
                          children: [
                            Expanded(
                              child: _DailyHeroMetric(
                                label: 'মোট খরচ',
                                value: '৳৮,৫০০',
                              ),
                            ),
                            Container(width: 1, height: 44, color: Colors.white.withValues(alpha: 0.18)),
                            Expanded(
                              child: _DailyHeroMetric(
                                label: 'মোট পণ্য সংখ্যা',
                                value: '৩২টি',
                              ),
                            ),
                            Container(width: 1, height: 44, color: Colors.white.withValues(alpha: 0.18)),
                            Expanded(
                              child: _DailyHeroMetric(
                                label: 'গড় ক্রয়',
                                value: '৳১৪০',
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 14),
                  _SectionCard(
                    title: 'ঘণ্টা ভিত্তিক ক্রয়',
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            const Text(
                              'LIVE',
                              style: TextStyle(
                                color: Color(0xFF0C8C67),
                                fontWeight: FontWeight.w900,
                              ),
                            ),
                            const Spacer(),
                            const Text(
                              'গত মাসের তুলনায় +৯% ↑',
                              style: TextStyle(
                                color: Color(0xFF0C8C67),
                                fontWeight: FontWeight.w800,
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 12),
                        SizedBox(
                          height: 182,
                          child: _TrendChart(points: _hourlyTrend),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 14),
                  _SectionCard(
                    title: 'শীর্ষ ৫টি পণ্য',
                    child: Column(
                      children: [
                        for (var i = 0; i < _topItems.length; i++) ...[
                          _DailyPurchaseTopItemRow(product: _topItems[i]),
                          if (i != _topItems.length - 1) const SizedBox(height: 10),
                        ],
                      ],
                    ),
                  ),
                  const SizedBox(height: 14),
                  _SectionCard(
                    title: 'পেমেন্ট ব্রেকডাউন',
                    child: Column(
                      children: [
                        for (final slice in _paymentSlices) ...[
                          _PaymentAnalysisRow(
                            label: slice.label,
                            amount: _currency(slice.amount),
                            percent: _purchasePaymentPercent(slice.amount),
                            color: slice.color,
                            icon: slice.icon,
                          ),
                          if (slice != _paymentSlices.last) const SizedBox(height: 12),
                        ],
                      ],
                    ),
                  ),
                  const SizedBox(height: 14),
                ],
              ),
            ),
          ),
        ],
      ),
      bottomNavigationBar: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          _ReportsExportBar(
            onPdf: () => _showReportSnackBar(context, 'PDF রিপোর্ট তৈরি হয়েছে'),
            onExcel: () => _showReportSnackBar(context, 'Excel রপ্তানি প্রস্তুত'),
            onWhatsApp: () => _showReportSnackBar(context, 'WhatsApp শেয়ার প্রস্তুত'),
          ),
          _ReportsBottomNav(selectedIndex: 3),
        ],
      ),
    );
  }

  double _purchasePaymentPercent(int amount) {
    final total = _paymentSlices.fold<int>(0, (sum, slice) => sum + slice.amount.abs());
    if (total <= 0) return 0;
    return amount.abs() / total;
  }
}

class _DokanStockValueReportPage extends StatefulWidget {
  const _DokanStockValueReportPage();

  @override
  State<_DokanStockValueReportPage> createState() => _DokanStockValueReportPageState();
}

class _DokanStockValueReportPageState extends State<_DokanStockValueReportPage> {
  DateTime _selectedDate = DateTime(2026, 5, 23);
  int _selectedRange = 1;

  final List<_StockRatioSlice> _ratioSlices = const [
    _StockRatioSlice(label: 'প্রফিট', value: 28, color: Color(0xFF0C8C67)),
    _StockRatioSlice(label: 'ব্যয়', value: 46, color: Color(0xFFD43B3B)),
    _StockRatioSlice(label: 'অন্যান্য', value: 26, color: Color(0xFF8E9A97)),
  ];

  String get _dateLabel =>
      '${_bnDigits(_selectedDate.day.toString())} ${_monthName(_selectedDate.month)} ${_bnDigits(_selectedDate.year.toString())}';

  void _shiftDate(int delta) {
    setState(() {
      _selectedDate = _selectedDate.add(Duration(days: delta));
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF3F8F7),
      appBar: AppBar(
        backgroundColor: const Color(0xFFF3FAFB),
        elevation: 0,
        foregroundColor: const Color(0xFF111111),
        leading: IconButton(
          onPressed: () => Navigator.of(context).maybePop(),
          icon: const Icon(Icons.arrow_back_rounded),
        ),
        centerTitle: true,
        title: const Text(
          'লাভ-ক্ষতি রিপোর্ট',
          style: TextStyle(
            color: Color(0xFF00694C),
            fontWeight: FontWeight.w900,
          ),
        ),
      ),
      body: CustomScrollView(
        physics: const ClampingScrollPhysics(),
        slivers: [
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.fromLTRB(16, 14, 16, 10),
              child: Row(
                children: [
                  _RoundDateNavButton(
                    icon: Icons.chevron_left_rounded,
                    onTap: () => _shiftDate(-1),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Container(
                      height: 44,
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(999),
                        border: Border.all(color: const Color(0xFFD9E6E2)),
                      ),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          const Icon(Icons.calendar_month_outlined, size: 18, color: Color(0xFF0C8C67)),
                          const SizedBox(width: 8),
                          Text(
                            _dateLabel,
                            style: const TextStyle(
                              color: Color(0xFF111111),
                              fontWeight: FontWeight.w800,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  const SizedBox(width: 10),
                  _RoundDateNavButton(
                    icon: Icons.chevron_right_rounded,
                    onTap: () => _shiftDate(1),
                  ),
                ],
              ),
            ),
          ),
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: SingleChildScrollView(
                scrollDirection: Axis.horizontal,
                child: Row(
                  children: [
                    _ReportChip(
                      label: 'এই সপ্তাহ',
                      selected: _selectedRange == 0,
                      onTap: () => setState(() => _selectedRange = 0),
                    ),
                    const SizedBox(width: 10),
                    _ReportChip(
                      label: 'এই মাস',
                      selected: _selectedRange == 1,
                      onTap: () => setState(() => _selectedRange = 1),
                    ),
                    const SizedBox(width: 10),
                    _ReportChip(
                      label: 'এই বছর',
                      selected: _selectedRange == 2,
                      onTap: () => setState(() => _selectedRange = 2),
                    ),
                    const SizedBox(width: 10),
                    _ReportChip(
                      label: 'কাস্টম',
                      selected: _selectedRange == 3,
                      onTap: () => setState(() => _selectedRange = 3),
                    ),
                  ],
                ),
              ),
            ),
          ),
          SliverPadding(
            padding: const EdgeInsets.fromLTRB(16, 14, 16, 156),
            sliver: SliverList(
              delegate: SliverChildListDelegate(
                [
                  Row(
                    children: [
                      Expanded(
                        child: _CompactSummaryCard(
                          title: 'গ্রস লাভ',
                          value: '৳৩৮,৮০০',
                          subtitle: '৪৬% মার্জিন',
                          background: const Color(0xFFE6F4EE),
                          foreground: const Color(0xFF0C8C67),
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: _CompactSummaryCard(
                          title: 'নিট লাভ',
                          value: '৳২৩,৩০০',
                          subtitle: '২৮% প্রফিট',
                          background: const Color(0xFF0C8C67),
                          foreground: Colors.white,
                          isFilled: true,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 14),
                  _SectionCard(
                    title: 'রাজস্ব (Revenue)',
                    child: Column(
                      children: const [
                        _ValueLineItem(
                          label: 'মোট বিক্রয়',
                          value: '৳৮৫,০০০',
                          valueColor: Color(0xFF0C8C67),
                        ),
                        SizedBox(height: 12),
                        _ValueLineItem(
                          label: 'রিটার্ন/বাতিল',
                          value: '−৳১,২০০',
                          valueColor: Color(0xFFD43B3B),
                        ),
                        SizedBox(height: 12),
                        _DividerLine(),
                        SizedBox(height: 12),
                        _ValueLineItem(
                          label: 'নিট বিক্রয়',
                          value: '৳৮৩,৮০০',
                          valueColor: Color(0xFF0C8C67),
                          emphasize: true,
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 14),
                  _SectionCard(
                    title: 'ব্যয় (Cost)',
                    child: Column(
                      children: const [
                        _ValueLineItem(
                          label: 'পণ্যের ক্রয়মূল্য',
                          value: '৳৪৫,০০০',
                          valueColor: Color(0xFF111111),
                        ),
                        SizedBox(height: 12),
                        _ValueLineItem(
                          label: 'পরিচালন খরচ',
                          value: '৳১৫,৫০০',
                          valueColor: Color(0xFF111111),
                        ),
                        SizedBox(height: 12),
                        _DividerLine(),
                        SizedBox(height: 12),
                        _ValueLineItem(
                          label: 'মোট ব্যয়',
                          value: '৳৬০,৫০০',
                          valueColor: Color(0xFFD43B3B),
                          emphasize: true,
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 14),
                  _SectionCard(
                    title: 'আর্থিক অনুপাত বিশ্লেষণ',
                    child: Column(
                      children: [
                        SizedBox(
                          height: 210,
                          child: _StockRatioChart(slices: _ratioSlices, centerLabel: 'নিট লাভ', centerValue: '২৮%'),
                        ),
                        const SizedBox(height: 10),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            for (final slice in _ratioSlices)
                              _RatioLegendItem(label: slice.label, color: slice.color),
                          ],
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
      bottomNavigationBar: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            width: double.infinity,
            padding: const EdgeInsets.fromLTRB(16, 8, 16, 8),
            decoration: BoxDecoration(
              color: const Color(0xFFEAF2F0),
              border: Border(top: BorderSide(color: const Color(0xFFD7E5E0))),
            ),
            child: Row(
              children: [
                Expanded(
                  child: _ReportExportActionButton(
                    label: 'PDF ডাউনলোড',
                    icon: Icons.picture_as_pdf_outlined,
                    onTap: () => _showReportSnackBar(context, 'PDF ডাউনলোড প্রস্তুত'),
                    filled: false,
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: _ReportExportActionButton(
                    label: 'Excel রিপোর্ট',
                    icon: Icons.grid_on_outlined,
                    onTap: () => _showReportSnackBar(context, 'Excel রিপোর্ট প্রস্তুত'),
                    filled: true,
                  ),
                ),
              ],
            ),
          ),
          _ReportsBottomNav(selectedIndex: 3),
        ],
      ),
    );
  }
}

class DokanStockReportScreen extends StatelessWidget {
  const DokanStockReportScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return const _DokanInventoryStockReportPage();
  }
}

class DokanExpenseReportScreen extends StatelessWidget {
  const DokanExpenseReportScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return const _ExpenseReportDashboardBody();
  }
}

class _ExpenseReportDashboardBody extends ConsumerWidget {
  const _ExpenseReportDashboardBody();

  int _filterIndex(DokanExpenseTimeFilter filter) {
    return switch (filter) {
      DokanExpenseTimeFilter.today => 0,
      DokanExpenseTimeFilter.thisWeek => 1,
      DokanExpenseTimeFilter.thisMonth => 2,
      DokanExpenseTimeFilter.thisYear => 3,
    };
  }

  DokanExpenseTimeFilter _filterFromIndex(int index) {
    return switch (index) {
      0 => DokanExpenseTimeFilter.today,
      1 => DokanExpenseTimeFilter.thisWeek,
      2 => DokanExpenseTimeFilter.thisMonth,
      _ => DokanExpenseTimeFilter.thisYear,
    };
  }

  Future<void> _confirmDelete(
    BuildContext context,
    WidgetRef ref,
    DokanExpenseRecord expense,
  ) async {
    final shouldDelete = await showDialog<bool>(
      context: context,
      builder: (dialogContext) {
        return AlertDialog(
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
          title: const Text('খরচ মুছে ফেলবেন?'),
          content: const Text('এই খরচটি স্থায়ীভাবে মুছে যাবে।'),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(dialogContext).pop(false),
              child: const Text('না'),
            ),
            ElevatedButton(
              onPressed: () => Navigator.of(dialogContext).pop(true),
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFFD43B3B),
                foregroundColor: Colors.white,
              ),
              child: const Text('হ্যাঁ, মুছে ফেলুন'),
            ),
          ],
        );
      },
    );
    if (shouldDelete != true || !context.mounted) return;
    await ref.read(expenseReportControllerProvider.notifier).deleteExpense(expense.id);
    if (!context.mounted) return;
    _showReportSnackBar(context, 'খরচ মুছে ফেলা হয়েছে');
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final asyncExpenses = ref.watch(expenseReportControllerProvider);
    final summary = ref.watch(expenseSummaryProvider);
    final categoryStats = ref.watch(expenseCategoryStatsProvider);
    final trendPoints = ref.watch(expenseTrendProvider);
    final filteredExpenses = ref.watch(filteredExpenseRecordsProvider);
    final selectedFilter = ref.watch(expenseTimeFilterProvider);
    final selectedCategory = ref.watch(expenseCategoryFilterProvider);

    if (asyncExpenses.isLoading) {
      return const Scaffold(
        backgroundColor: Color(0xFFF3F8F7),
        body: Center(
          child: CircularProgressIndicator(color: Color(0xFF0C8C67)),
        ),
      );
    }

    if (asyncExpenses.hasError) {
      return Scaffold(
        backgroundColor: const Color(0xFFF3F8F7),
        appBar: AppBar(
          backgroundColor: const Color(0xFFF3FAFB),
          leading: IconButton(
            onPressed: () => Navigator.of(context).maybePop(),
            icon: const Icon(Icons.arrow_back_rounded, color: Colors.black),
          ),
          title: const Text(
            'খরচ রিপোর্ট',
            style: TextStyle(color: Color(0xFF00694C), fontWeight: FontWeight.w900),
          ),
        ),
        body: const Center(
          child: Text(
            'খরচের তথ্য লোড করা যায়নি',
            style: TextStyle(color: Colors.black87, fontWeight: FontWeight.w700),
          ),
        ),
      );
    }

    final kpis = <_ExpenseSummaryKpi>[
      _ExpenseSummaryKpi(
        label: 'মোট খরচ',
        value: _currency(summary.totalExpense),
        icon: Icons.payments_outlined,
        accent: const Color(0xFF0C8C67),
        trend: summary.changePercent >= 0
            ? '+${_bnDigits(summary.changePercent.abs().round().toString())}%'
            : '-${_bnDigits(summary.changePercent.abs().round().toString())}%',
      ),
      _ExpenseSummaryKpi(
        label: 'লেনদেন',
        value: '${_bnDigits(summary.totalTransactions.toString())}টি',
        icon: Icons.receipt_long_outlined,
        accent: const Color(0xFF2F6BFF),
        trend: 'সক্রিয়',
      ),
      _ExpenseSummaryKpi(
        label: 'শীর্ষ ক্যাটাগরি',
        value: summary.topCategory,
        icon: Icons.category_outlined,
        accent: const Color(0xFFF49B1A),
        trend: 'শীর্ষ',
      ),
      _ExpenseSummaryKpi(
        label: 'পরিবর্তন',
        value: '${summary.changePercent >= 0 ? '+' : ''}${_bnDigits(summary.changePercent.abs().round().toString())}%',
        icon: Icons.trending_up_rounded,
        accent: const Color(0xFF9C4DFF),
        trend: 'গত সময়ের তুলনায়',
      ),
    ];

    return Scaffold(
      backgroundColor: const Color(0xFFF3F8F7),
      appBar: AppBar(
        backgroundColor: const Color(0xFFF3FAFB),
        elevation: 0,
        leading: IconButton(
          onPressed: () => Navigator.of(context).maybePop(),
          icon: const Icon(Icons.arrow_back_rounded, color: Colors.black),
        ),
        centerTitle: true,
        title: const Text(
          'খরচ রিপোর্ট',
          style: TextStyle(
            color: Color(0xFF00694C),
            fontWeight: FontWeight.w900,
          ),
        ),
        actions: [
          IconButton(
            onPressed: () => _showReportSnackBar(context, 'খরচ রিপোর্ট শেয়ার প্রস্তুত'),
            icon: const Icon(Icons.share_outlined, color: Colors.black87),
          ),
        ],
      ),
      body: CustomScrollView(
        physics: const ClampingScrollPhysics(),
        slivers: [
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.fromLTRB(16, 14, 16, 12),
              child: _TimeTabRow(
                selectedIndex: _filterIndex(selectedFilter),
                labels: const ['আজ', 'এই সপ্তাহ', 'এই মাস', 'এই বছর'],
                onChanged: (index) => ref.read(expenseTimeFilterProvider.notifier).state = _filterFromIndex(index),
              ),
            ),
          ),
          SliverPadding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            sliver: SliverToBoxAdapter(
              child: _SectionCard(
                title: 'আজকের সারসংক্ষেপ',
                child: GridView.builder(
                  itemCount: kpis.length,
                  shrinkWrap: true,
                  physics: const NeverScrollableScrollPhysics(),
                  padding: EdgeInsets.zero,
                  gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: 2,
                    mainAxisSpacing: 12,
                    crossAxisSpacing: 12,
                    childAspectRatio: 1.25,
                  ),
                  itemBuilder: (context, index) => _ExpenseKpiCard(item: kpis[index]),
                ),
              ),
            ),
          ),
          const SliverToBoxAdapter(child: SizedBox(height: 14)),
          SliverPadding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            sliver: SliverToBoxAdapter(
              child: _SectionCard(
                title: 'ট্রেন্ড অ্যানালিটিক্স',
                child: Column(
                  children: [
                    _ExpenseTrendChart(points: trendPoints),
                    const SizedBox(height: 10),
                    Align(
                      alignment: Alignment.centerLeft,
                      child: Text(
                        switch (selectedFilter) {
                          DokanExpenseTimeFilter.today => 'আজকের খরচের ট্রেন্ড',
                          DokanExpenseTimeFilter.thisWeek => 'সাপ্তাহিক খরচের ট্রেন্ড',
                          DokanExpenseTimeFilter.thisMonth => 'মাসভিত্তিক খরচের ট্রেন্ড',
                          DokanExpenseTimeFilter.thisYear => 'বার্ষিক খরচের ট্রেন্ড',
                        },
                        style: const TextStyle(
                          color: Color(0xFF111111),
                          fontWeight: FontWeight.w800,
                          fontSize: 12,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
          const SliverToBoxAdapter(child: SizedBox(height: 14)),
          SliverPadding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            sliver: SliverToBoxAdapter(
              child: _SectionCard(
                title: 'লেনদেন তালিকা',
                child: Column(
                  children: [
                    _ExpenseFilterBar(
                      initialQuery: ref.read(expenseSearchQueryProvider),
                      initialCategory: selectedCategory,
                      categories: categoryStats.map((item) => item.category).toList(growable: false),
                      onQueryChanged: (value) => ref.read(expenseSearchQueryProvider.notifier).state = value,
                      onCategoryChanged: (value) => ref.read(expenseCategoryFilterProvider.notifier).state = value,
                    ),
                    const SizedBox(height: 12),
                    filteredExpenses.isEmpty
                        ? const _ExpenseEmptyState(
                            title: 'কোনো খরচ পাওয়া যায়নি',
                            subtitle: 'ফিল্টার পরিবর্তন করুন অথবা নতুন খরচ যোগ করুন',
                          )
                        : ListView.builder(
                            itemCount: filteredExpenses.length,
                            shrinkWrap: true,
                            physics: const NeverScrollableScrollPhysics(),
                            padding: EdgeInsets.zero,
                            itemBuilder: (context, index) {
                              final expense = filteredExpenses[index];
                              return Padding(
                                padding: EdgeInsets.only(top: index == 0 ? 0 : 10),
                                child: _ExpenseTile(
                                  expense: expense,
                                  onEdit: () async {
                                    final result = await Navigator.of(context).push<bool>(
                                      MaterialPageRoute(
                                        builder: (_) => DokanExpenseEntryScreen(existingExpense: expense),
                                      ),
                                    );
                                    if (!context.mounted || result != true) return;
                                  },
                                  onDelete: () => _confirmDelete(context, ref, expense),
                                ),
                              );
                            },
                          ),
                  ],
                ),
              ),
            ),
          ),
          const SliverToBoxAdapter(child: SizedBox(height: 14)),
          const SliverToBoxAdapter(child: SizedBox(height: 14)),
          SliverPadding(
            padding: const EdgeInsets.fromLTRB(16, 0, 16, 92),
            sliver: SliverToBoxAdapter(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  _ReportExportActionButton(
                    label: '+ নতুন খরচ যোগ করুন',
                    icon: Icons.add_rounded,
                    onTap: () async {
                      final result = await Navigator.of(context).push<bool>(
                        MaterialPageRoute(builder: (_) => const DokanExpenseEntryScreen()),
                      );
                      if (!context.mounted || result != true) return;
                      _showReportSnackBar(context, 'খরচ সংরক্ষণ করা হয়েছে');
                    },
                    filled: true,
                  ),
                  const SizedBox(height: 8),
                  _ReportExportActionButton(
                    label: 'PDF Export',
                    icon: Icons.picture_as_pdf_outlined,
                    onTap: () => _showReportSnackBar(context, 'PDF রপ্তানি প্রস্তুত'),
                    filled: true,
                  ),
                  const SizedBox(height: 8),
                  _ReportExportActionButton(
                    label: 'Excel Export',
                    icon: Icons.grid_on_outlined,
                    onTap: () => _showReportSnackBar(context, 'Excel রপ্তানি প্রস্তুত'),
                    filled: true,
                  ),
                  const SizedBox(height: 4),
                ],
              ),
            ),
          ),
        ],
      ),
      bottomNavigationBar: _ReportsBottomNav(selectedIndex: 3),
    );
  }
}

class _ExpenseSummaryKpi {
  const _ExpenseSummaryKpi({
    required this.label,
    required this.value,
    required this.icon,
    required this.accent,
    required this.trend,
  });

  final String label;
  final String value;
  final IconData icon;
  final Color accent;
  final String trend;
}

class _TimeTabRow extends StatelessWidget {
  const _TimeTabRow({
    required this.selectedIndex,
    required this.labels,
    required this.onChanged,
  });

  final int selectedIndex;
  final List<String> labels;
  final ValueChanged<int> onChanged;

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      scrollDirection: Axis.horizontal,
      child: Row(
        children: List.generate(labels.length, (index) {
          final selected = index == selectedIndex;
          return Padding(
            padding: EdgeInsets.only(right: index == labels.length - 1 ? 0 : 10),
            child: _ReportChip(
              label: labels[index],
              selected: selected,
              onTap: () => onChanged(index),
            ),
          );
        }),
      ),
    );
  }
}

class _ExpenseKpiCard extends StatelessWidget {
  const _ExpenseKpiCard({required this.item});

  final _ExpenseSummaryKpi item;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: item.accent.withValues(alpha: 0.08),
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: const Color(0xFFD9E6E2)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Row(
            children: [
              Container(
                width: 34,
                height: 34,
                decoration: BoxDecoration(
                  color: item.accent.withValues(alpha: 0.16),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Icon(item.icon, color: item.accent, size: 18),
              ),
              const Spacer(),
              Text(
                item.trend,
                style: TextStyle(
                  color: item.accent,
                  fontWeight: FontWeight.w800,
                  fontSize: 11,
                ),
              ),
            ],
          ),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                item.label,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(
                  color: Color(0xFF5F6A66),
                  fontSize: 12,
                  fontWeight: FontWeight.w700,
                ),
              ),
              const SizedBox(height: 6),
              Text(
                item.value,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: TextStyle(
                  color: item.accent,
                  fontSize: 18,
                  fontWeight: FontWeight.w900,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class _ExpenseTile extends StatelessWidget {
  const _ExpenseTile({
    required this.expense,
    this.onEdit,
    this.onDelete,
  });

  final Object expense;
  final VoidCallback? onEdit;
  final VoidCallback? onDelete;

  @override
  Widget build(BuildContext context) {
    final title = expense is DokanExpenseRecord
        ? (expense as DokanExpenseRecord).title
        : (expense as dynamic).title as String;
    final category = expense is DokanExpenseRecord
        ? (expense as DokanExpenseRecord).category
        : (expense as dynamic).category as String;
    final amount = expense is DokanExpenseRecord
        ? (expense as DokanExpenseRecord).amount
        : (expense as dynamic).amount as int;
    final statusText = expense is DokanExpenseRecord
        ? ((expense as DokanExpenseRecord).status == DokanExpenseStatus.paid ? 'Paid' : 'Pending')
        : (expense as dynamic).status as String;
    final color = expense is DokanExpenseRecord
        ? const Color(0xFF0C8C67)
        : (expense as dynamic).color as Color;
    final dateTimeLabel = expense is DokanExpenseRecord
        ? _expenseDateLabel((expense as DokanExpenseRecord).date)
        : (expense as dynamic).dateTime as String;
    final isPaid = statusText == 'Paid';
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: const Color(0xFFD9E6E2)),
      ),
      child: Row(
        children: [
          Container(
            width: 40,
            height: 40,
            decoration: BoxDecoration(
              color: expense.color.withValues(alpha: 0.12),
              borderRadius: BorderRadius.circular(14),
            ),
            child: Icon(
              isPaid ? Icons.check_circle_outline_rounded : Icons.schedule_rounded,
              color: expense.color,
              size: 20,
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    color: Color(0xFF111111),
                    fontWeight: FontWeight.w900,
                  ),
                ),
                const SizedBox(height: 4),
                Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                      decoration: BoxDecoration(
                        color: color.withValues(alpha: 0.12),
                        borderRadius: BorderRadius.circular(999),
                      ),
                      child: Text(
                        category,
                        style: TextStyle(
                          color: color,
                          fontWeight: FontWeight.w800,
                          fontSize: 11,
                        ),
                      ),
                    ),
                    const SizedBox(width: 8),
                    Flexible(
                      child: Text(
                        dateTimeLabel,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(
                          color: Color(0xFF5F6A66),
                          fontWeight: FontWeight.w600,
                          fontSize: 12,
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
          const SizedBox(width: 10),
          Column(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(
                    _currency(amount.toInt()),
                    style: const TextStyle(
                      color: Color(0xFF0C8C67),
                      fontWeight: FontWeight.w900,
                    ),
                  ),
                    PopupMenuButton<int>(
                      padding: EdgeInsets.zero,
                      icon: const Icon(Icons.more_vert_rounded, color: Color(0xFF5F6A66)),
                      onSelected: (value) {
                        if (value == 0) {
                          onEdit?.call();
                        } else if (value == 1) {
                          onDelete?.call();
                        }
                      },
                    itemBuilder: (context) => const [
                      PopupMenuItem<int>(
                        value: 0,
                        child: Text('সম্পাদনা করুন'),
                      ),
                      PopupMenuItem<int>(
                        value: 1,
                        child: Text('মুছে ফেলুন'),
                      ),
                    ],
                  ),
                ],
              ),
              const SizedBox(height: 4),
              Text(
                statusText,
                style: TextStyle(
                  color: isPaid ? const Color(0xFF0C8C67) : const Color(0xFFF49B1A),
                  fontWeight: FontWeight.w800,
                  fontSize: 12,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class _ExpenseFilterBar extends StatefulWidget {
  const _ExpenseFilterBar({
    this.initialQuery = '',
    this.initialCategory,
    this.categories = const <String>[],
    this.onQueryChanged,
    this.onCategoryChanged,
  });

  final String initialQuery;
  final String? initialCategory;
  final List<String> categories;
  final ValueChanged<String>? onQueryChanged;
  final ValueChanged<String?>? onCategoryChanged;

  @override
  State<_ExpenseFilterBar> createState() => _ExpenseFilterBarState();
}

class _ExpenseFilterBarState extends State<_ExpenseFilterBar> {
  late final TextEditingController _controller;

  @override
  void initState() {
    super.initState();
    _controller = TextEditingController(text: widget.initialQuery);
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final categoryItems = <String?>[null, ...widget.categories];
    return Column(
      children: [
        Row(
          children: [
            Expanded(
              child: Container(
                height: 48,
                padding: const EdgeInsets.symmetric(horizontal: 14),
                decoration: BoxDecoration(
                  color: const Color(0xFFF7FAF9),
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(color: const Color(0xFFD9E6E2)),
                ),
                child: TextField(
                  controller: _controller,
                  onChanged: widget.onQueryChanged,
                  style: const TextStyle(color: Colors.black, fontWeight: FontWeight.w700),
                  decoration: const InputDecoration(
                    border: InputBorder.none,
                    icon: Icon(Icons.search_rounded, size: 20, color: Color(0xFF5F6A66)),
                    hintText: 'খরচ খুঁজুন',
                    hintStyle: TextStyle(color: Color(0xFF5F6A66), fontWeight: FontWeight.w600),
                  ),
                ),
              ),
            ),
          ],
        ),
        const SizedBox(height: 10),
        DropdownButtonFormField<String?>(
          value: widget.initialCategory,
          onChanged: widget.onCategoryChanged,
          decoration: InputDecoration(
            filled: true,
            fillColor: Colors.white,
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(16),
              borderSide: const BorderSide(color: Color(0xFFD9E6E2)),
            ),
            enabledBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(16),
              borderSide: const BorderSide(color: Color(0xFFD9E6E2)),
            ),
            focusedBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(16),
              borderSide: const BorderSide(color: Color(0xFF0C8C67), width: 1.4),
            ),
          ),
          items: [
            const DropdownMenuItem<String?>(
              value: null,
              child: Text('সব ক্যাটাগরি', style: TextStyle(color: Colors.black)),
            ),
            ...categoryItems.whereType<String>().map(
                  (item) => DropdownMenuItem<String?>(
                    value: item,
                    child: Text(item, style: const TextStyle(color: Colors.black)),
                ),
              ),
          ],
          icon: const Icon(Icons.keyboard_arrow_down_rounded, color: Color(0xFF0C8C67)),
          dropdownColor: Colors.white,
          style: const TextStyle(color: Color(0xFF111111), fontWeight: FontWeight.w700),
        ),
      ],
    );
  }
}

class _ExpenseTrendChart extends StatelessWidget {
  const _ExpenseTrendChart({this.points = const []});

  final List<ExpenseTrendPoint> points;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 180,
      width: double.infinity,
      child: CustomPaint(
        painter: _ExpenseTrendChartPainter(points: points),
        child: const SizedBox.expand(),
      ),
    );
  }
}

class _ExpenseTrendChartPainter extends CustomPainter {
  const _ExpenseTrendChartPainter({this.points = const []});

  final List<ExpenseTrendPoint> points;

  @override
  void paint(Canvas canvas, Size size) {
    final gridPaint = Paint()
      ..color = const Color(0xFFE7EEEC)
      ..strokeWidth = 1;
    final linePaint = Paint()
      ..color = const Color(0xFF0C8C67)
      ..strokeWidth = 3
      ..style = PaintingStyle.stroke
      ..strokeCap = StrokeCap.round
      ..strokeJoin = StrokeJoin.round;
    final fillPaint = Paint()
      ..shader = LinearGradient(
        colors: [
          const Color(0xFF0C8C67).withValues(alpha: 0.18),
          const Color(0xFF0C8C67).withValues(alpha: 0.02),
        ],
        begin: Alignment.topCenter,
        end: Alignment.bottomCenter,
      ).createShader(Rect.fromLTWH(0, 0, size.width, size.height));

    for (var i = 1; i <= 3; i++) {
      final dy = size.height * (i / 4);
      canvas.drawLine(Offset(0, dy), Offset(size.width, dy), gridPaint);
    }

    if (points.isEmpty) {
      return;
    }

    final maxValue = points.fold<int>(0, (max, item) => math.max(max, item.value)).toDouble();
    final minValue = 0.0;
    final chartPoints = <Offset>[];
    for (var i = 0; i < points.length; i++) {
      final x = points.length == 1 ? size.width * 0.5 : (size.width / (points.length - 1)) * i;
      final ratio = maxValue <= minValue ? 0.5 : (points[i].value / maxValue).clamp(0.0, 1.0);
      final y = size.height * (0.88 - (ratio * 0.62));
      chartPoints.add(Offset(x, y));
    }

    final path = Path()..moveTo(chartPoints.first.dx, chartPoints.first.dy);
    for (var i = 1; i < chartPoints.length; i++) {
      path.lineTo(chartPoints[i].dx, chartPoints[i].dy);
    }

    final fillPath = Path.from(path)
      ..lineTo(size.width, size.height)
      ..lineTo(0, size.height)
      ..close();
    canvas.drawPath(fillPath, fillPaint);
    canvas.drawPath(path, linePaint);

    final dotPaint = Paint()..color = const Color(0xFF0C8C67);
    for (final point in chartPoints) {
      canvas.drawCircle(point, 4.2, dotPaint);
    }
  }

  @override
  bool shouldRepaint(covariant _ExpenseTrendChartPainter oldDelegate) => oldDelegate.points != points;
}

String _expenseDateLabel(DateTime date) {
  const months = <String>[
    'জানুয়ারি',
    'ফেব্রুয়ারি',
    'মার্চ',
    'এপ্রিল',
    'মে',
    'জুন',
    'জুলাই',
    'আগস্ট',
    'সেপ্টেম্বর',
    'অক্টোবর',
    'নভেম্বর',
    'ডিসেম্বর',
  ];
  return '${_bnDigits(date.day.toString())} ${months[date.month - 1]} ${_bnDigits(date.year.toString())}';
}

class _ExpenseEmptyState extends StatelessWidget {
  const _ExpenseEmptyState({
    required this.title,
    required this.subtitle,
  });

  final String title;
  final String subtitle;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: const Color(0xFFF9FCFB),
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: const Color(0xFFD9E6E2)),
      ),
      child: Column(
        children: [
          Container(
            width: 54,
            height: 54,
            decoration: BoxDecoration(
              color: const Color(0xFFEAF7F0),
              borderRadius: BorderRadius.circular(18),
            ),
            child: const Icon(Icons.check_circle_outline_rounded, color: Color(0xFF0C8C67), size: 30),
          ),
          const SizedBox(height: 10),
          Text(
            title,
            textAlign: TextAlign.center,
            style: const TextStyle(
              color: Color(0xFF111111),
              fontWeight: FontWeight.w900,
            ),
          ),
          const SizedBox(height: 6),
          Text(
            subtitle,
            textAlign: TextAlign.center,
            style: const TextStyle(
              color: Color(0xFF5F6A66),
              fontWeight: FontWeight.w600,
              fontSize: 12,
            ),
          ),
        ],
      ),
    );
  }
}

int min(num a, num b) => a < b ? a.toInt() : b.toInt();

int max(num a, num b) => a > b ? a.toInt() : b.toInt();

class _DokanInventoryStockReportPage extends StatelessWidget {
  const _DokanInventoryStockReportPage();

  @override
  Widget build(BuildContext context) {
    const categories = <_StockCategoryValue>[
      _StockCategoryValue(name: 'চাল-ডাল', percent: 38, totalValue: 88000, color: Color(0xFF0C8C67)),
      _StockCategoryValue(name: 'তেল-মসলা', percent: 22, totalValue: 52600, color: Color(0xFF2F6BFF)),
      _StockCategoryValue(name: 'সাবান', percent: 16, totalValue: 42000, color: Color(0xFFF49B1A)),
      _StockCategoryValue(name: 'পানীয়', percent: 14, totalValue: 39800, color: Color(0xFF8C5CF6)),
      _StockCategoryValue(name: 'বিস্কুট', percent: 10, totalValue: 27900, color: Color(0xFFE25A4E)),
    ];

    const topProducts = <_StockValueProduct>[
      _StockValueProduct(rank: 1, name: 'মিনিকেট চাল ৫ কেজি', value: 32200, quantity: 48, category: 'চাল-ডাল', icon: Icons.grain_outlined, color: Color(0xFF0C8C67)),
      _StockValueProduct(rank: 2, name: 'সয়াবিন তেল ১ লিটার', value: 18650, quantity: 24, category: 'তেল-মসলা', icon: Icons.local_drink_outlined, color: Color(0xFF2F6BFF)),
      _StockValueProduct(rank: 3, name: 'লাক্স সাবান ১০০গ্রা', value: 14900, quantity: 36, category: 'সাবান', icon: Icons.spa_outlined, color: Color(0xFFF49B1A)),
      _StockValueProduct(rank: 4, name: 'কোকা কোলা ২৫০মি', value: 12800, quantity: 28, category: 'পানীয়', icon: Icons.local_cafe_outlined, color: Color(0xFF8C5CF6)),
      _StockValueProduct(rank: 5, name: 'চিনি ১ কেজি', value: 10900, quantity: 18, category: 'চাল-ডাল', icon: Icons.cookie_outlined, color: Color(0xFFE25A4E)),
    ];

    const deadStocks = <_DeadStockEntry>[
      _DeadStockEntry(name: 'চকলেট বিস্কুট ৫০ গ্রাম', daysSinceSale: 41),
      _DeadStockEntry(name: 'সয়াবিন তেল পুরনো ব্যাচ', daysSinceSale: 36),
      _DeadStockEntry(name: 'মেয়াদোত্তীর্ণ সাবান প্যাক', daysSinceSale: 53),
    ];

    return Scaffold(
      backgroundColor: const Color(0xFFF3F8F7),
      appBar: AppBar(
        backgroundColor: const Color(0xFFF3FAFB),
        elevation: 0,
        leading: IconButton(
          onPressed: () => Navigator.of(context).maybePop(),
          icon: const Icon(Icons.arrow_back_rounded, color: Colors.black),
        ),
        centerTitle: true,
        title: const Text(
          'স্টক ভ্যালু রিপোর্ট',
          style: TextStyle(
            color: Color(0xFF00694C),
            fontWeight: FontWeight.w900,
          ),
        ),
        actions: [
          IconButton(
            onPressed: () => _showReportSnackBar(context, 'স্টক রিপোর্ট শেয়ার প্রস্তুত'),
            icon: const Icon(Icons.share_outlined, color: Colors.black87),
          ),
        ],
      ),
      body: CustomScrollView(
        physics: const ClampingScrollPhysics(),
        slivers: [
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.fromLTRB(16, 14, 16, 12),
              child: Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  gradient: const LinearGradient(
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                    colors: [Color(0xFF0C8C67), Color(0xFF0A6A4F)],
                  ),
                  borderRadius: BorderRadius.circular(22),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text(
                      'মোট স্টক মূল্য',
                      style: TextStyle(
                        color: Colors.white70,
                        fontWeight: FontWeight.w700,
                        fontSize: 12,
                      ),
                    ),
                    const SizedBox(height: 6),
                    const Text(
                      '৳২,৮০,০০০',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 28,
                        fontWeight: FontWeight.w900,
                      ),
                    ),
                    const SizedBox(height: 14),
                    Row(
                      children: [
                        Expanded(
                          child: _StockHeroMiniMetric(
                            label: 'মোট পণ্য',
                            value: '১৮৫',
                          ),
                        ),
                        const SizedBox(width: 10),
                        Expanded(
                          child: _StockHeroMiniMetric(
                            label: 'কম স্টক',
                            value: '১৪',
                          ),
                        ),
                        const SizedBox(width: 10),
                        Expanded(
                          child: _StockHeroMiniMetric(
                            label: 'স্টক নেই',
                            value: '৬',
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
          ),
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: _SectionCard(
                title: 'ক্যাটাগরি ভিত্তিক মূল্য',
                child: Column(
                  children: [
                    for (var i = 0; i < categories.length; i++) ...[
                      _StockCategoryBarItem(item: categories[i]),
                      if (i != categories.length - 1) const SizedBox(height: 12),
                    ],
                  ],
                ),
              ),
            ),
          ),
          const SliverToBoxAdapter(child: SizedBox(height: 14)),
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: _SectionCard(
                title: 'শীর্ষ ৫টি পণ্য (মূল্য অনুযায়ী)',
                child: ListView.builder(
                  itemCount: topProducts.length,
                  shrinkWrap: true,
                  physics: const NeverScrollableScrollPhysics(),
                  padding: EdgeInsets.zero,
                  itemBuilder: (context, index) {
                    return Padding(
                      padding: EdgeInsets.only(top: index == 0 ? 0 : 10),
                      child: _StockValueProductTile(product: topProducts[index]),
                    );
                  },
                ),
              ),
            ),
          ),
          const SliverToBoxAdapter(child: SizedBox(height: 14)),
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: _SectionCard(
                title: 'ডেড স্টক (৩০+ দিন)',
                child: ListView.builder(
                  itemCount: deadStocks.length,
                  shrinkWrap: true,
                  physics: const NeverScrollableScrollPhysics(),
                  padding: EdgeInsets.zero,
                  itemBuilder: (context, index) {
                    return Padding(
                      padding: EdgeInsets.only(top: index == 0 ? 0 : 10),
                      child: _DeadStockTile(entry: deadStocks[index]),
                    );
                  },
                ),
              ),
            ),
          ),
          const SliverToBoxAdapter(child: SizedBox(height: 14)),
          SliverPadding(
            padding: const EdgeInsets.fromLTRB(16, 0, 16, 96),
            sliver: SliverToBoxAdapter(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  _ReportExportActionButton(
                    label: 'PDF ডাউনলোড',
                    icon: Icons.picture_as_pdf_outlined,
                    onTap: () => _showReportSnackBar(context, 'PDF ডাউনলোড প্রস্তুত'),
                    filled: true,
                  ),
                  const SizedBox(height: 10),
                  _ReportExportActionButton(
                    label: 'Excel রিপোর্ট',
                    icon: Icons.grid_on_outlined,
                    onTap: () => _showReportSnackBar(context, 'Excel রিপোর্ট প্রস্তুত'),
                    filled: true,
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
      bottomNavigationBar: _ReportsBottomNav(selectedIndex: 3),
    );
  }
}

class _StockCategoryValue {
  const _StockCategoryValue({
    required this.name,
    required this.percent,
    required this.totalValue,
    required this.color,
  });

  final String name;
  final int percent;
  final int totalValue;
  final Color color;
}

class _StockValueProduct {
  const _StockValueProduct({
    required this.rank,
    required this.name,
    required this.value,
    required this.quantity,
    required this.category,
    required this.icon,
    required this.color,
  });

  final int rank;
  final String name;
  final int value;
  final int quantity;
  final String category;
  final IconData icon;
  final Color color;
}

class _DeadStockEntry {
  const _DeadStockEntry({
    required this.name,
    required this.daysSinceSale,
  });

  final String name;
  final int daysSinceSale;
}

class _StockHeroMiniMetric extends StatelessWidget {
  const _StockHeroMiniMetric({
    required this.label,
    required this.value,
  });

  final String label;
  final String value;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 11),
      decoration: BoxDecoration(
        color: Colors.white.withValues(alpha: 0.12),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: Colors.white.withValues(alpha: 0.16)),
      ),
      child: Column(
        children: [
          Text(
            label,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: const TextStyle(
              color: Colors.white70,
              fontSize: 11,
              fontWeight: FontWeight.w700,
            ),
          ),
          const SizedBox(height: 4),
          Text(
            value,
            style: const TextStyle(
              color: Colors.white,
              fontSize: 18,
              fontWeight: FontWeight.w900,
            ),
          ),
        ],
      ),
    );
  }
}

class _StockCategoryBarItem extends StatelessWidget {
  const _StockCategoryBarItem({required this.item});

  final _StockCategoryValue item;

  @override
  Widget build(BuildContext context) {
    final progress = (item.percent / 100).clamp(0.0, 1.0);
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Expanded(
              child: Text(
                item.name,
                style: const TextStyle(
                  color: Color(0xFF111111),
                  fontWeight: FontWeight.w900,
                  fontSize: 14,
                ),
              ),
            ),
            Text(
              '${_bnDigits(item.percent.toString())}%',
              style: TextStyle(
                color: item.color,
                fontWeight: FontWeight.w800,
              ),
            ),
          ],
        ),
        const SizedBox(height: 6),
        ClipRRect(
          borderRadius: BorderRadius.circular(999),
          child: LinearProgressIndicator(
            value: progress,
            minHeight: 8,
            backgroundColor: const Color(0xFFE7EEEC),
            valueColor: AlwaysStoppedAnimation<Color>(item.color),
          ),
        ),
        const SizedBox(height: 6),
        Row(
          children: [
            const Text(
              'মোট মূল্য',
              style: TextStyle(
                color: Color(0xFF5F6A66),
                fontWeight: FontWeight.w600,
                fontSize: 12,
              ),
            ),
            const Spacer(),
            Text(
              _currency(item.totalValue),
              style: const TextStyle(
                color: Color(0xFF111111),
                fontWeight: FontWeight.w800,
                fontSize: 12,
              ),
            ),
          ],
        ),
      ],
    );
  }
}

class _StockValueProductTile extends StatelessWidget {
  const _StockValueProductTile({required this.product});

  final _StockValueProduct product;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: const Color(0xFFF9FCFB),
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: const Color(0xFFD9E6E2)),
      ),
      child: Row(
        children: [
          Container(
            width: 40,
            height: 40,
            decoration: BoxDecoration(
              color: product.color.withValues(alpha: 0.12),
              borderRadius: BorderRadius.circular(14),
            ),
            child: Icon(product.icon, color: product.color, size: 20),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  product.name,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    color: Color(0xFF111111),
                    fontWeight: FontWeight.w900,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  product.category,
                  style: const TextStyle(
                    color: Color(0xFF5F6A66),
                    fontWeight: FontWeight.w600,
                    fontSize: 12,
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(width: 10),
          Column(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Text(
                _currency(product.value),
                style: const TextStyle(
                  color: Color(0xFF0C8C67),
                  fontWeight: FontWeight.w900,
                ),
              ),
              const SizedBox(height: 4),
              Text(
                '${_bnDigits(product.quantity.toString())}টি',
                style: const TextStyle(
                  color: Color(0xFF3D4943),
                  fontWeight: FontWeight.w700,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class _DeadStockTile extends StatelessWidget {
  const _DeadStockTile({required this.entry});

  final _DeadStockEntry entry;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: const Color(0xFFFFF5F4),
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: const Color(0xFFF0CEC9)),
      ),
      child: Row(
        children: [
          Container(
            width: 38,
            height: 38,
            decoration: BoxDecoration(
              color: const Color(0xFFFDE8E4),
              borderRadius: BorderRadius.circular(12),
            ),
            child: const Icon(Icons.warning_amber_rounded, color: Color(0xFFD43B3B)),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  entry.name,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    color: Color(0xFF111111),
                    fontWeight: FontWeight.w900,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  'সর্বশেষ বিক্রি ${_bnDigits(entry.daysSinceSale.toString())} দিন আগে',
                  style: const TextStyle(
                    color: Color(0xFF5F6A66),
                    fontWeight: FontWeight.w600,
                    fontSize: 12,
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(width: 10),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
            decoration: BoxDecoration(
              color: const Color(0xFFFCE0DC),
              borderRadius: BorderRadius.circular(999),
            ),
            child: const Text(
              'সতর্কতা',
              style: TextStyle(
                color: Color(0xFFD43B3B),
                fontWeight: FontWeight.w800,
                fontSize: 12,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _RoundDateNavButton extends StatelessWidget {
  const _RoundDateNavButton({
    required this.icon,
    required this.onTap,
  });

  final IconData icon;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(999),
        child: Container(
          width: 44,
          height: 44,
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(999),
            border: Border.all(color: const Color(0xFFD9E6E2)),
          ),
          child: Icon(icon, color: const Color(0xFF0C8C67)),
        ),
      ),
    );
  }
}

class _DailyHeroMetric extends StatelessWidget {
  const _DailyHeroMetric({
    required this.label,
    required this.value,
  });

  final String label;
  final String value;

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Text(
          label,
          textAlign: TextAlign.center,
          maxLines: 1,
          overflow: TextOverflow.ellipsis,
          style: const TextStyle(
            color: Colors.white,
            fontWeight: FontWeight.w700,
            fontSize: 12,
          ),
        ),
        const SizedBox(height: 6),
        FittedBox(
          fit: BoxFit.scaleDown,
          child: Text(
            value,
            style: const TextStyle(
              color: Colors.white,
              fontSize: 17,
              fontWeight: FontWeight.w900,
            ),
          ),
        ),
      ],
    );
  }
}

class _DailyTopProductRow extends StatelessWidget {
  const _DailyTopProductRow({required this.product});

  final _TopProductStat product;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: const Color(0xFFF9FCFB),
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: const Color(0xFFD9E6E2)),
      ),
      child: Row(
        children: [
          Container(
            width: 34,
            height: 34,
            decoration: BoxDecoration(
              color: const Color(0xFFEAF7F0),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Center(
              child: Text(
                _bnDigits(product.rank.toString()),
                style: const TextStyle(
                  color: Color(0xFF0C8C67),
                  fontWeight: FontWeight.w900,
                ),
              ),
            ),
          ),
          const SizedBox(width: 12),
          Container(
            width: 40,
            height: 40,
            decoration: BoxDecoration(
              color: product.color.withValues(alpha: 0.12),
              borderRadius: BorderRadius.circular(14),
            ),
            child: Icon(product.icon, color: product.color, size: 20),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  product.name,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    color: Color(0xFF111111),
                    fontWeight: FontWeight.w900,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  product.category,
                  style: const TextStyle(
                    color: Color(0xFF5F6A66),
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(width: 10),
          Column(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Text(
                _currency(product.revenue),
                style: const TextStyle(
                  color: Color(0xFF0C8C67),
                  fontWeight: FontWeight.w900,
                ),
              ),
              const SizedBox(height: 4),
              Text(
                '${_bnDigits(product.salesCount.toString())}টি বিক্রয়',
                style: const TextStyle(
                  color: Color(0xFF3D4943),
                  fontWeight: FontWeight.w700,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class _PurchaseRankStat {
  const _PurchaseRankStat({
    required this.rank,
    required this.name,
    required this.units,
    required this.amount,
    required this.category,
    required this.icon,
    required this.color,
  });

  final int rank;
  final String name;
  final int units;
  final int amount;
  final String category;
  final IconData icon;
  final Color color;
}

class _DailyPurchaseTopItemRow extends StatelessWidget {
  const _DailyPurchaseTopItemRow({required this.product});

  final _PurchaseRankStat product;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: const Color(0xFFF9FCFB),
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: const Color(0xFFD9E6E2)),
      ),
      child: Row(
        children: [
          Container(
            width: 34,
            height: 34,
            decoration: BoxDecoration(
              color: const Color(0xFFEAF7F0),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Center(
              child: Text(
                _bnDigits(product.rank.toString()),
                style: const TextStyle(
                  color: Color(0xFF0C8C67),
                  fontWeight: FontWeight.w900,
                ),
              ),
            ),
          ),
          const SizedBox(width: 12),
          Container(
            width: 40,
            height: 40,
            decoration: BoxDecoration(
              color: product.color.withValues(alpha: 0.12),
              borderRadius: BorderRadius.circular(14),
            ),
            child: Icon(product.icon, color: product.color, size: 20),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  product.name,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    color: Color(0xFF111111),
                    fontWeight: FontWeight.w900,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  product.category,
                  style: const TextStyle(
                    color: Color(0xFF5F6A66),
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(width: 10),
          Column(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Text(
                _currency(product.amount),
                style: const TextStyle(
                  color: Color(0xFF0C8C67),
                  fontWeight: FontWeight.w900,
                ),
              ),
              const SizedBox(height: 4),
              Text(
                '${_bnDigits(product.units.toString())}টি ক্রয়',
                style: const TextStyle(
                  color: Color(0xFF3D4943),
                  fontWeight: FontWeight.w700,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class _StockRatioSlice {
  const _StockRatioSlice({
    required this.label,
    required this.value,
    required this.color,
  });

  final String label;
  final int value;
  final Color color;
}

class _CompactSummaryCard extends StatelessWidget {
  const _CompactSummaryCard({
    required this.title,
    required this.value,
    required this.subtitle,
    required this.background,
    required this.foreground,
    this.isFilled = false,
  });

  final String title;
  final String value;
  final String subtitle;
  final Color background;
  final Color foreground;
  final bool isFilled;

  @override
  Widget build(BuildContext context) {
    return Container(
      constraints: const BoxConstraints(minHeight: 76),
      padding: const EdgeInsets.all(10),
      decoration: BoxDecoration(
        color: background,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: isFilled ? background : const Color(0xFFD9E6E2)),
        boxShadow: const [
          BoxShadow(
            color: Color(0x08000000),
            blurRadius: 12,
            offset: Offset(0, 4),
          ),
        ],
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            title,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: TextStyle(
              color: foreground,
              fontWeight: FontWeight.w700,
              fontSize: 11.5,
            ),
          ),
          const SizedBox(height: 3),
          FittedBox(
            fit: BoxFit.scaleDown,
            child: Text(
              value,
              style: TextStyle(
                color: foreground,
                fontSize: 17,
                fontWeight: FontWeight.w900,
              ),
            ),
          ),
          const SizedBox(height: 3),
          Text(
            subtitle,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: TextStyle(
              color: foreground.withValues(alpha: isFilled ? 0.82 : 0.85),
              fontWeight: FontWeight.w600,
              fontSize: 10.5,
            ),
          ),
        ],
      ),
    );
  }
}

class _ValueLineItem extends StatelessWidget {
  const _ValueLineItem({
    required this.label,
    required this.value,
    required this.valueColor,
    this.emphasize = false,
  });

  final String label;
  final String value;
  final Color valueColor;
  final bool emphasize;

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Expanded(
          child: Text(
            label,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: TextStyle(
              color: const Color(0xFF111111),
              fontWeight: emphasize ? FontWeight.w900 : FontWeight.w700,
            ),
          ),
        ),
        const SizedBox(width: 12),
        Text(
          value,
          style: TextStyle(
            color: valueColor,
            fontWeight: emphasize ? FontWeight.w900 : FontWeight.w800,
          ),
        ),
      ],
    );
  }
}

class _DividerLine extends StatelessWidget {
  const _DividerLine();

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 1,
      width: double.infinity,
      color: const Color(0xFFE6ECEA),
    );
  }
}

class _StockRatioChart extends StatelessWidget {
  const _StockRatioChart({
    required this.slices,
    required this.centerLabel,
    required this.centerValue,
  });

  final List<_StockRatioSlice> slices;
  final String centerLabel;
  final String centerValue;

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (context, constraints) {
        return Center(
          child: SizedBox(
            width: math.min(constraints.maxWidth, 220),
            height: math.min(constraints.maxHeight, 220),
            child: CustomPaint(
              painter: _StockRatioPainter(slices),
              child: Center(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text(
                      centerLabel,
                      style: const TextStyle(
                        color: Color(0xFF3D4943),
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                    const SizedBox(height: 6),
                    Text(
                      centerValue,
                      style: const TextStyle(
                        color: Color(0xFF0C8C67),
                        fontSize: 22,
                        fontWeight: FontWeight.w900,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        );
      },
    );
  }
}

class _StockRatioPainter extends CustomPainter {
  _StockRatioPainter(this.slices);

  final List<_StockRatioSlice> slices;

  @override
  void paint(Canvas canvas, Size size) {
    if (slices.isEmpty) return;
    final total = slices.fold<int>(0, (sum, slice) => sum + slice.value);
    if (total <= 0) return;
    final rect = Rect.fromLTWH(10, 10, size.width - 20, size.height - 20);
    final strokeWidth = 20.0;
    final paint = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = strokeWidth
      ..strokeCap = StrokeCap.butt;
    var startAngle = -math.pi / 2;
    for (final slice in slices) {
      final sweepAngle = (slice.value / total) * math.pi * 2;
      paint.color = slice.color;
      canvas.drawArc(rect, startAngle, sweepAngle, false, paint);
      startAngle += sweepAngle;
    }
  }

  @override
  bool shouldRepaint(covariant _StockRatioPainter oldDelegate) => oldDelegate.slices != slices;
}

class _RatioLegendItem extends StatelessWidget {
  const _RatioLegendItem({
    required this.label,
    required this.color,
  });

  final String label;
  final Color color;

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Container(
          width: 10,
          height: 10,
          decoration: BoxDecoration(color: color, shape: BoxShape.circle),
        ),
        const SizedBox(width: 6),
        Text(
          label,
          style: const TextStyle(
            color: Color(0xFF3D4943),
            fontWeight: FontWeight.w700,
          ),
        ),
      ],
    );
  }
}

class _ReportExportActionButton extends StatefulWidget {
  const _ReportExportActionButton({
    required this.label,
    required this.icon,
    required this.onTap,
    required this.filled,
  });

  final String label;
  final IconData icon;
  final VoidCallback onTap;
  final bool filled;

  @override
  State<_ReportExportActionButton> createState() => _ReportExportActionButtonState();
}

class _ReportExportActionButtonState extends State<_ReportExportActionButton> {
  bool _pressed = false;

  void _setPressed(bool value) {
    if (_pressed == value) return;
    setState(() => _pressed = value);
  }

  @override
  Widget build(BuildContext context) {
    final foregroundColor = Colors.white;
    final labelColor = widget.label.contains('PDF') ? Colors.black : foregroundColor;
    final backgroundColor = widget.filled
        ? (_pressed ? const Color(0xFF0A6A4F) : const Color(0xFF0C8C67))
        : (_pressed ? const Color(0xFFDFF5EE) : Colors.white);

    final child = SizedBox(
      width: double.infinity,
      height: 48,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        mainAxisSize: MainAxisSize.max,
        children: [
          Icon(
            widget.icon,
            color: widget.label.contains('PDF') ? Colors.black : foregroundColor,
            size: 18,
          ),
          const SizedBox(width: 8),
          Flexible(
            child: Text(
              widget.label,
              maxLines: 1,
              overflow: TextOverflow.fade,
              softWrap: false,
              textAlign: TextAlign.center,
              style: TextStyle(
                color: labelColor,
                fontWeight: FontWeight.w800,
                fontSize: 13.5,
              ),
            ),
          ),
        ],
      ),
    );

    if (widget.filled) {
      return Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: widget.onTap,
          onTapDown: (_) => _setPressed(true),
          onTapUp: (_) => _setPressed(false),
          onTapCancel: () => _setPressed(false),
          borderRadius: BorderRadius.circular(16),
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 120),
            transform: Matrix4.translationValues(0, _pressed ? -1 : 0, 0),
            width: double.infinity,
            padding: const EdgeInsets.symmetric(horizontal: 10),
            decoration: BoxDecoration(
              color: backgroundColor,
              borderRadius: BorderRadius.circular(16),
              boxShadow: [
                BoxShadow(
                  color: _pressed ? const Color(0x400C8C67) : const Color(0x220C8C67),
                  blurRadius: _pressed ? 16 : 8,
                  offset: Offset(0, _pressed ? 8 : 4),
                ),
              ],
            ),
            child: child,
          ),
        ),
      );
    }

    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: widget.onTap,
        onTapDown: (_) => _setPressed(true),
        onTapUp: (_) => _setPressed(false),
        onTapCancel: () => _setPressed(false),
        borderRadius: BorderRadius.circular(16),
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 120),
          transform: Matrix4.translationValues(0, _pressed ? -1 : 0, 0),
          width: double.infinity,
          padding: const EdgeInsets.symmetric(horizontal: 10),
          decoration: BoxDecoration(
            color: backgroundColor,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(
              color: _pressed ? const Color(0xFF0C8C67) : const Color(0xFF0C8C67),
              width: _pressed ? 1.8 : 1.4,
            ),
              boxShadow: [
                BoxShadow(
                  color: _pressed ? const Color(0x240C8C67) : Colors.transparent,
                  blurRadius: _pressed ? 12 : 0,
                  offset: const Offset(0, 6),
                ),
              ],
          ),
          child: child,
        ),
      ),
    );
  }
}

class _ReportsBottomNav extends StatelessWidget {
  const _ReportsBottomNav({required this.selectedIndex});
  final int selectedIndex;

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      top: false,
      child: Container(
        padding: const EdgeInsets.fromLTRB(14, 12, 14, 12),
        decoration: const BoxDecoration(
          color: Color(0xFFEAF2F0),
          border: Border(top: BorderSide(color: Color(0xFFD7E5E0))),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            _ReportsNavItem(
              icon: Icons.home_outlined,
              label: '\u09b9\u09cb\u09ae',
              selected: selectedIndex == 0,
              onTap: () => Navigator.of(context).popUntil((r) => r.isFirst),
            ),
            _ReportsNavItem(
              icon: Icons.point_of_sale_outlined,
              label: '\u09ac\u09bf\u0995\u09cd\u09b0\u09af\u09bc',
              selected: selectedIndex == 1,
              onTap: () => Navigator.of(context).pushReplacement(
                MaterialPageRoute(builder: (_) => const DokanPosMainScreen()),
              ),
            ),
            _ReportsNavItem(
              icon: Icons.inventory_2_outlined,
              label: '\u09aa\u09a3\u09cd\u09af',
              selected: selectedIndex == 2,
              onTap: () => Navigator.of(context).pushReplacement(
                MaterialPageRoute(builder: (_) => const DokanProductListScreen()),
              ),
            ),
            _ReportsNavItem(
              icon: Icons.bar_chart_outlined,
              label: '\u09b0\u09bf\u09aa\u09cb\u09b0\u09cd\u099f',
              selected: selectedIndex == 3,
              onTap: () {},
            ),
            _ReportsNavItem(
              icon: Icons.more_horiz,
              label: '\u0986\u09b0\u0993',
              selected: selectedIndex == 4,
              onTap: () => Navigator.of(context).pushReplacement(
                MaterialPageRoute(builder: (_) => const DokanAroOptionScreen()),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _ReportsNavItem extends StatelessWidget {
  const _ReportsNavItem({
    required this.icon,
    required this.label,
    required this.selected,
    required this.onTap,
  });

  final IconData icon;
  final String label;
  final bool selected;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final activeColor = const Color(0xFF0C8C67);
    final inactiveColor = const Color(0xFF3D4943);
    return Expanded(
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: onTap,
          borderRadius: BorderRadius.circular(14),
          child: Padding(
            padding: const EdgeInsets.symmetric(vertical: 6),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(icon, color: selected ? activeColor : inactiveColor),
                const SizedBox(height: 4),
                FittedBox(
                  fit: BoxFit.scaleDown,
                  child: Text(
                    label,
                    style: TextStyle(
                      color: selected ? activeColor : inactiveColor,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
