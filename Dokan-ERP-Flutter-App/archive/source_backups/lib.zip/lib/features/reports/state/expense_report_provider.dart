import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:shared_preferences/shared_preferences.dart';

enum DokanExpenseTimeFilter { today, thisWeek, thisMonth, thisYear }

enum DokanExpenseStatus { paid, pending }

enum DokanExpensePaymentMethod { cash, bkash, nagad, bank }

class DokanExpenseRecord {
  const DokanExpenseRecord({
    required this.id,
    required this.title,
    required this.category,
    required this.amount,
    required this.date,
    this.note = '',
    this.receiptLabel = '',
    this.paymentMethod = DokanExpensePaymentMethod.cash,
    this.status = DokanExpenseStatus.paid,
  });

  final String id;
  final String title;
  final String category;
  final double amount;
  final DateTime date;
  final String note;
  final String receiptLabel;
  final DokanExpensePaymentMethod paymentMethod;
  final DokanExpenseStatus status;

  DokanExpenseRecord copyWith({
    String? id,
    String? title,
    String? category,
    double? amount,
    DateTime? date,
    String? note,
    String? receiptLabel,
    DokanExpensePaymentMethod? paymentMethod,
    DokanExpenseStatus? status,
  }) {
    return DokanExpenseRecord(
      id: id ?? this.id,
      title: title ?? this.title,
      category: category ?? this.category,
      amount: amount ?? this.amount,
      date: date ?? this.date,
      note: note ?? this.note,
      receiptLabel: receiptLabel ?? this.receiptLabel,
      paymentMethod: paymentMethod ?? this.paymentMethod,
      status: status ?? this.status,
    );
  }

  Map<String, dynamic> toJson() {
    return <String, dynamic>{
      'id': id,
      'title': title,
      'category': category,
      'amount': amount,
      'date': date.toIso8601String(),
      'note': note,
      'receiptLabel': receiptLabel,
      'paymentMethod': paymentMethod.name,
      'status': status.name,
    };
  }

  factory DokanExpenseRecord.fromJson(Map<String, dynamic> json) {
    return DokanExpenseRecord(
      id: json['id'] as String? ?? '',
      title: json['title'] as String? ?? '',
      category: json['category'] as String? ?? 'অন্যান্য',
      amount: (json['amount'] as num?)?.toDouble() ?? 0,
      date: DateTime.tryParse(json['date'] as String? ?? '') ?? DateTime.now(),
      note: json['note'] as String? ?? '',
      receiptLabel: json['receiptLabel'] as String? ?? '',
      paymentMethod: DokanExpensePaymentMethod.values.firstWhere(
        (element) => element.name == json['paymentMethod'],
        orElse: () => DokanExpensePaymentMethod.cash,
      ),
      status: DokanExpenseStatus.values.firstWhere(
        (element) => element.name == json['status'],
        orElse: () => DokanExpenseStatus.paid,
      ),
    );
  }

  String get paymentMethodLabel {
    switch (paymentMethod) {
      case DokanExpensePaymentMethod.cash:
        return 'নগদ';
      case DokanExpensePaymentMethod.bkash:
        return 'bKash';
      case DokanExpensePaymentMethod.nagad:
        return 'Nagad';
      case DokanExpensePaymentMethod.bank:
        return 'ব্যাংক';
    }
  }

  String get statusLabel {
    switch (status) {
      case DokanExpenseStatus.paid:
        return 'পরিশোধিত';
      case DokanExpenseStatus.pending:
        return 'বাকি';
    }
  }

  Color get statusColor {
    switch (status) {
      case DokanExpenseStatus.paid:
        return const Color(0xFF14855C);
      case DokanExpenseStatus.pending:
        return const Color(0xFFD97706);
    }
  }

  Color get categoryColor {
    switch (category) {
      case 'পণ্য ক্রয়':
        return const Color(0xFF14855C);
      case 'বিদ্যুৎ বিল':
        return const Color(0xFF0F766E);
      case 'গ্যাস বিল':
        return const Color(0xFFB45309);
      case 'ইন্টারনেট বিল':
        return const Color(0xFF2563EB);
      case 'কর্মচারীর বেতন':
        return const Color(0xFF7C3AED);
      case 'পরিবহন':
        return const Color(0xFFEA580C);
      case 'ভাড়া':
        return const Color(0xFFDB2777);
      case 'ট্যাক্স':
        return const Color(0xFFDC2626);
      case 'মেরামত':
        return const Color(0xFF0891B2);
      default:
        return const Color(0xFF3B82F6);
    }
  }

  IconData get categoryIcon {
    switch (category) {
      case 'পণ্য ক্রয়':
        return Icons.shopping_bag_outlined;
      case 'বিদ্যুৎ বিল':
        return Icons.bolt_outlined;
      case 'গ্যাস বিল':
        return Icons.local_fire_department_outlined;
      case 'ইন্টারনেট বিল':
        return Icons.wifi_outlined;
      case 'কর্মচারীর বেতন':
        return Icons.groups_outlined;
      case 'পরিবহন':
        return Icons.local_shipping_outlined;
      case 'ভাড়া':
        return Icons.home_outlined;
      case 'ট্যাক্স':
        return Icons.receipt_long_outlined;
      case 'মেরামত':
        return Icons.build_outlined;
      default:
        return Icons.attach_money_outlined;
    }
  }

  String get dateLabel {
    final DateTime dt = date;
    final String hour = dt.hour % 12 == 0 ? '12' : '${dt.hour % 12}';
    final String minute = dt.minute.toString().padLeft(2, '0');
    final String suffix = dt.hour >= 12 ? 'PM' : 'AM';
    return '${dt.day}/${dt.month}/${dt.year} • $hour:$minute $suffix';
  }
}

class ExpenseSummary {
  const ExpenseSummary({
    required this.totalAmount,
    required this.transactionCount,
    required this.topCategory,
    required this.topCategoryAmount,
    required this.previousAmount,
    required this.changePercent,
  });

  final double totalAmount;
  final int transactionCount;
  final String topCategory;
  final double topCategoryAmount;
  final double previousAmount;
  final double changePercent;

  int get totalExpense => totalAmount.round();

  double get totalExpenseAmount => totalAmount;

  int get totalTransactions => transactionCount;
}

class ExpenseCategoryStat {
  const ExpenseCategoryStat({
    required this.category,
    required this.totalAmount,
    required this.percentage,
  });

  final String category;
  final double totalAmount;
  final double percentage;

  int get percent => percentage.round();

  double get percentValue => percentage;
}

class ExpenseTrendPoint {
  const ExpenseTrendPoint({
    required this.label,
    required this.amount,
  });

  final String label;
  final double amount;

  int get value => amount.round();

  double get amountValue => amount;
}

class DokanExpenseController extends AsyncNotifier<List<DokanExpenseRecord>> {
  static const String _storageKey = 'dokan_expense_records_v2';

  @override
  Future<List<DokanExpenseRecord>> build() async {
    final SharedPreferences prefs = await SharedPreferences.getInstance();
    final String? raw = prefs.getString(_storageKey);
    if (raw == null || raw.isEmpty) {
      final List<DokanExpenseRecord> seeds = _seedExpenses();
      await _saveAll(prefs, seeds);
      return seeds;
    }

    final Object? decoded = jsonDecode(raw);
    if (decoded is List) {
      final List<DokanExpenseRecord> records = decoded
          .whereType<Map>()
          .map((Map<dynamic, dynamic> item) {
            return DokanExpenseRecord.fromJson(
              item.map((dynamic key, dynamic value) => MapEntry<String, dynamic>('$key', value)),
            );
          })
          .toList()
        ..sort((DokanExpenseRecord a, DokanExpenseRecord b) => b.date.compareTo(a.date));
      return records;
    }
    return _seedExpenses();
  }

  Future<void> addExpense(DokanExpenseRecord expense) async {
    final List<DokanExpenseRecord> current = List<DokanExpenseRecord>.from(state.asData?.value ?? const <DokanExpenseRecord>[]);
    final List<DokanExpenseRecord> updated = <DokanExpenseRecord>[
      expense,
      ...current,
    ]..sort((DokanExpenseRecord a, DokanExpenseRecord b) => b.date.compareTo(a.date));
    state = AsyncData<List<DokanExpenseRecord>>(updated);
    await _persist(updated);
  }

  Future<void> updateExpense(DokanExpenseRecord expense) async {
    final List<DokanExpenseRecord> current = List<DokanExpenseRecord>.from(state.asData?.value ?? const <DokanExpenseRecord>[]);
    final int index = current.indexWhere((DokanExpenseRecord item) => item.id == expense.id);
    if (index == -1) {
      return;
    }
    current[index] = expense;
    current.sort((DokanExpenseRecord a, DokanExpenseRecord b) => b.date.compareTo(a.date));
    state = AsyncData<List<DokanExpenseRecord>>(current);
    await _persist(current);
  }

  Future<void> deleteExpense(String id) async {
    final List<DokanExpenseRecord> current = List<DokanExpenseRecord>.from(state.asData?.value ?? const <DokanExpenseRecord>[]);
    final List<DokanExpenseRecord> updated = current.where((DokanExpenseRecord item) => item.id != id).toList();
    state = AsyncData<List<DokanExpenseRecord>>(updated);
    await _persist(updated);
  }

  Future<void> _persist(List<DokanExpenseRecord> records) async {
    final SharedPreferences prefs = await SharedPreferences.getInstance();
    await _saveAll(prefs, records);
  }

  Future<void> _saveAll(SharedPreferences prefs, List<DokanExpenseRecord> records) {
    return prefs.setString(
      _storageKey,
      jsonEncode(records.map((DokanExpenseRecord item) => item.toJson()).toList()),
    );
  }

  List<DokanExpenseRecord> _seedExpenses() {
    final DateTime now = DateTime.now();
    return <DokanExpenseRecord>[
      DokanExpenseRecord(
        id: 'exp-001',
        title: 'চাল ক্রয়',
        category: 'পণ্য ক্রয়',
        amount: 8200,
        date: now.subtract(const Duration(hours: 2)),
        note: 'দোকানের স্টক পূরণ',
        paymentMethod: DokanExpensePaymentMethod.cash,
      ),
      DokanExpenseRecord(
        id: 'exp-002',
        title: 'বিদ্যুৎ বিল পরিশোধ',
        category: 'বিদ্যুৎ বিল',
        amount: 1850,
        date: now.subtract(const Duration(days: 1, hours: 3)),
        note: 'মাসিক বিল',
        paymentMethod: DokanExpensePaymentMethod.bank,
      ),
      DokanExpenseRecord(
        id: 'exp-003',
        title: 'কর্মচারীর বেতন',
        category: 'কর্মচারীর বেতন',
        amount: 12500,
        date: now.subtract(const Duration(days: 2)),
        note: 'সেলসম্যানের বেতন',
        paymentMethod: DokanExpensePaymentMethod.bkash,
      ),
      DokanExpenseRecord(
        id: 'exp-004',
        title: 'ট্যাক্স জমা',
        category: 'ট্যাক্স',
        amount: 4600,
        date: now.subtract(const Duration(days: 5)),
        note: 'ত্রৈমাসিক ট্যাক্স',
        paymentMethod: DokanExpensePaymentMethod.bank,
      ),
      DokanExpenseRecord(
        id: 'exp-005',
        title: 'মেরামত খরচ',
        category: 'মেরামত',
        amount: 2450,
        date: now.subtract(const Duration(days: 8)),
        note: 'দোকানের ফ্রিজ সার্ভিস',
        paymentMethod: DokanExpensePaymentMethod.cash,
      ),
      DokanExpenseRecord(
        id: 'exp-006',
        title: 'ইন্টারনেট বিল',
        category: 'ইন্টারনেট বিল',
        amount: 1250,
        date: now.subtract(const Duration(days: 15)),
        note: 'মাসিক প্যাকেজ',
        paymentMethod: DokanExpensePaymentMethod.nagad,
      ),
      DokanExpenseRecord(
        id: 'exp-007',
        title: 'ভাড়া পরিশোধ',
        category: 'ভাড়া',
        amount: 18000,
        date: now.subtract(const Duration(days: 28)),
        note: 'দোকান ভাড়া',
        paymentMethod: DokanExpensePaymentMethod.cash,
      ),
    ]..sort((DokanExpenseRecord a, DokanExpenseRecord b) => b.date.compareTo(a.date));
  }
}

class ExpenseTimeFilterNotifier extends Notifier<DokanExpenseTimeFilter> {
  @override
  DokanExpenseTimeFilter build() => DokanExpenseTimeFilter.today;

  void setFilter(DokanExpenseTimeFilter value) {
    state = value;
  }
}

class ExpenseCategoryFilterNotifier extends Notifier<String?> {
  @override
  String? build() => null;

  void setFilter(String? value) {
    state = value;
  }
}

class ExpenseSearchNotifier extends Notifier<String> {
  @override
  String build() => '';

  void setQuery(String value) {
    state = value;
  }
}

final expenseReportControllerProvider =
    AsyncNotifierProvider<DokanExpenseController, List<DokanExpenseRecord>>(
  DokanExpenseController.new,
);

final expenseTimeFilterProvider =
    NotifierProvider<ExpenseTimeFilterNotifier, DokanExpenseTimeFilter>(
  ExpenseTimeFilterNotifier.new,
);

final expenseCategoryFilterProvider =
    NotifierProvider<ExpenseCategoryFilterNotifier, String?>(
  ExpenseCategoryFilterNotifier.new,
);

final expenseSearchQueryProvider =
    NotifierProvider<ExpenseSearchNotifier, String>(
  ExpenseSearchNotifier.new,
);

final filteredExpenseRecordsProvider = Provider<List<DokanExpenseRecord>>((Ref ref) {
  final AsyncValue<List<DokanExpenseRecord>> expensesAsync = ref.watch(expenseReportControllerProvider);
  final DokanExpenseTimeFilter timeFilter = ref.watch(expenseTimeFilterProvider);
  final String categoryFilter = ref.watch(expenseCategoryFilterProvider) ?? 'সব';
  final String searchQuery = ref.watch(expenseSearchQueryProvider).trim().toLowerCase();
  final List<DokanExpenseRecord> expenses = expensesAsync.asData?.value ?? const <DokanExpenseRecord>[];

  return expenses.where((DokanExpenseRecord expense) {
    final bool matchesTime = _matchesTimeFilter(expense.date, timeFilter);
    final bool matchesCategory = categoryFilter == 'সব' || expense.category == categoryFilter;
    final bool matchesSearch = searchQuery.isEmpty ||
        expense.title.toLowerCase().contains(searchQuery) ||
        expense.category.toLowerCase().contains(searchQuery) ||
        expense.note.toLowerCase().contains(searchQuery);
    return matchesTime && matchesCategory && matchesSearch;
  }).toList(growable: false);
});

final expenseSummaryProvider = Provider<ExpenseSummary>((Ref ref) {
  final List<DokanExpenseRecord> records = ref.watch(filteredExpenseRecordsProvider);
  final double totalAmount = records.fold<double>(0, (double sum, DokanExpenseRecord item) => sum + item.amount);
  final int transactionCount = records.length;
  final Map<String, double> categoryTotals = <String, double>{};
  for (final DokanExpenseRecord item in records) {
    categoryTotals.update(item.category, (double value) => value + item.amount, ifAbsent: () => item.amount);
  }
  final MapEntry<String, double>? topCategoryEntry = categoryTotals.entries.isNotEmpty
      ? categoryTotals.entries.reduce(
          (MapEntry<String, double> a, MapEntry<String, double> b) => a.value >= b.value ? a : b,
        )
      : null;

  final DokanExpenseTimeFilter timeFilter = ref.watch(expenseTimeFilterProvider);
  final List<DokanExpenseRecord> previousRecords = _previousPeriodRecords(ref, timeFilter);
  final double previousAmount = previousRecords.fold<double>(0, (double sum, DokanExpenseRecord item) => sum + item.amount);
  final double changePercent = previousAmount == 0
      ? (totalAmount == 0 ? 0 : 100)
      : ((totalAmount - previousAmount) / previousAmount) * 100;

  return ExpenseSummary(
    totalAmount: totalAmount,
    transactionCount: transactionCount,
    topCategory: topCategoryEntry?.key ?? 'নেই',
    topCategoryAmount: topCategoryEntry?.value ?? 0,
    previousAmount: previousAmount,
    changePercent: changePercent,
  );
});

final expenseCategoryStatsProvider = Provider<List<ExpenseCategoryStat>>((Ref ref) {
  final List<DokanExpenseRecord> records = ref.watch(filteredExpenseRecordsProvider);
  if (records.isEmpty) {
    return const <ExpenseCategoryStat>[];
  }
  final Map<String, double> totals = <String, double>{};
  for (final DokanExpenseRecord item in records) {
    totals.update(item.category, (double value) => value + item.amount, ifAbsent: () => item.amount);
  }
  final double grandTotal = totals.values.fold<double>(0, (double sum, double value) => sum + value);
  return totals.entries.map((MapEntry<String, double> entry) {
    final double percentage = grandTotal == 0 ? 0 : (entry.value / grandTotal) * 100;
    return ExpenseCategoryStat(
      category: entry.key,
      totalAmount: entry.value,
      percentage: percentage,
    );
  }).toList()
    ..sort((ExpenseCategoryStat a, ExpenseCategoryStat b) => b.totalAmount.compareTo(a.totalAmount));
});

final expenseTrendProvider = Provider<List<ExpenseTrendPoint>>((Ref ref) {
  final List<DokanExpenseRecord> records = ref.watch(filteredExpenseRecordsProvider);
  final DokanExpenseTimeFilter filter = ref.watch(expenseTimeFilterProvider);

  if (records.isEmpty) {
    return const <ExpenseTrendPoint>[];
  }

  switch (filter) {
    case DokanExpenseTimeFilter.today:
      return _buildHourlyTrend(records);
    case DokanExpenseTimeFilter.thisWeek:
      return _buildDailyTrend(records, 7);
    case DokanExpenseTimeFilter.thisMonth:
      return _buildDailyTrend(records, 30);
    case DokanExpenseTimeFilter.thisYear:
      return _buildMonthlyTrend(records);
  }
});

bool _matchesTimeFilter(DateTime date, DokanExpenseTimeFilter filter) {
  final DateTime now = DateTime.now();
  switch (filter) {
    case DokanExpenseTimeFilter.today:
      return DateUtils.isSameDay(date, now);
    case DokanExpenseTimeFilter.thisWeek:
      return now.difference(date).inDays >= 0 && now.difference(date).inDays < 7;
    case DokanExpenseTimeFilter.thisMonth:
      return date.year == now.year && date.month == now.month;
    case DokanExpenseTimeFilter.thisYear:
      return date.year == now.year;
  }
}

List<DokanExpenseRecord> _previousPeriodRecords(Ref ref, DokanExpenseTimeFilter filter) {
  final List<DokanExpenseRecord> allRecords = ref.read(expenseReportControllerProvider).asData?.value ?? const <DokanExpenseRecord>[];
  final DateTime now = DateTime.now();

  return allRecords.where((DokanExpenseRecord item) {
    final DateTime date = item.date;
    switch (filter) {
      case DokanExpenseTimeFilter.today:
        return date.day == now.day - 1 && date.month == now.month && date.year == now.year;
      case DokanExpenseTimeFilter.thisWeek:
        return now.difference(date).inDays >= 7 && now.difference(date).inDays < 14;
      case DokanExpenseTimeFilter.thisMonth:
        return date.year == now.year && date.month == now.month - 1;
      case DokanExpenseTimeFilter.thisYear:
        return date.year == now.year - 1;
    }
  }).toList(growable: false);
}

List<ExpenseTrendPoint> _buildHourlyTrend(List<DokanExpenseRecord> records) {
  final Map<int, double> totals = <int, double>{};
  for (final DokanExpenseRecord item in records) {
    totals.update(item.date.hour, (double value) => value + item.amount, ifAbsent: () => item.amount);
  }
  final List<int> hours = totals.keys.toList()..sort();
  return hours
      .map((int hour) => ExpenseTrendPoint(
            label: _hourLabel(hour),
            amount: totals[hour] ?? 0,
          ))
      .toList(growable: false);
}

List<ExpenseTrendPoint> _buildDailyTrend(List<DokanExpenseRecord> records, int days) {
  final DateTime now = DateTime.now();
  final Map<String, double> totals = <String, double>{};
  for (int index = days - 1; index >= 0; index--) {
    final DateTime day = now.subtract(Duration(days: index));
    totals[_dateKey(day)] = 0;
  }
  for (final DokanExpenseRecord item in records) {
    final String key = _dateKey(item.date);
    if (totals.containsKey(key)) {
      totals[key] = (totals[key] ?? 0) + item.amount;
    }
  }
  return totals.entries
      .map((MapEntry<String, double> entry) => ExpenseTrendPoint(
            label: _compactDateLabel(entry.key),
            amount: entry.value,
          ))
      .toList(growable: false);
}

List<ExpenseTrendPoint> _buildMonthlyTrend(List<DokanExpenseRecord> records) {
  final Map<int, double> totals = <int, double>{};
  for (final DokanExpenseRecord item in records) {
    totals.update(item.date.month, (double value) => value + item.amount, ifAbsent: () => item.amount);
  }
  final List<int> months = totals.keys.toList()..sort();
  return months
      .map((int month) => ExpenseTrendPoint(
            label: _monthName(month),
            amount: totals[month] ?? 0,
          ))
      .toList(growable: false);
}

String _hourLabel(int hour) {
  final int normalized = hour % 12 == 0 ? 12 : hour % 12;
  final String suffix = hour >= 12 ? 'PM' : 'AM';
  return '$normalized$suffix';
}

String _dateKey(DateTime date) {
  return '${date.year.toString().padLeft(4, '0')}-${date.month.toString().padLeft(2, '0')}-${date.day.toString().padLeft(2, '0')}';
}

String _compactDateLabel(String key) {
  final List<String> parts = key.split('-');
  if (parts.length != 3) {
    return key;
  }
  final int month = int.tryParse(parts[1]) ?? 1;
  final int day = int.tryParse(parts[2]) ?? 1;
  return '$day/${month.toString().padLeft(2, '0')}';
}

String _monthName(int month) {
  const List<String> names = <String>[
    '',
    'জানু',
    'ফেব',
    'মার্চ',
    'এপ্রি',
    'মে',
    'জুন',
    'জুলা',
    'আগ',
    'সেপ্টে',
    'অক্টো',
    'নভে',
    'ডিসে',
  ];
  return names[month];
}

extension DokanExpenseObjectCompat on Object {
  DokanExpenseRecord? get _asExpense =>
      this is DokanExpenseRecord ? this as DokanExpenseRecord : null;

  String get title => _asExpense?.title ?? '';

  String get name => title;

  String get category => _asExpense?.category ?? '';

  double get amount => _asExpense?.amount ?? 0;

  DateTime get date => _asExpense?.date ?? DateTime.now();

  String get note => _asExpense?.note ?? '';

  String get receiptLabel => _asExpense?.receiptLabel ?? '';

  String get paymentMethodLabel => _asExpense?.paymentMethodLabel ?? '';

  String get statusLabel => _asExpense?.statusLabel ?? '';

  String get dateLabel => _asExpense?.dateLabel ?? '';

  String get amountLabel => '৳${amount.toStringAsFixed(amount.truncateToDouble() == amount ? 0 : 2)}';

  String get displayAmount => amountLabel;

  Color get color => _asExpense?.statusColor ?? const Color(0xFF0E6D4E);

  IconData get icon => _asExpense?.categoryIcon ?? Icons.receipt_long_outlined;
}
