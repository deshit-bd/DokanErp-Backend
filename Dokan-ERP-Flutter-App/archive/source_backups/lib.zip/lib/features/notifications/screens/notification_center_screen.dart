import 'package:flutter/material.dart';

import '../../dashboard/screens/dashboard_screen.dart';
import '../../pos/screens/pos_screens.dart';
import '../../products/screens/product_screens.dart';
import '../../reports/screens/reports_screens.dart';
import '../../settings/screens/settings_screens.dart';

final _DokanNotificationStore _dokanNotificationStore = _DokanNotificationStore();
final _DokanNotificationPreferences _dokanNotificationPreferences = _DokanNotificationPreferences();

int get dokanNotificationUnreadCount => _dokanNotificationStore.unreadCount;

Listenable get dokanNotificationListenable => _dokanNotificationStore;

Future<void> showDokanNotificationPreviewSheet(BuildContext context) {
  return showModalBottomSheet<void>(
    context: context,
    backgroundColor: Colors.transparent,
    isScrollControlled: true,
    builder: (sheetContext) {
      return _NotificationPreviewSheet(
        onSeeAll: () {
          Navigator.of(sheetContext).pop();
          Navigator.of(context).push(
            MaterialPageRoute(
              builder: (_) => const DokanNotificationCenterScreen(),
            ),
          );
        },
      );
    },
  );
}

class _DokanNotificationStore extends ChangeNotifier {
  _DokanNotificationStore()
      : _groups = [
          _NotificationGroup(
            title: 'সাম্প্রতিক',
            style: _SectionStyle.primary,
            items: [
              _NotificationEntry(
                title: 'কম স্টক সতর্কতা',
                subtitle: 'একটি পণ্যের স্টক নির্ধারিত সীমার নিচে নেমে গেছে।',
                timeLabel: '২ মিনিট আগে',
                icon: Icons.warning_amber_rounded,
                iconBackground: Color(0xFFFFF0C2),
                iconColor: Color(0xFFD97706),
                unread: true,
                accent: Color(0xFF00694C),
                category: _NotificationCategory.inventory,
              ),
              _NotificationEntry(
                title: 'নতুন বিক্রয় হয়েছে',
                subtitle: 'আপনার দোকানে একটি নতুন বিক্রয় সম্পন্ন হয়েছে।',
                timeLabel: '১০ মিনিট আগে',
                icon: Icons.check_circle_rounded,
                iconBackground: Color(0xFFD1FAE5),
                iconColor: Color(0xFF059669),
                unread: true,
                accent: Color(0xFF00694C),
                category: _NotificationCategory.sale,
              ),
              _NotificationEntry(
                title: 'নতুন গ্রাহক যুক্ত হয়েছে',
                subtitle: 'একজন নতুন গ্রাহক আপনার কাস্টমার তালিকায় যোগ হয়েছে।',
                timeLabel: '২৫ মিনিট আগে',
                icon: Icons.person_add_alt_1_rounded,
                iconBackground: Color(0xFFE8F1FF),
                iconColor: Color(0xFF2563EB),
                unread: true,
                accent: Color(0xFF0E7B58),
                category: _NotificationCategory.general,
              ),
            ],
          ),
          _NotificationGroup(
            title: 'পুরোনো',
            style: _SectionStyle.secondary,
            items: [
              _NotificationEntry(
                title: 'পেমেন্ট গ্রহণ হয়েছে',
                subtitle: 'একটি ইনভয়েসের পেমেন্ট সফলভাবে গ্রহণ করা হয়েছে।',
                timeLabel: 'গতকাল',
                icon: Icons.credit_card_rounded,
                iconBackground: Color(0xFFDCEBFF),
                iconColor: Color(0xFF2563EB),
                unread: false,
                accent: Color(0xFF2563EB),
                category: _NotificationCategory.sale,
              ),
              _NotificationEntry(
                title: 'স্টক আপডেট হয়েছে',
                subtitle: 'একটি পণ্যের স্টক তথ্য সফলভাবে আপডেট করা হয়েছে।',
                timeLabel: 'গতকাল',
                icon: Icons.inventory_2_rounded,
                iconBackground: Color(0xFFF2E7FE),
                iconColor: Color(0xFF9333EA),
                unread: false,
                accent: Color(0xFF9333EA),
                category: _NotificationCategory.inventory,
              ),
              _NotificationEntry(
                title: 'সাপ্তাহিক রিপোর্ট প্রস্তুত',
                subtitle: 'আপনার সাপ্তাহিক বিক্রয় রিপোর্ট প্রস্তুত হয়েছে।',
                timeLabel: 'গতকাল',
                icon: Icons.assessment_rounded,
                iconBackground: Color(0xFFE2F3E8),
                iconColor: Color(0xFF0E7B58),
                unread: false,
                accent: Color(0xFF0E7B58),
                category: _NotificationCategory.report,
              ),
            ],
          ),
        ];

  final List<_NotificationGroup> _groups;

  List<_NotificationGroup> get groups => _groups;

  int get unreadCount {
    return _groups.expand((group) => group.items).where((item) => item.unread).length;
  }

  List<_NotificationEntry> previewEntries({int limit = 8}) {
    return _groups.expand((group) => group.items).take(limit).toList(growable: false);
  }

  void markAsRead(_NotificationEntry target) {
    var changed = false;
    for (final group in _groups) {
      for (var i = 0; i < group.items.length; i++) {
        final item = group.items[i];
        if (identical(item, target) && item.unread) {
          group.items[i] = item.copyWith(unread: false);
          changed = true;
        }
      }
    }
    if (changed) {
      notifyListeners();
    }
  }

  void markAllAsRead() {
    var changed = false;
    for (final group in _groups) {
      for (var i = 0; i < group.items.length; i++) {
        final item = group.items[i];
        if (item.unread) {
          group.items[i] = item.copyWith(unread: false);
          changed = true;
        }
      }
    }
    if (changed) {
      notifyListeners();
    }
  }
}

class DokanNotificationCenterScreen extends StatefulWidget {
  const DokanNotificationCenterScreen({super.key});

  @override
  State<DokanNotificationCenterScreen> createState() => _DokanNotificationCenterScreenState();
}

class _DokanNotificationCenterScreenState extends State<DokanNotificationCenterScreen> {
  List<_NotificationGroup> get _groups => _dokanNotificationStore.groups;

  final List<_FilterChipData> _filters = const [
    _FilterChipData(label: 'সব', selected: true, category: _NotificationCategory.all),
    _FilterChipData(label: 'অপঠিত', selected: false, category: _NotificationCategory.unread),
    _FilterChipData(label: 'বিক্রয়', selected: false, category: _NotificationCategory.sale),
    _FilterChipData(label: 'স্টক', selected: false, category: _NotificationCategory.inventory),
    _FilterChipData(label: 'রিপোর্ট', selected: false, category: _NotificationCategory.report),
  ];

  int _selectedFilterIndex = 0;
  final _DokanNotificationPreferences _prefs = _dokanNotificationPreferences;

  @override
  Widget build(BuildContext context) {
    final bottomPadding = MediaQuery.of(context).padding.bottom;

    return Scaffold(
      backgroundColor: const Color(0xFFF7FBFA),
      body: SafeArea(
        bottom: false,
        child: Column(
          children: [
            _HeaderBar(
              onBack: () => Navigator.of(context).pop(),
              onMarkAllRead: _markAllAsRead,
            ),
            _FilterStrip(
              selectedIndex: _selectedFilterIndex,
              filters: _filters,
              onSelected: (index) {
                setState(() {
                  _selectedFilterIndex = index;
                });
              },
            ),
            Expanded(
              child: SingleChildScrollView(
                physics: const AlwaysScrollableScrollPhysics(parent: BouncingScrollPhysics()),
                keyboardDismissBehavior: ScrollViewKeyboardDismissBehavior.onDrag,
                padding: const EdgeInsets.fromLTRB(20, 16, 20, 24),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    for (final group in _visibleGroups()) ...[
                      _NotificationGroupView(
                        group: group,
                        onItemTap: (item) => _openNotification(context, item),
                      ),
                      const SizedBox(height: 16),
                    ],
                    _UpdatePromoCard(
                      onTap: () => _showInfoSheet(
                        context,
                        title: 'নতুন আপডেট!',
                        message: 'এখন আরও দ্রুত নোটিফিকেশন দেখা, পড়া এবং ফিল্টার করা যাবে।',
                      ),
                    ),
                    const SizedBox(height: 16),
                    _NotificationPreferencesCard(
                      prefs: _prefs,
                      onChanged: () => setState(() {}),
                    ),
                    const SizedBox(height: 16),
                  ],
                ),
              ),
            ),
            _BottomNavBar(
              onHomeTap: () => Navigator.of(context).pushReplacement(
                MaterialPageRoute(
                  builder: (_) => const DokanHomeDashboardScreen(),
                ),
              ),
              onSalesTap: () => Navigator.of(context).pushReplacement(
                MaterialPageRoute(
                  builder: (_) => DokanPosMainScreen(key: UniqueKey()),
                ),
              ),
              onProductsTap: () => Navigator.of(context).pushReplacement(
                MaterialPageRoute(
                  builder: (_) => const DokanProductListScreen(),
                ),
              ),
              onReportsTap: () => Navigator.of(context).pushReplacement(
                MaterialPageRoute(
                  builder: (_) => const DokanReportsHomeScreen(),
                ),
              ),
              onMoreTap: () => Navigator.of(context).pushReplacement(
                MaterialPageRoute(
                  builder: (_) => const DokanAroOptionScreen(),
                ),
              ),
              bottomPadding: bottomPadding,
            ),
          ],
        ),
      ),
    );
  }

  List<_NotificationGroup> _visibleGroups() {
    final selectedCategory = _filters[_selectedFilterIndex].category;

    if (selectedCategory == _NotificationCategory.unread) {
      return _groups
          .map(
            (group) => _NotificationGroup(
              title: group.title,
              style: group.style,
              items: group.items.where((item) => item.unread).toList(),
            ),
          )
          .where((group) => group.items.isNotEmpty)
          .toList();
    }
    if (selectedCategory != _NotificationCategory.all) {
      return _groups
          .map(
            (group) => _NotificationGroup(
              title: group.title,
              style: group.style,
              items: group.items.where((item) => item.category == selectedCategory).toList(),
            ),
          )
          .where((group) => group.items.isNotEmpty)
          .toList();
    }
    return _groups;
  }

  void _markAllAsRead() {
    _dokanNotificationStore.markAllAsRead();
    setState(() {});

    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('সব নোটিফিকেশন পড়া হয়েছে'),
        behavior: SnackBarBehavior.floating,
      ),
    );
  }

  void _openNotification(BuildContext context, _NotificationEntry item) {
    _dokanNotificationStore.markAsRead(item);
    setState(() {});
    showModalBottomSheet<void>(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (context) {
        return _NotificationDetailSheet(
          title: item.title,
          subtitle: item.subtitle,
          timeLabel: item.timeLabel,
          accent: item.accent,
          icon: item.icon,
        );
      },
    );
  }

  void _showInfoSheet(
    BuildContext context, {
    required String title,
    required String message,
  }) {
    showModalBottomSheet<void>(
      context: context,
      backgroundColor: Colors.transparent,
      builder: (context) {
        return _InfoSheet(title: title, message: message);
      },
    );
  }
}

class _HeaderBar extends StatelessWidget {
  const _HeaderBar({
    required this.onBack,
    required this.onMarkAllRead,
  });

  final VoidCallback onBack;
  final VoidCallback onMarkAllRead;

  @override
  Widget build(BuildContext context) {
    return Container(
      color: Colors.white,
      padding: const EdgeInsets.fromLTRB(16, 10, 16, 18),
      child: Row(
        children: [
          _TopActionIcon(
            icon: Icons.arrow_back_rounded,
            onTap: onBack,
          ),
          const SizedBox(width: 8),
          const Expanded(
            child: Center(
              child: Text(
                'নোটিফিকেশন',
                style: TextStyle(
                  color: Color(0xFF00694C),
                  fontSize: 26,
                  height: 1,
                  fontWeight: FontWeight.w800,
                ),
              ),
            ),
          ),
          TextButton(
            onPressed: onMarkAllRead,
            style: TextButton.styleFrom(
              foregroundColor: const Color(0xFF00694C),
              padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 8),
              minimumSize: Size.zero,
              tapTargetSize: MaterialTapTargetSize.shrinkWrap,
            ),
            child: const Text(
              'সব পড়া হয়েছে',
              style: TextStyle(
                fontSize: 15,
                fontWeight: FontWeight.w600,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _FilterStrip extends StatelessWidget {
  const _FilterStrip({
    required this.filters,
    required this.selectedIndex,
    required this.onSelected,
  });

  final List<_FilterChipData> filters;
  final int selectedIndex;
  final ValueChanged<int> onSelected;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      color: const Color(0xFFF1FBFF),
      padding: const EdgeInsets.fromLTRB(16, 24, 16, 16),
      child: SingleChildScrollView(
        scrollDirection: Axis.horizontal,
        physics: const BouncingScrollPhysics(),
        child: Row(
          children: [
            for (var i = 0; i < filters.length; i++) ...[
              _FilterChip(
                label: filters[i].label,
                selected: i == selectedIndex,
                onTap: () => onSelected(i),
              ),
              if (i != filters.length - 1) const SizedBox(width: 12),
            ],
          ],
        ),
      ),
    );
  }
}

class _NotificationGroupView extends StatelessWidget {
  const _NotificationGroupView({
    required this.group,
    required this.onItemTap,
  });

  final _NotificationGroup group;
  final ValueChanged<_NotificationEntry> onItemTap;

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Padding(
          padding: const EdgeInsets.only(bottom: 8),
          child: Text(
            group.title,
            style: TextStyle(
              color: group.style.headingColor,
              fontSize: 12,
              fontWeight: FontWeight.w700,
              letterSpacing: 0.8,
              height: 1,
            ),
          ),
        ),
        if (group.style == _SectionStyle.primary)
          _PrimaryNotificationPanel(
            items: group.items,
            onItemTap: onItemTap,
          )
        else
          _SecondaryNotificationList(
            items: group.items,
            onItemTap: onItemTap,
          ),
      ],
    );
  }
}

class _PrimaryNotificationPanel extends StatelessWidget {
  const _PrimaryNotificationPanel({
    required this.items,
    required this.onItemTap,
  });

  final List<_NotificationEntry> items;
  final ValueChanged<_NotificationEntry> onItemTap;

  @override
  Widget build(BuildContext context) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(2),
      child: Container(
        decoration: const BoxDecoration(
          color: Color(0xFFF4FAF7),
          border: Border(
            left: BorderSide(color: Color(0xFF00694C), width: 3),
          ),
        ),
        child: Column(
          children: [
            for (var i = 0; i < items.length; i++) ...[
              _NotificationRow(
                item: items[i],
                style: _RowStyle.primary,
                onTap: () => onItemTap(items[i]),
              ),
              if (i != items.length - 1)
                const Divider(height: 1, thickness: 1, color: Color(0xFF131D21)),
            ],
          ],
        ),
      ),
    );
  }
}

class _SecondaryNotificationList extends StatelessWidget {
  const _SecondaryNotificationList({
    required this.items,
    required this.onItemTap,
  });

  final List<_NotificationEntry> items;
  final ValueChanged<_NotificationEntry> onItemTap;

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        for (var i = 0; i < items.length; i++) ...[
          _NotificationRow(
            item: items[i],
            style: _RowStyle.secondary,
            onTap: () => onItemTap(items[i]),
          ),
          if (i != items.length - 1)
            const Padding(
              padding: EdgeInsets.symmetric(vertical: 14),
              child: Divider(height: 1, thickness: 1, color: Color(0xFFB7C7BF)),
            ),
        ],
      ],
    );
  }
}

class _NotificationRow extends StatelessWidget {
  const _NotificationRow({
    required this.item,
    required this.style,
    required this.onTap,
  });

  final _NotificationEntry item;
  final _RowStyle style;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: onTap,
        child: Container(
          padding: const EdgeInsets.all(16),
          color: style.backgroundColor,
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                width: 40,
                height: 40,
                decoration: BoxDecoration(
                  color: item.iconBackground,
                  shape: BoxShape.circle,
                ),
                child: Icon(item.icon, color: item.iconColor, size: 24),
              ),
              const SizedBox(width: 16),
              Expanded(
                child: Padding(
                  padding: const EdgeInsets.only(top: 1),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        item.title,
                        style: TextStyle(
                          color: style.titleColor,
                          fontSize: 16,
                          fontWeight: item.unread ? FontWeight.w700 : FontWeight.w500,
                          height: 1.2,
                        ),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        item.subtitle,
                        style: TextStyle(
                          color: style.subtitleColor,
                          fontSize: 14,
                          height: 1.4,
                          fontWeight: FontWeight.w400,
                        ),
                      ),
                      const SizedBox(height: 8),
                      Text(
                        item.timeLabel,
                        style: TextStyle(
                          color: style.timeColor,
                          fontSize: 12,
                          height: 1.2,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              if (item.unread)
                Padding(
                  padding: const EdgeInsets.only(left: 12, top: 12),
                  child: Container(
                    width: 8,
                    height: 8,
                    decoration: BoxDecoration(
                      color: item.accent,
                      shape: BoxShape.circle,
                    ),
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }
}

class _UpdatePromoCard extends StatelessWidget {
  const _UpdatePromoCard({required this.onTap});

  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(22),
        child: Container(
          constraints: const BoxConstraints(minHeight: 246),
          decoration: BoxDecoration(
            gradient: const LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [Color(0xFF0B9A74), Color(0xFF0A7E5F)],
            ),
            borderRadius: BorderRadius.circular(22),
            boxShadow: const [
              BoxShadow(
                color: Color(0x33000000),
                blurRadius: 30,
                offset: Offset(0, 16),
              ),
            ],
          ),
          child: Stack(
            children: [
              Positioned(
                right: -4,
                bottom: -6,
                child: Icon(
                  Icons.workspace_premium_rounded,
                  size: 150,
                  color: Colors.white.withValues(alpha: 0.10),
                ),
              ),
              Positioned(
                right: 24,
                top: 22,
                child: Container(
                  width: 92,
                  height: 92,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    border: Border.all(
                      color: Colors.white.withValues(alpha: 0.10),
                      width: 2,
                    ),
                  ),
                ),
              ),
              Padding(
                padding: const EdgeInsets.fromLTRB(28, 28, 28, 28),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const SizedBox(height: 18),
                    const Text(
                      'নতুন আপডেট!',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 26,
                        height: 1.1,
                        fontWeight: FontWeight.w800,
                      ),
                    ),
                    const SizedBox(height: 14),
                    const SizedBox(
                      width: 252,
                      child: Text(
                        'এখন আরও দ্রুত নোটিফিকেশন দেখা, পড়া এবং ফিল্টার করা যাবে।',
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 17,
                          height: 1.35,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                    ),
                    const SizedBox(height: 22),
                    Align(
                      alignment: Alignment.centerLeft,
                      child: ElevatedButton(
                        onPressed: onTap,
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.white,
                          foregroundColor: const Color(0xFF005B44),
                          elevation: 0,
                          padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 14),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(16),
                          ),
                        ),
                        child: const Text(
                          'এখন দেখুন',
                          style: TextStyle(
                            fontSize: 17,
                            fontWeight: FontWeight.w800,
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _BottomNavBar extends StatelessWidget {
  const _BottomNavBar({
    required this.onHomeTap,
    required this.onSalesTap,
    required this.onProductsTap,
    required this.onReportsTap,
    required this.onMoreTap,
    required this.bottomPadding,
  });

  final VoidCallback onHomeTap;
  final VoidCallback onSalesTap;
  final VoidCallback onProductsTap;
  final VoidCallback onReportsTap;
  final VoidCallback onMoreTap;
  final double bottomPadding;

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: const BoxDecoration(
        color: Color(0xFFF2F8FB),
        border: Border(top: BorderSide(color: Color(0xFFD8E3E0))),
      ),
      padding: EdgeInsets.fromLTRB(12, 10, 12, 8 + bottomPadding),
      child: Row(
        children: [
          _BottomNavItem(
            icon: Icons.home_outlined,
            label: 'হোম',
            onTap: onHomeTap,
            selected: false,
          ),
          _BottomNavItem(
            icon: Icons.point_of_sale_outlined,
            label: 'বিক্রয়',
            onTap: onSalesTap,
          ),
          _BottomNavItem(
            icon: Icons.inventory_2_outlined,
            label: 'পণ্য',
            onTap: onProductsTap,
          ),
          _BottomNavItem(
            icon: Icons.insert_chart_outlined,
            label: 'রিপোর্ট',
            onTap: onReportsTap,
          ),
          _BottomNavItem(
            icon: Icons.more_horiz_rounded,
            label: 'আরও',
            onTap: onMoreTap,
          ),
        ],
      ),
    );
  }
}

class _BottomNavItem extends StatelessWidget {
  const _BottomNavItem({
    required this.icon,
    required this.label,
    required this.onTap,
    this.selected = false,
  });

  final IconData icon;
  final String label;
  final VoidCallback onTap;
  final bool selected;

  @override
  Widget build(BuildContext context) {
    final color = selected ? const Color(0xFF00694C) : const Color(0xFF4C5D57);

    return Expanded(
      child: Material(
        color: Colors.transparent,
        child: InkResponse(
          onTap: onTap,
          radius: 28,
          child: Padding(
            padding: const EdgeInsets.symmetric(vertical: 2),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(icon, color: color, size: 30),
                const SizedBox(height: 2),
                Text(
                  label,
                  style: TextStyle(
                    color: color,
                    fontSize: 14,
                    height: 1.0,
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _TopActionIcon extends StatelessWidget {
  const _TopActionIcon({
    required this.icon,
    required this.onTap,
  });

  final IconData icon;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.transparent,
      child: InkResponse(
        onTap: onTap,
        radius: 24,
        child: SizedBox(
          width: 40,
          height: 40,
          child: Icon(icon, color: const Color(0xFF1D2624), size: 31),
        ),
      ),
    );
  }
}

class _FilterChip extends StatelessWidget {
  const _FilterChip({
    required this.label,
    required this.selected,
    required this.onTap,
  });

  final String label;
  final bool selected;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final background = selected ? const Color(0xFF00694C) : const Color(0xFFDAE1E3);
    final foreground = selected ? Colors.white : const Color(0xFF5D6466);

    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(9999),
        child: Container(
          constraints: const BoxConstraints(minWidth: 55, minHeight: 32),
          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 8),
          decoration: BoxDecoration(
            color: background,
            borderRadius: BorderRadius.circular(9999),
            boxShadow: const [
              BoxShadow(
                color: Color(0x14000000),
                blurRadius: 2,
                offset: Offset(0, 1),
              ),
            ],
          ),
          alignment: Alignment.center,
          child: Text(
            label,
            style: TextStyle(
              color: foreground,
              fontSize: 12,
              height: 1.33,
              fontWeight: FontWeight.w600,
              letterSpacing: 0.6,
            ),
          ),
        ),
      ),
    );
  }
}

class _NotificationPreviewSheet extends StatelessWidget {
  const _NotificationPreviewSheet({
    required this.onSeeAll,
  });

  final VoidCallback onSeeAll;

  @override
  Widget build(BuildContext context) {
    return DraggableScrollableSheet(
      initialChildSize: 0.5,
      minChildSize: 0.34,
      maxChildSize: 0.8,
      builder: (context, scrollController) {
        return Container(
          decoration: const BoxDecoration(
            color: Color(0xFFF7FBFA),
            borderRadius: BorderRadius.vertical(top: Radius.circular(28)),
          ),
          child: SafeArea(
            top: false,
            child: ListView(
              controller: scrollController,
              padding: const EdgeInsets.fromLTRB(16, 10, 16, 20),
              children: [
                Center(
                  child: Container(
                    width: 42,
                    height: 4,
                    decoration: BoxDecoration(
                      color: const Color(0xFFD6E3E4),
                      borderRadius: BorderRadius.circular(999),
                    ),
                  ),
                ),
                const SizedBox(height: 14),
                Row(
                  children: [
                    const Expanded(
                      child: Text(
                        'সাম্প্রতিক নোটিফিকেশন',
                        style: TextStyle(
                          color: Color(0xFF17312B),
                          fontSize: 18,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                    ),
                    TextButton(
                      onPressed: onSeeAll,
                      style: TextButton.styleFrom(
                        foregroundColor: const Color(0xFF0E7B58),
                        padding: EdgeInsets.zero,
                        minimumSize: Size.zero,
                        tapTargetSize: MaterialTapTargetSize.shrinkWrap,
                      ),
                      child: const Text(
                        'সব দেখুন',
                        style: TextStyle(fontSize: 14, fontWeight: FontWeight.w600),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 12),
                AnimatedBuilder(
                  animation: _dokanNotificationStore,
                  builder: (context, _) {
                    final notifications = _dokanNotificationStore.previewEntries(limit: 8);
                    if (notifications.isEmpty) {
                      return Container(
                        padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 26),
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(20),
                          border: Border.all(color: const Color(0xFFE3EAEA)),
                        ),
                        child: const Text(
                          'এখনো কোনো নোটিফিকেশন নেই',
                          textAlign: TextAlign.center,
                          style: TextStyle(
                            color: Color(0xFF6B7D78),
                            fontSize: 14,
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                      );
                    }
                    return Column(
                      children: [
                        for (final item in notifications) ...[
                          _NotificationPreviewTile(
                            entry: item,
                            onTap: () => _dokanNotificationStore.markAsRead(item),
                          ),
                          const SizedBox(height: 10),
                        ],
                      ],
                    );
                  },
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}

class _NotificationPreviewTile extends StatelessWidget {
  const _NotificationPreviewTile({
    required this.entry,
    required this.onTap,
  });

  final _NotificationEntry entry;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(18),
        child: Container(
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(18),
            border: Border.all(color: const Color(0xFFE3EAEA)),
          ),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                width: 42,
                height: 42,
                decoration: BoxDecoration(
                  color: entry.iconBackground,
                  shape: BoxShape.circle,
                ),
                child: Icon(entry.icon, color: entry.iconColor, size: 22),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Expanded(
                        child: Text(
                          entry.title,
                          style: TextStyle(
                            color: const Color(0xFF17312B),
                            fontSize: 15,
                            fontWeight: entry.unread ? FontWeight.w700 : FontWeight.w500,
                          ),
                        ),
                        ),
                        if (entry.unread)
                          Container(
                            width: 8,
                            height: 8,
                            decoration: const BoxDecoration(
                              color: Color(0xFF0E7B58),
                              shape: BoxShape.circle,
                            ),
                          ),
                      ],
                    ),
                    const SizedBox(height: 4),
                    Text(
                      entry.subtitle,
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                        color: Color(0xFF5C6C68),
                        fontSize: 13,
                        height: 1.35,
                      ),
                    ),
                    const SizedBox(height: 6),
                    Text(
                      entry.timeLabel,
                      style: const TextStyle(
                        color: Color(0xFF8A9A96),
                        fontSize: 12,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _NotificationDetailSheet extends StatelessWidget {
  const _NotificationDetailSheet({
    required this.title,
    required this.subtitle,
    required this.timeLabel,
    required this.accent,
    required this.icon,
  });

  final String title;
  final String subtitle;
  final String timeLabel;
  final Color accent;
  final IconData icon;

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: const BoxDecoration(
        color: Color(0xFFF5FAF7),
        borderRadius: BorderRadius.vertical(top: Radius.circular(28)),
      ),
      padding: EdgeInsets.fromLTRB(
        20,
        18,
        20,
        20 + MediaQuery.of(context).padding.bottom,
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Center(
            child: Container(
              width: 48,
              height: 5,
              decoration: BoxDecoration(
                color: const Color(0xFFD9E3DF),
                borderRadius: BorderRadius.circular(999),
              ),
            ),
          ),
          const SizedBox(height: 18),
          Row(
            children: [
              Container(
                width: 50,
                height: 50,
                decoration: BoxDecoration(
                  color: accent.withValues(alpha: 0.12),
                  shape: BoxShape.circle,
                ),
                child: Icon(icon, color: accent, size: 28),
              ),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      title,
                      style: const TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.w800,
                        color: Color(0xFF131D21),
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      timeLabel,
                      style: const TextStyle(
                        fontSize: 12,
                        color: Color(0xFF6D7A73),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          Text(
            subtitle,
            style: const TextStyle(
              fontSize: 15,
              height: 1.55,
              color: Color(0xFF3D4943),
            ),
          ),
          const SizedBox(height: 20),
          Row(
            children: [
              Expanded(
                child: ElevatedButton(
                  onPressed: () => Navigator.of(context).pop(),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: accent,
                    foregroundColor: Colors.white,
                    padding: const EdgeInsets.symmetric(vertical: 14),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(14),
                    ),
                  ),
                  child: const Text(
                    'এখানে এখনো কোনো নোটিফিকেশন নেই',
                    style: TextStyle(fontSize: 15, fontWeight: FontWeight.w700),
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class _InfoSheet extends StatelessWidget {
  const _InfoSheet({
    required this.title,
    required this.message,
  });

  final String title;
  final String message;

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: const BoxDecoration(
        color: Color(0xFFF5FAF7),
        borderRadius: BorderRadius.vertical(top: Radius.circular(28)),
      ),
      padding: EdgeInsets.fromLTRB(
        20,
        18,
        20,
        20 + MediaQuery.of(context).padding.bottom,
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Center(
            child: Container(
              width: 48,
              height: 5,
              decoration: BoxDecoration(
                color: const Color(0xFFD9E3DF),
                borderRadius: BorderRadius.circular(999),
              ),
            ),
          ),
          const SizedBox(height: 18),
          Text(
            title,
            style: const TextStyle(
              fontSize: 22,
              fontWeight: FontWeight.w800,
              color: Color(0xFF131D21),
            ),
          ),
          const SizedBox(height: 10),
          Text(
            message,
            style: const TextStyle(
              fontSize: 15,
              height: 1.55,
              color: Color(0xFF3D4943),
            ),
          ),
          const SizedBox(height: 20),
          ElevatedButton(
            onPressed: () => Navigator.of(context).pop(),
            style: ElevatedButton.styleFrom(
              backgroundColor: const Color(0xFF00694C),
              foregroundColor: Colors.white,
              padding: const EdgeInsets.symmetric(vertical: 14),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(14),
              ),
            ),
            child: const Text(
              'ঠিক আছে',
              style: TextStyle(fontSize: 15, fontWeight: FontWeight.w700),
            ),
          ),
        ],
      ),
    );
  }
}

class _NotificationPreferencesCard extends StatelessWidget {
  const _NotificationPreferencesCard({
    required this.prefs,
    required this.onChanged,
  });

  final _DokanNotificationPreferences prefs;
  final VoidCallback onChanged;

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(22),
        border: Border.all(color: const Color(0xFFE0E9E4)),
        boxShadow: const [
          BoxShadow(
            color: Color(0x0C000000),
            blurRadius: 18,
            offset: Offset(0, 8),
          ),
        ],
      ),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'নোটিফিকেশন সেটিংস',
              style: TextStyle(
                color: Color(0xFF131D21),
                fontSize: 17,
                fontWeight: FontWeight.w800,
              ),
            ),
            const SizedBox(height: 8),
            const Text(
              'আপনার পছন্দমতো সতর্কতা নিয়ন্ত্রণ করুন',
              style: TextStyle(
                color: Color(0xFF5F6E68),
                fontSize: 12.5,
                height: 1.35,
              ),
            ),
            const SizedBox(height: 12),
            _PreferenceToggleRow(
              label: 'কম স্টক হলে সতর্ক করুন',
              value: prefs.lowStockAlert,
              onChanged: (value) {
                prefs.lowStockAlert = value;
                onChanged();
              },
            ),
            _PreferenceToggleRow(
              label: 'নতুন বিক্রয়',
              value: prefs.newSale,
              onChanged: (value) {
                prefs.newSale = value;
                onChanged();
              },
            ),
            _PreferenceToggleRow(
              label: 'নতুন গ্রাহক',
              value: prefs.newCustomer,
              onChanged: (value) {
                prefs.newCustomer = value;
                onChanged();
              },
            ),
            _PreferenceToggleRow(
              label: 'পেমেন্ট গ্রহণ',
              value: prefs.paymentReceived,
              onChanged: (value) {
                prefs.paymentReceived = value;
                onChanged();
              },
            ),
            _PreferenceToggleRow(
              label: 'দৈনিক রিপোর্ট',
              value: prefs.dailyReport,
              onChanged: (value) {
                prefs.dailyReport = value;
                onChanged();
              },
            ),
            _PreferenceToggleRow(
              label: 'সাপ্তাহিক রিপোর্ট',
              value: prefs.weeklyReport,
              onChanged: (value) {
                prefs.weeklyReport = value;
                onChanged();
              },
            ),
            _PreferenceToggleRow(
              label: 'স্টাফ কার্যক্রম',
              value: prefs.staffActivity,
              onChanged: (value) {
                prefs.staffActivity = value;
                onChanged();
              },
            ),
            _PreferenceToggleRow(
              label: 'সিস্টেম আপডেট',
              value: prefs.systemUpdate,
              onChanged: (value) {
                prefs.systemUpdate = value;
                onChanged();
              },
            ),
            const SizedBox(height: 16),
            const Text(
              'শব্দ সেটিংস',
              style: TextStyle(
                color: Color(0xFF131D21),
                fontSize: 15,
                fontWeight: FontWeight.w800,
              ),
            ),
            const SizedBox(height: 12),
            _PreferenceToggleRow(
              label: 'সাউন্ড',
              value: prefs.sound,
              onChanged: (value) {
                prefs.sound = value;
                onChanged();
              },
            ),
            _PreferenceToggleRow(
              label: 'ভাইব্রেশন',
              value: prefs.vibration,
              onChanged: (value) {
                prefs.vibration = value;
                onChanged();
              },
            ),
            _PreferenceToggleRow(
              label: 'পুশ নোটিফিকেশন',
              value: prefs.pushNotification,
              onChanged: (value) {
                prefs.pushNotification = value;
                onChanged();
              },
            ),
            _PreferenceToggleRow(
              label: 'ইমেইল',
              value: prefs.email,
              onChanged: (value) {
                prefs.email = value;
                onChanged();
              },
            ),
            _PreferenceToggleRow(
              label: 'এসএমএস',
              value: prefs.sms,
              onChanged: (value) {
                prefs.sms = value;
                onChanged();
              },
            ),
          ],
        ),
      ),
    );
  }
}

class _PreferenceToggleRow extends StatelessWidget {
  const _PreferenceToggleRow({
    required this.label,
    required this.value,
    required this.onChanged,
  });

  final String label;
  final bool value;
  final ValueChanged<bool> onChanged;

  @override
  Widget build(BuildContext context) {
    return SwitchListTile.adaptive(
      value: value,
      onChanged: onChanged,
      contentPadding: EdgeInsets.zero,
      dense: true,
      activeThumbColor: const Color(0xFF00694C),
      title: Text(
        label,
        style: const TextStyle(
          color: Color(0xFF131D21),
          fontSize: 14,
          fontWeight: FontWeight.w600,
        ),
      ),
    );
  }
}

class _DokanNotificationPreferences {
  bool lowStockAlert = true;
  bool newSale = true;
  bool newCustomer = true;
  bool paymentReceived = true;
  bool dailyReport = false;
  bool weeklyReport = false;
  bool staffActivity = true;
  bool systemUpdate = true;
  bool sound = true;
  bool vibration = true;
  bool pushNotification = true;
  bool email = false;
  bool sms = false;

  int get unreadCount => 3;
}

class _FilterChipData {
  const _FilterChipData({
    required this.label,
    required this.selected,
    required this.category,
  });

  final String label;
  final bool selected;
  final _NotificationCategory category;
}

class _NotificationGroup {
  _NotificationGroup({
    required this.title,
    required this.style,
    required this.items,
  });

  final String title;
  final _SectionStyle style;
  final List<_NotificationEntry> items;
}

class _NotificationEntry {
  _NotificationEntry({
    required this.title,
    required this.subtitle,
    required this.timeLabel,
    required this.icon,
    required this.iconBackground,
    required this.iconColor,
    required this.unread,
    required this.accent,
    required this.category,
  });

  final String title;
  final String subtitle;
  final String timeLabel;
  final IconData icon;
  final Color iconBackground;
  final Color iconColor;
  final bool unread;
  final Color accent;
  final _NotificationCategory category;

  _NotificationEntry copyWith({
    String? title,
    String? subtitle,
    String? timeLabel,
    IconData? icon,
    Color? iconBackground,
    Color? iconColor,
    bool? unread,
    Color? accent,
    _NotificationCategory? category,
  }) {
    return _NotificationEntry(
      title: title ?? this.title,
      subtitle: subtitle ?? this.subtitle,
      timeLabel: timeLabel ?? this.timeLabel,
      icon: icon ?? this.icon,
      iconBackground: iconBackground ?? this.iconBackground,
      iconColor: iconColor ?? this.iconColor,
      unread: unread ?? this.unread,
      accent: accent ?? this.accent,
      category: category ?? this.category,
    );
  }
}

enum _NotificationCategory {
  all,
  unread,
  sale,
  inventory,
  report,
  general,
}

enum _SectionStyle {
  primary,
  secondary;

  Color get headingColor => this == primary ? const Color(0xFF3D4943) : const Color(0xFF3D4943);
}

class _RowStyle {
  const _RowStyle({
    required this.backgroundColor,
    required this.titleColor,
    required this.subtitleColor,
    required this.timeColor,
    required this.titleWeight,
  });

  final Color backgroundColor;
  final Color titleColor;
  final Color subtitleColor;
  final Color timeColor;
  final FontWeight titleWeight;

  static const primary = _RowStyle(
    backgroundColor: Color(0xFFF4FAF7),
    titleColor: Color(0xFF131D21),
    subtitleColor: Color(0xFF3D4943),
    timeColor: Color(0xFF6D7A73),
    titleWeight: FontWeight.w400,
  );

  static const secondary = _RowStyle(
    backgroundColor: Colors.transparent,
    titleColor: Color(0xFF131D21),
    subtitleColor: Color(0xFF3D4943),
    timeColor: Color(0xFF6D7A73),
    titleWeight: FontWeight.w700,
  );
}

