// ignore_for_file: unused_element, unused_element_parameter

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../app/dokan_app_providers.dart';
import '../../pos/state/pos_checkout_provider.dart';

bool _isElevenDigitPhone(String value) => RegExp(r'^\d{11}$').hasMatch(value);

bool _isFourDigitCode(String value) => RegExp(r'^\d{4}$').hasMatch(value);

bool _isPasswordValid(String value) => value.trim().length >= 4;

void _showWarning(BuildContext context, String message) {
  ScaffoldMessenger.of(context).hideCurrentSnackBar();
  ScaffoldMessenger.of(context).showSnackBar(
    SnackBar(
      content: Text(
        message,
        style: const TextStyle(
          color: Colors.white,
          fontWeight: FontWeight.w600,
        ),
      ),
      backgroundColor: const Color(0xFFB42318),
      behavior: SnackBarBehavior.floating,
    ),
  );
}

class DokanLoginScreen extends ConsumerStatefulWidget {
  const DokanLoginScreen({
    super.key,
    this.onBack,
    this.onLogin,
    this.onOtpLogin,
    this.onAccountOpen,
    this.initialRole = 0,
    this.onRoleChanged,
  });

  final VoidCallback? onBack;
  final VoidCallback? onLogin;
  final VoidCallback? onOtpLogin;
  final VoidCallback? onAccountOpen;
  final int initialRole;
  final ValueChanged<int>? onRoleChanged;

  @override
  ConsumerState<DokanLoginScreen> createState() => _DokanLoginScreenState();
}

class _DokanLoginScreenState extends ConsumerState<DokanLoginScreen> {
  late int _selectedRole;
  bool _rememberMe = true;
  final TextEditingController _mobileController = TextEditingController();
  final TextEditingController _shopIdController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();

  String? _shopIdError;
  String? _phoneError;
  String? _passwordError;

  @override
  void initState() {
    super.initState();
    _selectedRole = widget.initialRole;
  }

  @override
  void dispose() {
    _mobileController.dispose();
    _shopIdController.dispose();
    _passwordController.dispose();
    super.dispose();
  }

  void _submitLogin() {
    final mobile = _mobileController.text.trim();
    final shopId = _shopIdController.text.trim();
    final password = _passwordController.text.trim();

    setState(() {
      _shopIdError = null;
      _phoneError = null;
      _passwordError = null;
    });

    bool hasError = false;

 if (_selectedRole == 1 && shopId.isEmpty) {
      setState(() => _shopIdError = 'দোকান নম্বর (Shop ID) দেওয়া আবশ্যক।');
      hasError = true;
    }

    if (mobile.isEmpty) {
      setState(() => _phoneError = 'ফোন নম্বর দেওয়া আবশ্যক।');
      hasError = true;
    } else if (!_isElevenDigitPhone(mobile)) {
      setState(() => _phoneError = 'সঠিক ১১ ডিজিট ফোন নম্বর দিন।');
      hasError = true;
    }

    if (password.isEmpty) {
      setState(() => _passwordError = 'পাসওয়ার্ড দেওয়া আবশ্যক।');
      hasError = true;
    } else if (!_isPasswordValid(password)) {
      setState(() => _passwordError = 'পাসওয়ার্ড কমপক্ষে ৪ অক্ষরের হতে হবে।');
      hasError = true;
    }

    if (hasError) return;

    final flow = ref.read(dokanAppFlowProvider);
final posState = ref.read(dokanPosProvider);

if (_selectedRole == 0) {
  // Owner Login

  if (mobile != flow.ownerPhone || password != flow.ownerPassword) {
    setState(() => _phoneError = 'মোবাইল নম্বর অথবা পাসওয়ার্ড ভুল।');
    return;
  }

  ref.read(dokanAppFlowProvider.notifier).loginUser(
    role: 0,
  );

  widget.onLogin?.call();
} else {
  // Salesman Login

  if (shopId != flow.shopName) {
    setState(() => _shopIdError = 'দোকান নম্বর (Shop ID) মিলছে না।');
    return;
  }

  final matchingStaff = posState.staffProfiles.where((staff) =>
      staff.phone == mobile &&
      staff.role == 'Salesman' &&
      staff.active).toList();

  if (matchingStaff.isEmpty) {
    setState(() => _phoneError = 'এই নম্বরে কোনো সক্রিয় সেলসম্যান পাওয়া যায়নি।');
    return;
  }

  final staff = matchingStaff.first;

  if (staff.pinCode != password) {
    setState(() => _passwordError = 'PIN ভুল।');
    return;
  }

  ref.read(dokanAppFlowProvider.notifier).loginUser(
    role: 1,
    salesmanPhone: staff.phone,
    salesmanName: staff.name,
  );

  widget.onLogin?.call();
}
}
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF1FBFF),
      body: SafeArea(
        child: Column(
          children: [
            _LoginHeader(onBack: widget.onBack ?? () => Navigator.maybePop(context)),
            Expanded(
              child: LayoutBuilder(
                builder: (context, constraints) {
                  return SingleChildScrollView(
                    physics: const ClampingScrollPhysics(),
                    child: ConstrainedBox(
                      constraints: BoxConstraints(minHeight: constraints.maxHeight),
                      child: Container(
                        decoration: const BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
                          boxShadow: [
                            BoxShadow(
                              color: Color(0x12000000),
                              blurRadius: 10,
                              offset: Offset(0, -1),
                            ),
                          ],
                        ),
                        child: Padding(
                          padding: const EdgeInsets.fromLTRB(20, 24, 20, 0),
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Column(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  _RoleToggle(
                                    selectedIndex: _selectedRole,
                                    onChanged: (index) {
                                      setState(() => _selectedRole = index);
                                      widget.onRoleChanged?.call(index);
                                    },
                                  ),
                                  const SizedBox(height: 24),
                                  _LoginFormHeader(
  isSalesman: _selectedRole == 1,
),
                                  const SizedBox(height: 24),
                                  if (_selectedRole == 1) ...[
  _LoginInputField(
    label: 'দোকান নম্বর (Shop ID)',
    hintText: 'Shop ID',
    helperText: 'যে দোকানে কাজ করেন সেই Shop ID লিখুন',
    keyboardType: TextInputType.text,
    prefix: const _FieldIcon(icon: Icons.storefront_rounded),
    controller: _shopIdController,
  ),
  if (_shopIdError != null) ...[
    const SizedBox(height: 4),
    Align(
      alignment: Alignment.centerLeft,
      child: Text(
        _shopIdError!,
        style: const TextStyle(
          color: Colors.red,
          fontSize: 13,
          fontWeight: FontWeight.bold,
        ),
      ),
    ),
  ],
  const SizedBox(height: 24),
],
                                  _LoginInputField(
                                    label: _selectedRole == 1
    ? 'সেলসম্যান মোবাইল নম্বর'
    : 'মোবাইল নম্বর',
                                    hintText: '01XXXXXXXXX',
                                    helperText: '১১ ডিজিটের মোবাইল নম্বর',
                                    keyboardType: TextInputType.phone,
                                    prefix: const _CountryPrefix(),
                                    controller: _mobileController,
                                    inputFormatters: [
                                      FilteringTextInputFormatter.digitsOnly,
                                      LengthLimitingTextInputFormatter(11),
                                    ],
                                  ),
                                  if (_phoneError != null) ...[
                                    const SizedBox(height: 4),
                                    Align(
                                      alignment: Alignment.centerLeft,
                                      child: Text(
                                        _phoneError!,
                                        style: const TextStyle(
                                          color: Colors.red,
                                          fontSize: 13,
                                          fontWeight: FontWeight.bold,
                                        ),
                                      ),
                                    ),
                                  ],
                                  const SizedBox(height: 24),
                                  _LoginInputField(
                                   label: _selectedRole == 1
    ? 'PIN'
    : 'পাসওয়ার্ড',
                                    hintText: _selectedRole == 1
    ? 'সেলসম্যান PIN লিখুন'
    : 'পাসওয়ার্ড লিখুন',
                                    helperText: _selectedRole == 1
    ? 'সেলসম্যান PIN'
    : 'কমপক্ষে ৪ ডিজিট',
                                    prefix: const _FieldIcon(icon: Icons.lock_outline_rounded),
                                    controller: _passwordController,
                                  ),
                                  if (_passwordError != null) ...[
                                    const SizedBox(height: 4),
                                    Align(
                                      alignment: Alignment.centerLeft,
                                      child: Text(
                                        _passwordError!,
                                        style: const TextStyle(
                                          color: Colors.red,
                                          fontSize: 13,
                                          fontWeight: FontWeight.bold,
                                        ),
                                      ),
                                    ),
                                  ],
                                  const SizedBox(height: 20),
                                  _RememberForgotRow(
                                    rememberMe: _rememberMe,
                                    onRememberChanged: (value) {
                                      setState(() => _rememberMe = value ?? false);
                                    },
                                    onForgotPressed: widget.onOtpLogin,
                                  ),
                                  const SizedBox(height: 20),
                                  _PrimaryActionButton(
                                    label: 'লগইন করুন',
                                    onPressed: _submitLogin,
                                  ),
                                  const SizedBox(height: 20),
                                  const _DividerWithLabel(label: 'অথবা'),
                                  const SizedBox(height: 20),
                                  _OutlineActionButton(
                                    label: 'OTP Login',
                                    icon: Icons.sms_outlined,
                                    onPressed: widget.onOtpLogin,
                                  ),
                                  const SizedBox(height: 16),
                                  if (_selectedRole == 0)
                                    _RegistrationLink(label: 'অ্যাকাউন্ট খুলুন', onPressed: widget.onAccountOpen)
                                  else
                                    const Padding(
                                      padding: EdgeInsets.symmetric(vertical: 2),
                                      child: Text(
                                        'সেলসম্যান অ্যাকাউন্ট তৈরি করতে পারবেন না।',
                                        textAlign: TextAlign.center,
                                        style: TextStyle(
                                          fontSize: 13,
                                          color: Color(0xFF6D7A73),
                                        ),
                                      ),
                                    ),
                                ],
                              ),
                              const SizedBox(height: 24),
                              const _SecurityFooter(),
                            ],
                          ),
                        ),
                      ),
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class DokanRegisterScreen extends StatefulWidget {
  const DokanRegisterScreen({
    super.key,
    this.onBack,
    this.onContinue,
  });

  final VoidCallback? onBack;
  final void Function(String name, String phone, String password)? onContinue;

  @override
  State<DokanRegisterScreen> createState() => _DokanRegisterScreenState();
}

class _DokanRegisterScreenState extends State<DokanRegisterScreen> {
  final TextEditingController _nameController = TextEditingController();
  final TextEditingController _mobileController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();
  final TextEditingController _confirmPasswordController = TextEditingController();
  @override
  void dispose() {
    _nameController.dispose();
    _mobileController.dispose();
    _passwordController.dispose();
    _confirmPasswordController.dispose();
    super.dispose();
  }

  void _continue() {
    final name = _nameController.text.trim();
    final mobile = _mobileController.text.trim();
    final password = _passwordController.text.trim();
    final confirmPassword = _confirmPasswordController.text.trim();

    if (name.isEmpty) {
      _showWarning(context, 'মালিকের নাম দিতে হবে।');
      return;
    }
    if (!_isElevenDigitPhone(mobile)) {
      _showWarning(context, 'মোবাইল নম্বর 11 digit হতে হবে।');
      return;
    }
    if (!_isPasswordValid(password)) {
      _showWarning(context, 'পাসওয়ার্ড কমপক্ষে 4 character হতে হবে।');
      return;
    }
    if (confirmPassword != password) {
      _showWarning(context, 'পাসওয়ার্ড মিলছে না।');
      return;
    }

    widget.onContinue?.call(name, mobile, password);
  }

  @override
  Widget build(BuildContext context) {
    return _FlowScreen(
      onBack: widget.onBack,
      accent: const Color(0xFF00694C),
      background: const Color(0xFFF4FBF7),
      title: 'অ্যাকাউন্ট খুলুন',
      subtitle: 'নতুন merchant account তৈরি করে দোকানের সেটআপ শুরু করুন।',
      icon: Icons.storefront_rounded,
      primaryLabel: 'আগে যান',
      onPrimary: _continue,
      children: [
        _FlowInputField(
          label: 'মালিকের নাম',
          hintText: 'আপনার নাম লিখুন',
          icon: Icons.person_outline_rounded,
          controller: _nameController,
        ),
        const SizedBox(height: 16),
        _FlowInputField(
          label: 'মোবাইল নম্বর',
          hintText: '01XXXXXXXXX',
          icon: Icons.phone_android_rounded,
          keyboardType: TextInputType.phone,
          controller: _mobileController,
          inputFormatters: [
            FilteringTextInputFormatter.digitsOnly,
            LengthLimitingTextInputFormatter(11),
          ],
        ),
        const SizedBox(height: 16),
        _FlowInputField(
          label: 'পাসওয়ার্ড',
          hintText: 'কমপক্ষে 4 character',
          icon: Icons.lock_outline_rounded,
          controller: _passwordController,
        ),
        const SizedBox(height: 16),
        _FlowInputField(
          label: 'কনফার্ম পাসওয়ার্ড',
          hintText: 'আবার লিখুন',
          icon: Icons.verified_user_outlined,
          obscureText: false,
          controller: _confirmPasswordController,
        ),
      ],
    );
  }
}

class DokanOtpLoginScreen extends StatefulWidget {
  const DokanOtpLoginScreen({
    super.key,
    this.onBack,
    this.onSendOtp,
  });

  final VoidCallback? onBack;
  final VoidCallback? onSendOtp;

  @override
  State<DokanOtpLoginScreen> createState() => _DokanOtpLoginScreenState();
}

class _DokanOtpLoginScreenState extends State<DokanOtpLoginScreen> {
  final TextEditingController _mobileController = TextEditingController();

  @override
  void dispose() {
    _mobileController.dispose();
    super.dispose();
  }

  void _sendOtp() {
    final mobile = _mobileController.text.trim();
    if (!_isElevenDigitPhone(mobile)) {
      _showWarning(context, 'মোবাইল নম্বর 11 digit হতে হবে।');
      return;
    }
    widget.onSendOtp?.call();
  }

  @override
  Widget build(BuildContext context) {
    return _FlowScreen(
      onBack: widget.onBack,
      accent: const Color(0xFF0E8B69),
      background: const Color(0xFFF1FBFF),
      title: 'OTP Login',
      subtitle: 'মোবাইল নাম্বার দিন, আমরা লগইনের জন্য OTP পাঠাবো।',
      icon: Icons.sms_outlined,
      primaryLabel: 'OTP পাঠান',
      onPrimary: _sendOtp,
      children: [
        _FlowInputField(
          label: 'মোবাইল নম্বর',
          hintText: '01XXXXXXXXX',
          icon: Icons.phone_android_rounded,
          keyboardType: TextInputType.phone,
          controller: _mobileController,
          inputFormatters: [
            FilteringTextInputFormatter.digitsOnly,
            LengthLimitingTextInputFormatter(11),
          ],
        ),
      ],
    );
  }
}

class DokanOtpVerificationScreen extends StatefulWidget {
  const DokanOtpVerificationScreen({
    super.key,
    this.onBack,
    this.onVerified,
  });

  final VoidCallback? onBack;
  final VoidCallback? onVerified;

  @override
  State<DokanOtpVerificationScreen> createState() => _DokanOtpVerificationScreenState();
}

class _DokanOtpVerificationScreenState extends State<DokanOtpVerificationScreen> {
  final TextEditingController _otpController = TextEditingController();

  @override
  void dispose() {
    _otpController.dispose();
    super.dispose();
  }

  void _verifyOtp() {
    final otp = _otpController.text.trim();
    if (!_isFourDigitCode(otp)) {
      _showWarning(context, 'OTP 4 digit হতে হবে।');
      return;
    }
    widget.onVerified?.call();
  }

  @override
  Widget build(BuildContext context) {
    return _FlowScreen(
      onBack: widget.onBack,
      accent: const Color(0xFF00694C),
      background: const Color(0xFFF7FBFA),
      title: 'OTP Verification',
      subtitle: 'মোবাইলে আসা ৪ সংখ্যার কোড বসিয়ে যাচাই করুন।',
      icon: Icons.verified_outlined,
      primaryLabel: 'যাচাই করুন',
      onPrimary: _verifyOtp,
      children: [
        _FlowInputField(
          label: 'OTP কোড',
          hintText: '0000',
          icon: Icons.pin_rounded,
          keyboardType: TextInputType.number,
          controller: _otpController,
          inputFormatters: [
            FilteringTextInputFormatter.digitsOnly,
            LengthLimitingTextInputFormatter(4),
          ],
        ),
      ],
    );
  }
}

class DokanPinLoginScreen extends StatefulWidget {
  const DokanPinLoginScreen({
    super.key,
    this.onBack,
    this.onLogin,
  });

  final VoidCallback? onBack;
  final VoidCallback? onLogin;

  @override
  State<DokanPinLoginScreen> createState() => _DokanPinLoginScreenState();
}

class _DokanPinLoginScreenState extends State<DokanPinLoginScreen> {
  final TextEditingController _pinController = TextEditingController();

  @override
  void dispose() {
    _pinController.dispose();
    super.dispose();
  }

  void _login() {
    final pin = _pinController.text.trim();
    if (!_isFourDigitCode(pin)) {
      _showWarning(context, 'PIN 4 digit হতে হবে।');
      return;
    }
    widget.onLogin?.call();
  }

  @override
  Widget build(BuildContext context) {
    return _FlowScreen(
      onBack: widget.onBack,
      accent: const Color(0xFF0A6A4F),
      background: const Color(0xFFF4FBF7),
      title: 'PIN Login',
      subtitle: 'দ্রুত প্রবেশের জন্য ৪ ডিজিটের PIN ব্যবহার করুন।',
      icon: Icons.pin_rounded,
      primaryLabel: 'লগইন করুন',
      onPrimary: _login,
      children: [
        _FlowInputField(
          label: 'PIN',
          hintText: '0000',
          icon: Icons.pin_rounded,
          keyboardType: TextInputType.number,
          controller: _pinController,
          inputFormatters: [
            FilteringTextInputFormatter.digitsOnly,
            LengthLimitingTextInputFormatter(4),
          ],
        ),
      ],
    );
  }
}

class DokanPinSetupScreen extends StatefulWidget {
  const DokanPinSetupScreen({
    super.key,
    this.onBack,
    this.onContinue,
  });

  final VoidCallback? onBack;
  final VoidCallback? onContinue;

  @override
  State<DokanPinSetupScreen> createState() => _DokanPinSetupScreenState();
}

class _DokanPinSetupScreenState extends State<DokanPinSetupScreen> {
  final TextEditingController _pinController = TextEditingController();
  final TextEditingController _confirmPinController = TextEditingController();
  @override
  void dispose() {
    _pinController.dispose();
    _confirmPinController.dispose();
    super.dispose();
  }

  void _continue() {
    final pin = _pinController.text.trim();
    final confirmPin = _confirmPinController.text.trim();

    if (!_isFourDigitCode(pin)) {
      _showWarning(context, 'PIN 4 digit হতে হবে।');
      return;
    }
    if (confirmPin != pin) {
      _showWarning(context, 'PIN মিলছে না।');
      return;
    }
    widget.onContinue?.call();
  }

  @override
  Widget build(BuildContext context) {
    return _FlowScreen(
      onBack: widget.onBack,
      accent: const Color(0xFF00694C),
      background: const Color(0xFFF8FCFA),
      title: 'PIN Setup',
      subtitle: 'প্রথমবার লগইনের পর ৪ ডিজিটের PIN সেট করুন।',
      icon: Icons.password_rounded,
      primaryLabel: 'PIN সেট করুন',
      onPrimary: _continue,
      children: [
        _FlowInputField(
          label: 'নতুন PIN',
          hintText: '0000',
          icon: Icons.pin_rounded,
          controller: _pinController,
          inputFormatters: [
            FilteringTextInputFormatter.digitsOnly,
            LengthLimitingTextInputFormatter(4),
          ],
        ),
        const SizedBox(height: 16),
        _FlowInputField(
          label: 'PIN পুনরায় লিখুন',
          hintText: 'আবার লিখুন',
          icon: Icons.verified_user_outlined,
          obscureText: false,
          controller: _confirmPinController,
          inputFormatters: [
            FilteringTextInputFormatter.digitsOnly,
            LengthLimitingTextInputFormatter(4),
          ],
        ),
      ],
    );
  }
}

class DokanShopSetupScreen extends StatefulWidget {
  const DokanShopSetupScreen({
    super.key,
    this.onBack,
    this.onContinue,
  });

  final VoidCallback? onBack;
  final ValueChanged<String>? onContinue;

  @override
  State<DokanShopSetupScreen> createState() => _DokanShopSetupScreenState();
}

class _DokanShopSetupScreenState extends State<DokanShopSetupScreen> {
  final TextEditingController _shopNameController = TextEditingController();
  final TextEditingController _addressController = TextEditingController();
  final TextEditingController _locationController = TextEditingController();
  String? _category;

  static const List<String> _categories = [
    'মুদি',
    'কসমেটিক',
    'ফার্মেসি',
    'স্টেশনারি',
    'ইলেকট্রনিক্স',
  ];

  @override
  void dispose() {
    _shopNameController.dispose();
    _addressController.dispose();
    _locationController.dispose();
    super.dispose();
  }

  void _continue() {
    final shopName = _shopNameController.text.trim();
    final address = _addressController.text.trim();
    final location = _locationController.text.trim();

    if (shopName.isEmpty) {
      _showWarning(context, 'দোকানের নাম দিতে হবে।');
      return;
    }
    if (address.isEmpty) {
      _showWarning(context, 'ঠিকানা দিতে হবে।');
      return;
    }
    if (_category == null) {
      _showWarning(context, 'ক্যাটাগরি নির্বাচন করুন।');
      return;
    }
    if (location.isEmpty) {
      _showWarning(context, 'লোকেশন দিতে হবে।');
      return;
    }

    widget.onContinue?.call(shopName);
  }

  @override
  Widget build(BuildContext context) {
    return _FlowScreen(
      onBack: widget.onBack,
      accent: const Color(0xFF0E8B69),
      background: const Color(0xFFF1FBFF),
      title: 'দোকান সেটআপ',
      subtitle: 'দোকানের নাম, ঠিকানা, ক্যাটাগরি এবং লোকেশন সেট করুন।',
      icon: Icons.location_city_outlined,
      primaryLabel: 'সেটআপ শেষ করুন',
      onPrimary: _continue,
      children: [
        _FlowInputField(
          label: 'দোকানের নাম',
          hintText: 'আপনার দোকানের নাম',
          icon: Icons.storefront_outlined,
          controller: _shopNameController,
        ),
        const SizedBox(height: 16),
        _FlowInputField(
          label: 'ঠিকানা',
          hintText: 'দোকানের ঠিকানা লিখুন',
          icon: Icons.location_on_outlined,
          controller: _addressController,
        ),
        const SizedBox(height: 16),
        _CategoryPicker(
          value: _category,
          items: _categories,
          onChanged: (value) => setState(() => _category = value),
        ),
        const SizedBox(height: 16),
        _FlowInputField(
          label: 'লোকেশন',
          hintText: 'মানচিত্র লোকেশন',
          icon: Icons.my_location_rounded,
          controller: _locationController,
        ),
      ],
    );
  }
}

class DokanWelcomeScreen extends StatelessWidget {
  const DokanWelcomeScreen({
    super.key,
    required this.accountName,
    this.onPopularProducts,
  });

  final String accountName;
  final VoidCallback? onPopularProducts;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF3FAF4),
      body: SafeArea(
        top: false,
        bottom: false,
        child: LayoutBuilder(
          builder: (context, constraints) {
            final sheetTop = (constraints.maxHeight * 0.44).clamp(306.0, 348.0);

            return Stack(
              clipBehavior: Clip.none,
              children: [
                const Positioned.fill(
                  child: DecoratedBox(
                    decoration: BoxDecoration(color: Color(0xFFF3FAF4)),
                  ),
                ),
                Positioned(
                  left: 0,
                  right: 0,
                  top: 50,
                  child: Center(
                    child: SizedBox(
                      width: 328,
                      height: 300,
                      child: Stack(
                        alignment: Alignment.center,
                        children: [
                          Container(
                            width: 276,
                            height: 276,
                            decoration: BoxDecoration(
                              color: const Color(0xFFEAF7F0),
                              borderRadius: BorderRadius.circular(34),
                            ),
                          ),
                          Container(
                            width: 176,
                            height: 176,
                            decoration: BoxDecoration(
                              color: const Color(0xFFDCEDE4),
                              borderRadius: BorderRadius.circular(88),
                            ),
                          ),
                          Container(
                            width: 124,
                            height: 124,
                            decoration: BoxDecoration(
                              color: const Color(0xFF0E8B69),
                              borderRadius: BorderRadius.circular(32),
                              boxShadow: [
                                BoxShadow(
                                  color: const Color(0xFF0E8B69).withValues(alpha: 0.22),
                                  blurRadius: 18,
                                  offset: const Offset(0, 10),
                                ),
                              ],
                            ),
                            child: const Icon(
                              Icons.check_rounded,
                              color: Colors.white,
                              size: 72,
                            ),
                          ),
                          Positioned(
                            left: 28,
                            top: 72,
                            child: _ConfettiMark(color: Color(0xFF7ABEA7), size: 11),
                          ),
                          Positioned(
                            right: 48,
                            top: 54,
                            child: _ConfettiMark(color: Color(0xFF2F8F73), size: 10),
                          ),
                          Positioned(
                            left: 82,
                            bottom: 32,
                            child: _ConfettiMark(color: Color(0xFFFFB07A), size: 11),
                          ),
                          Positioned(
                            right: 74,
                            bottom: 58,
                            child: _ConfettiMark(color: Color(0xFF7ABEA7), size: 9),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
                Positioned(
                  left: 0,
                  right: 0,
                  top: sheetTop,
                  bottom: 0,
                  child: Container(
                    width: double.infinity,
                    decoration: const BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.vertical(top: Radius.circular(32)),
                      boxShadow: [
                        BoxShadow(
                          color: Color(0x08000000),
                          blurRadius: 32,
                          offset: Offset(0, -12),
                        ),
                      ],
                    ),
                    child: Column(
                      children: [
                        Expanded(
                          child: SingleChildScrollView(
                            physics: const ClampingScrollPhysics(),
                            padding: const EdgeInsets.fromLTRB(20, 24, 20, 28),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                Center(
                                  child: Column(
                                    children: [
                                      Text(
                                        'স্বাগতম, $accountName',
                                        textAlign: TextAlign.center,
                                        style: const TextStyle(
                                          fontSize: 30,
                                          fontWeight: FontWeight.w800,
                                          color: Color(0xFF131D21),
                                          height: 1.1,
                                          letterSpacing: -0.6,
                                        ),
                                      ),
                                      const SizedBox(height: 10),
                                      const Text(
                                        'আপনার অ্যাকাউন্ট প্রস্তুত। এখন পরের ধাপগুলো শুরু করুন।',
                                        textAlign: TextAlign.center,
                                        style: TextStyle(
                                          fontSize: 15,
                                          height: 1.45,
                                          color: Color(0xFF4A5A54),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                const SizedBox(height: 24),
                            _WelcomeActionTile(
                              icon: Icons.storefront_rounded,
                              title: 'জনপ্রিয় পণ্য থেকে যোগ করুন',
                              subtitle: '৫০টি সাধারণ পণ্য একসাথে যোগ করুন',
                              badge: 'সহজ',
                              onTap: onPopularProducts,
                            ),
                            const SizedBox(height: 14),
                            const _WelcomeActionTile(
                              icon: Icons.qr_code_scanner_rounded,
                              title: 'বারকোড স্ক্যান করে যোগ করুন',
                              subtitle: 'পণ্যের বারকোড স্ক্যান করুন',
                                ),
                                const SizedBox(height: 14),
                                const _WelcomeActionTile(
                                  icon: Icons.edit_note_rounded,
                                  title: 'নিজে পণ্য যোগ করুন',
                                  subtitle: 'ম্যানুয়ালি পণ্যের তথ্য দিন',
                                ),
                                const SizedBox(height: 18),
                                Text(
                                  'পরে সেটিংস থেকে আরও পণ্য যোগ করা যাবে',
                                  style: TextStyle(
                                    color: Colors.grey.shade700,
                                    fontSize: 13,
                                    height: 1.35,
                                  ),
                                  textAlign: TextAlign.center,
                                ),
                              ],
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            );
          },
        ),
      ),
    );
  }
}

class _WelcomeActionTile extends StatelessWidget {
  const _WelcomeActionTile({
    required this.icon,
    required this.title,
    required this.subtitle,
    this.badge,
    this.onTap,
  });

  final IconData icon;
  final String title;
  final String subtitle;
  final String? badge;
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) {
    final card = Container(
      width: double.infinity,
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: const Color(0xFFFBFCFC),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: const Color(0xFFE7ECE9)),
        boxShadow: const [
          BoxShadow(
            color: Color(0x0F000000),
            blurRadius: 16,
            offset: Offset(0, 6),
          ),
        ],
      ),
      child: Row(
        children: [
          Container(
            width: 64,
            height: 64,
            decoration: BoxDecoration(
              color: const Color(0xFFE3EFE9),
              borderRadius: BorderRadius.circular(16),
            ),
            child: Icon(icon, color: const Color(0xFF00694C), size: 34),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Expanded(
                      child: Text(
                        title,
                        style: const TextStyle(
                          fontSize: 17,
                          fontWeight: FontWeight.w700,
                          color: Color(0xFF1C2C27),
                          height: 1.2,
                        ),
                      ),
                    ),
                    if (badge != null) ...[
                      const SizedBox(width: 8),
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                        decoration: BoxDecoration(
                          color: const Color(0xFFE6F2EE),
                          borderRadius: BorderRadius.circular(999),
                        ),
                        child: Text(
                          badge!,
                          style: const TextStyle(
                            color: Color(0xFF00694C),
                            fontSize: 12,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                      ),
                    ],
                  ],
                ),
                const SizedBox(height: 6),
                Text(
                  subtitle,
                  style: const TextStyle(
                    fontSize: 13,
                    height: 1.35,
                    color: Color(0xFF5B6A65),
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(width: 8),
          const Icon(
            Icons.chevron_right_rounded,
            color: Color(0xFF4F5A56),
            size: 30,
          ),
        ],
      ),
    );

    if (onTap == null) {
      return card;
    }

    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(20),
        child: card,
      ),
    );
  }
}

class _ConfettiMark extends StatelessWidget {
  const _ConfettiMark({
    required this.color,
    required this.size,
  });

  final Color color;
  final double size;

  @override
  Widget build(BuildContext context) {
    return Transform.rotate(
      angle: size / 22,
      child: Container(
        width: size,
        height: size * 2,
        decoration: BoxDecoration(
          color: color,
          borderRadius: BorderRadius.circular(size),
        ),
      ),
    );
  }
}

class _FlowScreen extends StatelessWidget {
  const _FlowScreen({
    required this.title,
    required this.subtitle,
    required this.icon,
    required this.accent,
    required this.background,
    required this.primaryLabel,
    required this.children,
    this.onBack,
    this.onPrimary,
  });

  final String title;
  final String subtitle;
  final IconData icon;
  final Color accent;
  final Color background;
  final String primaryLabel;
  final List<Widget> children;
  final VoidCallback? onBack;
  final VoidCallback? onPrimary;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: background,
      body: SafeArea(
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 14, 20, 12),
              child: Row(
                children: [
                  IconButton(
                    onPressed: onBack,
                    icon: const Icon(Icons.arrow_back_rounded),
                    color: const Color(0xFF131D21),
                    iconSize: 22,
                    padding: EdgeInsets.zero,
                    constraints: const BoxConstraints.tightFor(width: 36, height: 36),
                  ),
                  const Spacer(),
                  const Text(
                    'DokanERP',
                    style: TextStyle(
                      fontSize: 15,
                      fontWeight: FontWeight.w700,
                      color: Color(0xFF131D21),
                    ),
                  ),
                ],
              ),
            ),
            Expanded(
              child: LayoutBuilder(
                builder: (context, constraints) {
                  return SingleChildScrollView(
                    physics: const ClampingScrollPhysics(),
                    child: ConstrainedBox(
                      constraints: BoxConstraints(minHeight: constraints.maxHeight),
                      child: Padding(
                        padding: const EdgeInsets.fromLTRB(20, 4, 20, 20),
                        child: Column(
                          children: [
                            Container(
                              width: double.infinity,
                              padding: const EdgeInsets.all(22),
                              decoration: BoxDecoration(
                                gradient: LinearGradient(
                                  begin: Alignment.topLeft,
                                  end: Alignment.bottomRight,
                                  colors: [
                                    accent,
                                    accent.withValues(alpha: 0.86),
                                  ],
                                ),
                                borderRadius: BorderRadius.circular(28),
                                boxShadow: [
                                  BoxShadow(
                                    color: accent.withValues(alpha: 0.20),
                                    blurRadius: 30,
                                    offset: const Offset(0, 14),
                                  ),
                                ],
                              ),
                              child: Row(
                                children: [
                                  Container(
                                    width: 64,
                                    height: 64,
                                    decoration: BoxDecoration(
                                      color: Colors.white.withValues(alpha: 0.14),
                                      borderRadius: BorderRadius.circular(20),
                                    ),
                                    child: Icon(icon, color: Colors.white, size: 32),
                                  ),
                                  const SizedBox(width: 16),
                                  Expanded(
                                    child: Column(
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        const Text(
                                          'নিরাপদ ফর্ম',
                                          style: TextStyle(
                                            color: Colors.white,
                                            fontSize: 13,
                                            fontWeight: FontWeight.w600,
                                          ),
                                        ),
                                        const SizedBox(height: 6),
                                        Text(
                                          title,
                                          style: const TextStyle(
                                            color: Colors.white,
                                            fontSize: 22,
                                            fontWeight: FontWeight.w800,
                                            height: 1.1,
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            const SizedBox(height: 18),
                            Text(
                              subtitle,
                              textAlign: TextAlign.center,
                              style: const TextStyle(
                                fontSize: 14,
                                height: 1.5,
                                color: Color(0xFF40514A),
                              ),
                            ),
                            const SizedBox(height: 18),
                            Container(
                              width: double.infinity,
                              padding: const EdgeInsets.all(18),
                              decoration: BoxDecoration(
                                color: Colors.white,
                                borderRadius: BorderRadius.circular(24),
                                boxShadow: const [
                                  BoxShadow(
                                    color: Color(0x12000000),
                                    blurRadius: 16,
                                    offset: Offset(0, 8),
                                  ),
                                ],
                              ),
                              child: Column(
                                children: [
                                  ...children,
                                  const SizedBox(height: 24),
                                  _PrimaryActionButton(
                                    label: primaryLabel,
                                    onPressed: onPrimary,
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _FlowInputField extends StatelessWidget {
  const _FlowInputField({
    required this.label,
    required this.hintText,
    required this.icon,
    this.keyboardType,
    this.obscureText = false,
    this.onToggleObscure,
    this.controller,
    this.inputFormatters,
  });

  final String label;
  final String hintText;
  final IconData icon;
  final TextInputType? keyboardType;
  final bool obscureText;
  final VoidCallback? onToggleObscure;
  final TextEditingController? controller;
  final List<TextInputFormatter>? inputFormatters;

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label,
          style: const TextStyle(
            color: Color(0xFF1D2723),
            fontSize: 14,
            fontWeight: FontWeight.w700,
          ),
        ),
        const SizedBox(height: 8),
        TextField(
          controller: controller,
          keyboardType: keyboardType,
          obscureText: obscureText,
          obscuringCharacter: '•',
          cursorColor: const Color(0xFF00694C),
          inputFormatters: inputFormatters,
          style: const TextStyle(
            color: Color(0xFF131D21),
            fontSize: 16,
            fontWeight: FontWeight.w600,
          ),
          decoration: InputDecoration(
            hintText: hintText,
            hintStyle: const TextStyle(
              color: Color(0xFF93A1A7),
              fontSize: 15,
            ),
            prefixIcon: Icon(icon, color: const Color(0xFF00694C), size: 18),
            suffixIcon: onToggleObscure == null
                ? null
                : IconButton(
                    onPressed: onToggleObscure,
                    icon: Icon(
                      obscureText ? Icons.visibility_off_outlined : Icons.visibility_outlined,
                      color: const Color(0xFF6D7A73),
                    ),
                  ),
            filled: true,
            fillColor: const Color(0xFFF8FCFA),
            contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
            enabledBorder: OutlineInputBorder(
              borderSide: const BorderSide(color: Color(0xFFD6E4DE)),
              borderRadius: BorderRadius.circular(16),
            ),
            focusedBorder: OutlineInputBorder(
              borderSide: const BorderSide(color: Color(0xFF00694C), width: 1.4),
              borderRadius: BorderRadius.circular(16),
            ),
          ),
        ),
      ],
    );
  }
}

class _CategoryPicker extends StatelessWidget {
  const _CategoryPicker({
    required this.value,
    required this.items,
    required this.onChanged,
  });

  final String? value;
  final List<String> items;
  final ValueChanged<String?> onChanged;

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          'ক্যাটাগরি',
          style: TextStyle(
            color: Color(0xFF1D2723),
            fontSize: 14,
            fontWeight: FontWeight.w700,
          ),
        ),
        const SizedBox(height: 8),
        Container(
          decoration: BoxDecoration(
            color: const Color(0xFFF8FCFA),
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: const Color(0xFFD6E4DE)),
          ),
          padding: const EdgeInsets.symmetric(horizontal: 16),
          child: DropdownButtonHideUnderline(
            child: DropdownButton<String>(
              isExpanded: true,
              value: value,
              hint: const Text(
                'একটি ক্যাটাগরি নির্বাচন করুন',
                style: TextStyle(
                  color: Color(0xFF93A1A7),
                  fontSize: 15,
                ),
              ),
              icon: const Icon(Icons.keyboard_arrow_down_rounded, color: Color(0xFF00694C)),
              borderRadius: BorderRadius.circular(16),
              dropdownColor: Colors.white,
              onChanged: onChanged,
              items: items
                  .map(
                    (item) => DropdownMenuItem<String>(
                      value: item,
                      child: Text(
                        item,
                        style: const TextStyle(
                          color: Color(0xFF131D21),
                          fontSize: 15,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ),
                  )
                  .toList(),
            ),
          ),
        ),
      ],
    );
  }
}

class _OtpCodeField extends StatelessWidget {
  const _OtpCodeField();

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        const Text(
          'OTP CODE',
          style: TextStyle(
            fontSize: 13,
            fontWeight: FontWeight.w700,
            color: Color(0xFF00694C),
            letterSpacing: 1.1,
          ),
        ),
        const SizedBox(height: 12),
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: List.generate(6, (index) {
            return SizedBox(
              width: 44,
              height: 54,
              child: TextField(
                textAlign: TextAlign.center,
                keyboardType: TextInputType.number,
                maxLength: 1,
                cursorColor: const Color(0xFF00694C),
                style: const TextStyle(
                  color: Color(0xFF131D21),
                  fontSize: 22,
                  fontWeight: FontWeight.w700,
                ),
                decoration: InputDecoration(
                  counterText: '',
                  filled: true,
                  fillColor: const Color(0xFFF8FCFA),
                  enabledBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(14),
                    borderSide: const BorderSide(color: Color(0xFFD6E4DE)),
                  ),
                  focusedBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(14),
                    borderSide: const BorderSide(color: Color(0xFF00694C), width: 1.4),
                  ),
                ),
              ),
            );
          }),
        ),
      ],
    );
  }
}

class _PinRowField extends StatelessWidget {
  const _PinRowField({this.label = '৪ ডিজিট PIN'});

  final String label;

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label,
          style: const TextStyle(
            color: Color(0xFF1D2723),
            fontSize: 14,
            fontWeight: FontWeight.w700,
          ),
        ),
        const SizedBox(height: 12),
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: List.generate(4, (index) {
            return SizedBox(
              width: 56,
              height: 58,
              child: TextField(
                textAlign: TextAlign.center,
                keyboardType: TextInputType.number,
                maxLength: 1,
                cursorColor: const Color(0xFF00694C),
                style: const TextStyle(
                  color: Color(0xFF131D21),
                  fontSize: 24,
                  fontWeight: FontWeight.w700,
                ),
                decoration: InputDecoration(
                  counterText: '',
                  filled: true,
                  fillColor: const Color(0xFFF8FCFA),
                  enabledBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(14),
                    borderSide: const BorderSide(color: Color(0xFFD6E4DE)),
                  ),
                  focusedBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(14),
                    borderSide: const BorderSide(color: Color(0xFF00694C), width: 1.4),
                  ),
                ),
              ),
            );
          }),
        ),
      ],
    );
  }
}

class _LoginHeader extends StatelessWidget {
  const _LoginHeader({required this.onBack});

  final VoidCallback onBack;

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 192,
      width: double.infinity,
      decoration: const BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            Color(0xFF00694C),
            Color(0xFF008560),
          ],
        ),
      ),
      child: Stack(
        children: [
          Positioned(
            left: -20,
            top: -20,
            child: _DecorDot(size: 120, color: Colors.white.withValues(alpha: 0.10)),
          ),
          Positioned(
            right: -30,
            top: 40,
            child: _DecorDot(size: 180, color: Colors.white.withValues(alpha: 0.05)),
          ),
          SafeArea(
            bottom: false,
            child: Padding(
              padding: const EdgeInsets.fromLTRB(20, 14, 20, 20),
              child: Column(
                children: [
                  Row(
                    children: [
                      IconButton(
                        onPressed: onBack,
                        icon: const Icon(Icons.arrow_back_rounded),
                        color: Colors.white,
                        iconSize: 22,
                        padding: EdgeInsets.zero,
                        constraints: const BoxConstraints.tightFor(width: 36, height: 36),
                      ),
                      const Spacer(),
                      const Text(
                        'DokanERP',
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 15,
                          fontWeight: FontWeight.w700,
                          letterSpacing: -0.2,
                        ),
                      ),
                    ],
                  ),
                  const Spacer(),
                  Row(
                    children: [
                      Container(
                        width: 72,
                        height: 68,
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(16),
                          boxShadow: const [
                            BoxShadow(
                              color: Color(0x1A000000),
                              blurRadius: 25,
                              offset: Offset(0, 8),
                            ),
                          ],
                        ),
                        child: const Icon(
                          Icons.storefront_rounded,
                          color: Color(0xFF00694C),
                          size: 34,
                        ),
                      ),
                      const SizedBox(width: 16),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisSize: MainAxisSize.min,
                          children: const [
                            Text(
                              'Welcome',
                              style: TextStyle(
                                color: Colors.white,
                                fontSize: 18,
                                fontWeight: FontWeight.w700,
                                height: 1.2,
                              ),
                            ),
                            SizedBox(height: 6),
                            Text(
                              'শপে প্রবেশ করতে নিরাপদভাবে লগইন করুন',
                              style: TextStyle(
                                color: Colors.white,
                                fontSize: 14,
                                height: 1.35,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _DecorDot extends StatelessWidget {
  const _DecorDot({required this.size, required this.color});

  final double size;
  final Color color;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        color: color,
        borderRadius: BorderRadius.circular(size / 2),
      ),
    );
  }
}

class _RoleToggle extends StatelessWidget {
  const _RoleToggle({
    required this.selectedIndex,
    required this.onChanged,
  });

  final int selectedIndex;
  final ValueChanged<int> onChanged;

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 52,
      decoration: BoxDecoration(
        color: const Color(0xFFE4F0F4),
        borderRadius: BorderRadius.circular(12),
      ),
      padding: const EdgeInsets.all(4),
      child: Row(
        children: [
          Expanded(
            child: _RoleToggleButton(
              selected: selectedIndex == 0,
              label: 'মার্চেন্ট / অ্যাডমিন',
              icon: Icons.admin_panel_settings_rounded,
              onTap: () => onChanged(0),
            ),
          ),
          const SizedBox(width: 4),
          Expanded(
            child: _RoleToggleButton(
              selected: selectedIndex == 1,
              label: 'সেলসম্যান',
              icon: Icons.badge_rounded,
              onTap: () => onChanged(1),
            ),
          ),
        ],
      ),
    );
  }
}

class _RoleToggleButton extends StatelessWidget {
  const _RoleToggleButton({
    required this.selected,
    required this.label,
    required this.icon,
    required this.onTap,
  });

  final bool selected;
  final String label;
  final IconData icon;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final background = selected ? const Color(0xFF00694C) : Colors.transparent;
    final foreground = selected ? Colors.white : const Color(0xFF3D4943);

    return Material(
      color: background,
      borderRadius: BorderRadius.circular(8),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(8),
        child: Container(
          height: 44,
          alignment: Alignment.center,
          child: FittedBox(
            fit: BoxFit.scaleDown,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(icon, color: foreground, size: 15),
                const SizedBox(width: 6),
                Text(
                  label,
                  style: TextStyle(
                    color: foreground,
                    fontSize: 14,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _LoginFormHeader extends StatelessWidget {
  const _LoginFormHeader({
    required this.isSalesman,
  });

  final bool isSalesman;

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          isSalesman ? 'সেলসম্যান লগইন' : 'মার্চেন্ট লগইন',
          style: const TextStyle(
            fontSize: 28,
            fontWeight: FontWeight.w700,
            color: Color(0xFF131D21),
            letterSpacing: -0.4,
          ),
        ),
        const SizedBox(height: 8),
        Text(
          isSalesman
              ? 'সেলসম্যান মোবাইল নম্বর ও PIN ব্যবহার করে লগইন করুন'
              : 'মার্চেন্ট/অ্যাডমিন মোবাইল নম্বর ও পাসওয়ার্ড ব্যবহার করে লগইন করুন',
          style: const TextStyle(
            fontSize: 14,
            height: 1.4,
            color: Color(0xFF3D4943),
          ),
        ),
      ],
    );
  }
}

class _LoginInputField extends StatelessWidget {
  const _LoginInputField({
    required this.label,
    required this.hintText,
    required this.helperText,
    this.prefix,
    this.obscureText = false,
    this.onToggleObscure,
    this.keyboardType,
    this.controller,
    this.inputFormatters,
  });

  final String label;
  final String hintText;
  final String helperText;
  final Widget? prefix;
  final bool obscureText;
  final VoidCallback? onToggleObscure;
  final TextInputType? keyboardType;
  final TextEditingController? controller;
  final List<TextInputFormatter>? inputFormatters;

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label,
          style: const TextStyle(
            fontSize: 16,
            fontWeight: FontWeight.w700,
            color: Color(0xFF3D4943),
          ),
        ),
        const SizedBox(height: 8),
        SizedBox(
          height: 50,
          child: Row(
            children: [
              if (prefix != null) ...[
                prefix!,
                const SizedBox(width: 8),
              ],
              Expanded(
                child: TextField(
                  controller: controller,
                  keyboardType: keyboardType,
                  obscureText: obscureText,
                  obscuringCharacter: '•',
                  cursorColor: const Color(0xFF00694C),
                  inputFormatters: inputFormatters,
                  style: const TextStyle(
                    color: Color(0xFF131D21),
                    fontSize: 16,
                    fontWeight: FontWeight.w600,
                  ),
                  decoration: InputDecoration(
                    hintText: hintText,
                    hintStyle: const TextStyle(
                      color: Color(0xFF93A1A7),
                      fontSize: 16,
                    ),
                    filled: true,
                    fillColor: Colors.white,
                    contentPadding: const EdgeInsets.symmetric(
                      horizontal: 16,
                      vertical: 14,
                    ),
                    enabledBorder: OutlineInputBorder(
                      borderSide: const BorderSide(color: Color(0xFFBCCAC1)),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    focusedBorder: OutlineInputBorder(
                      borderSide: const BorderSide(color: Color(0xFF00694C), width: 1.4),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    suffixIcon: onToggleObscure == null
                        ? null
                        : IconButton(
                            onPressed: onToggleObscure,
                            icon: Icon(
                              obscureText ? Icons.visibility_off_outlined : Icons.visibility_outlined,
                              color: const Color(0xFF6D7A73),
                            ),
                          ),
                  ),
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 4),
        Text(
          helperText,
          style: const TextStyle(
            fontSize: 11,
            color: Color(0xFF6D7A73),
          ),
        ),
      ],
    );
  }
}

class _CountryPrefix extends StatelessWidget {
  const _CountryPrefix();

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 56,
      height: 50,
      alignment: Alignment.center,
      decoration: BoxDecoration(
        color: Colors.white,
        border: Border.all(color: const Color(0xFFBCCAC1)),
        borderRadius: BorderRadius.circular(12),
      ),
      child: const Text(
        '+88',
        style: TextStyle(
          fontSize: 16,
          color: Color(0xFF131D21),
        ),
      ),
    );
  }
}

class _FieldIcon extends StatelessWidget {
  const _FieldIcon({required this.icon});

  final IconData icon;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 50,
      height: 50,
      alignment: Alignment.center,
      decoration: BoxDecoration(
        color: Colors.white,
        border: Border.all(color: const Color(0xFFBCCAC1)),
        borderRadius: BorderRadius.circular(12),
      ),
      child: Icon(icon, size: 18, color: const Color(0xFF6D7A73)),
    );
  }
}

class _RememberForgotRow extends StatelessWidget {
  const _RememberForgotRow({
    required this.rememberMe,
    required this.onRememberChanged,
    required this.onForgotPressed,
  });

  final bool rememberMe;
  final ValueChanged<bool?> onRememberChanged;
  final VoidCallback? onForgotPressed;

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Expanded(
          child: InkWell(
            onTap: () => onRememberChanged(!rememberMe),
            borderRadius: BorderRadius.circular(8),
            child: Align(
              alignment: Alignment.centerLeft,
              child: FittedBox(
                fit: BoxFit.scaleDown,
                alignment: Alignment.centerLeft,
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Container(
                      width: 20,
                      height: 20,
                      decoration: BoxDecoration(
                        color: Colors.white,
                        border: Border.all(color: const Color(0xFFBCCAC1)),
                        borderRadius: BorderRadius.circular(4),
                      ),
                      child: rememberMe
                          ? const Icon(Icons.check_rounded, size: 14, color: Color(0xFF00694C))
                          : null,
                    ),
                    const SizedBox(width: 8),
                    const Text(
                      'মনে রাখুন',
                      style: TextStyle(
                        fontSize: 14,
                        color: Color(0xFF3D4943),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
        const SizedBox(width: 12),
        Flexible(
          child: Align(
            alignment: Alignment.centerRight,
            child: TextButton(
              onPressed: onForgotPressed,
              style: TextButton.styleFrom(
                foregroundColor: const Color(0xFF00694C),
                padding: EdgeInsets.zero,
                minimumSize: Size.zero,
                tapTargetSize: MaterialTapTargetSize.shrinkWrap,
              ),
              child: const FittedBox(
                fit: BoxFit.scaleDown,
                child: Text(
                  'পাসওয়ার্ড ভুলে গেছেন?',
                  style: TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ),
            ),
          ),
        ),
      ],
    );
  }
}

class _PrimaryActionButton extends StatelessWidget {
  const _PrimaryActionButton({
    required this.label,
    required this.onPressed,
  });

  final String label;
  final VoidCallback? onPressed;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 60,
      width: double.infinity,
      child: ElevatedButton(
        onPressed: onPressed,
        style: ElevatedButton.styleFrom(
          backgroundColor: const Color(0xFF00694C),
          foregroundColor: Colors.white,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(12),
          ),
          elevation: 0,
        ),
        child: Stack(
          alignment: Alignment.center,
          children: [
            Positioned.fill(
              child: DecoratedBox(
                decoration: BoxDecoration(
                  color: Colors.white.withValues(alpha: 0.01),
                  borderRadius: BorderRadius.circular(12),
                  boxShadow: const [
                    BoxShadow(
                      color: Color(0x3300694C),
                      blurRadius: 18,
                      offset: Offset(0, 8),
                    ),
                  ],
                ),
              ),
            ),
            Text(
              label,
              style: const TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.w700,
                letterSpacing: 0.3,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _DividerWithLabel extends StatelessWidget {
  const _DividerWithLabel({required this.label});

  final String label;

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        const Expanded(
          child: Divider(color: Color(0xFFBCCAC1), thickness: 1),
        ),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16),
          child: Text(
            label,
            style: const TextStyle(
              fontSize: 14,
              color: Color(0xFF6D7A73),
            ),
          ),
        ),
        const Expanded(
          child: Divider(color: Color(0xFFBCCAC1), thickness: 1),
        ),
      ],
    );
  }
}

class _OutlineActionButton extends StatelessWidget {
  const _OutlineActionButton({
    required this.label,
    required this.icon,
    required this.onPressed,
  });

  final String label;
  final IconData icon;
  final VoidCallback? onPressed;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 50,
      width: double.infinity,
      child: OutlinedButton(
        onPressed: onPressed,
        style: OutlinedButton.styleFrom(
          side: const BorderSide(color: Color(0xFFBCCAC1)),
          foregroundColor: const Color(0xFF3D4943),
          backgroundColor: Colors.white,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(12),
          ),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, color: const Color(0xFF00694C), size: 18),
            const SizedBox(width: 8),
            Text(
              label,
              style: const TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.w700,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _RegistrationLink extends StatelessWidget {
  const _RegistrationLink({
    required this.label,
    required this.onPressed,
  });

  final String label;
  final VoidCallback? onPressed;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Center(
        child: FittedBox(
          fit: BoxFit.scaleDown,
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Text(
                'নতুন দোকান তৈরি করতে চান? ',
                style: TextStyle(
                  fontSize: 14,
                  color: Color(0xFF3D4943),
                ),
              ),
              TextButton(
                onPressed: onPressed,
                style: TextButton.styleFrom(
                  foregroundColor: const Color(0xFF00694C),
                  padding: EdgeInsets.zero,
                  minimumSize: Size.zero,
                  tapTargetSize: MaterialTapTargetSize.shrinkWrap,
                ),
                child: Text(
                  label,
                  style: TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _SecurityFooter extends StatelessWidget {
  const _SecurityFooter();

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.fromLTRB(20, 24, 20, 32),
      decoration: const BoxDecoration(
        color: Color(0xFF00694C),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: const [
          _SecurityBadge(
            icon: Icons.verified_user_rounded,
            title: 'নিরাপদ',
          ),
          _SecurityBadge(
            icon: Icons.support_agent_rounded,
            title: 'সাপোর্ট',
          ),
          _SecurityBadge(
            icon: Icons.lock_rounded,
            title: 'প্রোটেক্টেড',
          ),
        ],
      ),
    );
  }
}

class _SecurityBadge extends StatelessWidget {
  const _SecurityBadge({
    required this.icon,
    required this.title,
  });

  final IconData icon;
  final String title;

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Container(
          width: 40,
          height: 40,
          decoration: BoxDecoration(
            color: Colors.white.withValues(alpha: 0.10),
            borderRadius: BorderRadius.circular(12),
          ),
          child: Icon(icon, color: Colors.white, size: 18),
        ),
        const SizedBox(height: 8),
        Text(
          title,
          style: const TextStyle(
            color: Colors.white,
            fontSize: 12,
            fontWeight: FontWeight.w600,
          ),
        ),
      ],
    );
  }
}

