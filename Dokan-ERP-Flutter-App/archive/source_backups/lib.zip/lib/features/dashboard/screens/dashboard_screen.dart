﻿import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../app/dokan_app_providers.dart';
import '../../notifications/screens/notification_center_screen.dart';
import '../../pos/screens/pos_screens.dart';
import '../../products/screens/product_screens.dart';
import '../../reports/screens/reports_screens.dart';
import '../../settings/screens/settings_screens.dart';

class DokanHomeDashboardScreen extends ConsumerWidget {
  const DokanHomeDashboardScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final flow = ref.watch(dokanAppFlowProvider);
    final selectedCount = ref.read(dokanPopularProductsProvider.notifier).selectedCount;
    final catalogProducts = ref.watch(dokanInventoryCatalogProvider);
    final threshold = ref.watch(stockThresholdProvider);
    final lowStockCount = catalogProducts.where((product) => product.stock > 0 && product.stock < threshold).length;
    final todayLabel = _todayLabel();

    return Scaffold(
      backgroundColor: const Color(0xFFEAF5FB),
      body: SafeArea(
        bottom: false,
        child: LayoutBuilder(
          builder: (context, constraints) {
            const footerHeight = 58.0;
            return Stack(
              children: [
                Positioned.fill(
                  child: Column(
                    children: [
                      Padding(
                        padding: const EdgeInsets.fromLTRB(18, 8, 18, 10),
                        child: Row(
                          children: [
                            _HeaderIconButton(
                              icon: Icons.menu_rounded,
                              onTap: () => Navigator.of(context).push(
                                MaterialPageRoute(builder: (_) => const DokanAroOptionScreen()),
                              ),
                            ),
                            const SizedBox(width: 8),
                            Expanded(
                              child: Column(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  FittedBox(
                                    fit: BoxFit.scaleDown,
                                    child: Text(
                                      flow.shopName,
                                      textAlign: TextAlign.center,
                                      style: const TextStyle(
                                        color: Color(0xFF0D6B55),
                                        fontSize: 26,
                                        fontWeight: FontWeight.w800,
                                        height: 1.0,
                                      ),
                                    ),
                                  ),
                                  const SizedBox(height: 4),
                                  const Row(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    mainAxisSize: MainAxisSize.min,
                                    children: [
                                      Icon(Icons.circle, size: 10, color: Color(0xFF17A572)),
                                      SizedBox(width: 8),
                                      Text(
                                        'অনলাইন',
                                        style: TextStyle(
                                          color: Color(0xFF17A572),
                                          fontSize: 15,
                                          fontWeight: FontWeight.w600,
                                        ),
                                      ),
                                    ],
                                  ),
                                ],
                              ),
                            ),
                            const SizedBox(width: 8),
                            AnimatedBuilder(
                              animation: dokanNotificationListenable,
                              builder: (context, _) {
                                return _HeaderIconButton(
                                  icon: Icons.notifications_none_rounded,
                                  onTap: () => showDokanNotificationPreviewSheet(context),
                                  badge: dokanNotificationUnreadCount > 0,
                                );
                              },
                            ),
                            const SizedBox(width: 8),
                            _HeaderIconButton(
                              icon: Icons.mic_none_rounded,
                              onTap: () => Navigator.of(context).push(
                                MaterialPageRoute(builder: (_) => const DokanAroOptionScreen()),
                              ),
                            ),
                          ],
                        ),
                      ),
                      const Divider(height: 1, color: Color(0xFFD6E3E4)),
                      Expanded(
                        child: SingleChildScrollView(
                          physics: const ClampingScrollPhysics(),
                          padding: const EdgeInsets.fromLTRB(20, 16, 20, footerHeight + 60),
                          child: ConstrainedBox(
                            constraints: BoxConstraints(minHeight: constraints.maxHeight - 110),
                            child: Column(
                              mainAxisSize: MainAxisSize.min,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                _SalesSummaryCard(
                                  dateLabel: todayLabel,
                                  totalSales: '৳ ৮,৮৫০',
                                  totalOrders: '৩২টি',
                                  profit: '৳ ৪,২৪০',
                                  onTap: () => Navigator.of(context).push(
                                    MaterialPageRoute(
                                      builder: (_) => const DokanDailySalesReportScreen(),
                                    ),
                                  ),
                                ),
                                const SizedBox(height: 12),
                                GridView.count(
                                  crossAxisCount: 2,
                                  crossAxisSpacing: 12,
                                  mainAxisSpacing: 12,
                                  shrinkWrap: true,
                                  physics: const NeverScrollableScrollPhysics(),
                                  childAspectRatio: 1.7,
                                  children: [
                                    _StatCard(
                                      background: const Color(0xFFF8ECD2),
                                      tint: const Color(0xFF8D6B12),
                                      icon: Icons.warning_amber_rounded,
                                      label: 'কম স্টক',
                                      value: '${_bengaliNumber(lowStockCount)}টি',
                                      onTap: () => Navigator.of(context).push(
                                        MaterialPageRoute(
                                          builder: (_) => const DokanLowStockAlertListScreen(),
                                        ),
                                      ),
                                    ),
                                    _StatCard(
                                      background: const Color(0xFFFCE7E8),
                                      tint: const Color(0xFFB11E24),
                                      icon: Icons.menu_book_rounded,
                                      label: 'মোট বাকী',
                                      value: '৳ ৮,৫০০',
                                      onTap: () => Navigator.of(context).push(
                                        MaterialPageRoute(
                                          builder: (_) => const DokanProfitLossReportScreen(),
                                        ),
                                      ),
                                    ),
                                    _StatCard(
                                      background: const Color(0xFFE7F0FF),
                                      tint: const Color(0xFF1F63E0),
                                      icon: Icons.shopping_cart_outlined,
                                      label: 'আজকের ক্রয়',
                                      value: '৳ ১২,০০০',
                                      onTap: () => Navigator.of(context).push(
                                        MaterialPageRoute(
                                          builder: (_) => DokanPosMainScreen(key: UniqueKey()),
                                        ),
                                      ),
                                    ),
                                    _StatCard(
                                      background: const Color(0xFFE2F3E8),
                                      tint: const Color(0xFF0E7B58),
                                      icon: Icons.inventory_2_outlined,
                                      label: 'মোট পণ্য',
                                      value: '${_bengaliNumber(selectedCount)}টি',
                                      onTap: () => Navigator.of(context).push(
                                        MaterialPageRoute(
                                          builder: (_) => const DokanProductListScreen(),
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                                const SizedBox(height: 12),
                                Row(
                                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                  children: [
                                    const Text(
                                      'সাম্প্রতিক পণ্য',
                                      style: TextStyle(
                                        color: Color(0xFF1D2624),
                                        fontSize: 22,
                                        fontWeight: FontWeight.w700,
                                      ),
                                    ),
                                    TextButton(
                                      onPressed: () => Navigator.of(context).push(
                                        MaterialPageRoute(
                                          builder: (_) => const DokanProductListScreen(),
                                        ),
                                      ),
                                      style: TextButton.styleFrom(
                                        foregroundColor: const Color(0xFF0E7B58),
                                        padding: EdgeInsets.zero,
                                        minimumSize: Size.zero,
                                        tapTargetSize: MaterialTapTargetSize.shrinkWrap,
                                      ),
                                      child: const Text(
                                        'সব দেখুন',
                                        style: TextStyle(
                                          fontSize: 15,
                                          fontWeight: FontWeight.w600,
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                                const SizedBox(height: 8),
                                SizedBox(
                                  height: 120,
                                  child: ListView.separated(
                                    scrollDirection: Axis.horizontal,
                                    itemCount: _recentProducts.length,
                                    separatorBuilder: (context, _) => const SizedBox(width: 12),
                                    itemBuilder: (context, index) {
                                      final product = _recentProducts[index];
                                      return _ProductCard(
                                        title: product.title,
                                        price: product.price,
                                        icon: product.icon,
                                        colors: product.colors,
                                        onTap: () => Navigator.of(context).push(
                                          MaterialPageRoute(
                                            builder: (_) => const DokanProductDetailScreen(),
                                          ),
                                        ),
                                      );
                                    },
                                  ),
                                ),
                                const SizedBox(height: 10),
                                _AnalysisCard(
                                  title: 'বিক্রয় বিশ্লেষণ',
                                  subtitle: 'গত ৭ দিনের তুলনায় ১৫% বৃদ্ধি',
                                  onTap: () => Navigator.of(context).push(
                                    MaterialPageRoute(
                                      builder: (_) => const DokanReportsHomeScreen(),
                                    ),
                                  ),
                                ),
                                const SizedBox(height: 6),
                                Align(
                                  alignment: Alignment.centerRight,
                                  child: _MicFab(
                                    onTap: () => Navigator.of(context).push(
                                      MaterialPageRoute(
                                        builder: (_) => const DokanNotificationCenterScreen(),
                                      ),
                                    ),
                                  ),
                                ),
                                const SizedBox(height: 26),
                              ],
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                Align(
                  alignment: Alignment.bottomCenter,
                  child: Container(
                    height: footerHeight + MediaQuery.of(context).padding.bottom,
                    decoration: const BoxDecoration(
                      color: Colors.white,
                      border: Border(top: BorderSide(color: Color(0xFFE1E8E6))),
                    ),
                    padding: EdgeInsets.fromLTRB(
                      12,
                      2,
                      12,
                      2 + MediaQuery.of(context).padding.bottom,
                    ),
                    child: Row(
                      children: [
                        _BottomNavItem(
                          icon: Icons.home_rounded,
                          label: 'হোম',
                          selected: true,
                          onTap: () {},




                        ),
                        _BottomNavItem(
                          icon: Icons.calculate_rounded,
                          label: 'বিক্রয়',
                          onTap: () => Navigator.of(context).push(
                            MaterialPageRoute(
                              builder: (_) => const DokanPosMainScreen(),
                            ),
                          ),
                        ),
                        _BottomNavItem(
                          icon: Icons.inventory_2_rounded,
                          label: 'পণ্য',
                          onTap: () => Navigator.of(context).push(
                            MaterialPageRoute(
                              builder: (_) => const DokanProductListScreen(),
                            ),
                          ),
                        ),
                        _BottomNavItem(
                          icon: Icons.bar_chart_rounded,
                          label: 'রিপোর্ট',
                          onTap: () => Navigator.of(context).push(
                            MaterialPageRoute(
                              builder: (_) => const DokanReportsHomeScreen(),
                            ),
                          ),
                        ),
                        _BottomNavItem(
                          icon: Icons.more_horiz_rounded,
                          label: 'আরও',
                          onTap: () => Navigator.of(context).push(
                            MaterialPageRoute(
                              builder: (_) => const DokanAroOptionScreen(),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            );
          },
        ),
      ),
    );
  }
}

class _HeaderIconButton extends StatelessWidget {
  const _HeaderIconButton({
    required this.icon,
    required this.onTap,
    this.badge = false,
  });

  final IconData icon;
  final VoidCallback onTap;
  final bool badge;

  @override
  Widget build(BuildContext context) {
    return Stack(
      clipBehavior: Clip.none,
      children: [
        Material(
          color: Colors.transparent,
          child: InkResponse(
            onTap: onTap,
            radius: 24,
            child: SizedBox(
              width: 34,
              height: 34,
              child: Icon(icon, color: const Color(0xFF30413D), size: 28),
            ),
          ),
        ),
        if (badge)
          Positioned(
            right: 1,
            top: 1,
            child: Container(
              width: 7,
              height: 7,
              decoration: const BoxDecoration(
                color: Color(0xFFD63B32),
                shape: BoxShape.circle,
              ),
            ),
          ),
      ],
    );
  }
}

class _SalesSummaryCard extends StatelessWidget {
  const _SalesSummaryCard({
    required this.dateLabel,
    required this.totalSales,
    required this.totalOrders,
    required this.profit,
    this.onTap,
  });

  final String dateLabel;
  final String totalSales;
  final String totalOrders;
  final String profit;
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(26),
        child: Container(
          width: double.infinity,
          padding: const EdgeInsets.all(20),
          decoration: BoxDecoration(
            gradient: const LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [Color(0xFF0EAA74), Color(0xFF0B7A5E)],
            ),
            borderRadius: BorderRadius.circular(26),
            boxShadow: const [
              BoxShadow(
                color: Color(0x26000000),
                blurRadius: 20,
                offset: Offset(0, 12),
              ),
            ],
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  const Text(
                    'আজকের বিক্রয়',
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 18,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                  const Spacer(),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 9),
                    decoration: BoxDecoration(
                      color: Colors.white.withValues(alpha: 0.18),
                      borderRadius: BorderRadius.circular(18),
                    ),
                    child: Text(
                      dateLabel,
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 13,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 8),
              Text(
                totalSales,
                style: const TextStyle(
                  color: Colors.white,
                  fontSize: 40,
                  fontWeight: FontWeight.w700,
                  height: 1.0,
                ),
              ),
              const SizedBox(height: 16),
              Container(height: 1, color: Colors.white.withValues(alpha: 0.14)),
              const SizedBox(height: 14),
              Row(
                children: [
                  Expanded(
                    child: _MetricBlock(label: 'মোট বিক্রয়', value: totalOrders),
                  ),
                  Expanded(
                    child: _MetricBlock(label: 'লাভ', value: profit),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _MetricBlock extends StatelessWidget {
  const _MetricBlock({
    required this.label,
    required this.value,
  });

  final String label;
  final String value;

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label,
          style: TextStyle(
            color: Colors.white.withValues(alpha: 0.82),
            fontSize: 15,
            fontWeight: FontWeight.w500,
          ),
        ),
        const SizedBox(height: 6),
        Text(
          value,
          style: const TextStyle(
            color: Colors.white,
            fontSize: 20,
            fontWeight: FontWeight.w700,
          ),
        ),
      ],
    );
  }
}

class _StatCard extends StatelessWidget {
  const _StatCard({
    required this.background,
    required this.tint,
    required this.icon,
    required this.label,
    required this.value,
    this.onTap,
  });

  final Color background;
  final Color tint;
  final IconData icon;
  final String label;
  final String value;
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(22),
        child: Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: background,
            borderRadius: BorderRadius.circular(22),
            border: Border.all(color: tint.withValues(alpha: 0.14)),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Row(
                children: [
                  Icon(icon, color: tint, size: 30),
                  const Spacer(),
                  Text(
                    value,
                    style: TextStyle(
                      color: tint,
                      fontSize: 20,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                ],
              ),
              Text(
                label,
                style: TextStyle(
                  color: tint.withValues(alpha: 0.95),
                  fontSize: 15,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _AnalysisCard extends StatelessWidget {
  const _AnalysisCard({
    required this.title,
    required this.subtitle,
    this.onTap,
  });

  final String title;
  final String subtitle;
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(20),
        child: Container(
          width: double.infinity,
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: const Color(0xFFE8F1F0),
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: const Color(0xFFCCD8D5)),
          ),
          child: Row(
            children: [
              Container(
                width: 40,
                height: 40,
                decoration: BoxDecoration(
                  color: const Color(0xFFD2E8E1),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: const Icon(
                  Icons.trending_up_rounded,
                  color: Color(0xFF0D7E5A),
                  size: 24,
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      title,
                      style: const TextStyle(
                        color: Color(0xFF1F2A28),
                        fontSize: 18,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                    const SizedBox(height: 3),
                    Text(
                      subtitle,
                      style: const TextStyle(
                        color: Color(0xFF50615B),
                        fontSize: 14,
                        height: 1.25,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _RecentProduct {
  const _RecentProduct(this.title, this.price, this.icon, this.colors);

  final String title;
  final String price;
  final IconData icon;
  final List<Color> colors;
}

const List<_RecentProduct> _recentProducts = <_RecentProduct>[
  _RecentProduct(
    'মিনিকেট চাল',
    '৳ ৭৫',
    Icons.rice_bowl_rounded,
    [Color(0xFFF4F1E7), Color(0xFFE7DDD0)],
  ),
  _RecentProduct(
    'সয়াবিন তেল',
    '৳ ১৬৫',
    Icons.oil_barrel_rounded,
    [Color(0xFFF6E5A8), Color(0xFFD6B64E)],
  ),
  _RecentProduct(
    'লবণ',
    '৳ ২৫',
    Icons.spa_rounded,
    [Color(0xFFE5F0EC), Color(0xFFCFE0D8)],
  ),
];

class _ProductCard extends StatelessWidget {
  const _ProductCard({
    required this.title,
    required this.price,
    required this.icon,
    required this.colors,
    this.onTap,
  });

  final String title;
  final String price;
  final IconData icon;
  final List<Color> colors;
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(18),
        child: Container(
          width: 146,
          height: 112,
          padding: const EdgeInsets.all(7),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(18),
            border: Border.all(color: const Color(0xFFD5DEDB)),
            boxShadow: const [
              BoxShadow(
                color: Color(0x0A000000),
                blurRadius: 10,
                offset: Offset(0, 5),
              ),
            ],
          ),
          child: Column(
            mainAxisSize: MainAxisSize.max,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                height: 56,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(14),
                  gradient: LinearGradient(
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                    colors: colors,
                  ),
                ),
                child: Center(
                  child: Container(
                    width: 38,
                    height: 38,
                    decoration: BoxDecoration(
                      color: Colors.white.withValues(alpha: 0.9),
                      shape: BoxShape.circle,
                    ),
                    child: Icon(icon, color: const Color(0xFF116C55), size: 22),
                  ),
                ),
              ),
              const SizedBox(height: 4),
              Text(
                title,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(
                  color: Color(0xFF22302C),
                  fontSize: 13,
                  fontWeight: FontWeight.w600,
                  height: 1.0,
                ),
              ),
              const SizedBox(height: 2),
              Text(
                price,
                style: const TextStyle(
                  color: Color(0xFF0E7B58),
                  fontSize: 14,
                  fontWeight: FontWeight.w700,
                  height: 1.0,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _MicFab extends StatelessWidget {
  const _MicFab({required this.onTap});

  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: const Color(0xFF0A7B59),
      shape: const CircleBorder(),
      elevation: 10,
      child: InkWell(
        onTap: onTap,
        customBorder: const CircleBorder(),
        child: const SizedBox(
          width: 56,
          height: 56,
          child: Icon(Icons.mic_none_rounded, color: Colors.white, size: 28),
        ),
      ),
    );
  }
}

class _BottomNavItem extends StatelessWidget {
  const _BottomNavItem({
    required this.icon,
    required this.label,
    this.selected = false,
    this.onTap,
  });

  final IconData icon;
  final String label;
  final bool selected;
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) {
    final color = selected ? const Color(0xFF0E7B58) : const Color(0xFF485652);
    return Expanded(
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: onTap,
          borderRadius: BorderRadius.circular(16),
          child: Padding(
            padding: const EdgeInsets.symmetric(vertical: 2),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(icon, color: color, size: 26),
                const SizedBox(height: 1),
                Text(
                  label,
                  style: TextStyle(
                    color: color,
                    fontSize: 12,
                    fontWeight: selected ? FontWeight.w700 : FontWeight.w500,
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

String _todayLabel() {
  const weekdays = ['রবি', 'সোম', 'মঙ্গল', 'বুধ', 'বৃহস্পতি', 'শুক্র', 'শনি'];
  const months = ['জানু', 'ফেব', 'মার্চ', 'এপ্রি', 'মে', 'জুন', 'জুল', 'আগ', 'সেপ', 'অক্টো', 'নভে', 'ডিসে'];
  final now = DateTime.now();
  final weekday = weekdays[now.weekday % 7];
  return '$weekday, ${now.day} ${months[now.month - 1]} ${now.year}';
}

String _bengaliNumber(int value) {
  const digits = ['০', '১', '২', '৩', '৪', '৫', '৬', '৭', '৮', '৯'];
  return value.toString().split('').map((digit) {
    final index = int.tryParse(digit);
    return index == null ? digit : digits[index];
  }).join();
}
