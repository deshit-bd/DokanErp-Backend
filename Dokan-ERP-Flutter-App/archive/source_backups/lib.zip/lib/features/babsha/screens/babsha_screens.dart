import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:url_launcher/url_launcher.dart';

import '../../pos/state/pos_checkout_provider.dart';
import '../../reports/screens/expense_entry_screen.dart';
import '../../../shared/widgets/dokan_placeholder_screen.dart';

String _banglaDigits(String input) {
  const map = <String, String>{
    '0': '০',
    '1': '১',
    '2': '২',
    '3': '৩',
    '4': '৪',
    '5': '৫',
    '6': '৬',
    '7': '৭',
    '8': '৮',
    '9': '৯',
  };
  return input.split('').map((char) => map[char] ?? char).join();
}

String _formatCurrency(int value) {
  final digits = value.toString().replaceAllMapped(
        RegExp(r'(\d)(?=(\d{3})+(?!\d))'),
        (match) => '${match[1]},',
      );
  return '৳ ${_banglaDigits(digits)}';
}

String _formatDate(DateTime date) {
  const months = <String>[
    'জানুয়ারি',
    'ফেব্রুয়ারি',
    'মার্চ',
    'এপ্রিল',
    'মে',
    'জুন',
    'জুলাই',
    'আগস্ট',
    'সেপ্টেম্বর',
    'অক্টোবর',
    'নভেম্বর',
    'ডিসেম্বর',
  ];
  return '${_banglaDigits(date.day.toString())} ${months[date.month - 1]} ${_banglaDigits(date.year.toString())}';
}

String _formatDateTime(DateTime date) {
  final hour = date.hour % 12 == 0 ? 12 : date.hour % 12;
  final minute = date.minute.toString().padLeft(2, '0');
  final period = date.hour >= 12 ? 'PM' : 'AM';
  return '${_formatDate(date)} • ${_banglaDigits(hour.toString())}:${_banglaDigits(minute)} $period';
}

String _formatShortTime(DateTime date) {
  final hour = date.hour % 12 == 0 ? 12 : date.hour % 12;
  final minute = date.minute.toString().padLeft(2, '0');
  final period = date.hour >= 12 ? 'PM' : 'AM';
  return '${_banglaDigits(hour.toString())}:${_banglaDigits(minute)} $period';
}

String _customerKeyForOrder(DokanPosOrderRecord order) {
  final phone = order.customerNumber.trim();
  if (phone.isNotEmpty) {
    return phone;
  }
  return order.customerName.trim().toLowerCase();
}

String _customerDisplayName(String value) {
  final text = value.trim();
  return text.isEmpty ? 'গ্রাহক' : text;
}

String _customerAddress(String value) {
  final text = value.trim();
  return text.isEmpty ? 'সংরক্ষিত নেই' : text;
}

String _supplierAddress(String value) {
  final text = value.trim();
  return text.isEmpty ? 'ঠিকানা নেই' : text;
}

String _supplierMaskedPhone(String value) {
  final digits = value.replaceAll(RegExp(r'[^0-9]'), '');
  if (digits.isEmpty) {
    return 'ফোন নেই';
  }
  if (digits.length <= 4) {
    return digits;
  }
  final lastFour = digits.substring(digits.length - 4);
  final prefix = digits.startsWith('880') ? '+880' : digits.startsWith('01') ? '01' : digits.substring(0, 2);
  return '$prefix••••$lastFour';
}

String _supplierInitials(String value) {
  final parts = value.trim().split(RegExp(r'\s+')).where((part) => part.isNotEmpty).toList(growable: false);
  if (parts.isEmpty) {
    return 'স';
  }
  if (parts.length == 1) {
    return parts.first.substring(0, 1).toUpperCase();
  }
  return '${parts.first.substring(0, 1).toUpperCase()}${parts.last.substring(0, 1).toUpperCase()}';
}

String _supplierPhoneDigits(String value) {
  return value.replaceAll(RegExp(r'[^0-9]'), '');
}

String _supplierPhoneForWhatsApp(String value) {
  final digits = _supplierPhoneDigits(value);
  if (digits.startsWith('880')) {
    return digits;
  }
  if (digits.startsWith('01') && digits.length == 11) {
    return '88$digits';
  }
  return digits;
}

String _customerInitials(String value) {
  final parts = value
      .trim()
      .split(RegExp(r'\s+'))
      .where((part) => part.isNotEmpty)
      .toList(growable: false);
  if (parts.isEmpty) {
    return 'গ';
  }
  if (parts.length == 1) {
    return String.fromCharCode(parts.first.runes.first);
  }
  return '${String.fromCharCode(parts.first.runes.first)}${String.fromCharCode(parts[1].runes.first)}';
}

class DokanAddExpenseScreen extends StatelessWidget {
  const DokanAddExpenseScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return const DokanExpenseEntryScreen();
  }
}

class DokanExpenseListScreen extends StatelessWidget {
  const DokanExpenseListScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return const DokanPlaceholderScreen(
      title: 'DokanERP Expense List Screen',
      subtitle: 'View and manage recorded expenses.',
    );
  }
}

class DokanAddNewStaffScreen extends ConsumerStatefulWidget {
  const DokanAddNewStaffScreen({super.key, this.staffKey});

  final String? staffKey;

  @override
  ConsumerState<DokanAddNewStaffScreen> createState() => _DokanAddNewStaffScreenState();
}

class _DokanAddNewStaffScreenState extends ConsumerState<DokanAddNewStaffScreen> {
  final TextEditingController _nameController = TextEditingController();
  final TextEditingController _phoneController = TextEditingController();
  final TextEditingController _addressController = TextEditingController();
  final TextEditingController _noteController = TextEditingController();
  bool _isSubmitting = false;
  String? _nameError;
  String? _phoneError;
  String? _roleError;
  String _role = 'Salesman';

  static const List<String> _roles = <String>['Salesman', 'Manager', 'Cashier', 'Other'];

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      final staff = _resolveStaff();
      if (staff == null || !mounted) {
        return;
      }
      setState(() {
        _nameController.text = staff.name;
        _phoneController.text = staff.phone;
        _addressController.text = staff.address;
        _noteController.text = staff.note;
        _role = staff.role;
      });
    });
  }

  _StaffSummary? _resolveStaff() {
    if (widget.staffKey == null) {
      return null;
    }
    final state = ref.read(dokanPosProvider);
    final staff = _buildStaffSummaries(state).where((item) => item.key == widget.staffKey).toList(growable: false);
    return staff.isEmpty ? null : staff.first;
  }

  @override
  void dispose() {
    _nameController.dispose();
    _phoneController.dispose();
    _addressController.dispose();
    _noteController.dispose();
    super.dispose();
  }

  bool _isValidMobile(String value) => RegExp(r'^(?:\+8801|01)[0-9]{9}$').hasMatch(value.trim());

  void _validate() {
    setState(() {
      _nameError = _nameController.text.trim().isEmpty ? 'নাম দেওয়া বাধ্যতামূলক' : null;
      final phone = _phoneController.text.trim();
      if (phone.isEmpty) {
        _phoneError = 'নম্বর খালি রাখা যাবে না';
      } else if (!_isValidMobile(phone)) {
        _phoneError = 'সঠিক মোবাইল নম্বর দিন';
      } else {
        _phoneError = null;
      }
      _roleError = _role.trim().isEmpty ? 'ভূমিকা নির্বাচন করুন' : null;
    });
  }

  bool get _canSubmit {
    return !_isSubmitting &&
        _nameController.text.trim().isNotEmpty &&
        _phoneController.text.trim().isNotEmpty &&
        _isValidMobile(_phoneController.text) &&
        _role.trim().isNotEmpty;
  }

  Future<void> _save() async {
    _validate();
    if (!_canSubmit) {
      return;
    }

    setState(() => _isSubmitting = true);
    ref.read(dokanPosProvider.notifier).addStaff(
          name: _nameController.text,
          phone: _phoneController.text,
          role: _role,
          address: _addressController.text,
          note: _noteController.text,
          permissions: _defaultPermissionsForRole(_role),
        );

    if (!mounted) {
      return;
    }

    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('কর্মচারী সংরক্ষণ করা হয়েছে')),
    );
    Navigator.of(context).pop(true);
  }

  @override
  Widget build(BuildContext context) {
    final canSubmit = _canSubmit;

    return Scaffold(
      backgroundColor: const Color(0xFFF4F8F6),
      body: SafeArea(
        child: ListView(
          physics: const AlwaysScrollableScrollPhysics(parent: ClampingScrollPhysics()),
          padding: const EdgeInsets.fromLTRB(16, 12, 16, 24),
          children: [
            Row(
              children: [
                _HeaderButton(
                  icon: Icons.arrow_back_rounded,
                  onTap: () => Navigator.of(context).maybePop(),
                ),
                const SizedBox(width: 12),
                const Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'নতুন কর্মচারী',
                        style: TextStyle(
                          color: Color(0xFF163732),
                          fontSize: 22,
                          fontWeight: FontWeight.w800,
                        ),
                      ),
                      SizedBox(height: 2),
                      Text(
                        'সহজ ফর্ম, পরিষ্কার যাচাই',
                        style: TextStyle(
                          color: Color(0xFF6B7B79),
                          fontSize: 13,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
            const SizedBox(height: 14),
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: const Color(0xFFD9E5E1)),
              ),
              child: Column(
                children: [
                  TextField(
                    controller: _nameController,
                    onChanged: (_) => _validate(),
                    style: const TextStyle(color: Color(0xFF111111)),
                    decoration: InputDecoration(
                      labelText: 'নাম *',
                      errorText: _nameError,
                      filled: true,
                      fillColor: const Color(0xFFF8FAF9),
                      border: OutlineInputBorder(borderRadius: BorderRadius.circular(16)),
                      enabledBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(16),
                        borderSide: const BorderSide(color: Color(0xFFD9E5E1)),
                      ),
                      focusedBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(16),
                        borderSide: const BorderSide(color: Color(0xFF0C8C67), width: 1.4),
                      ),
                    ),
                  ),
                  const SizedBox(height: 12),
                  TextField(
                    controller: _phoneController,
                    keyboardType: TextInputType.phone,
                    inputFormatters: [FilteringTextInputFormatter.allow(RegExp(r'[0-9+]'))],
                    onChanged: (_) => _validate(),
                    style: const TextStyle(color: Color(0xFF111111)),
                    decoration: InputDecoration(
                      labelText: 'মোবাইল নম্বর *',
                      hintText: '+8801XXXXXXXXX / 01XXXXXXXXX',
                      errorText: _phoneError,
                      filled: true,
                      fillColor: const Color(0xFFF8FAF9),
                      border: OutlineInputBorder(borderRadius: BorderRadius.circular(16)),
                      enabledBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(16),
                        borderSide: const BorderSide(color: Color(0xFFD9E5E1)),
                      ),
                      focusedBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(16),
                        borderSide: const BorderSide(color: Color(0xFF0C8C67), width: 1.4),
                      ),
                    ),
                  ),
                  const SizedBox(height: 12),
                  DropdownButtonFormField<String>(
                    initialValue: _role,
                    items: _roles
                        .map(
                          (role) => DropdownMenuItem<String>(
                            value: role,
                            child: Text(role),
                          ),
                        )
                        .toList(growable: false),
                    onChanged: (value) {
                      if (value == null) return;
                      setState(() => _role = value);
                      _validate();
                    },
                    decoration: InputDecoration(
                      labelText: 'ভূমিকা *',
                      errorText: _roleError,
                      filled: true,
                      fillColor: const Color(0xFFF8FAF9),
                      border: OutlineInputBorder(borderRadius: BorderRadius.circular(16)),
                    ),
                  ),
                  const SizedBox(height: 12),
                  TextField(
                    controller: _addressController,
                    style: const TextStyle(color: Color(0xFF111111)),
                    decoration: InputDecoration(
                      labelText: 'ঠিকানা',
                      filled: true,
                      fillColor: const Color(0xFFF8FAF9),
                      border: OutlineInputBorder(borderRadius: BorderRadius.circular(16)),
                    ),
                  ),
                  const SizedBox(height: 12),
                  TextField(
                    controller: _noteController,
                    maxLines: 3,
                    style: const TextStyle(color: Color(0xFF111111)),
                    decoration: InputDecoration(
                      labelText: 'নোট',
                      filled: true,
                      fillColor: const Color(0xFFF8FAF9),
                      border: OutlineInputBorder(borderRadius: BorderRadius.circular(16)),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 16),
            SizedBox(
              height: 52,
              child: FilledButton(
                onPressed: canSubmit ? _save : null,
                style: FilledButton.styleFrom(
                  backgroundColor: const Color(0xFF0C8C67),
                  foregroundColor: Colors.white,
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                ),
                child: _isSubmitting
                    ? const SizedBox(
                        width: 20,
                        height: 20,
                        child: CircularProgressIndicator(strokeWidth: 2.4, color: Colors.white),
                      )
                    : const Text('সংরক্ষণ'),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class DokanStaffListScreen extends ConsumerStatefulWidget {
  const DokanStaffListScreen({super.key});

  @override
  ConsumerState<DokanStaffListScreen> createState() => _DokanStaffListScreenState();
}

class _DokanStaffListScreenState extends ConsumerState<DokanStaffListScreen> {
  final TextEditingController _searchController = TextEditingController();
  final Set<String> _selectedKeys = <String>{};
  bool _selectionMode = false;
  bool _ready = false;
  String _query = '';

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted) setState(() => _ready = true);
    });
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  Future<void> _onRefresh() async {
    await Future<void>.delayed(const Duration(milliseconds: 350));
    if (mounted) setState(() {});
  }

  void _enterSelectionMode(_StaffSummary staff) {
    setState(() {
      _selectionMode = true;
      _selectedKeys.add(staff.key);
    });
  }

  void _toggleSelection(_StaffSummary staff) {
    setState(() {
      if (_selectedKeys.contains(staff.key)) {
        _selectedKeys.remove(staff.key);
      } else {
        _selectedKeys.add(staff.key);
        _selectionMode = true;
      }
      if (_selectedKeys.isEmpty) {
        _selectionMode = false;
      }
    });
  }

  void _clearSelection() {
    setState(() {
      _selectedKeys.clear();
      _selectionMode = false;
    });
  }

  Future<void> _deleteSelected(BuildContext context, WidgetRef ref, List<_StaffSummary> selected) async {
    if (selected.isEmpty) return;
    final confirmed = await _showBulkDeleteDialog(
      context: context,
      entityLabel: 'কর্মচারী',
      names: selected.map((e) => e.name).toList(growable: false),
    );
    if (!confirmed) return;
    for (final item in selected) {
      ref.read(dokanPosProvider.notifier).deleteStaff(item.key);
    }
    if (mounted) {
      _clearSelection();
      setState(() {});
    }
  }

  @override
  Widget build(BuildContext context) {
    if (!_ready) {
      return const _SupplierLoadingScreen();
    }

    final state = ref.watch(dokanPosProvider);
    final staff = _buildStaffSummaries(state);
    final q = _query.trim().toLowerCase();
    final filtered = q.isEmpty
        ? staff
        : staff.where((item) => item.name.toLowerCase().contains(q) || item.phone.toLowerCase().contains(q)).toList(growable: false);
    final total = staff.length;
    final active = staff.where((item) => item.active).length;
    final inactive = total - active;
    final selected = staff.where((item) => _selectedKeys.contains(item.key)).toList(growable: false);

    return Scaffold(
      backgroundColor: const Color(0xFFF4F8F6),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const DokanAddNewStaffScreen())),
        backgroundColor: const Color(0xFF0C8C67),
        foregroundColor: Colors.white,
        icon: const Icon(Icons.person_add_alt_1_rounded),
        label: const Text('কর্মচারী যোগ করুন'),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      ),
      bottomNavigationBar: _selectionMode
          ? SafeArea(
              top: false,
              child: Padding(
                padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
                child: SizedBox(
                  height: 52,
                  child: FilledButton.icon(
                    onPressed: selected.isEmpty ? null : () => _deleteSelected(context, ref, selected),
                    icon: const Icon(Icons.delete_rounded),
                    label: Text('ডিলিট করুন (${_banglaDigits(selected.length.toString())})'),
                    style: FilledButton.styleFrom(
                      backgroundColor: const Color(0xFFD6453A),
                      foregroundColor: Colors.white,
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                    ),
                  ),
                ),
              ),
            )
          : null,
      body: SafeArea(
        bottom: false,
        child: RefreshIndicator(
          onRefresh: _onRefresh,
          color: const Color(0xFF0C8C67),
          child: ListView(
            physics: const AlwaysScrollableScrollPhysics(parent: ClampingScrollPhysics()),
            padding: EdgeInsets.fromLTRB(16, 12, 16, _selectionMode ? 144 : 96),
            children: [
              Row(
                children: [
                  _HeaderButton(icon: Icons.arrow_back_rounded, onTap: () => Navigator.of(context).maybePop()),
                  const SizedBox(width: 12),
                  const Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'কর্মচারী',
                          style: TextStyle(color: Color(0xFF163732), fontSize: 22, fontWeight: FontWeight.w800),
                        ),
                        SizedBox(height: 2),
                        Text(
                          'কর্মচারীর তথ্য, ভূমিকা ও অনুমতি',
                          style: TextStyle(color: Color(0xFF6B7B79), fontSize: 13, fontWeight: FontWeight.w500),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(width: 8),
                  _HeaderButton(icon: Icons.refresh_rounded, onTap: _onRefresh),
                ],
              ),
              const SizedBox(height: 14),
              _SearchField(
                controller: _searchController,
                query: _query,
                onChanged: (value) => setState(() => _query = value),
                onClear: () {
                  _searchController.clear();
                  setState(() => _query = '');
                },
              ),
              const SizedBox(height: 14),
              Row(
                children: [
                  Expanded(
                    child: _SummaryCard(
                      icon: Icons.people_alt_rounded,
                      iconColor: const Color(0xFF0E855D),
                      iconBackground: const Color(0xFFE7F5EF),
                      title: 'মোট কর্মচারী',
                      value: _banglaDigits(total.toString()),
                      subtitle: 'সকল স্টাফ',
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: _SummaryCard(
                      icon: Icons.verified_user_rounded,
                      iconColor: const Color(0xFF1B62D3),
                      iconBackground: const Color(0xFFE8F0FF),
                      title: 'সক্রিয় কর্মচারী',
                      value: _banglaDigits(active.toString()),
                      subtitle: 'এখন সক্রিয়',
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 12),
              _SummaryCard(
                icon: Icons.do_not_disturb_on_rounded,
                iconColor: const Color(0xFFB3261E),
                iconBackground: const Color(0xFFFDECEC),
                title: 'নিষ্ক্রিয় কর্মচারী',
                value: _banglaDigits(inactive.toString()),
                subtitle: 'অস্থায়ীভাবে বন্ধ',
                valueColor: const Color(0xFFB3261E),
              ),
              const SizedBox(height: 14),
              if (filtered.isEmpty)
                const _SupplierSectionEmptyState(label: 'কোনো কর্মচারী পাওয়া যায়নি')
              else
                ...filtered.map(
                  (item) => Padding(
                    padding: const EdgeInsets.only(bottom: 12),
                    child: _StaffCard(
                      staff: item,
                      selected: _selectedKeys.contains(item.key),
                      selectionMode: _selectionMode,
                      onTap: () {
                        if (_selectionMode) {
                          _toggleSelection(item);
                        } else {
                          Navigator.of(context).push(
                            MaterialPageRoute(builder: (_) => DokanStaffDetailScreen(staffKey: item.key)),
                          );
                        }
                      },
                      onLongPress: () {
                        if (_selectionMode) {
                          _toggleSelection(item);
                        } else {
                          _enterSelectionMode(item);
                        }
                      },
                    ),
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }
}

class DokanStaffDetailScreen extends ConsumerWidget {
  const DokanStaffDetailScreen({super.key, required this.staffKey});

  final String staffKey;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final staff = _findStaff(ref.watch(dokanPosProvider), staffKey);
    if (staff == null) {
      return const _SupplierErrorScreen(message: 'কর্মচারীর তথ্য পাওয়া যায়নি');
    }

    final granted = staff.permissions.toSet();
    final recentActivities = <_ActivityEntry>[
      _ActivityEntry(title: 'শেষ লগইন', subtitle: _formatDateTime(staff.lastLoginAt), icon: Icons.login_rounded),
      _ActivityEntry(title: 'শেষ সক্রিয়তা', subtitle: _formatDateTime(staff.lastActiveAt), icon: Icons.access_time_rounded),
      _ActivityEntry(title: 'সাম্প্রতিক বিক্রয়', subtitle: '${_banglaDigits(staff.recentSalesCount.toString())} টি', icon: Icons.point_of_sale_rounded),
    ];

    return Scaffold(
      backgroundColor: const Color(0xFFF4F8F6),
      body: SafeArea(
        child: ListView(
          physics: const AlwaysScrollableScrollPhysics(parent: ClampingScrollPhysics()),
          padding: const EdgeInsets.fromLTRB(16, 12, 16, 24),
          children: [
            Row(
              children: [
                _HeaderButton(icon: Icons.arrow_back_rounded, onTap: () => Navigator.of(context).maybePop()),
                const SizedBox(width: 12),
                const Expanded(
                  child: Text(
                    'কর্মচারী বিস্তারিত',
                    textAlign: TextAlign.center,
                    style: TextStyle(color: Color(0xFF163732), fontSize: 18, fontWeight: FontWeight.w800),
                  ),
                ),
                const SizedBox(width: 40),
              ],
            ),
            const SizedBox(height: 14),
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: const Color(0xFFD9E5E1)),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Container(
                        width: 58,
                        height: 58,
                        decoration: BoxDecoration(
                          color: const Color(0xFFE7F5EF),
                          borderRadius: BorderRadius.circular(18),
                        ),
                        alignment: Alignment.center,
                        child: Text(
                          _staffInitials(staff.name),
                          style: const TextStyle(color: Color(0xFF0C8C67), fontSize: 18, fontWeight: FontWeight.w900),
                        ),
                      ),
                      const SizedBox(width: 14),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(staff.name, style: const TextStyle(color: Color(0xFF163732), fontSize: 18, fontWeight: FontWeight.w900)),
                            const SizedBox(height: 4),
                            Text(staff.role, style: const TextStyle(color: Color(0xFF6B7B79), fontSize: 13, fontWeight: FontWeight.w500)),
                          ],
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 16),
                  Wrap(
                    spacing: 10,
                    runSpacing: 10,
                    children: [
                      _miniInfoChip(icon: Icons.call_rounded, text: staff.phone),
                      _miniInfoChip(icon: Icons.badge_rounded, text: staff.role),
                      _miniInfoChip(icon: Icons.verified_user_rounded, text: staff.active ? 'Active' : 'Inactive'),
                    ],
                  ),
                  const SizedBox(height: 16),
                  Row(
                    children: [
                      Expanded(
                        child: _SummaryCard(
                          icon: Icons.calendar_month_rounded,
                          iconColor: const Color(0xFF0E855D),
                          iconBackground: const Color(0xFFE7F5EF),
                          title: 'যোগদানের তারিখ',
                          value: _formatDate(staff.joinedAt),
                          subtitle: 'কর্মজীবনের শুরু',
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: _SummaryCard(
                          icon: Icons.check_circle_rounded,
                          iconColor: staff.active ? const Color(0xFF0C8C67) : const Color(0xFFB3261E),
                          iconBackground: staff.active ? const Color(0xFFE7F5EF) : const Color(0xFFFDECEC),
                          title: 'Status',
                          value: staff.active ? 'Active' : 'Inactive',
                          subtitle: 'বর্তমান অবস্থা',
                          valueColor: staff.active ? const Color(0xFF0C8C67) : const Color(0xFFB3261E),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
            const SizedBox(height: 14),
            Row(
              children: [
                Expanded(
                  child: FilledButton.icon(
                    onPressed: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => DokanAddNewStaffScreen(staffKey: staff.key))),
                    icon: const Icon(Icons.edit_rounded),
                    label: const Text('সম্পাদনা করুন'),
                    style: FilledButton.styleFrom(
                      backgroundColor: const Color(0xFF0C8C67),
                      foregroundColor: Colors.white,
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                    ),
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: OutlinedButton.icon(
                    onPressed: () => ref.read(dokanPosProvider.notifier).toggleStaffStatus(staff.key),
                    icon: Icon(staff.active ? Icons.pause_circle_rounded : Icons.play_circle_rounded),
                    label: Text(staff.active ? 'নিষ্ক্রিয় করুন' : 'সক্রিয় করুন'),
                    style: OutlinedButton.styleFrom(
                      foregroundColor: const Color(0xFF163732),
                      side: const BorderSide(color: Color(0xFFD9E5E1)),
                      backgroundColor: Colors.white,
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 14),
            _DetailSection(
              title: 'কর্মচারী তথ্য',
              child: Column(
                children: [
                  _InfoRow(label: 'নাম', value: staff.name),
                  const Divider(height: 24),
                  _InfoRow(label: 'ফোন নম্বর', value: staff.phone),
                  const Divider(height: 24),
                  _InfoRow(label: 'ভূমিকা', value: staff.role),
                  const Divider(height: 24),
                  _InfoRow(label: 'ঠিকানা', value: staff.address.isEmpty ? 'সংরক্ষিত নেই' : staff.address),
                  const Divider(height: 24),
                  _InfoRow(label: 'নোট', value: staff.note.isEmpty ? 'সংরক্ষিত নেই' : staff.note),
                ],
              ),
            ),
            const SizedBox(height: 14),
            _DetailSection(
              title: 'কার্যক্রম',
              child: Column(
                children: recentActivities
                    .map(
                      (entry) => Padding(
                        padding: const EdgeInsets.only(bottom: 10),
                        child: Container(
                          padding: const EdgeInsets.all(12),
                          decoration: BoxDecoration(
                            color: const Color(0xFFF7FAF9),
                            borderRadius: BorderRadius.circular(14),
                            border: Border.all(color: const Color(0xFFE2ECE8)),
                          ),
                          child: Row(
                            children: [
                              Container(
                                width: 40,
                                height: 40,
                                decoration: BoxDecoration(
                                  color: const Color(0xFFE7F5EF),
                                  borderRadius: BorderRadius.circular(12),
                                ),
                                child: Icon(entry.icon, color: const Color(0xFF0C8C67), size: 20),
                              ),
                              const SizedBox(width: 10),
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(entry.title, style: const TextStyle(color: Color(0xFF163732), fontSize: 13.5, fontWeight: FontWeight.w700)),
                                    const SizedBox(height: 3),
                                    Text(entry.subtitle, style: const TextStyle(color: Color(0xFF6B7B79), fontSize: 12, fontWeight: FontWeight.w500)),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    )
                    .toList(growable: false),
              ),
            ),
            const SizedBox(height: 14),
            _DetailSection(
              title: 'অনুমতি',
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Wrap(
                    spacing: 8,
                    runSpacing: 8,
                    children: granted.isEmpty
                        ? const [Chip(label: Text('কোনো অনুমতি নেই'))]
                        : granted.map((permission) => Chip(label: Text(_permissionLabel(permission)))).toList(growable: false),
                  ),
                  const SizedBox(height: 12),
                  OutlinedButton.icon(
                    onPressed: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => DokanStaffPermissionsScreen(staffKey: staff.key))),
                    icon: const Icon(Icons.tune_rounded),
                    label: const Text('অনুমতি পরিচালনা'),
                    style: OutlinedButton.styleFrom(
                      foregroundColor: const Color(0xFF163732),
                      side: const BorderSide(color: Color(0xFFD9E5E1)),
                      backgroundColor: Colors.white,
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                    ),
                  ),
                  const SizedBox(height: 10),
                  OutlinedButton.icon(
                    onPressed: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => DokanStaffPinSetupScreen(staffKey: staff.key))),
                    icon: const Icon(Icons.pin_rounded),
                    label: const Text('PIN সেট করুন'),
                    style: OutlinedButton.styleFrom(
                      foregroundColor: const Color(0xFF163732),
                      side: const BorderSide(color: Color(0xFFD9E5E1)),
                      backgroundColor: Colors.white,
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class DokanNewSupplierAddScreen extends ConsumerStatefulWidget {
  const DokanNewSupplierAddScreen({super.key});

  @override
  ConsumerState<DokanNewSupplierAddScreen> createState() => _DokanNewSupplierAddScreenState();
}

class _DokanNewSupplierAddScreenState extends ConsumerState<DokanNewSupplierAddScreen> {
  final TextEditingController _nameController = TextEditingController();
  final TextEditingController _phoneController = TextEditingController();
  final TextEditingController _addressController = TextEditingController();
  final TextEditingController _productTypeController = TextEditingController();
  final TextEditingController _creditLimitController = TextEditingController();
  bool _isSubmitting = false;
  String? _nameError;
  String? _phoneError;
  String? _creditLimitError;

  @override
  void dispose() {
    _nameController.dispose();
    _phoneController.dispose();
    _addressController.dispose();
    _productTypeController.dispose();
    _creditLimitController.dispose();
    super.dispose();
  }

  bool _isPhoneValid(String value) {
    final text = value.trim();
    return RegExp(r'^(?:\+8801|01)[0-9]{9}$').hasMatch(text);
  }

  bool _isNameValid(String value) => value.trim().isNotEmpty;

  int? _parseCreditLimit() {
    final text = _creditLimitController.text.trim();
    if (text.isEmpty) {
      return 0;
    }
    return int.tryParse(text);
  }

  void _validate() {
    setState(() {
      _nameError = _isNameValid(_nameController.text) ? null : 'নাম দেওয়া বাধ্যতামূলক';
      final phoneText = _phoneController.text.trim();
      if (phoneText.isEmpty) {
        _phoneError = 'নম্বর খালি রাখা যাবে না';
      } else if (!_isPhoneValid(phoneText)) {
        _phoneError = 'সঠিক মোবাইল নম্বর দিন';
      } else {
        _phoneError = null;
      }

      final creditText = _creditLimitController.text.trim();
      final credit = creditText.isEmpty ? 0 : int.tryParse(creditText);
      _creditLimitError = creditText.isNotEmpty && (credit == null || credit < 0) ? 'সঠিক সীমা লিখুন' : null;
    });
  }

  bool get _canSubmit {
    final credit = _parseCreditLimit();
    return !_isSubmitting &&
        _isNameValid(_nameController.text) &&
        _phoneController.text.trim().isNotEmpty &&
        _isPhoneValid(_phoneController.text) &&
        credit != null &&
        credit >= 0;
  }

  Future<void> _save() async {
    _validate();
    if (!_canSubmit) {
      return;
    }

    final creditLimit = _parseCreditLimit();
    if (creditLimit == null || creditLimit < 0) {
      setState(() => _creditLimitError = 'সঠিক সীমা লিখুন');
      return;
    }

    setState(() => _isSubmitting = true);
    ref.read(dokanPosProvider.notifier).addSupplier(
          name: _nameController.text,
          phone: _phoneController.text,
          address: _addressController.text,
          productType: _productTypeController.text,
          creditLimit: creditLimit,
        );

    if (!mounted) {
      return;
    }

    Navigator.of(context).pop(true);
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('সরবরাহকারী যোগ করা হয়েছে')),
    );
  }

  @override
  Widget build(BuildContext context) {
    final canSubmit = _canSubmit;

    return Scaffold(
      backgroundColor: const Color(0xFFF4F8F6),
      body: SafeArea(
        child: ListView(
          physics: const AlwaysScrollableScrollPhysics(parent: ClampingScrollPhysics()),
          padding: const EdgeInsets.fromLTRB(16, 12, 16, 24),
          children: [
            Row(
              children: [
                _HeaderButton(
                  icon: Icons.arrow_back_rounded,
                  onTap: () => Navigator.of(context).maybePop(),
                ),
                const SizedBox(width: 12),
                const Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'নতুন সরবরাহকারী',
                        style: TextStyle(
                          color: Color(0xFF163732),
                          fontSize: 22,
                          fontWeight: FontWeight.w800,
                        ),
                      ),
                      SizedBox(height: 2),
                      Text(
                        'সহজ ফর্ম, পরিষ্কার যাচাই',
                        style: TextStyle(
                          color: Color(0xFF6B7B79),
                          fontSize: 13,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
            const SizedBox(height: 14),
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: const Color(0xFFD9E5E1)),
              ),
              child: Column(
                children: [
                  TextField(
                    controller: _nameController,
                    onChanged: (_) => _validate(),
                    style: const TextStyle(color: Color(0xFF111111)),
                    decoration: InputDecoration(
                      labelText: 'নাম *',
                      hintText: 'সরবরাহকারীর নাম',
                      errorText: _nameError,
                      filled: true,
                      fillColor: const Color(0xFFF8FAF9),
                      border: OutlineInputBorder(borderRadius: BorderRadius.circular(16)),
                      enabledBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(16),
                        borderSide: const BorderSide(color: Color(0xFFD9E5E1)),
                      ),
                      focusedBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(16),
                        borderSide: const BorderSide(color: Color(0xFF0C8C67), width: 1.4),
                      ),
                    ),
                  ),
                  const SizedBox(height: 12),
                  TextField(
                    controller: _phoneController,
                    keyboardType: TextInputType.phone,
                    inputFormatters: [
                      FilteringTextInputFormatter.allow(RegExp(r'[0-9+]')),
                    ],
                    onChanged: (_) => _validate(),
                    style: const TextStyle(color: Color(0xFF111111)),
                    decoration: InputDecoration(
                      labelText: 'মোবাইল *',
                      hintText: '+8801XXXXXXXXX / 01XXXXXXXXX',
                      errorText: _phoneError,
                      filled: true,
                      fillColor: const Color(0xFFF8FAF9),
                      border: OutlineInputBorder(borderRadius: BorderRadius.circular(16)),
                      enabledBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(16),
                        borderSide: const BorderSide(color: Color(0xFFD9E5E1)),
                      ),
                      focusedBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(16),
                        borderSide: const BorderSide(color: Color(0xFF0C8C67), width: 1.4),
                      ),
                    ),
                  ),
                  const SizedBox(height: 12),
                  TextField(
                    controller: _addressController,
                    style: const TextStyle(color: Color(0xFF111111)),
                    decoration: InputDecoration(
                      labelText: 'ঠিকানা',
                      hintText: 'ঐচ্ছিক',
                      filled: true,
                      fillColor: const Color(0xFFF8FAF9),
                      border: OutlineInputBorder(borderRadius: BorderRadius.circular(16)),
                      enabledBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(16),
                        borderSide: const BorderSide(color: Color(0xFFD9E5E1)),
                      ),
                      focusedBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(16),
                        borderSide: const BorderSide(color: Color(0xFF0C8C67), width: 1.4),
                      ),
                    ),
                  ),
                  const SizedBox(height: 12),
                  TextField(
                    controller: _productTypeController,
                    style: const TextStyle(color: Color(0xFF111111)),
                    decoration: InputDecoration(
                      labelText: 'পণ্যের ধরন',
                      hintText: 'ঐচ্ছিক',
                      filled: true,
                      fillColor: const Color(0xFFF8FAF9),
                      border: OutlineInputBorder(borderRadius: BorderRadius.circular(16)),
                      enabledBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(16),
                        borderSide: const BorderSide(color: Color(0xFFD9E5E1)),
                      ),
                      focusedBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(16),
                        borderSide: const BorderSide(color: Color(0xFF0C8C67), width: 1.4),
                      ),
                    ),
                  ),
                  const SizedBox(height: 12),
                  TextField(
                    controller: _creditLimitController,
                    keyboardType: TextInputType.number,
                    inputFormatters: [FilteringTextInputFormatter.digitsOnly],
                    onChanged: (_) => _validate(),
                    style: const TextStyle(color: Color(0xFF111111)),
                    decoration: InputDecoration(
                      labelText: 'ক্রেডিট লিমিট',
                      hintText: 'ঐচ্ছিক',
                      errorText: _creditLimitError,
                      filled: true,
                      fillColor: const Color(0xFFF8FAF9),
                      border: OutlineInputBorder(borderRadius: BorderRadius.circular(16)),
                      enabledBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(16),
                        borderSide: const BorderSide(color: Color(0xFFD9E5E1)),
                      ),
                      focusedBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(16),
                        borderSide: const BorderSide(color: Color(0xFF0C8C67), width: 1.4),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 16),
            SizedBox(
              height: 52,
              child: FilledButton(
                onPressed: canSubmit && !_isSubmitting ? _save : null,
                style: FilledButton.styleFrom(
                  backgroundColor: const Color(0xFF0C8C67),
                  foregroundColor: Colors.white,
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                ),
                child: _isSubmitting
                    ? const SizedBox(
                        width: 20,
                        height: 20,
                        child: CircularProgressIndicator(strokeWidth: 2.4, color: Colors.white),
                      )
                    : const Text('সংরক্ষণ'),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class DokanSupplierListScreen extends ConsumerStatefulWidget {
  const DokanSupplierListScreen({super.key});

  @override
  ConsumerState<DokanSupplierListScreen> createState() => _DokanSupplierListScreenState();
}

class _DokanSupplierListScreenState extends ConsumerState<DokanSupplierListScreen> {
  final TextEditingController _searchController = TextEditingController();
  final Set<String> _selectedSupplierKeys = <String>{};
  bool _ready = false;
  bool _selectionMode = false;
  String _query = '';

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!mounted) {
        return;
      }
      setState(() => _ready = true);
    });
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  Future<void> _onRefresh() async {
    await Future<void>.delayed(const Duration(milliseconds: 350));
    if (mounted) {
      setState(() {});
    }
  }

  void _enterSelectionMode(_SupplierSummary supplier) {
    setState(() {
      _selectionMode = true;
      _selectedSupplierKeys.add(supplier.key);
    });
  }

  void _toggleSupplierSelection(_SupplierSummary supplier) {
    setState(() {
      if (_selectedSupplierKeys.contains(supplier.key)) {
        _selectedSupplierKeys.remove(supplier.key);
      } else {
        _selectedSupplierKeys.add(supplier.key);
        _selectionMode = true;
      }
      if (_selectedSupplierKeys.isEmpty) {
        _selectionMode = false;
      }
    });
  }

  void _clearSupplierSelection() {
    setState(() {
      _selectedSupplierKeys.clear();
      _selectionMode = false;
    });
  }

  Future<void> _deleteSelectedSuppliers(
    BuildContext context,
    WidgetRef ref,
    List<_SupplierSummary> selectedSuppliers,
  ) async {
    if (selectedSuppliers.isEmpty) {
      return;
    }

    final confirmed = await _showBulkDeleteDialog(
      context: context,
      entityLabel: 'সরবরাহকারী',
      names: selectedSuppliers.map((item) => item.name).toList(growable: false),
    );
    if (!confirmed) {
      return;
    }

    for (final supplier in selectedSuppliers) {
      ref.read(dokanPosProvider.notifier).deleteSupplier(supplier.key);
    }

    if (mounted) {
      _clearSupplierSelection();
      setState(() {});
    }
  }

  @override
  Widget build(BuildContext context) {
    final state = ref.watch(dokanPosProvider);

    if (!_ready) {
      return const _SupplierLoadingScreen();
    }

    try {
      final suppliers = _buildSupplierSummaries(state);
      final query = _query.trim().toLowerCase();
      final filteredSuppliers = query.isEmpty
          ? suppliers
          : suppliers.where((supplier) {
              return supplier.name.toLowerCase().contains(query) ||
                  supplier.phone.toLowerCase().contains(query);
            }).toList(growable: false);

      final totalSuppliers = suppliers.length;
      final totalDue = suppliers.fold<int>(0, (sum, supplier) => sum + supplier.totalDue);
      final currentMonthPurchase = suppliers.fold<int>(0, (sum, supplier) => sum + supplier.currentMonthPurchase);
      final selectedSuppliers = suppliers
          .where((supplier) => _selectedSupplierKeys.contains(supplier.key))
          .toList(growable: false);
      final canDeleteSelected = _selectionMode && selectedSuppliers.isNotEmpty;

      return Scaffold(
        backgroundColor: const Color(0xFFF4F8F6),
        floatingActionButton: FloatingActionButton.extended(
          onPressed: () async {
            await Navigator.of(context).push<bool>(
              MaterialPageRoute(builder: (_) => const DokanNewSupplierAddScreen()),
            );
          },
          backgroundColor: const Color(0xFF0C8C67),
          foregroundColor: Colors.white,
          icon: const Icon(Icons.person_add_alt_1_rounded),
          label: const Text('নতুন সরবরাহকারী'),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        ),
        bottomNavigationBar: _selectionMode
            ? SafeArea(
                top: false,
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
                  child: SizedBox(
                    height: 52,
                    width: double.infinity,
                    child: FilledButton.icon(
                      onPressed: canDeleteSelected
                          ? () => _deleteSelectedSuppliers(context, ref, selectedSuppliers)
                          : null,
                      icon: const Icon(Icons.delete_rounded),
                      label: Text('ডিলিট করুন (${_banglaDigits(selectedSuppliers.length.toString())})'),
                      style: FilledButton.styleFrom(
                        backgroundColor: const Color(0xFFD6453A),
                        foregroundColor: Colors.white,
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                      ),
                    ),
                  ),
                ),
              )
            : null,
        body: SafeArea(
          bottom: false,
          child: RefreshIndicator(
            onRefresh: _onRefresh,
            color: const Color(0xFF0C8C67),
            child: ListView(
              physics: const AlwaysScrollableScrollPhysics(parent: ClampingScrollPhysics()),
              padding: EdgeInsets.fromLTRB(16, 12, 16, _selectionMode ? 144 : 96),
              children: [
                Row(
                  children: [
                    _HeaderButton(
                      icon: Icons.arrow_back_rounded,
                      onTap: () => Navigator.of(context).maybePop(),
                    ),
                    const SizedBox(width: 12),
                    const Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'সরবরাহকারী তালিকা',
                            style: TextStyle(
                              color: Color(0xFF163732),
                              fontSize: 22,
                              fontWeight: FontWeight.w800,
                            ),
                          ),
                          SizedBox(height: 2),
                          Text(
                            'সরবরাহকারী, বাকি ও ক্রয় তথ্য',
                            style: TextStyle(
                              color: Color(0xFF6B7B79),
                              fontSize: 13,
                              fontWeight: FontWeight.w500,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 14),
                _SearchField(
                  controller: _searchController,
                  query: _query,
                  onChanged: (value) => setState(() => _query = value),
                  onClear: () {
                    _searchController.clear();
                    setState(() => _query = '');
                  },
                ),
                const SizedBox(height: 14),
                Row(
                  children: [
                    Expanded(
                      child: _SummaryCard(
                        icon: Icons.local_shipping_rounded,
                        iconColor: const Color(0xFF0E855D),
                        iconBackground: const Color(0xFFE7F5EF),
                        title: 'মোট সরবরাহকারী',
                        value: _banglaDigits(totalSuppliers.toString()),
                        subtitle: totalSuppliers > 0 ? 'সক্রিয় তালিকা' : 'এখনও সরবরাহকারী নেই',
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: _SummaryCard(
                        icon: Icons.account_balance_wallet_rounded,
                        iconColor: const Color(0xFFB14A12),
                        iconBackground: const Color(0xFFFFF0E2),
                        title: 'মোট বকেয়া',
                        value: _formatCurrency(totalDue),
                        subtitle: 'সব সরবরাহকারীর বকেয়া',
                        valueColor: const Color(0xFFB3261E),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 12),
                _SummaryCard(
                  icon: Icons.shopping_cart_checkout_rounded,
                  iconColor: const Color(0xFF2564D7),
                  iconBackground: const Color(0xFFEAF2FF),
                  title: 'এই মাসের ক্রয়',
                  value: _formatCurrency(currentMonthPurchase),
                  subtitle: 'বর্তমান মাসের মোট ক্রয় যোগফল',
                ),
                const SizedBox(height: 14),
                if (query.isNotEmpty)
                  Padding(
                    padding: const EdgeInsets.only(bottom: 10),
                    child: Text(
                      'ফলাফল: ${_banglaDigits(filteredSuppliers.length.toString())} জন সরবরাহকারী',
                      style: const TextStyle(
                        color: Color(0xFF516462),
                        fontSize: 13,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ),
                if (filteredSuppliers.isEmpty)
                  const _SupplierEmptyState()
                else
                  ...filteredSuppliers.map(
                    (supplier) => Padding(
                      padding: const EdgeInsets.only(bottom: 12),
                      child: _SupplierListTile(
                        supplier: supplier,
                        selected: _selectedSupplierKeys.contains(supplier.key),
                        selectionMode: _selectionMode,
                        onTap: () {
                          if (_selectionMode) {
                            _toggleSupplierSelection(supplier);
                          } else {
                            Navigator.of(context).push(
                              MaterialPageRoute(
                                builder: (_) => DokanSupplierDetailScreen(supplierKey: supplier.key),
                              ),
                            );
                          }
                        },
                        onLongPress: () {
                          if (_selectionMode) {
                            _toggleSupplierSelection(supplier);
                          } else {
                            _enterSelectionMode(supplier);
                          }
                        },
                      ),
                    ),
                  ),
              ],
            ),
          ),
        ),
      );
    } catch (_) {
      return const _SupplierErrorScreen();
    }
  }
}

class DokanSupplierPaymentScreen extends ConsumerStatefulWidget {
  const DokanSupplierPaymentScreen({super.key, required this.supplierKey});

  final String supplierKey;

  @override
  ConsumerState<DokanSupplierPaymentScreen> createState() => _DokanSupplierPaymentScreenState();
}

class _DokanSupplierPaymentScreenState extends ConsumerState<DokanSupplierPaymentScreen> {
  final ScrollController _scrollController = ScrollController();
  final TextEditingController _bkashPhoneController = TextEditingController();
  final TextEditingController _bkashTransactionController = TextEditingController();
  final TextEditingController _bkashAmountController = TextEditingController();
  final TextEditingController _nagadPhoneController = TextEditingController();
  final TextEditingController _nagadTransactionController = TextEditingController();
  final TextEditingController _nagadAmountController = TextEditingController();
  final TextEditingController _cardNumberController = TextEditingController();
  final TextEditingController _bankNameController = TextEditingController();
  final TextEditingController _cardExpiryController = TextEditingController();
  final TextEditingController _cardPinController = TextEditingController();
  final TextEditingController _cardAmountController = TextEditingController();
  final TextEditingController _cashAmountController = TextEditingController();
  DokanPosPaymentMethod _selectedMethod = DokanPosPaymentMethod.cash;
  bool _isSubmitting = false;
  String? _bkashPhoneError;
  String? _bkashTransactionError;
  String? _bkashAmountError;
  String? _nagadPhoneError;
  String? _nagadTransactionError;
  String? _nagadAmountError;
  String? _cardNumberError;
  String? _bankNameError;
  String? _cardExpiryError;
  String? _cardPinError;
  String? _cardAmountError;
  String? _cashAmountError;

  @override
  void dispose() {
    _scrollController.dispose();
    _bkashPhoneController.dispose();
    _bkashTransactionController.dispose();
    _bkashAmountController.dispose();
    _nagadPhoneController.dispose();
    _nagadTransactionController.dispose();
    _nagadAmountController.dispose();
    _cardNumberController.dispose();
    _bankNameController.dispose();
    _cardExpiryController.dispose();
    _cardPinController.dispose();
    _cardAmountController.dispose();
    _cashAmountController.dispose();
    super.dispose();
  }

  bool _isValidMobile(String value) => RegExp(r'^01[0-9]{9}$').hasMatch(value.trim());

  bool _isValidAlphanumeric(String value) => RegExp(r'^[a-zA-Z0-9]+$').hasMatch(value.trim());

  bool _isValidCardNumber(String value) => RegExp(r'^[0-9]{16}$').hasMatch(value.trim());

  bool _isValidExpiry(String value) => RegExp(r'^(0[1-9]|1[0-2])\/[0-9]{2}$').hasMatch(value.trim());

  bool _isValidPin(String value) => RegExp(r'^[0-9]{4}([0-9]{2})?$').hasMatch(value.trim());

  int? _parseAmount(String value) {
    final text = value.trim();
    if (text.isEmpty) {
      return null;
    }
    return int.tryParse(text);
  }

  void _validateActiveMethod(int dueAmount) {
    setState(() {
      _bkashPhoneError = null;
      _bkashTransactionError = null;
      _bkashAmountError = null;
      _nagadPhoneError = null;
      _nagadTransactionError = null;
      _nagadAmountError = null;
      _cardNumberError = null;
      _bankNameError = null;
      _cardExpiryError = null;
      _cardPinError = null;
      _cardAmountError = null;
      _cashAmountError = null;

      switch (_selectedMethod) {
        case DokanPosPaymentMethod.bkash:
          final phone = _bkashPhoneController.text.trim();
          final transaction = _bkashTransactionController.text.trim();
          final amount = _parseAmount(_bkashAmountController.text);
          _bkashPhoneError = phone.isEmpty || !_isValidMobile(phone) ? 'সঠিক bKash নম্বর দিন' : null;
          _bkashTransactionError = transaction.isEmpty || !_isValidAlphanumeric(transaction)
              ? 'Transaction ID দিন'
              : null;
          if (amount == null || amount <= 0) {
            _bkashAmountError = 'টাকা লিখুন';
          } else if (amount > dueAmount) {
            _bkashAmountError = 'বকেয়ার বেশি টাকা দেওয়া যাবে না';
          }
          break;
        case DokanPosPaymentMethod.nagad:
          final phone = _nagadPhoneController.text.trim();
          final transaction = _nagadTransactionController.text.trim();
          final amount = _parseAmount(_nagadAmountController.text);
          _nagadPhoneError = phone.isEmpty || !_isValidMobile(phone) ? 'সঠিক Nagad নম্বর দিন' : null;
          _nagadTransactionError = transaction.isEmpty || !_isValidAlphanumeric(transaction)
              ? 'Transaction ID দিন'
              : null;
          if (amount == null || amount <= 0) {
            _nagadAmountError = 'টাকা লিখুন';
          } else if (amount > dueAmount) {
            _nagadAmountError = 'বকেয়ার বেশি টাকা দেওয়া যাবে না';
          }
          break;
        case DokanPosPaymentMethod.card:
          final cardNumber = _cardNumberController.text.trim();
          final bankName = _bankNameController.text.trim();
          final expiry = _cardExpiryController.text.trim();
          final pin = _cardPinController.text.trim();
          final amount = _parseAmount(_cardAmountController.text);
          _cardNumberError = _isValidCardNumber(cardNumber) ? null : 'সঠিক কার্ড নম্বর দিন';
          _bankNameError = bankName.isEmpty ? 'ব্যাংকের নাম দিন' : null;
          _cardExpiryError = _isValidExpiry(expiry) ? null : 'সঠিক মেয়াদ শেষের তারিখ দিন';
          _cardPinError = _isValidPin(pin) ? null : 'সঠিক PIN দিন';
          if (amount == null || amount <= 0) {
            _cardAmountError = 'টাকা লিখুন';
          } else if (amount > dueAmount) {
            _cardAmountError = 'বকেয়ার বেশি টাকা দেওয়া যাবে না';
          }
          break;
        case DokanPosPaymentMethod.cash:
          final amount = _parseAmount(_cashAmountController.text);
          if (amount == null) {
            _cashAmountError = 'টাকা লিখুন';
          } else if (amount <= 0) {
            _cashAmountError = 'সঠিক টাকা লিখুন';
          } else if (amount > dueAmount) {
            _cashAmountError = 'বকেয়ার বেশি টাকা দেওয়া যাবে না';
          }
          break;
        case DokanPosPaymentMethod.rocket:
        case DokanPosPaymentMethod.bank:
          _cashAmountError = 'এই পেমেন্ট পদ্ধতি এখন সমর্থিত নয়';
          break;
      }
    });
  }

  void _populateAmountForSelectedMethod(String value) {
    switch (_selectedMethod) {
      case DokanPosPaymentMethod.bkash:
        _bkashAmountController.text = value;
        break;
      case DokanPosPaymentMethod.nagad:
        _nagadAmountController.text = value;
        break;
      case DokanPosPaymentMethod.card:
        _cardAmountController.text = value;
        break;
      case DokanPosPaymentMethod.cash:
        _cashAmountController.text = value;
        break;
      case DokanPosPaymentMethod.rocket:
      case DokanPosPaymentMethod.bank:
        break;
    }
  }

  int _currentAmount() {
    switch (_selectedMethod) {
      case DokanPosPaymentMethod.bkash:
        return int.tryParse(_bkashAmountController.text.trim()) ?? 0;
      case DokanPosPaymentMethod.nagad:
        return int.tryParse(_nagadAmountController.text.trim()) ?? 0;
      case DokanPosPaymentMethod.card:
        return int.tryParse(_cardAmountController.text.trim()) ?? 0;
      case DokanPosPaymentMethod.cash:
        return int.tryParse(_cashAmountController.text.trim()) ?? 0;
      case DokanPosPaymentMethod.rocket:
      case DokanPosPaymentMethod.bank:
        return 0;
    }
  }

  String _transactionNote() {
    switch (_selectedMethod) {
      case DokanPosPaymentMethod.bkash:
        return 'bKash ${_bkashPhoneController.text.trim()} | TXN ${_bkashTransactionController.text.trim()}';
      case DokanPosPaymentMethod.nagad:
        return 'Nagad ${_nagadPhoneController.text.trim()} | TXN ${_nagadTransactionController.text.trim()}';
      case DokanPosPaymentMethod.card:
        return 'Card ${_cardNumberController.text.trim()} | ${_bankNameController.text.trim()} | ${_cardExpiryController.text.trim()}';
      case DokanPosPaymentMethod.cash:
        return 'Cash payment';
      case DokanPosPaymentMethod.rocket:
      case DokanPosPaymentMethod.bank:
        return _paymentMethodLabel(_selectedMethod);
    }
  }

  bool _canSubmitForMethod(int dueAmount) {
    final amount = _currentAmount();
    switch (_selectedMethod) {
      case DokanPosPaymentMethod.bkash:
        return _bkashPhoneError == null &&
            _bkashTransactionError == null &&
            _bkashAmountError == null &&
            amount > 0 &&
            amount <= dueAmount;
      case DokanPosPaymentMethod.nagad:
        return _nagadPhoneError == null &&
            _nagadTransactionError == null &&
            _nagadAmountError == null &&
            amount > 0 &&
            amount <= dueAmount;
      case DokanPosPaymentMethod.card:
        return _cardNumberError == null &&
            _bankNameError == null &&
            _cardExpiryError == null &&
            _cardPinError == null &&
            _cardAmountError == null &&
            amount > 0 &&
            amount <= dueAmount;
      case DokanPosPaymentMethod.cash:
        return _cashAmountError == null && amount > 0 && amount <= dueAmount;
      case DokanPosPaymentMethod.rocket:
      case DokanPosPaymentMethod.bank:
        return false;
    }
  }

  Future<void> _showConfirmDialog(_SupplierSummary supplier) async {
    final amount = _currentAmount();
    final confirmed = await showDialog<bool>(
          context: context,
          builder: (dialogContext) {
            return AlertDialog(
              title: const Text('আপনি কি নিশ্চিত?'),
              content: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('সরবরাহকারী: ${supplier.name}'),
                  const SizedBox(height: 6),
                  Text('পেমেন্ট পদ্ধতি: ${_paymentMethodLabel(_selectedMethod)}'),
                  const SizedBox(height: 6),
                  Text('টাকা: ${_formatCurrency(amount)}'),
                ],
              ),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
              actionsPadding: const EdgeInsets.fromLTRB(20, 0, 12, 12),
              actions: [
                TextButton(
                  onPressed: () => Navigator.of(dialogContext).pop(false),
                  child: const Text('বাতিল'),
                ),
                FilledButton(
                  onPressed: () => Navigator.of(dialogContext).pop(true),
                  style: FilledButton.styleFrom(
                    backgroundColor: const Color(0xFF0C8C67),
                    foregroundColor: Colors.white,
                  ),
                  child: const Text('নিশ্চিত করুন'),
                ),
              ],
            );
          },
        ) ??
        false;

    if (!confirmed) {
      return;
    }

    setState(() => _isSubmitting = true);
    ref.read(dokanPosProvider.notifier).addSupplierPayment(
          supplierKey: supplier.key,
          supplierName: supplier.name,
          amount: amount,
          paymentMethod: _selectedMethod,
          note: _transactionNote(),
        );

    if (!mounted) {
      return;
    }

    Navigator.of(context).pop(true);
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('পেমেন্ট সফলভাবে সম্পন্ন হয়েছে')),
    );
  }

  Widget _buildPaymentField({
    required TextEditingController controller,
    required String label,
    required String hint,
    String? errorText,
    TextInputType keyboardType = TextInputType.text,
    List<TextInputFormatter> inputFormatters = const <TextInputFormatter>[],
    bool obscureText = false,
    ValueChanged<String>? onChanged,
    Widget? suffixIcon,
  }) {
    return TextField(
      controller: controller,
      keyboardType: keyboardType,
      obscureText: obscureText,
      inputFormatters: inputFormatters,
      onChanged: onChanged,
      style: const TextStyle(color: Color(0xFF111111)),
      decoration: InputDecoration(
        labelText: label,
        hintText: hint,
        errorText: errorText,
        filled: true,
        fillColor: const Color(0xFFF8FAF9),
        suffixIcon: suffixIcon,
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(16)),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(16),
          borderSide: const BorderSide(color: Color(0xFFD9E5E1)),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(16),
          borderSide: const BorderSide(color: Color(0xFF0C8C67), width: 1.4),
        ),
      ),
    );
  }

  Widget _buildSelectedMethodForm(int dueAmount) {
    switch (_selectedMethod) {
      case DokanPosPaymentMethod.bkash:
        return Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('bKash payment flow', style: TextStyle(color: Color(0xFF163732), fontSize: 13.5, fontWeight: FontWeight.w700)),
            const SizedBox(height: 12),
            _buildPaymentField(
              controller: _bkashPhoneController,
              label: 'bKash Account Number *',
              hint: '01XXXXXXXXX',
              keyboardType: TextInputType.phone,
              inputFormatters: [FilteringTextInputFormatter.digitsOnly, LengthLimitingTextInputFormatter(11)],
              errorText: _bkashPhoneError,
              onChanged: (_) => _validateActiveMethod(dueAmount),
            ),
            const SizedBox(height: 12),
            _buildPaymentField(
              controller: _bkashTransactionController,
              label: 'Transaction ID *',
              hint: 'Alphanumeric',
              errorText: _bkashTransactionError,
              onChanged: (_) => _validateActiveMethod(dueAmount),
            ),
            const SizedBox(height: 12),
            _buildPaymentField(
              controller: _bkashAmountController,
              label: 'Amount *',
              hint: '০১XXXXXXXXX',
              keyboardType: TextInputType.number,
              inputFormatters: [FilteringTextInputFormatter.digitsOnly],
              errorText: _bkashAmountError,
              onChanged: (_) => _validateActiveMethod(dueAmount),
            ),
          ],
        );
      case DokanPosPaymentMethod.nagad:
        return Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('Nagad payment flow', style: TextStyle(color: Color(0xFF163732), fontSize: 13.5, fontWeight: FontWeight.w700)),
            const SizedBox(height: 12),
            _buildPaymentField(
              controller: _nagadPhoneController,
              label: 'Nagad Account Number *',
              hint: '01XXXXXXXXX',
              keyboardType: TextInputType.phone,
              inputFormatters: [FilteringTextInputFormatter.digitsOnly, LengthLimitingTextInputFormatter(11)],
              errorText: _nagadPhoneError,
              onChanged: (_) => _validateActiveMethod(dueAmount),
            ),
            const SizedBox(height: 12),
            _buildPaymentField(
              controller: _nagadTransactionController,
              label: 'Transaction ID *',
              hint: 'Alphanumeric',
              errorText: _nagadTransactionError,
              onChanged: (_) => _validateActiveMethod(dueAmount),
            ),
            const SizedBox(height: 12),
            _buildPaymentField(
              controller: _nagadAmountController,
              label: 'Amount *',
              hint: 'Transaction ID',
              keyboardType: TextInputType.number,
              inputFormatters: [FilteringTextInputFormatter.digitsOnly],
              errorText: _nagadAmountError,
              onChanged: (_) => _validateActiveMethod(dueAmount),
            ),
          ],
        );
      case DokanPosPaymentMethod.card:
        return Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('Card payment flow', style: TextStyle(color: Color(0xFF163732), fontSize: 13.5, fontWeight: FontWeight.w700)),
            const SizedBox(height: 12),
            _buildPaymentField(
              controller: _cardNumberController,
              label: 'Card Number *',
              hint: '16 digit number',
              keyboardType: TextInputType.number,
              inputFormatters: [FilteringTextInputFormatter.digitsOnly, LengthLimitingTextInputFormatter(16)],
              errorText: _cardNumberError,
              onChanged: (_) => _validateActiveMethod(dueAmount),
            ),
            const SizedBox(height: 12),
            DropdownButtonFormField<String>(
              initialValue: _bankNameController.text.trim().isEmpty ? null : _bankNameController.text.trim(),
              decoration: InputDecoration(
                labelText: 'Bank Name *',
                hintText: '১৬ সংখ্যার কার্ড নম্বর',
                errorText: _bankNameError,
                filled: true,
                fillColor: const Color(0xFFF8FAF9),
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(16)),
                enabledBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(16),
                  borderSide: const BorderSide(color: Color(0xFFD9E5E1)),
                ),
                focusedBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(16),
                  borderSide: const BorderSide(color: Color(0xFF0C8C67), width: 1.4),
                ),
              ),
              dropdownColor: Colors.white,
              items: const <String>['DBBL', 'BRAC Bank', 'City Bank', 'IFIC Bank']
                  .map((bank) => DropdownMenuItem<String>(value: bank, child: Text(bank, style: TextStyle(color: Color(0xFF111111)))))
                  .toList(growable: false),
              onChanged: (value) {
                setState(() => _bankNameController.text = value ?? '');
                _validateActiveMethod(dueAmount);
              },
            ),
            const SizedBox(height: 12),
            _buildPaymentField(
              controller: _cardExpiryController,
              label: 'Expiry Date *',
              hint: 'MM/YY',
              errorText: _cardExpiryError,
              onChanged: (_) => _validateActiveMethod(dueAmount),
            ),
            const SizedBox(height: 12),
            _buildPaymentField(
              controller: _cardPinController,
              label: 'PIN *',
              hint: '4 or 6 digit PIN',
              keyboardType: TextInputType.number,
              inputFormatters: [FilteringTextInputFormatter.digitsOnly, LengthLimitingTextInputFormatter(6)],
              obscureText: true,
              errorText: _cardPinError,
              onChanged: (_) => _validateActiveMethod(dueAmount),
            ),
            const SizedBox(height: 12),
            _buildPaymentField(
              controller: _cardAmountController,
              label: 'Amount *',
              hint: 'ব্যাংকের নাম',
              keyboardType: TextInputType.number,
              inputFormatters: [FilteringTextInputFormatter.digitsOnly],
              errorText: _cardAmountError,
              onChanged: (_) => _validateActiveMethod(dueAmount),
            ),
          ],
        );
      case DokanPosPaymentMethod.cash:
        return Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('Cash payment flow', style: TextStyle(color: Color(0xFF163732), fontSize: 13.5, fontWeight: FontWeight.w700)),
            const SizedBox(height: 12),
            _buildPaymentField(
              controller: _cashAmountController,
              label: 'Amount *',
              hint: 'MM/YY',
              keyboardType: TextInputType.number,
              inputFormatters: [FilteringTextInputFormatter.digitsOnly],
              errorText: _cashAmountError,
              onChanged: (_) => _validateActiveMethod(dueAmount),
            ),
          ],
        );
      case DokanPosPaymentMethod.rocket:
      case DokanPosPaymentMethod.bank:
        return const _SupplierSectionEmptyState(label: 'এই পেমেন্ট পদ্ধতি এখন সমর্থিত নয়');
    }
  }

  @override
  Widget build(BuildContext context) {
    final state = ref.watch(dokanPosProvider);
    final summaries = _buildSupplierSummaries(state);
    _SupplierSummary? supplier;
    for (final item in summaries) {
      if (item.key == widget.supplierKey) {
        supplier = item;
        break;
      }
    }

    if (supplier == null) {
      return const _SupplierErrorScreen(message: 'সরবরাহকারীর তথ্য পাওয়া যায়নি');
    }

    final selectedSupplier = supplier;
    final dueAmount = selectedSupplier.totalDue;
    final canSubmit = !_isSubmitting && _canSubmitForMethod(dueAmount);

    return Scaffold(
      backgroundColor: const Color(0xFFF4F8F6),
      body: SafeArea(
        child: ListView(
          physics: const AlwaysScrollableScrollPhysics(parent: ClampingScrollPhysics()),
          padding: const EdgeInsets.fromLTRB(16, 12, 16, 24),
          children: [
            Row(
              children: [
                _HeaderButton(
                  icon: Icons.arrow_back_rounded,
                  onTap: () => Navigator.of(context).maybePop(),
                ),
                const SizedBox(width: 12),
                const Expanded(
                  child: Text(
                    'সরবরাহকারী পেমেন্ট',
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      color: Color(0xFF163732),
                      fontSize: 18,
                      fontWeight: FontWeight.w800,
                    ),
                  ),
                ),
                const SizedBox(width: 40),
              ],
            ),
            const SizedBox(height: 14),
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: const Color(0xFFD9E5E1)),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'সরবরাহকারীর বিবরণ',
                    style: TextStyle(
                      color: Color(0xFF163732),
                      fontSize: 15,
                      fontWeight: FontWeight.w800,
                    ),
                  ),
                  const SizedBox(height: 14),
                  _InfoRow(label: 'নাম', value: selectedSupplier.name),
                  const Divider(height: 24),
                  _InfoRow(
                    label: 'বকেয়া',
                    value: _formatCurrency(dueAmount),
                    valueColor: const Color(0xFFB3261E),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 14),
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: const Color(0xFFD9E5E1)),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'পেমেন্ট তথ্য',
                    style: TextStyle(
                      color: Color(0xFF163732),
                      fontSize: 15,
                      fontWeight: FontWeight.w800,
                    ),
                  ),
                  const SizedBox(height: 12),
                  _buildSelectedMethodForm(dueAmount),
                  const SizedBox(height: 12),
                  Wrap(
                    spacing: 10,
                    runSpacing: 10,
                    children: [
                      _actionChip(
                        label: 'Full due',
                        onTap: () {
                          _populateAmountForSelectedMethod(dueAmount.toString());
                          _validateActiveMethod(dueAmount);
                        },
                      ),
                      _actionChip(
                        label: 'Half due',
                        onTap: () {
                          final half = dueAmount ~/ 2;
                          _populateAmountForSelectedMethod((half <= 0 ? dueAmount : half).toString());
                          _validateActiveMethod(dueAmount);
                        },
                      ),
                      _actionChip(
                        label: 'Custom',
                        onTap: () {
                          _populateAmountForSelectedMethod('');
                          _validateActiveMethod(dueAmount);
                        },
                      ),
                    ],
                  ),
                ],
              ),
            ),
            const SizedBox(height: 14),
            const Text(
              'পেমেন্ট পদ্ধতি',
              style: TextStyle(
                color: Color(0xFF163732),
                fontSize: 15,
                fontWeight: FontWeight.w800,
              ),
            ),
            const SizedBox(height: 12),
            ..._allowedSupplierPaymentMethods.map(
              (method) => Padding(
                padding: const EdgeInsets.only(bottom: 10),
                child: _SupplierPaymentMethodCard(
                  method: method,
                  selected: _selectedMethod == method,
                  onTap: () {
                    setState(() => _selectedMethod = method);
                    _validateActiveMethod(dueAmount);
                  },
                ),
              ),
            ),
            SizedBox(
              height: 52,
              child: FilledButton(
                onPressed: canSubmit
                    ? () async {
                        if (!_canSubmitForMethod(dueAmount)) {
                          _validateActiveMethod(dueAmount);
                          return;
                        }
                        await _showConfirmDialog(selectedSupplier);
                      }
                    : null,
                style: FilledButton.styleFrom(
                  backgroundColor: const Color(0xFF0C8C67),
                  foregroundColor: Colors.white,
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                ),
                child: _isSubmitting
                    ? const SizedBox(
                        width: 20,
                        height: 20,
                        child: CircularProgressIndicator(strokeWidth: 2.4, color: Colors.white),
                      )
                    : const Text('পেমেন্ট নিশ্চিত করুন'),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class DokanSupplierDetailScreen extends ConsumerWidget {
  const DokanSupplierDetailScreen({super.key, required this.supplierKey});

  final String supplierKey;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final state = ref.watch(dokanPosProvider);
    final summaries = _buildSupplierSummaries(state);
    _SupplierSummary? supplier;
    for (final item in summaries) {
      if (item.key == supplierKey) {
        supplier = item;
        break;
      }
    }

    if (supplier == null) {
      return const _SupplierErrorScreen(message: 'সরবরাহকারীর তথ্য পাওয়া যায়নি');
    }

    final selectedSupplier = supplier;
    final purchaseHistory = selectedSupplier.ledger.where((entry) => entry.kind == DokanSupplierLedgerKind.purchase).toList(growable: false);
    final paymentHistory = selectedSupplier.ledger.where((entry) => entry.kind == DokanSupplierLedgerKind.payment).toList(growable: false);
    final recentActivity = selectedSupplier.ledger.take(3).toList(growable: false);
    final hasPhone = selectedSupplier.phone.trim().isNotEmpty;
    final purchaseHistoryKey = GlobalKey();

    return Scaffold(
      backgroundColor: const Color(0xFFF4F8F6),
      body: SafeArea(
        child: ListView(
          physics: const AlwaysScrollableScrollPhysics(parent: ClampingScrollPhysics()),
          padding: const EdgeInsets.fromLTRB(16, 12, 16, 24),
          children: [
            Row(
              children: [
                _HeaderButton(
                  icon: Icons.arrow_back_rounded,
                  onTap: () => Navigator.of(context).maybePop(),
                ),
                const SizedBox(width: 12),
                const Expanded(
                  child: Text(
                    'সরবরাহকারীর বিস্তারিত',
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      color: Color(0xFF163732),
                      fontSize: 18,
                      fontWeight: FontWeight.w800,
                    ),
                  ),
                ),
                const SizedBox(width: 40),
              ],
            ),
            const SizedBox(height: 14),
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: const Color(0xFFD9E5E1)),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Container(
                        width: 58,
                        height: 58,
                        decoration: BoxDecoration(
                          color: const Color(0xFFE7F5EF),
                          borderRadius: BorderRadius.circular(18),
                        ),
                        alignment: Alignment.center,
                        child: Text(
                          _supplierInitials(selectedSupplier.name),
                          style: const TextStyle(
                            color: Color(0xFF0C8C67),
                            fontSize: 18,
                            fontWeight: FontWeight.w900,
                          ),
                        ),
                      ),
                      const SizedBox(width: 14),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              selectedSupplier.name,
                              style: const TextStyle(
                                color: Color(0xFF163732),
                                fontSize: 18,
                                fontWeight: FontWeight.w900,
                              ),
                            ),
                            const SizedBox(height: 4),
                            Text(
                              _supplierAddress(selectedSupplier.address),
                              style: const TextStyle(
                                color: Color(0xFF6B7B79),
                                fontSize: 13,
                                fontWeight: FontWeight.w500,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 16),
                  Wrap(
                    spacing: 10,
                    runSpacing: 10,
                    children: [
                      _miniInfoChip(icon: Icons.call_rounded, text: hasPhone ? selectedSupplier.phone : 'ফোন নেই'),
                      _miniInfoChip(
                        icon: Icons.inventory_2_rounded,
                        text: selectedSupplier.productType.isEmpty ? 'পণ্যের ধরন নেই' : selectedSupplier.productType,
                      ),
                      _miniInfoChip(
                        icon: Icons.percent_rounded,
                        text: selectedSupplier.creditLimit > 0 ? 'ক্রেডিট ${_formatCurrency(selectedSupplier.creditLimit)}' : 'ক্রেডিট নেই',
                      ),
                    ],
                  ),
                  const SizedBox(height: 16),
                  Row(
                    children: [
                      Expanded(
                        child: _SummaryCard(
                          icon: Icons.shopping_bag_rounded,
                          iconColor: const Color(0xFF0E855D),
                          iconBackground: const Color(0xFFE7F5EF),
                          title: 'মোট ক্রয়',
                          value: _formatCurrency(selectedSupplier.totalPurchase),
                          subtitle: 'এ পর্যন্ত মোট ক্রয়',
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: _SummaryCard(
                          icon: Icons.account_balance_wallet_rounded,
                          iconColor: const Color(0xFFB14A12),
                          iconBackground: const Color(0xFFFFF0E2),
                          title: 'মোট বকেয়া',
                          value: _formatCurrency(selectedSupplier.totalDue),
                          subtitle: selectedSupplier.totalDue > 0 ? 'এখনও বকেয়া আছে' : 'বকেয়া নেই',
                          valueColor: selectedSupplier.totalDue > 0 ? const Color(0xFFB3261E) : const Color(0xFF0C8C67),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
            const SizedBox(height: 14),
            Row(
              children: [
                Expanded(
                  child: FilledButton.icon(
                    onPressed: selectedSupplier.totalDue > 0
                        ? () {
                            Navigator.of(context).push(
                              MaterialPageRoute(
                                builder: (_) => DokanSupplierPaymentScreen(supplierKey: selectedSupplier.key),
                              ),
                            );
                          }
                        : null,
                    icon: const Icon(Icons.payments_rounded),
                    label: const Text('পেমেন্ট করুন'),
                    style: FilledButton.styleFrom(
                      backgroundColor: const Color(0xFF0C8C67),
                      foregroundColor: Colors.white,
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                    ),
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: OutlinedButton.icon(
                    onPressed: () {
                      final targetContext = purchaseHistoryKey.currentContext;
                      if (targetContext != null) {
                        Scrollable.ensureVisible(
                          targetContext,
                          duration: const Duration(milliseconds: 320),
                          curve: Curves.easeOutCubic,
                          alignment: 0.08,
                        );
                      }
                    },
                    icon: const Icon(Icons.receipt_long_rounded),
                    label: const Text('ক্রয় ইতিহাস'),
                    style: OutlinedButton.styleFrom(
                      foregroundColor: const Color(0xFF163732),
                      side: const BorderSide(color: Color(0xFFD9E5E1)),
                      backgroundColor: Colors.white,
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 10),
            if (hasPhone)
              OutlinedButton.icon(
                onPressed: () async {
                  final digits = _supplierPhoneForWhatsApp(selectedSupplier.phone);
                  if (digits.isEmpty) {
                    return;
                  }
                  final success = await launchUrl(
                    Uri.parse('https://wa.me/$digits?text=${Uri.encodeComponent('নতুন পণ্য অর্ডার, ${selectedSupplier.name}')}'),
                    mode: LaunchMode.externalApplication,
                  );
                  if (!success && context.mounted) {
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(content: Text('WhatsApp চালু করা যায়নি')),
                    );
                  }
                },
                icon: const Icon(Icons.chat_rounded),
                label: const Text('WhatsApp order'),
                style: OutlinedButton.styleFrom(
                  foregroundColor: const Color(0xFF163732),
                  side: const BorderSide(color: Color(0xFFD9E5E1)),
                  backgroundColor: Colors.white,
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                ),
              ),
            const SizedBox(height: 14),
            KeyedSubtree(
              key: purchaseHistoryKey,
              child: _DetailSection(
                title: 'ক্রয় ইতিহাস',
                child: _SupplierLedgerHistoryList(
                  emptyLabel: 'কোনো ক্রয় ইতিহাস নেই',
                  records: purchaseHistory,
                ),
              ),
            ),
            const SizedBox(height: 14),
            _DetailSection(
              title: 'পেমেন্ট ইতিহাস',
              child: _SupplierLedgerHistoryList(
                emptyLabel: 'কোনো পেমেন্ট ইতিহাস নেই',
                records: paymentHistory,
              ),
            ),
            const SizedBox(height: 14),
            _DetailSection(
              title: 'সাম্প্রতিক কার্যক্রম',
              child: _SupplierLedgerHistoryList(
                emptyLabel: 'কোনো সাম্প্রতিক কার্যক্রম নেই',
                records: recentActivity,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class DokanAllDuesSummaryScreen extends StatelessWidget {
  const DokanAllDuesSummaryScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return const DokanPlaceholderScreen(
      title: 'DokanERP All-Dues Summary',
      subtitle: 'Summary of due balances across customers and suppliers.',
    );
  }
}

class DokanDueCollectionScreen extends StatelessWidget {
  const DokanDueCollectionScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return const DokanPlaceholderScreen(
      title: 'DokanERP Due Collection Screen',
      subtitle: 'Collect customer due payments.',
    );
  }
}

class DokanCustomerListScreen extends ConsumerStatefulWidget {
  const DokanCustomerListScreen({super.key});

  @override
  ConsumerState<DokanCustomerListScreen> createState() => _DokanCustomerListScreenState();
}

class _DokanCustomerListScreenState extends ConsumerState<DokanCustomerListScreen> {
  final TextEditingController _searchController = TextEditingController();
  bool _ready = false;
  String _query = '';

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!mounted) {
        return;
      }
      setState(() => _ready = true);
    });
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  Future<void> _onRefresh() async {
    await Future<void>.delayed(const Duration(milliseconds: 450));
    if (mounted) {
      setState(() {});
    }
  }

  @override
  Widget build(BuildContext context) {
    final state = ref.watch(dokanPosProvider);

    if (!_ready) {
      return const _CustomerLoadingScreen();
    }

    try {
      final customers = _buildCustomerSummaries(state);
      final filteredCustomers = _query.trim().isEmpty
          ? customers
          : customers.where((customer) {
              final query = _query.trim().toLowerCase();
              return customer.name.toLowerCase().contains(query) ||
                  customer.phone.toLowerCase().contains(query);
            }).toList(growable: false);

      final totalCustomers = customers.length;
      final totalReceivable = customers.fold<int>(0, (sum, customer) => sum + customer.totalDue);
      final dueCustomers = customers.where((customer) => customer.totalDue > 0).length;

      return Scaffold(
        backgroundColor: const Color(0xFFF4F8F6),
        floatingActionButton: FloatingActionButton.extended(
          onPressed: () => _showAddCustomerSheet(context, ref),
          backgroundColor: const Color(0xFF0C8C67),
          foregroundColor: Colors.white,
          icon: const Icon(Icons.person_add_alt_1_rounded),
          label: const Text('গ্রাহক যোগ করুন'),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        ),
        body: SafeArea(
          bottom: false,
          child: Column(
            children: [
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 10, 16, 12),
                child: Row(
                  children: [
                    _HeaderButton(
                      icon: Icons.arrow_back_rounded,
                      onTap: () => Navigator.of(context).maybePop(),
                    ),
                    const SizedBox(width: 12),
                    const Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'গ্রাহক',
                            style: TextStyle(
                              color: Color(0xFF163732),
                              fontSize: 22,
                              fontWeight: FontWeight.w800,
                            ),
                          ),
                          SizedBox(height: 2),
                          Text(
                            'গ্রাহকের তথ্য, বাকি ও ট্রানজেকশন',
                            style: TextStyle(
                              color: Color(0xFF6B7B79),
                              fontSize: 13,
                              fontWeight: FontWeight.w500,
                            ),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(width: 8),
                      _HeaderButton(
                        icon: Icons.refresh_rounded,
                        onTap: _onRefresh,
                      ),
                  ],
                ),
              ),
              Expanded(
                child: RefreshIndicator(
                  onRefresh: _onRefresh,
                  color: const Color(0xFF0C8C67),
                  child: ListView(
                    physics: const AlwaysScrollableScrollPhysics(parent: ClampingScrollPhysics()),
                    padding: const EdgeInsets.fromLTRB(16, 0, 16, 96),
                    children: [
                      _SearchField(
                        controller: _searchController,
                        query: _query,
                        onChanged: (value) => setState(() => _query = value),
                        onClear: () {
                          _searchController.clear();
                          setState(() => _query = '');
                        },
                      ),
                      const SizedBox(height: 14),
                      _ReceivableHeroCard(
                        totalReceivable: totalReceivable,
                        totalCustomers: totalCustomers,
                        dueCustomers: dueCustomers,
                      ),
                      const SizedBox(height: 14),
                      Row(
                        children: [
                          Expanded(
                            child: _SummaryCard(
                              icon: Icons.people_alt_rounded,
                              iconColor: const Color(0xFF0E855D),
                              iconBackground: const Color(0xFFE7F5EF),
                              title: 'গ্রাহক',
                              value: _banglaDigits(totalCustomers.toString()),
                              subtitle: dueCustomers > 0
                                  ? 'বাকি আছে ${_banglaDigits(dueCustomers.toString())} জন'
                                  : 'সব হিসাব আপডেট আছে',
                            ),
                          ),
                          const SizedBox(width: 12),
                          Expanded(
                            child: _SummaryCard(
                              icon: Icons.account_balance_wallet_rounded,
                              iconColor: const Color(0xFFB14A12),
                              iconBackground: const Color(0xFFFFF0E2),
                              title: 'মোট পাওনা',
                              value: _formatCurrency(totalReceivable),
                              subtitle: 'সকল গ্রাহকের বাকি যোগফল',
                              valueColor: const Color(0xFFB3261E),
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 14),
                      if (_query.trim().isNotEmpty)
                        Padding(
                          padding: const EdgeInsets.only(bottom: 10),
                          child: Text(
                            'ফলাফল: ${_banglaDigits(filteredCustomers.length.toString())} জন গ্রাহক',
                            style: const TextStyle(
                              color: Color(0xFF516462),
                              fontSize: 13,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                        ),
                      if (filteredCustomers.isEmpty)
                        const _CustomerEmptyState()
                      else
                        ...filteredCustomers.map(
                          (customer) => Padding(
                            padding: const EdgeInsets.only(bottom: 12),
                            child: Dismissible(
                              key: ValueKey('customer-${customer.key}'),
                              direction: DismissDirection.endToStart,
                              background: Container(
                                decoration: BoxDecoration(
                                  color: const Color(0xFFFDECEC),
                                  borderRadius: BorderRadius.circular(16),
                                ),
                                alignment: Alignment.centerRight,
                                padding: const EdgeInsets.symmetric(horizontal: 18),
                                child: const Row(
                                  mainAxisAlignment: MainAxisAlignment.end,
                                  children: [
                                    Icon(Icons.delete_rounded, color: Color(0xFFD6453A)),
                                    SizedBox(width: 8),
                                    Text(
                                      'বাদ দিন',
                                      style: TextStyle(
                                        color: Color(0xFFD6453A),
                                        fontWeight: FontWeight.w800,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              confirmDismiss: (_) => _confirmDeleteCustomer(context, ref, customer),
                              child: _CustomerListTile(
                                customer: customer,
                                onTap: () => Navigator.of(context).push(
                                  MaterialPageRoute(
                                    builder: (_) => DokanCustomerDetailScreen(customerKey: customer.key),
                                  ),
                                ),
                                onLongPress: () => _confirmDeleteCustomer(context, ref, customer),
                              ),
                            ),
                          ),
                        ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      );
    } catch (_) {
      return const _CustomerErrorScreen();
    }
  }
}

class DokanCustomerDetailScreen extends ConsumerWidget {
  const DokanCustomerDetailScreen({super.key, required this.customerKey});

  final String customerKey;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final state = ref.watch(dokanPosProvider);

    try {
      final customers = _buildCustomerSummaries(state);
      _CustomerSummary? customer;
      for (final item in customers) {
        if (item.key == customerKey) {
          customer = item;
          break;
        }
      }

      if (customer == null) {
        return const _CustomerErrorScreen(message: 'গ্রাহকের তথ্য পাওয়া যায়নি');
      }
      final selectedCustomer = customer;

      final transactionHistory = selectedCustomer.orders;
      final paymentHistory = selectedCustomer.orders.where((order) => order.paidAmount > 0).toList(growable: false);
      final recentActivity = selectedCustomer.orders.take(3).toList(growable: false);

      return Scaffold(
        backgroundColor: const Color(0xFFF4F8F6),
        body: SafeArea(
          bottom: true,
          child: RefreshIndicator(
            onRefresh: () async {
              await Future<void>.delayed(const Duration(milliseconds: 400));
            },
            color: const Color(0xFF0C8C67),
            child: ListView(
              physics: const AlwaysScrollableScrollPhysics(parent: ClampingScrollPhysics()),
              padding: const EdgeInsets.fromLTRB(16, 10, 16, 28),
              children: [
                Row(
                  children: [
                    _HeaderButton(
                      icon: Icons.arrow_back_rounded,
                      onTap: () => Navigator.of(context).maybePop(),
                    ),
                    const SizedBox(width: 12),
                    const Expanded(
                      child: Text(
                        'গ্রাহক প্রোফাইল',
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          color: Color(0xFF163732),
                          fontSize: 18,
                          fontWeight: FontWeight.w800,
                        ),
                      ),
                    ),
                    const SizedBox(width: 40),
                  ],
                ),
                const SizedBox(height: 14),
                _CustomerProfileCard(customer: selectedCustomer),
                const SizedBox(height: 14),
                _CustomerStatsGrid(customer: selectedCustomer),
                const SizedBox(height: 14),
                _DetailSection(
                  title: 'গ্রাহক তথ্য',
                  child: Column(
                    children: [
                      _InfoRow(
                        label: 'ফোন নম্বর',
                        value: selectedCustomer.phone.isEmpty ? 'সংরক্ষিত নেই' : selectedCustomer.phone,
                      ),
                      const Divider(height: 24),
                      _InfoRow(label: 'ঠিকানা', value: selectedCustomer.address),
                      const Divider(height: 24),
                      _InfoRow(
                        label: 'শেষ ট্রানজেকশন',
                        value: _formatDateTime(selectedCustomer.lastTransactionAt),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 14),
                _DetailSection(
                  title: 'ক্রয় সারসংক্ষেপ',
                  child: Column(
                    children: [
                      _InfoRow(label: 'মোট ক্রয়', value: _formatCurrency(selectedCustomer.totalPurchase)),
                      const Divider(height: 24),
                      _InfoRow(label: 'মোট পরিশোধ', value: _formatCurrency(selectedCustomer.totalPaid)),
                      const Divider(height: 24),
                      _InfoRow(
                        label: 'বর্তমান বাকি',
                        value: _formatCurrency(selectedCustomer.totalDue),
                        valueColor: selectedCustomer.totalDue > 0 ? const Color(0xFFB3261E) : const Color(0xFF0C8C67),
                      ),
                      const Divider(height: 24),
                      _InfoRow(label: 'লেনদেন সংখ্যা', value: '${_banglaDigits(selectedCustomer.orders.length.toString())} টি'),
                    ],
                  ),
                ),
                const SizedBox(height: 14),
                _DetailSection(
                  title: 'ট্রানজেকশন ইতিহাস',
                  child: _HistoryList(
                    emptyLabel: 'এই গ্রাহকের কোনো ট্রানজেকশন নেই',
                    records: transactionHistory,
                    itemBuilder: (record) => _TransactionTile(record: record),
                  ),
                ),
                const SizedBox(height: 14),
                _DetailSection(
                  title: 'পেমেন্ট ইতিহাস',
                  child: _HistoryList(
                    emptyLabel: 'এই গ্রাহকের কোনো পেমেন্ট নেই',
                    records: paymentHistory,
                    itemBuilder: (record) => _PaymentTile(record: record),
                  ),
                ),
                const SizedBox(height: 14),
                _DetailSection(
                  title: 'সাম্প্রতিক কার্যক্রম',
                  child: _HistoryList(
                    emptyLabel: 'কোনো সাম্প্রতিক কার্যক্রম নেই',
                    records: recentActivity,
                    itemBuilder: (record) => _ActivityTile(record: record),
                  ),
                ),
                const SizedBox(height: 18),
                SizedBox(
                  height: 52,
                  child: FilledButton.icon(
                    onPressed: () => Navigator.of(context).maybePop(),
                    icon: const Icon(Icons.arrow_back_rounded),
                    label: const Text('ফিরে যান'),
                    style: FilledButton.styleFrom(
                      backgroundColor: const Color(0xFF163732),
                      foregroundColor: Colors.white,
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      );
    } catch (_) {
      return const _CustomerErrorScreen(message: 'গ্রাহক প্রোফাইল লোড করা যায়নি');
    }
  }
}

Future<void> _callCustomer(BuildContext context, String phone) async {
  final uri = Uri(scheme: 'tel', path: phone);
  final success = await launchUrl(uri, mode: LaunchMode.externalApplication);
  if (!success && context.mounted) {
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('কল শুরু করা যায়নি')),
    );
  }
}

Future<bool> _showBulkDeleteDialog({
  required BuildContext context,
  required String entityLabel,
  required List<String> names,
}) async {
  final confirmed = await showDialog<bool>(
        context: context,
        builder: (dialogContext) {
          return AlertDialog(
            title: const Text('আপনি কি নিশ্চিত?'),
            content: Text(
              '${names.join(' • ')}\n\nনির্বাচিত $entityLabel(গুলো) মুছতে চান?',
            ),
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
            actionsPadding: const EdgeInsets.fromLTRB(20, 0, 12, 12),
            actions: [
              TextButton(
                onPressed: () => Navigator.of(dialogContext).pop(false),
                child: const Text('বাতিল'),
              ),
              FilledButton(
                onPressed: () => Navigator.of(dialogContext).pop(true),
                style: FilledButton.styleFrom(
                  backgroundColor: const Color(0xFFD6453A),
                  foregroundColor: Colors.white,
                ),
                child: const Text('মুছুন'),
              ),
            ],
          );
        },
      ) ??
      false;
  return confirmed;
}

Future<bool> _confirmDeleteCustomer(
  BuildContext context,
  WidgetRef ref,
  _CustomerSummary customer,
) async {
  final confirmed = await showDialog<bool>(
        context: context,
        builder: (dialogContext) {
          return AlertDialog(
            title: const Text('গ্রাহক বাদ দিন'),
            content: Text(
              '${customer.name} গ্রাহককে তালিকা থেকে বাদ দিতে চান?\n\nসতর্কতা: এটি তালিকা থেকে সরিয়ে দেবে, কিন্তু আগের লেনদেনের ডাটা সিস্টেমে থাকতে পারে।',
            ),
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
            actionsPadding: const EdgeInsets.fromLTRB(20, 0, 12, 12),
            actions: [
              TextButton(
                onPressed: () => Navigator.of(dialogContext).pop(false),
                child: const Text('বাতিল'),
              ),
              FilledButton(
                onPressed: () => Navigator.of(dialogContext).pop(true),
                style: FilledButton.styleFrom(
                  backgroundColor: const Color(0xFFD6453A),
                  foregroundColor: Colors.white,
                ),
                child: const Text('বাদ দিন'),
              ),
            ],
          );
        },
      ) ??
      false;

  if (confirmed) {
    ref.read(dokanPosProvider.notifier).deleteCustomer(customer.key);
  }

  return confirmed;
}

Future<void> _showAddCustomerSheet(BuildContext context, WidgetRef ref) async {
  final nameController = TextEditingController();
  final phoneController = TextEditingController();
  final addressController = TextEditingController();
  final openingDueController = TextEditingController();

  await showModalBottomSheet<void>(
    context: context,
    isScrollControlled: true,
    useSafeArea: true,
    backgroundColor: Colors.transparent,
    builder: (sheetContext) {
      bool isSubmitting = false;
      String? nameError;
      String? phoneError;
      String? openingDueError;

      bool isPhoneValid(String value) => RegExp(r'^[0-9]{11}$').hasMatch(value.trim());
      bool isNameValid(String value) => value.trim().isNotEmpty;

      return StatefulBuilder(
        builder: (context, setSheetState) {
          final openingDueText = openingDueController.text.trim();
          final openingDueValue = openingDueText.isEmpty ? 0 : int.tryParse(openingDueText);
          final openingDueHasError = openingDueText.isNotEmpty && (openingDueValue == null || openingDueValue < 0);
          final canSubmit =
              !isSubmitting && isNameValid(nameController.text) && isPhoneValid(phoneController.text) && !openingDueHasError;

          return AnimatedPadding(
            duration: const Duration(milliseconds: 180),
            curve: Curves.easeOut,
            padding: EdgeInsets.only(bottom: MediaQuery.of(sheetContext).viewInsets.bottom + 12),
            child: Container(
              width: double.infinity,
              decoration: const BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.vertical(top: Radius.circular(28)),
              ),
              child: SingleChildScrollView(
                keyboardDismissBehavior: ScrollViewKeyboardDismissBehavior.onDrag,
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(16, 12, 16, 16),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Center(
                        child: Container(
                          width: 44,
                          height: 4,
                          decoration: BoxDecoration(
                            color: const Color(0xFFD6E4E0),
                            borderRadius: BorderRadius.circular(999),
                          ),
                        ),
                      ),
                      const SizedBox(height: 14),
                      const Text(
                        'গ্রাহক যোগ করুন',
                        style: TextStyle(
                          color: Color(0xFF163732),
                          fontSize: 18,
                          fontWeight: FontWeight.w900,
                        ),
                      ),
                      const SizedBox(height: 12),
                      TextField(
                        controller: nameController,
                        onChanged: (_) {
                          setSheetState(() {
                            nameError = isNameValid(nameController.text) ? null : 'নাম দিতে হবে';
                          });
                        },
                        style: const TextStyle(color: Color(0xFF111111)),
                        decoration: InputDecoration(
                          labelText: 'নাম *',
                          errorText: nameError,
                          filled: true,
                          fillColor: const Color(0xFFF7FAF9),
                          border: OutlineInputBorder(borderRadius: BorderRadius.circular(18)),
                        ),
                      ),
                      const SizedBox(height: 10),
                      TextField(
                        controller: phoneController,
                        keyboardType: TextInputType.phone,
                        onChanged: (_) {
                          setSheetState(() {
                            phoneError = isPhoneValid(phoneController.text) ? null : '১১ সংখ্যার সঠিক নম্বর লিখুন';
                          });
                        },
                        style: const TextStyle(color: Color(0xFF111111)),
                        decoration: InputDecoration(
                          labelText: 'ফোন নম্বর *',
                          errorText: phoneError,
                          filled: true,
                          fillColor: const Color(0xFFF7FAF9),
                          border: OutlineInputBorder(borderRadius: BorderRadius.circular(18)),
                        ),
                      ),
                      const SizedBox(height: 10),
                      TextField(
                        controller: addressController,
                        style: const TextStyle(color: Color(0xFF111111)),
                        decoration: InputDecoration(
                          labelText: 'ঠিকানা',
                          filled: true,
                          fillColor: const Color(0xFFF7FAF9),
                          border: OutlineInputBorder(borderRadius: BorderRadius.circular(18)),
                        ),
                      ),
                      const SizedBox(height: 10),
                      TextField(
                        controller: openingDueController,
                        keyboardType: TextInputType.number,
                        onChanged: (_) {
                          setSheetState(() {
                            final text = openingDueController.text.trim();
                            final amount = text.isEmpty ? 0 : int.tryParse(text);
                            openingDueError = text.isEmpty || (amount != null && amount >= 0)
                                ? null
                                : 'বাকি টাকার পরিমাণ সঠিক নয়';
                          });
                        },
                        style: const TextStyle(color: Color(0xFF111111)),
                        decoration: InputDecoration(
                          labelText: 'প্রারম্ভিক বাকি',
                          errorText: openingDueError,
                          filled: true,
                          fillColor: const Color(0xFFF7FAF9),
                          border: OutlineInputBorder(borderRadius: BorderRadius.circular(18)),
                        ),
                      ),
                      const SizedBox(height: 16),
                      SizedBox(
                        height: 52,
                        width: double.infinity,
                        child: FilledButton(
                          onPressed: canSubmit
                              ? () async {
                                  setSheetState(() {
                                    nameError = isNameValid(nameController.text) ? null : 'নাম দিতে হবে';
                                    phoneError = isPhoneValid(phoneController.text) ? null : '১১ সংখ্যার সঠিক নম্বর লিখুন';
                                    final text = openingDueController.text.trim();
                                    final amount = text.isEmpty ? 0 : int.tryParse(text);
                                    openingDueError = text.isEmpty || (amount != null && amount >= 0)
                                        ? null
                                        : 'বাকি টাকার পরিমাণ সঠিক নয়';
                                  });

                                  if (!isNameValid(nameController.text) || !isPhoneValid(phoneController.text)) {
                                    return;
                                  }

                                  final openingDueText = openingDueController.text.trim();
                                  final openingDue = openingDueText.isEmpty ? 0 : int.tryParse(openingDueText) ?? -1;
                                  if (openingDue < 0) {
                                    setSheetState(() => openingDueError = 'বাকি টাকার পরিমাণ সঠিক নয়');
                                    return;
                                  }

                                  setSheetState(() => isSubmitting = true);
                                  await Future<void>.delayed(const Duration(milliseconds: 250));
                                  ref.read(dokanPosProvider.notifier).addCustomer(
                                        name: nameController.text,
                                        phone: phoneController.text,
                                        address: addressController.text,
                                        openingDue: openingDue,
                                      );
                                  if (sheetContext.mounted) {
                                    Navigator.of(sheetContext).pop();
                                  }
                                  if (context.mounted) {
                                    ScaffoldMessenger.of(context).showSnackBar(
                                      const SnackBar(content: Text('গ্রাহক যোগ করা হয়েছে')),
                                    );
                                  }
                                }
                              : null,
                          style: FilledButton.styleFrom(
                            backgroundColor: const Color(0xFF0C8C67),
                            foregroundColor: Colors.white,
                            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                          ),
                          child: isSubmitting
                              ? const SizedBox(
                                  width: 20,
                                  height: 20,
                                  child: CircularProgressIndicator(
                                    strokeWidth: 2.4,
                                    color: Colors.white,
                                  ),
                                )
                              : const Text('সংরক্ষণ'),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          );
        },
      );
    },
  );
}

List<_CustomerSummary> _buildCustomerSummaries(DokanPosState state) {
  final grouped = <String, List<DokanPosOrderRecord>>{};
  for (final order in state.orders) {
    final key = _customerKeyForOrder(order);
    if (state.hiddenCustomerKeys.contains(key)) {
      continue;
    }
    grouped.putIfAbsent(key, () => <DokanPosOrderRecord>[]).add(order);
  }

  final profilesByKey = <String, DokanCustomerProfileRecord>{
    for (final profile in state.customerProfiles) profile.key: profile,
  };

  final allKeys = <String>{...grouped.keys, ...profilesByKey.keys}
      .where((key) => !state.hiddenCustomerKeys.contains(key))
      .toList(growable: false);

  final customers = allKeys.map((key) {
    final profile = profilesByKey[key];
    final purchaseOrders = List<DokanPosOrderRecord>.from(grouped[key] ?? const <DokanPosOrderRecord>[])
      ..sort((a, b) => b.createdAt.compareTo(a.createdAt));
    final openingDue = profile?.openingDue ?? 0;
    final totalPurchase = purchaseOrders.fold<int>(0, (sum, order) => sum + order.totalAmount);
    final totalPaid = purchaseOrders.fold<int>(0, (sum, order) => sum + order.paidAmount);
    final orderDue = purchaseOrders.fold<int>(0, (sum, order) => sum + order.dueAmount);
    final totalDue = orderDue + openingDue;
    final name = _customerDisplayName(
      profile?.name ?? (purchaseOrders.isNotEmpty ? purchaseOrders.first.customerName : key),
    );
    final phone = profile?.phone.trim().isNotEmpty == true
        ? profile!.phone.trim()
        : (purchaseOrders.isNotEmpty ? purchaseOrders.first.customerNumber.trim() : '');
    final address = _customerAddress(profile?.address ?? '');
    final firstTransactionAt = purchaseOrders.isNotEmpty
        ? purchaseOrders.last.createdAt
        : (profile?.createdAt ?? DateTime.now());
    final lastTransactionAt = purchaseOrders.isNotEmpty
        ? purchaseOrders.first.createdAt
        : (profile?.updatedAt ?? firstTransactionAt);
    final openingRecord = openingDue > 0
        ? DokanPosOrderRecord(
            id: 'opening-$key',
            customerName: name,
            customerNumber: phone,
            totalAmount: openingDue,
            paidAmount: 0,
            dueAmount: openingDue,
            paymentMethod: DokanPosPaymentMethod.cash,
            status: DokanPosOrderStatus.due,
            summary: 'প্রারম্ভিক বাকি',
            createdAt: purchaseOrders.isNotEmpty
                ? firstTransactionAt.subtract(const Duration(microseconds: 1))
                : firstTransactionAt,
          )
        : null;
    final openingRecords = openingRecord == null
        ? const <DokanPosOrderRecord>[]
        : <DokanPosOrderRecord>[openingRecord];
    final historyOrders = <DokanPosOrderRecord>[
      ...openingRecords,
      ...purchaseOrders,
    ]..sort((a, b) => b.createdAt.compareTo(a.createdAt));

    return _CustomerSummary(
      key: key,
      name: name,
      phone: phone,
      address: address,
      totalPurchase: totalPurchase,
      totalPaid: totalPaid,
      totalDue: totalDue,
      openingDue: openingDue,
      orders: List<DokanPosOrderRecord>.unmodifiable(historyOrders),
      transactionOrders: List<DokanPosOrderRecord>.unmodifiable(purchaseOrders),
      firstTransactionAt: firstTransactionAt,
      lastTransactionAt: lastTransactionAt,
      createdAt: profile?.createdAt ?? firstTransactionAt,
    );
  }).toList(growable: false)
    ..sort((a, b) {
      final dueCompare = b.totalDue.compareTo(a.totalDue);
      if (dueCompare != 0) {
        return dueCompare;
      }
      return b.lastTransactionAt.compareTo(a.lastTransactionAt);
    });

  return customers;
}

class _CustomerSummary {
  const _CustomerSummary({
    required this.key,
    required this.name,
    required this.phone,
    required this.address,
    required this.totalPurchase,
    required this.totalPaid,
    required this.totalDue,
    required this.openingDue,
    required this.orders,
    required this.transactionOrders,
    required this.firstTransactionAt,
    required this.lastTransactionAt,
    required this.createdAt,
  });

  final String key;
  final String name;
  final String phone;
  final String address;
  final int totalPurchase;
  final int totalPaid;
  final int totalDue;
  final int openingDue;
  final List<DokanPosOrderRecord> orders;
  final List<DokanPosOrderRecord> transactionOrders;
  final DateTime firstTransactionAt;
  final DateTime lastTransactionAt;
  final DateTime createdAt;
}

class _CustomerLoadingScreen extends StatelessWidget {
  const _CustomerLoadingScreen();

  @override
  Widget build(BuildContext context) {
    return const Scaffold(
      backgroundColor: Color(0xFFF4F8F6),
      body: SafeArea(
        child: Center(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              CircularProgressIndicator(color: Color(0xFF0C8C67)),
              SizedBox(height: 14),
              Text(
                'গ্রাহকের তথ্য লোড হচ্ছে...',
                style: TextStyle(
                  color: Color(0xFF4E625F),
                  fontWeight: FontWeight.w600,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _CustomerErrorScreen extends StatelessWidget {
  const _CustomerErrorScreen({this.message = 'গ্রাহকের তথ্য পাওয়া যায়নি'});

  final String message;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF4F8F6),
      body: SafeArea(
        child: Center(
          child: Padding(
            padding: const EdgeInsets.all(24),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(
                  width: 76,
                  height: 76,
                  decoration: BoxDecoration(
                    color: const Color(0xFFFDECEC),
                    borderRadius: BorderRadius.circular(24),
                  ),
                  child: const Icon(
                    Icons.person_off_rounded,
                    color: Color(0xFFD6453A),
                    size: 40,
                  ),
                ),
                const SizedBox(height: 16),
                Text(
                  message,
                  textAlign: TextAlign.center,
                  style: const TextStyle(
                    color: Color(0xFF163732),
                    fontSize: 18,
                    fontWeight: FontWeight.w800,
                  ),
                ),
                const SizedBox(height: 8),
                const Text(
                  'দয়া করে আবার চেষ্টা করুন অথবা গ্রাহক ডেটা চেক করুন।',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    color: Color(0xFF6B7B79),
                    height: 1.4,
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _SearchField extends StatelessWidget {
  const _SearchField({
    required this.controller,
    required this.query,
    required this.onChanged,
    required this.onClear,
  });

  final TextEditingController controller;
  final String query;
  final ValueChanged<String> onChanged;
  final VoidCallback onClear;

  @override
  Widget build(BuildContext context) {
    return TextField(
      controller: controller,
      onChanged: onChanged,
      style: const TextStyle(color: Color(0xFF111111)),
      cursorColor: const Color(0xFF0C8C67),
      decoration: InputDecoration(
        hintText: 'নাম বা নম্বর খুঁজুন',
        prefixIcon: const Icon(Icons.search_rounded),
        suffixIcon: query.isEmpty
            ? null
            : IconButton(
                onPressed: onClear,
                icon: const Icon(Icons.close_rounded),
              ),
        filled: true,
        fillColor: Colors.white,
        hintStyle: const TextStyle(color: Color(0xFF111111)),
        prefixIconColor: const Color(0xFF0C8C67),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(16),
          borderSide: const BorderSide(color: Color(0xFFD9E5E1)),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(16),
          borderSide: const BorderSide(color: Color(0xFFD9E5E1)),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(16),
          borderSide: const BorderSide(color: Color(0xFF0C8C67), width: 1.4),
        ),
      ),
    );
  }
}

class _SummaryCard extends StatelessWidget {
  const _SummaryCard({
    required this.icon,
    required this.iconColor,
    required this.iconBackground,
    required this.title,
    required this.value,
    required this.subtitle,
    this.valueColor,
  });

  final IconData icon;
  final Color iconColor;
  final Color iconBackground;
  final String title;
  final String value;
  final String subtitle;
  final Color? valueColor;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: const Color(0xFFD9E5E1)),
        boxShadow: const [
          BoxShadow(
            color: Color(0x08000000),
            blurRadius: 14,
            offset: Offset(0, 6),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: 40,
            height: 40,
            decoration: BoxDecoration(
              color: iconBackground,
              borderRadius: BorderRadius.circular(12),
            ),
            child: Icon(icon, color: iconColor, size: 22),
          ),
          const SizedBox(height: 12),
          Text(
            title,
            style: const TextStyle(
              color: Color(0xFF5C6C6A),
              fontSize: 12,
              fontWeight: FontWeight.w600,
            ),
          ),
          const SizedBox(height: 4),
          Text(
            value,
            style: TextStyle(
              color: valueColor ?? const Color(0xFF163732),
              fontSize: 18,
              fontWeight: FontWeight.w800,
            ),
          ),
          const SizedBox(height: 4),
          Text(
            subtitle,
            style: const TextStyle(
              color: Color(0xFF7A8A88),
              fontSize: 11.5,
              height: 1.25,
            ),
          ),
        ],
      ),
    );
  }
}

class _ReceivableHeroCard extends StatelessWidget {
  const _ReceivableHeroCard({
    required this.totalReceivable,
    required this.totalCustomers,
    required this.dueCustomers,
  });

  final int totalReceivable;
  final int totalCustomers;
  final int dueCustomers;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [Color(0xFF0F8C67), Color(0xFF0A6A4F)],
        ),
        borderRadius: BorderRadius.circular(16),
        boxShadow: const [
          BoxShadow(
            color: Color(0x220B5B40),
            blurRadius: 18,
            offset: Offset(0, 10),
          ),
        ],
      ),
      child: Row(
        children: [
          Container(
            width: 54,
            height: 54,
            decoration: BoxDecoration(
              color: Colors.white.withValues(alpha: 0.16),
              borderRadius: BorderRadius.circular(16),
            ),
            child: const Icon(
              Icons.account_balance_wallet_rounded,
              color: Colors.white,
              size: 28,
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'মোট পাওনা',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 14,
                    fontWeight: FontWeight.w700,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  _formatCurrency(totalReceivable),
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 24,
                    fontWeight: FontWeight.w900,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  'গ্রাহক ${_banglaDigits(totalCustomers.toString())} জন • বাকি আছে ${_banglaDigits(dueCustomers.toString())} জন',
                  style: TextStyle(
                    color: Colors.white.withValues(alpha: 0.86),
                    fontSize: 12,
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(width: 8),
          const Icon(Icons.chevron_right_rounded, color: Colors.white, size: 26),
        ],
      ),
    );
  }
}

class _CustomerListTile extends StatelessWidget {
  const _CustomerListTile({
    required this.customer,
    required this.onTap,
    required this.onLongPress,
  });

  final _CustomerSummary customer;
  final VoidCallback onTap;
  final VoidCallback onLongPress;

  @override
  Widget build(BuildContext context) {
    final dueColor = customer.totalDue > 0 ? const Color(0xFFB3261E) : const Color(0xFF0C8C67);
    final avatarColor = customer.totalDue > 0 ? const Color(0xFFFDECEC) : const Color(0xFFE7F5EF);
    final avatarTint = customer.totalDue > 0 ? const Color(0xFFD6453A) : const Color(0xFF0C8C67);

    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: onTap,
        onLongPress: onLongPress,
        borderRadius: BorderRadius.circular(16),
        child: Container(
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: const Color(0xFFD9E5E1)),
            boxShadow: const [
              BoxShadow(
                color: Color(0x07000000),
                blurRadius: 12,
                offset: Offset(0, 4),
              ),
            ],
          ),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                width: 48,
                height: 48,
                decoration: BoxDecoration(
                  color: avatarColor,
                  borderRadius: BorderRadius.circular(16),
                ),
                alignment: Alignment.center,
                child: Text(
                  _customerInitials(customer.name),
                  style: TextStyle(
                    color: avatarTint,
                    fontSize: 15,
                    fontWeight: FontWeight.w800,
                  ),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Expanded(
                          child: Text(
                            customer.name,
                            style: const TextStyle(
                              color: Color(0xFF163732),
                              fontSize: 16,
                              fontWeight: FontWeight.w800,
                            ),
                          ),
                        ),
                        if (customer.totalDue > 0)
                          _Pill(label: 'বাকি আছে', background: const Color(0xFFFDECEC), textColor: dueColor),
                        if (customer.totalDue <= 0)
                          const _Pill(
                            label: 'পরিশোধিত',
                            background: Color(0xFFE7F5EF),
                            textColor: Color(0xFF0C8C67),
                          ),
                      ],
                    ),
                    const SizedBox(height: 4),
                    Text(
                      customer.phone.isEmpty ? 'ফোন নম্বর সংরক্ষিত নেই' : customer.phone,
                      style: const TextStyle(
                        color: Color(0xFF6B7B79),
                        fontSize: 12.5,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                    const SizedBox(height: 10),
                    Wrap(
                      spacing: 8,
                      runSpacing: 8,
                      children: [
                        _MetricPill(
                          label: 'মোট ক্রয়',
                          value: _formatCurrency(customer.totalPurchase),
                        ),
                        _MetricPill(
                          label: 'বাকি',
                          value: _formatCurrency(customer.totalDue),
                          valueColor: dueColor,
                        ),
                        _MetricPill(
                          label: 'শেষ লেনদেন',
                          value: _formatDate(customer.lastTransactionAt),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 8),
              const Padding(
                padding: EdgeInsets.only(top: 6),
                child: Icon(
                  Icons.chevron_right_rounded,
                  color: Color(0xFF8C9A97),
                  size: 24,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _CustomerProfileCard extends StatelessWidget {
  const _CustomerProfileCard({required this.customer});

  final _CustomerSummary customer;

  @override
  Widget build(BuildContext context) {
    final dueColor = customer.totalDue > 0 ? const Color(0xFFD6453A) : const Color(0xFF0C8C67);

    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [Color(0xFF0F8C67), Color(0xFF0A6A4F)],
        ),
        borderRadius: BorderRadius.circular(16),
        boxShadow: const [
          BoxShadow(
            color: Color(0x220B5B40),
            blurRadius: 18,
            offset: Offset(0, 10),
          ),
        ],
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: 56,
            height: 56,
            decoration: BoxDecoration(
              color: Colors.white.withValues(alpha: 0.16),
              borderRadius: BorderRadius.circular(18),
            ),
            alignment: Alignment.center,
            child: Text(
              _customerInitials(customer.name),
              style: const TextStyle(
                color: Colors.white,
                fontSize: 18,
                fontWeight: FontWeight.w800,
              ),
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  customer.name,
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 20,
                    fontWeight: FontWeight.w800,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  customer.phone.isEmpty ? 'ফোন নম্বর নেই' : customer.phone,
                  style: TextStyle(
                    color: Colors.white.withValues(alpha: 0.88),
                    fontSize: 13,
                    fontWeight: FontWeight.w500,
                  ),
                ),
                const SizedBox(height: 12),
                Wrap(
                  spacing: 8,
                  runSpacing: 8,
                  children: [
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
                      decoration: BoxDecoration(
                        color: Colors.white.withValues(alpha: 0.16),
                        borderRadius: BorderRadius.circular(999),
                        border: Border.all(color: Colors.white.withValues(alpha: 0.12)),
                      ),
                      child: Text(
                        customer.totalDue > 0 ? 'বাকি ${_formatCurrency(customer.totalDue)}' : 'পরিশোধিত',
                        style: const TextStyle(
                          color: Colors.white,
                          fontSize: 12,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                    ),
                    if (customer.phone.isNotEmpty)
                      OutlinedButton.icon(
                        onPressed: () => _callCustomer(context, customer.phone),
                        icon: const Icon(Icons.call_rounded, size: 18),
                        label: const Text('কল'),
                        style: OutlinedButton.styleFrom(
                          foregroundColor: Colors.white,
                          side: BorderSide(color: Colors.white.withValues(alpha: 0.28)),
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(999)),
                          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
                        ),
                      ),
                  ],
                ),
                const SizedBox(height: 10),
                Text(
                  'সর্বশেষ ট্রানজেকশন ${_formatDateTime(customer.lastTransactionAt)}',
                  style: TextStyle(
                    color: Colors.white.withValues(alpha: 0.82),
                    fontSize: 12,
                    fontWeight: FontWeight.w500,
                  ),
                ),
                const SizedBox(height: 8),
                Text(
                  'মোট বাকি ${_formatCurrency(customer.totalDue)}',
                  style: TextStyle(
                    color: dueColor == const Color(0xFFD6453A) ? const Color(0xFFFFD9D6) : Colors.white.withValues(alpha: 0.9),
                    fontSize: 13,
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _CustomerStatsGrid extends StatelessWidget {
  const _CustomerStatsGrid({required this.customer});

  final _CustomerSummary customer;

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Expanded(
          child: _MiniStatCard(
            title: 'মোট ক্রয়',
            value: _formatCurrency(customer.totalPurchase),
            icon: Icons.shopping_bag_rounded,
            color: const Color(0xFF0C8C67),
            background: const Color(0xFFE7F5EF),
          ),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: _MiniStatCard(
            title: 'মোট পরিশোধ',
            value: _formatCurrency(customer.totalPaid),
            icon: Icons.payments_rounded,
            color: const Color(0xFF1B62D3),
            background: const Color(0xFFE8F0FF),
          ),
        ),
      ],
    );
  }
}

class _MiniStatCard extends StatelessWidget {
  const _MiniStatCard({
    required this.title,
    required this.value,
    required this.icon,
    required this.color,
    required this.background,
  });

  final String title;
  final String value;
  final IconData icon;
  final Color color;
  final Color background;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: const Color(0xFFD9E5E1)),
        boxShadow: const [
          BoxShadow(
            color: Color(0x07000000),
            blurRadius: 12,
            offset: Offset(0, 4),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: 38,
            height: 38,
            decoration: BoxDecoration(
              color: background,
              borderRadius: BorderRadius.circular(12),
            ),
            child: Icon(icon, color: color, size: 20),
          ),
          const SizedBox(height: 12),
          Text(
            title,
            style: const TextStyle(
              color: Color(0xFF6B7B79),
              fontSize: 12,
              fontWeight: FontWeight.w600,
            ),
          ),
          const SizedBox(height: 4),
          Text(
            value,
            maxLines: 2,
            overflow: TextOverflow.ellipsis,
            style: const TextStyle(
              color: Color(0xFF163732),
              fontSize: 16,
              fontWeight: FontWeight.w800,
              height: 1.15,
            ),
          ),
        ],
      ),
    );
  }
}

class _DetailSection extends StatelessWidget {
  const _DetailSection({
    required this.title,
    required this.child,
  });

  final String title;
  final Widget child;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: const Color(0xFFD9E5E1)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            title,
            style: const TextStyle(
              color: Color(0xFF163732),
              fontSize: 16,
              fontWeight: FontWeight.w800,
            ),
          ),
          const SizedBox(height: 12),
          child,
        ],
      ),
    );
  }
}

class _InfoRow extends StatelessWidget {
  const _InfoRow({
    required this.label,
    required this.value,
    this.valueColor,
  });

  final String label;
  final String value;
  final Color? valueColor;

  @override
  Widget build(BuildContext context) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Expanded(
          child: Text(
            label,
            style: const TextStyle(
              color: Color(0xFF6B7B79),
              fontSize: 13,
              fontWeight: FontWeight.w600,
            ),
          ),
        ),
        const SizedBox(width: 12),
        Flexible(
          child: Text(
            value,
            textAlign: TextAlign.end,
            style: TextStyle(
              color: valueColor ?? const Color(0xFF163732),
              fontSize: 13.5,
              fontWeight: FontWeight.w700,
              height: 1.3,
            ),
          ),
        ),
      ],
    );
  }
}

class _HistoryList extends StatelessWidget {
  const _HistoryList({
    required this.emptyLabel,
    required this.records,
    required this.itemBuilder,
  });

  final String emptyLabel;
  final List<DokanPosOrderRecord> records;
  final Widget Function(DokanPosOrderRecord record) itemBuilder;

  @override
  Widget build(BuildContext context) {
    if (records.isEmpty) {
      return Padding(
        padding: const EdgeInsets.symmetric(vertical: 8),
        child: Text(
          emptyLabel,
          style: const TextStyle(
            color: Color(0xFF6B7B79),
            fontSize: 13,
            fontWeight: FontWeight.w500,
          ),
        ),
      );
    }

    return Column(
      children: [
        for (var index = 0; index < records.length; index++) ...[
          itemBuilder(records[index]),
          if (index != records.length - 1) const SizedBox(height: 10),
        ],
      ],
    );
  }
}

class _TransactionTile extends StatelessWidget {
  const _TransactionTile({required this.record});

  final DokanPosOrderRecord record;

  @override
  Widget build(BuildContext context) {
    final statusColor = record.status == DokanPosOrderStatus.paid
        ? const Color(0xFF0C8C67)
        : record.status == DokanPosOrderStatus.partiallyPaid
            ? const Color(0xFFD87A10)
            : const Color(0xFFB3261E);
    final statusLabel = record.status == DokanPosOrderStatus.paid
        ? 'পরিশোধিত'
        : record.status == DokanPosOrderStatus.partiallyPaid
            ? 'আংশিক পরিশোধিত'
            : record.status == DokanPosOrderStatus.due
                ? 'বাকি'
                : 'বাতিল';

    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: const Color(0xFFF7FAF9),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: const Color(0xFFE2ECE8)),
      ),
      child: Row(
        children: [
          Container(
            width: 40,
            height: 40,
            decoration: BoxDecoration(
              color: statusColor.withValues(alpha: 0.12),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Icon(
              record.status == DokanPosOrderStatus.paid
                  ? Icons.check_circle_rounded
                  : record.status == DokanPosOrderStatus.partiallyPaid
                      ? Icons.timelapse_rounded
                      : record.status == DokanPosOrderStatus.due
                          ? Icons.error_outline_rounded
                          : Icons.cancel_rounded,
              color: statusColor,
              size: 20,
            ),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  record.summary,
                  style: const TextStyle(
                    color: Color(0xFF163732),
                    fontSize: 13.5,
                    fontWeight: FontWeight.w700,
                  ),
                ),
                const SizedBox(height: 3),
                Text(
                  '${_formatDate(record.createdAt)} • ${dokanPosPaymentMethodLabel(record.paymentMethod)}',
                  style: const TextStyle(
                    color: Color(0xFF6B7B79),
                    fontSize: 12,
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(width: 10),
          Column(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Text(
                _formatCurrency(record.totalAmount),
                style: const TextStyle(
                  color: Color(0xFF163732),
                  fontSize: 13.5,
                  fontWeight: FontWeight.w800,
                ),
              ),
              const SizedBox(height: 4),
              _Pill(
                label: statusLabel,
                background: statusColor.withValues(alpha: 0.12),
                textColor: statusColor,
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class _PaymentTile extends StatelessWidget {
  const _PaymentTile({required this.record});

  final DokanPosOrderRecord record;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: const Color(0xFFF7FAF9),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: const Color(0xFFE2ECE8)),
      ),
      child: Row(
        children: [
          Container(
            width: 40,
            height: 40,
            decoration: BoxDecoration(
              color: const Color(0xFFE7F5EF),
              borderRadius: BorderRadius.circular(12),
            ),
            child: const Icon(Icons.payments_rounded, color: Color(0xFF0C8C67), size: 20),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  record.customerName,
                  style: const TextStyle(
                    color: Color(0xFF163732),
                    fontSize: 13.5,
                    fontWeight: FontWeight.w700,
                  ),
                ),
                const SizedBox(height: 3),
                Text(
                  '${_formatDate(record.createdAt)} • ${dokanPosPaymentMethodLabel(record.paymentMethod)}',
                  style: const TextStyle(
                    color: Color(0xFF6B7B79),
                    fontSize: 12,
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(width: 10),
          Column(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Text(
                _formatCurrency(record.paidAmount),
                style: const TextStyle(
                  color: Color(0xFF0C8C67),
                  fontSize: 13.5,
                  fontWeight: FontWeight.w800,
                ),
              ),
              const SizedBox(height: 4),
              Text(
                record.dueAmount > 0 ? 'বাকি ${_formatCurrency(record.dueAmount)}' : 'সম্পূর্ণ',
                style: const TextStyle(
                  color: Color(0xFF7A8A88),
                  fontSize: 12,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class _ActivityTile extends StatelessWidget {
  const _ActivityTile({required this.record});

  final DokanPosOrderRecord record;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: const Color(0xFFF7FAF9),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: const Color(0xFFE2ECE8)),
      ),
      child: Row(
        children: [
          Container(
            width: 40,
            height: 40,
            decoration: BoxDecoration(
              color: const Color(0xFFEAF2FF),
              borderRadius: BorderRadius.circular(12),
            ),
            child: const Icon(Icons.receipt_long_rounded, color: Color(0xFF1B62D3), size: 20),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  record.summary,
                  style: const TextStyle(
                    color: Color(0xFF163732),
                    fontSize: 13.5,
                    fontWeight: FontWeight.w700,
                  ),
                ),
                const SizedBox(height: 3),
                Text(
                  '${record.customerName}${record.customerNumber.isEmpty ? '' : ' • ${record.customerNumber}'}',
                  style: const TextStyle(
                    color: Color(0xFF6B7B79),
                    fontSize: 12,
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(width: 10),
          Text(
            _formatShortTime(record.createdAt),
            style: const TextStyle(
              color: Color(0xFF7A8A88),
              fontSize: 12,
              fontWeight: FontWeight.w600,
            ),
          ),
        ],
      ),
    );
  }
}

class _HeaderButton extends StatelessWidget {
  const _HeaderButton({
    required this.icon,
    required this.onTap,
  });

  final IconData icon;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.white,
      borderRadius: BorderRadius.circular(14),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(14),
        child: SizedBox(
          width: 42,
          height: 42,
          child: Icon(
            icon,
            color: const Color(0xFF163732),
            size: 22,
          ),
        ),
      ),
    );
  }
}

class _Pill extends StatelessWidget {
  const _Pill({
    required this.label,
    required this.background,
    required this.textColor,
  });

  final String label;
  final Color background;
  final Color textColor;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
      decoration: BoxDecoration(
        color: background,
        borderRadius: BorderRadius.circular(999),
      ),
      child: Text(
        label,
        style: TextStyle(
          color: textColor,
          fontSize: 11.5,
          fontWeight: FontWeight.w700,
        ),
      ),
    );
  }
}

class _MetricPill extends StatelessWidget {
  const _MetricPill({
    required this.label,
    required this.value,
    this.valueColor,
  });

  final String label;
  final String value;
  final Color? valueColor;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
      decoration: BoxDecoration(
        color: const Color(0xFFF1F6F4),
        borderRadius: BorderRadius.circular(12),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisSize: MainAxisSize.min,
        children: [
          Text(
            label,
            style: const TextStyle(
              color: Color(0xFF6B7B79),
              fontSize: 11,
              fontWeight: FontWeight.w600,
            ),
          ),
          const SizedBox(height: 3),
          Text(
            value,
            style: TextStyle(
              color: valueColor ?? const Color(0xFF163732),
              fontSize: 12.5,
              fontWeight: FontWeight.w800,
            ),
          ),
        ],
      ),
    );
  }
}

class _CustomerEmptyState extends StatelessWidget {
  const _CustomerEmptyState();

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: const Color(0xFFD9E5E1)),
      ),
      child: const Column(
        children: [
          Icon(Icons.person_search_rounded, color: Color(0xFF0C8C67), size: 52),
          SizedBox(height: 12),
          Text(
            'কোনো গ্রাহক পাওয়া যায়নি',
            textAlign: TextAlign.center,
            style: TextStyle(
              color: Color(0xFF163732),
              fontSize: 16,
              fontWeight: FontWeight.w800,
            ),
          ),
          SizedBox(height: 6),
          Text(
            'গ্রাহকের তথ্য এখনো তৈরি হয়নি বা সার্চের সাথে মেলেনি।',
            textAlign: TextAlign.center,
            style: TextStyle(
              color: Color(0xFF6B7B79),
              fontSize: 13,
              height: 1.4,
            ),
          ),
        ],
      ),
    );
  }
}

const List<DokanPosPaymentMethod> _allowedSupplierPaymentMethods = <DokanPosPaymentMethod>[
  DokanPosPaymentMethod.cash,
  DokanPosPaymentMethod.bkash,
  DokanPosPaymentMethod.nagad,
  DokanPosPaymentMethod.card,
];

class _SupplierSummary {
  const _SupplierSummary({
    required this.key,
    required this.name,
    required this.phone,
    required this.address,
    required this.productType,
    required this.creditLimit,
    required this.totalPurchase,
    required this.totalPaid,
    required this.totalDue,
    required this.currentMonthPurchase,
    required this.lastTransactionAt,
    required this.ledger,
  });

  final String key;
  final String name;
  final String phone;
  final String address;
  final String productType;
  final int creditLimit;
  final int totalPurchase;
  final int totalPaid;
  final int totalDue;
  final int currentMonthPurchase;
  final DateTime lastTransactionAt;
  final List<DokanSupplierLedgerRecord> ledger;
}

List<_SupplierSummary> _buildSupplierSummaries(DokanPosState state) {
  final grouped = <String, List<DokanSupplierLedgerRecord>>{};
  for (final record in state.supplierLedger) {
    if (state.hiddenSupplierKeys.contains(record.supplierKey)) {
      continue;
    }
    grouped.putIfAbsent(record.supplierKey, () => <DokanSupplierLedgerRecord>[]).add(record);
  }

  final profilesByKey = <String, DokanSupplierProfileRecord>{
    for (final profile in state.supplierProfiles) profile.key: profile,
  };

  final allKeys = <String>{...grouped.keys, ...profilesByKey.keys}
      .where((key) => !state.hiddenSupplierKeys.contains(key))
      .toList(growable: false);

  final now = DateTime.now();
  final suppliers = allKeys.map((key) {
    final profile = profilesByKey[key];
    final ledger = List<DokanSupplierLedgerRecord>.from(grouped[key] ?? const <DokanSupplierLedgerRecord>[])
      ..sort((a, b) => b.createdAt.compareTo(a.createdAt));

    final totalPurchase = ledger
        .where((record) => record.kind == DokanSupplierLedgerKind.purchase)
        .fold<int>(0, (sum, record) => sum + record.amount);
    final totalPaid = ledger
        .where((record) => record.kind == DokanSupplierLedgerKind.payment)
        .fold<int>(0, (sum, record) => sum + record.amount);
    final totalDue = totalPurchase - totalPaid;
    final currentMonthPurchase = ledger
        .where((record) =>
            record.kind == DokanSupplierLedgerKind.purchase &&
            record.createdAt.year == now.year &&
            record.createdAt.month == now.month)
        .fold<int>(0, (sum, record) => sum + record.amount);
    final lastTransactionAt = ledger.isNotEmpty
        ? ledger.first.createdAt
        : (profile?.updatedAt ?? profile?.createdAt ?? now);

    return _SupplierSummary(
      key: key,
      name: profile?.name ?? (ledger.isNotEmpty ? ledger.first.supplierName : key),
      phone: profile?.phone ?? '',
      address: profile?.address ?? '',
      productType: profile?.productType ?? '',
      creditLimit: profile?.creditLimit ?? 0,
      totalPurchase: totalPurchase,
      totalPaid: totalPaid,
      totalDue: totalDue < 0 ? 0 : totalDue,
      currentMonthPurchase: currentMonthPurchase,
      lastTransactionAt: lastTransactionAt,
      ledger: List<DokanSupplierLedgerRecord>.unmodifiable(ledger),
    );
  }).toList(growable: false)
    ..sort((a, b) {
      final dueCompare = b.totalDue.compareTo(a.totalDue);
      if (dueCompare != 0) {
        return dueCompare;
      }
      return b.lastTransactionAt.compareTo(a.lastTransactionAt);
    });

  return suppliers;
}

String _paymentMethodLabel(DokanPosPaymentMethod method) {
  switch (method) {
    case DokanPosPaymentMethod.cash:
      return 'নগদ';
    case DokanPosPaymentMethod.bkash:
      return 'bKash';
    case DokanPosPaymentMethod.nagad:
      return 'Nagad';
    case DokanPosPaymentMethod.card:
      return 'Card';
    case DokanPosPaymentMethod.rocket:
      return 'Rocket';
    case DokanPosPaymentMethod.bank:
      return 'Bank';
  }
}

IconData _paymentMethodIcon(DokanPosPaymentMethod method) {
  switch (method) {
    case DokanPosPaymentMethod.cash:
      return Icons.payments_rounded;
    case DokanPosPaymentMethod.bkash:
      return Icons.account_balance_wallet_rounded;
    case DokanPosPaymentMethod.nagad:
      return Icons.phone_android_rounded;
    case DokanPosPaymentMethod.card:
      return Icons.credit_card_rounded;
    case DokanPosPaymentMethod.rocket:
      return Icons.flight_takeoff_rounded;
    case DokanPosPaymentMethod.bank:
      return Icons.account_balance_rounded;
  }
}

Color _paymentMethodAccent(DokanPosPaymentMethod method) {
  switch (method) {
    case DokanPosPaymentMethod.cash:
      return const Color(0xFF0C8C67);
    case DokanPosPaymentMethod.bkash:
      return const Color(0xFFE2136E);
    case DokanPosPaymentMethod.nagad:
      return const Color(0xFFFF8A00);
    case DokanPosPaymentMethod.card:
      return const Color(0xFF2564D7);
    case DokanPosPaymentMethod.rocket:
      return const Color(0xFF6A4CFF);
    case DokanPosPaymentMethod.bank:
      return const Color(0xFF607D8B);
  }
}

Widget _miniInfoChip({
  required IconData icon,
  required String text,
}) {
  return Container(
    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 9),
    decoration: BoxDecoration(
      color: const Color(0xFFF7FAF9),
      borderRadius: BorderRadius.circular(14),
      border: Border.all(color: const Color(0xFFD9E5E1)),
    ),
    child: Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Icon(icon, size: 16, color: const Color(0xFF0C8C67)),
        const SizedBox(width: 8),
        Text(
          text,
          style: const TextStyle(
            color: Color(0xFF163732),
            fontSize: 12.5,
            fontWeight: FontWeight.w600,
          ),
        ),
      ],
    ),
  );
}

Widget _actionChip({
  required String label,
  required VoidCallback onTap,
}) {
  return Material(
    color: const Color(0xFFF7FAF9),
    borderRadius: BorderRadius.circular(999),
    child: InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(999),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(999),
          border: Border.all(color: const Color(0xFFD9E5E1)),
        ),
        child: Text(
          label,
          style: const TextStyle(
            color: Color(0xFF163732),
            fontSize: 12.5,
            fontWeight: FontWeight.w700,
          ),
        ),
      ),
    ),
  );
}

class _SupplierLoadingScreen extends StatelessWidget {
  const _SupplierLoadingScreen();

  @override
  Widget build(BuildContext context) {
    return const Scaffold(
      backgroundColor: Color(0xFFF4F8F6),
      body: SafeArea(
        child: Center(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              CircularProgressIndicator(color: Color(0xFF0C8C67)),
              SizedBox(height: 14),
              Text(
                'সরবরাহকারীর তথ্য লোড হচ্ছে...',
                style: TextStyle(
                  color: Color(0xFF4E625F),
                  fontWeight: FontWeight.w600,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _SupplierErrorScreen extends StatelessWidget {
  const _SupplierErrorScreen({this.message = 'সরবরাহকারীর তথ্য পাওয়া যায়নি'});

  final String message;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF4F8F6),
      body: SafeArea(
        child: Center(
          child: Padding(
            padding: const EdgeInsets.all(24),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(
                  width: 76,
                  height: 76,
                  decoration: BoxDecoration(
                    color: const Color(0xFFFDECEC),
                    borderRadius: BorderRadius.circular(24),
                  ),
                  child: const Icon(
                    Icons.local_shipping_outlined,
                    color: Color(0xFFD6453A),
                    size: 40,
                  ),
                ),
                const SizedBox(height: 16),
                Text(
                  message,
                  textAlign: TextAlign.center,
                  style: const TextStyle(
                    color: Color(0xFF163732),
                    fontSize: 18,
                    fontWeight: FontWeight.w800,
                  ),
                ),
                const SizedBox(height: 8),
                const Text(
                  'আবার চেষ্টা করুন বা তালিকা রিফ্রেশ করুন।',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    color: Color(0xFF6B7B79),
                    height: 1.4,
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _SupplierEmptyState extends StatelessWidget {
  const _SupplierEmptyState();

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: const Color(0xFFD9E5E1)),
      ),
      child: const Column(
        children: [
          Icon(Icons.local_shipping_outlined, color: Color(0xFF0C8C67), size: 52),
          SizedBox(height: 12),
          Text(
            'কোনো সরবরাহকারী পাওয়া যায়নি',
            textAlign: TextAlign.center,
            style: TextStyle(
              color: Color(0xFF163732),
              fontSize: 16,
              fontWeight: FontWeight.w800,
            ),
          ),
          SizedBox(height: 6),
          Text(
            'নতুন সরবরাহকারী যোগ করলে তালিকা এখানে দেখা যাবে।',
            textAlign: TextAlign.center,
            style: TextStyle(
              color: Color(0xFF6B7B79),
              fontSize: 13,
              height: 1.4,
            ),
          ),
        ],
      ),
    );
  }
}

class _SupplierSectionEmptyState extends StatelessWidget {
  const _SupplierSectionEmptyState({required this.label});

  final String label;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.symmetric(vertical: 18, horizontal: 16),
      decoration: BoxDecoration(
        color: const Color(0xFFF7FAF9),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: const Color(0xFFD9E5E1)),
      ),
      child: Text(
        label,
        textAlign: TextAlign.center,
        style: const TextStyle(
          color: Color(0xFF6B7B79),
          fontWeight: FontWeight.w600,
        ),
      ),
    );
  }
}

class _SupplierListTile extends StatelessWidget {
  const _SupplierListTile({
    required this.supplier,
    required this.onTap,
    required this.onLongPress,
    required this.selected,
    required this.selectionMode,
  });

  final _SupplierSummary supplier;
  final VoidCallback onTap;
  final VoidCallback onLongPress;
  final bool selected;
  final bool selectionMode;

  @override
  Widget build(BuildContext context) {
    final dueColor = supplier.totalDue > 0 ? const Color(0xFFB3261E) : const Color(0xFF0C8C67);
    final borderColor = selected ? const Color(0xFF0C8C67) : const Color(0xFFD9E5E1);

    return Material(
      color: Colors.white,
      borderRadius: BorderRadius.circular(16),
      child: InkWell(
        onTap: onTap,
        onLongPress: onLongPress,
        borderRadius: BorderRadius.circular(16),
        child: Container(
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: borderColor, width: selected ? 1.4 : 1),
            color: selected ? const Color(0xFFF1FBF6) : Colors.white,
          ),
          child: Row(
            children: [
              Stack(
                clipBehavior: Clip.none,
                children: [
                  Container(
                    width: 52,
                    height: 52,
                    decoration: BoxDecoration(
                      color: const Color(0xFFE7F5EF),
                      borderRadius: BorderRadius.circular(16),
                    ),
                    alignment: Alignment.center,
                    child: Text(
                      _supplierInitials(supplier.name),
                      style: const TextStyle(
                        color: Color(0xFF0C8C67),
                        fontSize: 16,
                        fontWeight: FontWeight.w900,
                      ),
                    ),
                  ),
                  if (selectionMode)
                    Positioned(
                      right: -4,
                      top: -4,
                      child: Container(
                        width: 22,
                        height: 22,
                        decoration: BoxDecoration(
                          color: selected ? const Color(0xFF0C8C67) : Colors.white,
                          shape: BoxShape.circle,
                          border: Border.all(color: const Color(0xFF0C8C67), width: 1.5),
                        ),
                        child: selected
                            ? const Icon(Icons.check_rounded, size: 14, color: Colors.white)
                            : null,
                      ),
                    ),
                ],
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      supplier.name,
                      style: const TextStyle(
                        color: Color(0xFF163732),
                        fontSize: 15,
                        fontWeight: FontWeight.w800,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      _supplierMaskedPhone(supplier.phone),
                      style: const TextStyle(
                        color: Color(0xFF6B7B79),
                        fontSize: 12.5,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      'সর্বশেষ ${_formatDateTime(supplier.lastTransactionAt)}',
                      style: const TextStyle(
                        color: Color(0xFF7C8C8A),
                        fontSize: 11.5,
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 10),
              Column(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  Text(
                    supplier.totalDue > 0 ? 'বকেয়া' : 'পরিশোধ',
                    style: TextStyle(
                      color: dueColor,
                      fontSize: 11.5,
                      fontWeight: FontWeight.w800,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    _formatCurrency(supplier.totalDue),
                    style: TextStyle(
                      color: dueColor,
                      fontSize: 15,
                      fontWeight: FontWeight.w900,
                    ),
                  ),
                  const SizedBox(height: 8),
                  const Icon(Icons.chevron_right_rounded, color: Color(0xFF7C8C8A)),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _StaffSummary {
  const _StaffSummary({
    required this.key,
    required this.name,
    required this.phone,
    required this.role,
    required this.address,
    required this.note,
    required this.active,
    required this.joinedAt,
    required this.lastActiveAt,
    required this.lastLoginAt,
    required this.recentSalesCount,
    required this.permissions,
    required this.pinCode,
    required this.createdAt,
    required this.updatedAt,
  });

  final String key;
  final String name;
  final String phone;
  final String role;
  final String address;
  final String note;
  final bool active;
  final DateTime joinedAt;
  final DateTime lastActiveAt;
  final DateTime lastLoginAt;
  final int recentSalesCount;
  final List<String> permissions;
  final String? pinCode;
  final DateTime createdAt;
  final DateTime updatedAt;

  String get statusLabel => active ? 'Active' : 'Inactive';
}

class _ActivityEntry {
  const _ActivityEntry({
    required this.title,
    required this.subtitle,
    required this.icon,
  });

  final String title;
  final String subtitle;
  final IconData icon;
}

class _PermissionOption {
  const _PermissionOption(this.key, this.label);

  final String key;
  final String label;
}

class _PermissionCategory {
  const _PermissionCategory(this.label, this.options);

  final String label;
  final List<_PermissionOption> options;
}

const List<_PermissionCategory> _staffPermissionSections = <_PermissionCategory>[
  _PermissionCategory('বিক্রয় পরিচালনা', <_PermissionOption>[
    _PermissionOption('sales.create', 'বিক্রয় তৈরি'),
    _PermissionOption('sales.view', 'বিক্রয় দেখা'),
    _PermissionOption('sales.update', 'বিক্রয় সম্পাদনা'),
  ]),
  _PermissionCategory('পণ্য পরিচালনা', <_PermissionOption>[
    _PermissionOption('product.view', 'পণ্য দেখা'),
    _PermissionOption('product.add', 'পণ্য যোগ'),
    _PermissionOption('product.update', 'পণ্য সম্পাদনা'),
    _PermissionOption('stock.manage', 'স্টক পরিচালনা'),
  ]),
  _PermissionCategory('গ্রাহক পরিচালনা', <_PermissionOption>[
    _PermissionOption('customer.view', 'গ্রাহক দেখা'),
    _PermissionOption('customer.add', 'গ্রাহক যোগ'),
    _PermissionOption('customer.due', 'বাকি দেখা'),
  ]),
  _PermissionCategory('সরবরাহকারী পরিচালনা', <_PermissionOption>[
    _PermissionOption('supplier.view', 'সরবরাহকারী দেখা'),
    _PermissionOption('supplier.add', 'সরবরাহকারী যোগ'),
    _PermissionOption('supplier.payment', 'সরবরাহকারী পেমেন্ট'),
  ]),
  _PermissionCategory('রিপোর্ট দেখা', <_PermissionOption>[
    _PermissionOption('reports.view', 'রিপোর্ট দেখা'),
    _PermissionOption('reports.sales', 'বিক্রয় রিপোর্ট'),
    _PermissionOption('reports.profit', 'লাভ-ক্ষতি রিপোর্ট'),
  ]),
  _PermissionCategory('হিসাব দেখা', <_PermissionOption>[
    _PermissionOption('accounts.view', 'হিসাব দেখা'),
    _PermissionOption('accounts.expense', 'খরচ দেখা'),
    _PermissionOption('accounts.payment', 'পেমেন্ট দেখা'),
  ]),
  _PermissionCategory('কর্মচারী পরিচালনা', <_PermissionOption>[
    _PermissionOption('staff.manage', 'কর্মচারী পরিচালনা'),
    _PermissionOption('staff.permissions', 'অনুমতি পরিচালনা'),
    _PermissionOption('staff.pin', 'PIN সেটআপ'),
  ]),
];

List<String> _defaultPermissionsForRole(String role) {
  switch (role) {
    case 'Manager':
      return _staffPermissionSections
          .expand((section) => section.options)
          .map((option) => option.key)
          .where((key) => key != 'staff.pin')
          .toList(growable: false);
    case 'Cashier':
      return <String>[
        'sales.view',
        'customer.view',
        'accounts.view',
        'accounts.payment',
      ];
    case 'Salesman':
      return <String>[
        'sales.create',
        'sales.view',
        'customer.view',
      ];
    default:
      return <String>[
        'sales.view',
        'customer.view',
      ];
  }
}

String _permissionLabel(String key) {
  for (final section in _staffPermissionSections) {
    for (final option in section.options) {
      if (option.key == key) {
        return option.label;
      }
    }
  }
  return key;
}

String _staffRoleDisplay(String role) {
  switch (role.trim()) {
    case 'Salesman':
      return 'Salesman';
    case 'Manager':
      return 'Manager';
    case 'Cashier':
      return 'Cashier';
    default:
      return role.trim().isEmpty ? 'Other' : role.trim();
  }
}

String _staffInitials(String value) {
  final parts = value.trim().split(RegExp(r'\s+')).where((part) => part.isNotEmpty).toList(growable: false);
  if (parts.isEmpty) {
    return 'ক';
  }
  if (parts.length == 1) {
    return String.fromCharCode(parts.first.runes.first);
  }
  return '${String.fromCharCode(parts.first.runes.first)}${String.fromCharCode(parts.last.runes.first)}';
}

String _staffMaskedPhone(String value) {
  final digits = value.replaceAll(RegExp(r'[^0-9]'), '');
  if (digits.isEmpty) {
    return 'ফোন নেই';
  }
  if (digits.length <= 4) {
    return digits;
  }
  return '${digits.substring(0, 3)}••••${digits.substring(digits.length - 4)}';
}

_StaffSummary? _findStaff(DokanPosState state, String key) {
  final match = _buildStaffSummaries(state).where((item) => item.key == key).toList(growable: false);
  return match.isEmpty ? null : match.first;
}

List<_StaffSummary> _buildStaffSummaries(DokanPosState state) {
  final summaries = state.staffProfiles
      .where((profile) => !state.hiddenStaffKeys.contains(profile.key))
      .map(
        (profile) => _StaffSummary(
          key: profile.key,
          name: profile.name,
          phone: profile.phone,
          role: _staffRoleDisplay(profile.role),
          address: profile.address,
          note: profile.note,
          active: profile.active,
          joinedAt: profile.joinedAt,
          lastActiveAt: profile.lastActiveAt,
          lastLoginAt: profile.lastLoginAt,
          recentSalesCount: profile.recentSalesCount,
          permissions: profile.permissions,
          pinCode: profile.pinCode,
          createdAt: profile.createdAt,
          updatedAt: profile.updatedAt,
        ),
      )
      .toList(growable: false)
    ..sort((a, b) {
      if (a.active != b.active) {
        return b.active ? 1 : -1;
      }
      return b.lastActiveAt.compareTo(a.lastActiveAt);
    });
  return summaries;
}

class _StaffCard extends StatelessWidget {
  const _StaffCard({
    required this.staff,
    required this.selected,
    required this.selectionMode,
    required this.onTap,
    required this.onLongPress,
  });

  final _StaffSummary staff;
  final bool selected;
  final bool selectionMode;
  final VoidCallback onTap;
  final VoidCallback onLongPress;

  @override
  Widget build(BuildContext context) {
    final dueColor = staff.active ? const Color(0xFF0C8C67) : const Color(0xFFB3261E);
    final borderColor = selected ? const Color(0xFF0C8C67) : const Color(0xFFD9E5E1);

    return Material(
      color: Colors.white,
      borderRadius: BorderRadius.circular(16),
      child: InkWell(
        onTap: onTap,
        onLongPress: onLongPress,
        borderRadius: BorderRadius.circular(16),
        child: Container(
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: borderColor, width: selected ? 1.4 : 1),
            color: selected ? const Color(0xFFF1FBF6) : Colors.white,
          ),
          child: Row(
            children: [
              Stack(
                clipBehavior: Clip.none,
                children: [
                  Container(
                    width: 52,
                    height: 52,
                    decoration: BoxDecoration(
                      color: const Color(0xFFE7F5EF),
                      borderRadius: BorderRadius.circular(16),
                    ),
                    alignment: Alignment.center,
                    child: Text(
                      _staffInitials(staff.name),
                      style: const TextStyle(color: Color(0xFF0C8C67), fontSize: 16, fontWeight: FontWeight.w900),
                    ),
                  ),
                  if (selectionMode)
                    Positioned(
                      right: -4,
                      top: -4,
                      child: Container(
                        width: 22,
                        height: 22,
                        decoration: BoxDecoration(
                          color: selected ? const Color(0xFF0C8C67) : Colors.white,
                          shape: BoxShape.circle,
                          border: Border.all(color: const Color(0xFF0C8C67), width: 1.5),
                        ),
                        child: selected
                            ? const Icon(Icons.check_rounded, size: 14, color: Colors.white)
                            : null,
                      ),
                    ),
                ],
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Expanded(
                          child: Text(
                            staff.name,
                            style: const TextStyle(color: Color(0xFF163732), fontSize: 16, fontWeight: FontWeight.w800),
                          ),
                        ),
                        _Pill(
                          label: staff.active ? 'Active' : 'Inactive',
                          background: staff.active ? const Color(0xFFE7F5EF) : const Color(0xFFFDECEC),
                          textColor: dueColor,
                        ),
                      ],
                    ),
                    const SizedBox(height: 4),
                    Text(
                      _staffMaskedPhone(staff.phone),
                      style: const TextStyle(color: Color(0xFF6B7B79), fontSize: 12.5, fontWeight: FontWeight.w600),
                    ),
                    const SizedBox(height: 6),
                    Wrap(
                      spacing: 8,
                      runSpacing: 8,
                      children: [
                        _MetricPill(label: 'ভূমিকা', value: staff.role),
                        _MetricPill(label: 'সর্বশেষ সক্রিয়', value: _formatShortTime(staff.lastActiveAt)),
                      ],
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 8),
              const Icon(Icons.chevron_right_rounded, color: Color(0xFF7C8C8A)),
            ],
          ),
        ),
      ),
    );
  }
}

class DokanStaffPermissionsScreen extends ConsumerStatefulWidget {
  const DokanStaffPermissionsScreen({super.key, required this.staffKey});

  final String staffKey;

  @override
  ConsumerState<DokanStaffPermissionsScreen> createState() => _DokanStaffPermissionsScreenState();
}

class _DokanStaffPermissionsScreenState extends ConsumerState<DokanStaffPermissionsScreen> {
  late final Set<String> _selected;
  bool _saving = false;

  @override
  void initState() {
    super.initState();
    final staff = _findStaff(ref.read(dokanPosProvider), widget.staffKey);
    _selected = staff == null ? <String>{} : staff.permissions.toSet();
  }

  Future<void> _save() async {
    final staff = _findStaff(ref.read(dokanPosProvider), widget.staffKey);
    if (staff == null) return;
    final confirmed = await showDialog<bool>(
          context: context,
          builder: (dialogContext) => AlertDialog(
            title: const Text('আপনি কি নিশ্চিত?'),
            content: Text('${staff.name} এর অনুমতি সংরক্ষণ করবেন?'),
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
            actions: [
              TextButton(onPressed: () => Navigator.of(dialogContext).pop(false), child: const Text('বাতিল')),
              FilledButton(
                onPressed: () => Navigator.of(dialogContext).pop(true),
                style: FilledButton.styleFrom(backgroundColor: const Color(0xFF0C8C67), foregroundColor: Colors.white),
                child: const Text('সংরক্ষণ'),
              ),
            ],
          ),
        ) ??
        false;
    if (!confirmed) return;

    setState(() => _saving = true);
    ref.read(dokanPosProvider.notifier).updateStaffPermissions(widget.staffKey, _selected.toList(growable: false));
    if (!mounted) return;
    Navigator.of(context).pop(true);
  }

  @override
  Widget build(BuildContext context) {
    final staff = _findStaff(ref.watch(dokanPosProvider), widget.staffKey);
    if (staff == null) {
      return const _SupplierErrorScreen(message: 'কর্মচারীর তথ্য পাওয়া যায়নি');
    }

    return Scaffold(
      backgroundColor: const Color(0xFFF4F8F6),
      body: SafeArea(
        child: ListView(
          physics: const AlwaysScrollableScrollPhysics(parent: ClampingScrollPhysics()),
          padding: const EdgeInsets.fromLTRB(16, 12, 16, 24),
          children: [
            Row(
              children: [
                _HeaderButton(icon: Icons.arrow_back_rounded, onTap: () => Navigator.of(context).maybePop()),
                const SizedBox(width: 12),
                const Expanded(
                  child: Text(
                    'অনুমতি',
                    textAlign: TextAlign.center,
                    style: TextStyle(color: Color(0xFF163732), fontSize: 18, fontWeight: FontWeight.w800),
                  ),
                ),
                const SizedBox(width: 40),
              ],
            ),
            const SizedBox(height: 14),
            _DetailSection(
              title: staff.name,
              child: Text(
                '${staff.role} • ${staff.active ? 'Active' : 'Inactive'}',
                style: const TextStyle(color: Color(0xFF6B7B79), fontWeight: FontWeight.w600),
              ),
            ),
            const SizedBox(height: 14),
            ..._staffPermissionSections.map(
              (section) => Padding(
                padding: const EdgeInsets.only(bottom: 12),
                child: _DetailSection(
                  title: section.label,
                  child: Column(
                    children: section.options.map((option) {
                      return SwitchListTile(
                        value: _selected.contains(option.key),
                        onChanged: (value) {
                          setState(() {
                            if (value) {
                              _selected.add(option.key);
                            } else {
                              _selected.remove(option.key);
                            }
                          });
                        },
                        title: Text(option.label, style: const TextStyle(color: Color(0xFF163732), fontWeight: FontWeight.w600)),
                        contentPadding: EdgeInsets.zero,
                        activeThumbColor: const Color(0xFF0C8C67),
                      );
                    }).toList(growable: false),
                  ),
                ),
              ),
            ),
            SizedBox(
              height: 52,
              child: FilledButton(
                onPressed: _saving ? null : _save,
                style: FilledButton.styleFrom(
                  backgroundColor: const Color(0xFF0C8C67),
                  foregroundColor: Colors.white,
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                ),
                child: _saving
                    ? const SizedBox(
                        width: 20,
                        height: 20,
                        child: CircularProgressIndicator(strokeWidth: 2.4, color: Colors.white),
                      )
                    : const Text('সংরক্ষণ'),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class DokanStaffPinSetupScreen extends ConsumerStatefulWidget {
  const DokanStaffPinSetupScreen({super.key, required this.staffKey});

  final String staffKey;

  @override
  ConsumerState<DokanStaffPinSetupScreen> createState() => _DokanStaffPinSetupScreenState();
}

class _DokanStaffPinSetupScreenState extends ConsumerState<DokanStaffPinSetupScreen> {
  final TextEditingController _pinController = TextEditingController();
  final TextEditingController _confirmPinController = TextEditingController();
  bool _isSubmitting = false;
  String? _pinError;
  String? _confirmError;

  @override
  void dispose() {
    _pinController.dispose();
    _confirmPinController.dispose();
    super.dispose();
  }

  bool _isValidPin(String value) => RegExp(r'^[0-9]{4}$').hasMatch(value.trim());

  void _validate() {
    setState(() {
      _pinError = _pinController.text.trim().isEmpty
          ? 'PIN দিন'
          : _isValidPin(_pinController.text)
              ? null
              : 'PIN দিন';
      _confirmError = _confirmPinController.text.trim().isEmpty || _confirmPinController.text.trim() == _pinController.text.trim()
          ? null
          : 'PIN মিলছে না';
    });
  }

  bool get _canSubmit => !_isSubmitting && _isValidPin(_pinController.text) && _pinController.text.trim() == _confirmPinController.text.trim();

  Future<void> _save() async {
    _validate();
    if (!_canSubmit) return;
    setState(() => _isSubmitting = true);
    ref.read(dokanPosProvider.notifier).setStaffPin(
          staffKey: widget.staffKey,
          pinCode: _pinController.text.trim(),
        );
    if (!mounted) return;
    Navigator.of(context).pop(true);
  }

  @override
  Widget build(BuildContext context) {
    final staff = _findStaff(ref.watch(dokanPosProvider), widget.staffKey);
    if (staff == null) {
      return const _SupplierErrorScreen(message: 'কর্মচারীর তথ্য পাওয়া যায়নি');
    }

    return Scaffold(
      backgroundColor: const Color(0xFFF4F8F6),
      body: SafeArea(
        child: ListView(
          physics: const AlwaysScrollableScrollPhysics(parent: ClampingScrollPhysics()),
          padding: const EdgeInsets.fromLTRB(16, 12, 16, 24),
          children: [
            Row(
              children: [
                _HeaderButton(icon: Icons.arrow_back_rounded, onTap: () => Navigator.of(context).maybePop()),
                const SizedBox(width: 12),
                const Expanded(
                  child: Text(
                    'PIN সেটআপ',
                    textAlign: TextAlign.center,
                    style: TextStyle(color: Color(0xFF163732), fontSize: 18, fontWeight: FontWeight.w800),
                  ),
                ),
                const SizedBox(width: 40),
              ],
            ),
            const SizedBox(height: 14),
            _DetailSection(
              title: staff.name,
              child: Text(
                'নিরাপদ PIN তৈরি করুন',
                style: const TextStyle(color: Color(0xFF6B7B79), fontWeight: FontWeight.w600),
              ),
            ),
            const SizedBox(height: 14),
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: const Color(0xFFD9E5E1)),
              ),
              child: Column(
                children: [
                  TextField(
                    controller: _pinController,
                    keyboardType: TextInputType.number,
                    obscureText: true,
                    inputFormatters: [FilteringTextInputFormatter.digitsOnly, LengthLimitingTextInputFormatter(4)],
                    onChanged: (_) => _validate(),
                    style: const TextStyle(color: Color(0xFF111111)),
                    decoration: InputDecoration(
                      labelText: '4-digit PIN *',
                      errorText: _pinError,
                      filled: true,
                      fillColor: const Color(0xFFF8FAF9),
                      border: OutlineInputBorder(borderRadius: BorderRadius.circular(16)),
                    ),
                  ),
                  const SizedBox(height: 12),
                  TextField(
                    controller: _confirmPinController,
                    keyboardType: TextInputType.number,
                    obscureText: true,
                    inputFormatters: [FilteringTextInputFormatter.digitsOnly, LengthLimitingTextInputFormatter(4)],
                    onChanged: (_) => _validate(),
                    style: const TextStyle(color: Color(0xFF111111)),
                    decoration: InputDecoration(
                      labelText: 'Confirm PIN *',
                      errorText: _confirmError,
                      filled: true,
                      fillColor: const Color(0xFFF8FAF9),
                      border: OutlineInputBorder(borderRadius: BorderRadius.circular(16)),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 16),
            SizedBox(
              height: 52,
              child: FilledButton(
                onPressed: _canSubmit ? _save : null,
                style: FilledButton.styleFrom(
                  backgroundColor: const Color(0xFF0C8C67),
                  foregroundColor: Colors.white,
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                ),
                child: _isSubmitting
                    ? const SizedBox(
                        width: 20,
                        height: 20,
                        child: CircularProgressIndicator(strokeWidth: 2.4, color: Colors.white),
                      )
                    : const Text('সংরক্ষণ'),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _SupplierLedgerTile extends StatelessWidget {
  const _SupplierLedgerTile({required this.record});

  final DokanSupplierLedgerRecord record;

  @override
  Widget build(BuildContext context) {
    final isPurchase = record.kind == DokanSupplierLedgerKind.purchase;
    final accent = isPurchase ? const Color(0xFF0C8C67) : const Color(0xFF2564D7);
    final background = isPurchase ? const Color(0xFFE7F5EF) : const Color(0xFFEAF2FF);
    final title = isPurchase ? 'ক্রয়' : 'পেমেন্ট';
    final amountPrefix = isPurchase ? '+' : '-';

    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: const Color(0xFFFDFEFE),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: const Color(0xFFD9E5E1)),
      ),
      child: Row(
        children: [
          Container(
            width: 42,
            height: 42,
            decoration: BoxDecoration(
              color: background,
              borderRadius: BorderRadius.circular(14),
            ),
            child: Icon(
              isPurchase ? Icons.shopping_bag_rounded : Icons.payments_rounded,
              color: accent,
              size: 20,
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: const TextStyle(
                    color: Color(0xFF163732),
                    fontSize: 14,
                    fontWeight: FontWeight.w800,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  record.note,
                  style: const TextStyle(
                    color: Color(0xFF6B7B79),
                    fontSize: 12.5,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  _formatDateTime(record.createdAt),
                  style: const TextStyle(
                    color: Color(0xFF7C8C8A),
                    fontSize: 11.5,
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(width: 10),
          Column(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Text(
                '$amountPrefix${_formatCurrency(record.amount)}',
                style: TextStyle(
                  color: accent,
                  fontSize: 14,
                  fontWeight: FontWeight.w900,
                ),
              ),
              const SizedBox(height: 4),
              Text(
                _paymentMethodLabel(record.paymentMethod ?? DokanPosPaymentMethod.cash),
                style: const TextStyle(
                  color: Color(0xFF7C8C8A),
                  fontSize: 11.5,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class _SupplierLedgerHistoryList extends StatelessWidget {
  const _SupplierLedgerHistoryList({
    required this.emptyLabel,
    required this.records,
  });

  final String emptyLabel;
  final List<DokanSupplierLedgerRecord> records;

  @override
  Widget build(BuildContext context) {
    if (records.isEmpty) {
      return _SupplierSectionEmptyState(label: emptyLabel);
    }

    return Column(
      children: [
        for (final record in records) ...[
          _SupplierLedgerTile(record: record),
          if (record != records.last) const SizedBox(height: 10),
        ],
      ],
    );
  }
}

class _SupplierPaymentMethodCard extends StatelessWidget {
  const _SupplierPaymentMethodCard({
    required this.method,
    required this.selected,
    required this.onTap,
  });

  final DokanPosPaymentMethod method;
  final bool selected;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final accent = _paymentMethodAccent(method);
    return Material(
      color: Colors.white,
      borderRadius: BorderRadius.circular(16),
      elevation: selected ? 2 : 0,
      shadowColor: selected ? accent.withValues(alpha: 0.15) : Colors.transparent,
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(16),
        child: Container(
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: selected ? accent : const Color(0xFFD9E5E1), width: selected ? 1.4 : 1),
          ),
          child: Row(
            children: [
              Container(
                width: 42,
                height: 42,
                decoration: BoxDecoration(
                  color: selected ? accent.withValues(alpha: 0.12) : const Color(0xFFF7FAF9),
                  borderRadius: BorderRadius.circular(14),
                ),
                child: Icon(_paymentMethodIcon(method), color: accent, size: 20),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Text(
                  _paymentMethodLabel(method),
                  style: const TextStyle(
                    color: Color(0xFF163732),
                    fontSize: 14,
                    fontWeight: FontWeight.w800,
                  ),
                ),
              ),
              AnimatedContainer(
                duration: const Duration(milliseconds: 150),
                width: 22,
                height: 22,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: selected ? accent : Colors.transparent,
                  border: Border.all(color: selected ? accent : const Color(0xFFC9D7D3)),
                ),
                child: selected
                    ? const Icon(Icons.check_rounded, size: 14, color: Colors.white)
                    : null,
              ),
            ],
          ),
        ),
      ),
    );
  }
}


